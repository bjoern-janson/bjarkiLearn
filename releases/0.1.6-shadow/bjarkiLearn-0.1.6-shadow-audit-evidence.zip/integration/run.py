from pathlib import Path
import hashlib,importlib,json,sys
ROOT=Path(__file__).resolve().parent;AUDIT=ROOT.parent
sys.path.insert(0,'C:/Users/Mewn/Documents/Codex/2026-10-16/let/work/deps')
SOURCE=AUDIT/'source/bjarkiLearn'
def hashes():return {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in SOURCE.glob('*.lua')}
def plain(v):return {k:plain(x) for k,x in v.items()} if hasattr(v,'items') else v
def table(lua,v):return lua.table_from({k:table(lua,x) for k,x in v.items()}) if isinstance(v,dict) else v
before=hashes();rows=[];comparisons=[];signatures={}
for engine in ('lua51','lua54'):
 Lua=importlib.import_module('lupa.'+engine).LuaRuntime
 expected=None
 for variant in (122,339,1062,5195,5196,9852,9853,0):
  lua=Lua(unpack_returned_tuples=True);lua.globals().LEARN_ROOT=SOURCE.as_posix();lua.globals().BUS_PATH=(AUDIT/'verification/prior/fixtures/SharedEvidence.lua').as_posix();lua.globals().ROOT_VARIANT=variant
  lua.execute((ROOT/'harness.lua').read_text(encoding='utf-8-sig'))
  try:
   data=plain(lua.execute((ROOT/'trace.lua').read_text(encoding='utf-8-sig')))
   if expected is None:expected=data
   comparisons.append({'engine':engine,'variant':variant,'exact_root_family_trajectory':data==expected})
   fresh=Lua(unpack_returned_tuples=True);fresh.globals().LEARN_ROOT=SOURCE.as_posix();fresh.execute((ROOT/'harness.lua').read_text(encoding='utf-8-sig'));fresh.globals().bjarkiLearnDB=table(fresh,data['save'])
   fresh.execute('World.combat=false;World.unitCombat=false;Init();for i=1,2000 do Advance(World.now+.125);if not Runtime.core.dirty then break end end; assert(Runtime.core.model and not Runtime.core.dirty)')
   same=plain(fresh.globals().Runtime.core.model)==data['model']
   rows.append({'engine':engine,'variant':variant,'passed':data==expected and same,'fresh_reload_exact_model':same,'checks':data['checks'],'root_counts':data['counts']})
   signatures[(engine,variant)]=data
  except Exception as e:rows.append({'engine':engine,'variant':variant,'passed':False,'error':str(e)})
for variant in (122,339,1062,5195,5196,9852,9853,0):comparisons.append({'variant':variant,'cross_lua_exact':signatures.get(('lua51',variant))==signatures.get(('lua54',variant)) and ('lua51',variant) in signatures})
report={'passed':all(r['passed'] for r in rows) and all(r.get('exact_root_family_trajectory',r.get('cross_lua_exact')) for r in comparisons),'source_hashes':before,'source_unchanged':before==hashes(),'cases':rows,'comparisons':comparisons,'scope':'Actual Main/Adapter/Core/Network and archived SharedEvidence with modeled WoW host; same-family native metamorphic traces, session resets and fresh runtime reload. No live-client proof.'}
(ROOT/'results.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'passed':report['passed'],'source_unchanged':report['source_unchanged'],'cases':len(rows),'passed_cases':sum(r['passed'] for r in rows),'comparisons':len(comparisons),'errors':[r for r in rows if not r['passed']]},indent=2))
sys.exit(0 if report['passed'] and report['source_unchanged'] else 1)
