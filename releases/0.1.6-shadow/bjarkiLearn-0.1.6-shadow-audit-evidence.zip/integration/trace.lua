-- Metamorphic native trace: changing the registered root rank must not change
-- the core trajectory. SharedEvidence is the preserved actual bridge fixture.
assert(loadfile(BUS_PATH))('bjarkiPortraits',{})
World.ids.target=World.ids.player;World.classes.target='DRUID'
Init();Advance(10)
local snapshots={}
local function capture()
 local c=Runtime.core
 Check(not Runtime.faulted and Runtime.errors==0,'native runtime fault')
 Check(BjarkiEvidenceV1.stats.errors==0,'bridge listener error')
 Check(#c.actorOrder<=16 and #c.occurrenceOrder<=128 and #c.examples<=256 and #c.modelDependencies<=256,'bounds')
 local out={status=c:Status(),export=c:Export(),context=BjarkiLearn:GetContext('player'),forecast=BjarkiLearn:Forecast('player'),model=NS.Copy(c.model)}
 snapshots[#snapshots+1]=out
 -- Public objects are copies even with age-varying inputs and trained scores.
 if out.context then out.context.history[3]=-999 end
 local fresh=BjarkiLearn:GetContext('player')
 Check(not fresh or fresh.history[3]~=-999,'public context mutation escaped')
 if out.context then out.context.history=fresh.history end
end
for i=0,23 do
 local t=10+i*3
 World.combat=true;World.unitCombat=true;Advance(t)
 for j=1,8 do
  Advance(t+j*.25)
  if j==3 and i%4==0 then
   local spell=ROOT_VARIANT==0 and ({339,1062,5195,5196,9852,9853})[(i/4)%6+1] or ROOT_VARIANT
   Event('UNIT_SPELLCAST_SUCCEEDED','player','rank-independent-'..i,spell)
   Event('UNIT_SPELLCAST_SUCCEEDED','target','rank-independent-'..i,spell)
  end
  if j==5 and i%3==0 then
   Check(BjarkiEvidenceV1:Publish({source='bjarkiPortraits',kind='aura-positive',isHelpful=true,
    recipientGUID=World.ids.player,unit='target',spellId=22812,auraInstanceID=200+i,
    observedAt=World.now-.5,expirationTime=World.now+3,duration=4,newApplication=false}),'bridge publication')
  end
  if j==6 and i==11 then Event('PLAYER_ENTERING_WORLD') end
 end
 World.combat=false;World.unitCombat=false;Advance(t+2.25)
 if i==15 then Runtime:Command('disable');Runtime:Command('enable') end
 if i%4==3 then capture() end
end
for _=1,2000 do Advance(World.now+.125);if not Runtime.core.dirty then break end end
Check(Runtime.core.model and not Runtime.core.dirty,'model completed')
Advance(World.now+.25);capture()
local status=Runtime.core:Status()
Check(status.families[3].positive>=2 and status.families[3].negative>=8,'root support')
Check(BjarkiLearn:Forecast('player').outputs[3].score~=nil,'supported root shadow score')
Equal(Runtime.core.stats.duplicateCasts,6,'same cast via alias deduplicated')
Event('PLAYER_LOGOUT')
return {snapshots=snapshots,save=bjarkiLearnDB,model=NS.Copy(Runtime.core.model),checks=CHECKS,counts=status.families[3]}
