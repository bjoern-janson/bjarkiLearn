"""Negative controls for classifier; mutate only in-memory report copies."""
import contextlib,copy,io,runpy,sys
from pathlib import Path
import run
original_read,original_save=run.read,run.save
results=[]
def retired_error(data):
 job=next(j for j in data['jobs'] if j['suite']=='audit012_core');report=next(iter(job['reports'].values()))
 next(r for r in report if r['passed'] is False)['error']='injected different defect with same case name'
def reload_failure(data):
 job=next(j for j in data['jobs'] if j['suite']=='audit015_integration');report=next(iter(job['reports'].values()))
 next(r for r in report['comparisons'] if r['kind']=='native_saved_reload')['passed']=False
def runtime_change(data):data['source_before']['Rules.lua']='0'*64
for name,mutate in [('same_case_different_error_rejected',retired_error),('new_within_release_reload_failure_rejected',reload_failure),('changed_runtime_hash_rejected',runtime_change)]:
 captured=[]
 def read(path):
  data=original_read(path)
  if path==run.REPORTS/'raw.json':mutate(data)
  return data
 run.read=read;run.save=lambda path,data:captured.append(data)
 output=io.StringIO();exit_code=None
 try:
  with contextlib.redirect_stdout(output):runpy.run_path(str(Path(__file__).with_name('classification.py')),run_name='__main__')
 except SystemExit as exc:exit_code=exc.code
 results.append({'name':name,'passed':exit_code==1 and len(captured)==1 and captured[0]['passed'] is False and bool(captured[0]['unexpected_failures']),'exit_code':exit_code,'reasons':captured[0]['unexpected_failures'] if captured else []})
run.read,run.save=original_read,original_save
report={'passed':all(r['passed'] for r in results),'cases':results,'scope':'In-memory negative controls; on-disk reports and source never modified.'}
original_save(run.REPORTS/'classification-negative-controls.json',report)
print(report)
sys.exit(0 if report['passed'] else 1)
