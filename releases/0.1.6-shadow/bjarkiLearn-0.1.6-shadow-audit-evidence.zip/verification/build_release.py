"""Package only verified 0.1.6 sources; validate every archived byte and CRC."""
from pathlib import Path
import argparse, hashlib, json, zipfile
ROOT=Path(__file__).resolve().parent
SOURCE=ROOT/'source/bjarkiLearn'
def sha(data): return hashlib.sha256(data).hexdigest()
def hashes(root): return {p.relative_to(root).as_posix():sha(p.read_bytes()) for p in sorted(root.rglob('*')) if p.is_file()}
def read(path): return json.loads(path.read_text(encoding='utf-8-sig'))
def save(path,value): path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
def archive(path,items):
    with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,data in sorted(items.items()):
            entry=zipfile.ZipInfo(name,date_time=(2026,10,23,0,0,0))
            entry.compress_type=zipfile.ZIP_DEFLATED;entry.external_attr=0o100644<<16
            z.writestr(entry,data,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
    with zipfile.ZipFile(path) as z:
        assert z.testzip() is None
        assert sorted(z.namelist())==sorted(items)
        assert all(z.read(name)==data for name,data in items.items())
    return {'name':path.name,'sha256':sha(path.read_bytes()),'bytes':path.stat().st_size,'files':len(items),'crc_and_every_archived_byte_verified':True}
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,default=ROOT/'dist');a=p.parse_args()
    output=a.output.resolve();output.mkdir(parents=True,exist_ok=True)
    verify=read(ROOT/'reports-016/verification.json');actual=hashes(SOURCE)
    assert verify['passed'] and verify['source_hashes']==actual, 'Run verification against this exact source first'
    review=read(ROOT/'review-016/final-source.json')
    assert review['source_hashes']==actual and review['tested_runtime_unchanged'], 'Final source review is stale'
    assert (ROOT/'review-016/final-review.txt').exists(), 'Missing independent final review'
    assert len(actual)==14
    addon={('bjarkiLearn/'+key):(SOURCE/key).read_bytes() for key in actual}
    addon_result=archive(output/'bjarkiLearn-0.1.6-shadow.zip',addon)
    package={'version':'0.1.6-shadow','install':addon_result,'source_hashes':actual,
             'verification':'reports-016/verification.json','independent_review':'review-016/final-review.txt',
             'scope':'Offline Lua verification, not live WoW or predictive-usefulness validation.'}
    save(ROOT/'package-v0.1.6.json',package)
    folders=('source','baseline','prior','audit015','tests-016','inherited','review-016','smoke','reports-016','docs')
    files={}
    for folder in folders:
        for path in sorted((ROOT/folder).rglob('*')):
            if not path.is_file():continue
            rel=path.relative_to(ROOT)
            if '__pycache__' in rel.parts or path.suffix=='.pyc':continue
            if rel.parts[:2]==('inherited','runs'):continue
            files[rel.as_posix()]=path.read_bytes()
    for name in ('input-manifest.json','design.txt','plan.txt','progress.txt','run_all.py','build_release.py','requirements-test.txt','README-VERIFICATION.txt','package-v0.1.6.json'):
        files[name]=(ROOT/name).read_bytes()
    # Hashes cover all payload files except this manifest itself.
    files['bundle-files.json']=(json.dumps({name:sha(data) for name,data in sorted(files.items())},indent=2)+'\n').encode()
    evidence_result=archive(output/'bjarkiLearn-0.1.6-shadow-verification.zip',files)
    result={'version':'0.1.6-shadow','install':addon_result,'verification':evidence_result,'source_files':len(actual)}
    save(output/'bjarkiLearn-0.1.6-package.json',result)
    print(json.dumps(result,indent=2))
if __name__=='__main__':main()
