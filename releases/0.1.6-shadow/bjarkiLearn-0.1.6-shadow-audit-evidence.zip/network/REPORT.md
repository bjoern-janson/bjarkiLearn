# Independent persistence and model audit

No confirmed defects in the assigned scope.

Executed six new bounded scenarios against each of the immutable 0.1.6 source and exact 0.1.5 baseline, in both Lua 5.1 and Lua 5.4: **24/24 passed** (1,655,940 primitive checks; this is an assertion count, not independent scenarios). The baseline uses its own intentional semantic expectations for old witness encoding and Druid association. This does not assert equality for models trained on intentionally changed inputs.

## Reproduce

From `C:/Users/Mewn/Documents/Codex/2026-10-22/de`:

```powershell
& 'C:/Users/Mewn/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe' 'work/learn-shadow-0.1.6-audit/network/run.py'
```

`run.py` locates the already supplied Lupa package at `C:/Users/Mewn/Documents/Codex/2026-10-16/let/work/deps`. It reads unmodified Bootstrap, Rules, Network and Core modules into real Lua VMs and writes results only in this `network` folder. Exit status was 0. Exact cases and per-case checks are in `results.json`; `before-hashes.json` and `after-hashes.json` cover every file under each source tree and compare equal.

## Evidence

1. **Recency, known bit, association and vocabulary.** Tested 5,135 age/expiry combinations per version/engine, including future evidence, age zero, age eight with `(0,1)`, just beyond eight, exact expiry and an expiry just after the observation. Every emitted input remained in [0,1]. Verified class-association and conditional bits against the public candidate table for all nine classes and an unknown class. All six new root ranks map to root only in 0.1.6; twelve Nature's Grasp activation/proc IDs stay excluded. Relevant source: Rules.lua:17, Rules.lua:35, Rules.lua:52-81.
2. **Projection purity and anchored inputs.** Inserted future evidence before older evidence, then queried times out of order. Future records did not hide eligible earlier records; an expired latest witness did not resurrect the old witness. Queries did not mutate core state. Renewing the witness, resolving the window, exporting and restoring preserved the original anchored 48-vector. Relevant source: Core.lua:149-167, Core.lua:348-365, Core.lua:397-408, Core.lua:603-657.
3. **Persistence atomicity at the maximum corpus size.** Rejected ten malformed 256-row saves, including invalid last-row recency, NaN known input, an overlong input, malformed mask/label/regime, an interior hole, out-of-range and fractional keys, and an outer metatable. Before each attempt, a serving model, replay candidate and pending window all existed. Rejection preserved every core field and the identities of all four live objects. A wrong semantic key with an invalid payload was rejected before examining the malformed examples; only the intended incompatible counter changed. The original candidate still published afterward. Relevant source: Core.lua:611-657.
4. **Support, masks and deterministic replay.** Exactly two positives and eight negatives expose all three scores; one positive or seven negatives withhold them. Masked positives and other-regime rows did not contribute to support. Four epochs produced 40 updates for 10 player rows and counted frequency only once. Incremental publication exactly matched an independent direct ordered replay; same-version export/restore also reproduced the entire model. Relevant source: Core.lua:368-377, Core.lua:423-473, Core.lua:542-580; Network.lua:221-318.
5. **All 256 serving descriptors with real windows.** Used 264 ordinary Context/Tick windows, without fabricated internal `_Resolve` rows or method patches. A completed model retained all 256 descriptors while eight of its real training rows left the replay buffer. A new late root cast for the first evicted negative row immediately withdrew the model, all descriptors and the cached forecast. The replacement model exactly matched clean replay of the retained corpus. Relevant source: Core.lua:210-220, Core.lua:244-247, Core.lua:410-420, Core.lua:451-465.
6. **Finite atomic network updates.** One observed head left omitted output/linear head parameters unchanged. Disabled statistics preserved counts. A deliberate data-only overflow in the last hidden weight caused `nonfinite_update` and preserved the full model and its parameter/statistics table identities after earlier candidate work. No production methods were replaced. Relevant source: Network.lua:221-318.

## Static scope checks

- Network.lua is byte-identical to exact 0.1.5: SHA-256 `49668680ce13803c329a816f76863b04bb752cb07e5d2759cf7076af05165c49`.
- Core.lua differs from 0.1.5 only at line 383, where forecast target is read from Config instead of the old literal.
- Bootstrap.lua:9 changes the compatibility key for the feature/rules/target meanings. Rejection of old learning is intentional. Main.lua:77-85 reads the enabled preference independently before restore and then applies it even when learning is rejected; this is source review here, with native startup paths covered by the parent packaged suite.

## Limits

These are offline executions in Lua through Lupa, using normalized synthetic inputs. They are not live WoW behavior, protected/secret-value runtime proof, calibration evidence, or evidence of predictive usefulness. The direct network overflow case intentionally modifies model instance numbers to reach a numerical failure path and is not presented as a native-game reachable failure. Nothing outside this audit's assigned folder was written; both input trees remain unchanged. No defect severity or repair recommendation is warranted by these results.
