local ns,version=...
local out,checks={},0
local current=version=='current016'
local C,R,M=ns.Config,ns.Rules,ns.Models
local function ck(v,label) checks=checks+1;assert(v,label or 'assertion') end
local function eq(a,b,label) ck(a==b,(label or 'value')..': '..tostring(a)..' ~= '..tostring(b)) end
local function near(a,b,label) ck(type(a)=='number' and math.abs(a-b)<1e-13,(label or 'number')..': '..tostring(a)..' ~= '..tostring(b)) end
local function deep(a,b,label)
 eq(type(a),type(b),label)
 if type(a)~='table' then eq(a,b,label);return end
 for k,v in next,a do deep(v,b[k],(label or '')..'.'..tostring(k)) end
 for k in next,b do ck(a[k]~=nil,(label or '')..' extra key '..tostring(k)) end
end
local function test(name,fn)
 local start=checks;local ok,detail=pcall(fn)
 out[#out+1]={name=name,passed=ok,checks=checks-start,detail=ok and detail or nil,error=not ok and tostring(detail) or nil}
end
local function core() local c=ns.Core.New();c:SetCoverage(true);return c end
local function ctx(c,t,id,role)
 return assert(c:Context({actor=id or 'P',at=t,role=role or 'self',class='DRUID',combat=true,bound=true,health=.7,power=.4,form='bear'}))
end
local function train(c)
 for tick=1,1100 do if not c.dirty then break end;c:Tick(c.now,false) end
 ck(not c.dirty and c.candidate==nil,'bounded replay finishes');if c.model then ck(c.model:Valid(),'published model valid') end;return c.model
end
local function makeSave(n)
 local saved={schema=C.schema,compat=C.compat,examples={}}
 for row=1,n do
  local w={x=R.Features({class='DRUID',role='self',combat=true,health=(row%7)/6,power=.5},10,{defensiveWitness={at=10-(row%65)/8}}),y={},mask={},regime='player',predictions={neural={},linear={},frequency={}}}
  for f=1,6 do w.y[f]=((row+f)%5==0) and 1 or 0;w.mask[f]=(row+f)%11~=0 end;saved.examples[row]=w
 end
 return saved
end
local function modelFor(save)
 local m=assert(M.New(C.featureCount,C.hiddenCount,C.outputCount,C.seed))
 for epoch=1,C.epochs do for _,w in ipairs(save.examples) do if w.regime=='player' then ck(m:Learn(w.x,w.y,w.mask,epoch==1),'direct clean replay') end end end
 return m
end
local function liveRow(c,index,positive)
 local t=10+(index-1)*3;ctx(c,t);c:Tick(t,true);local w=assert(c.actors.P.window)
 if positive then ctx(c,t+1);ck(c:Cast({id='event-'..index,actor='P',at=t+1,family=3}),'cast inserted') end
 c:Tick(t+2.25,true);ck(w.y~=nil,'real window resolved');return w
end

test('dense_witness_boundary_grid_and_class_feature_mapping',function()
 local actor={class='DRUID',role='self',combat=true,form='bear',health=0,power=1};local at=100
 for i=-1,1025 do
  local age=i/128
  for _,expiry in ipairs({false,100,100+age,100+age+1/1024,109}) do
   local x=R.Features(actor,at+age,{defensiveWitness={at=at,expires=expiry or nil}})
   local fresh=age>=0 and age<=8 and (not expiry or at+age<expiry)
   near(x[47],fresh and (current and (1-age/8) or 1) or 0,'recency boundary');eq(x[48],fresh and 1 or 0,'known boundary')
   eq(x[36],current and 1 or 0,'Druid root feature');eq(x[37],0,'Druid root is not conditional')
   for k=1,48 do ck(x[k]>=0 and x[k]<=1,'normalized feature '..k) end
  end
 end
 for _,class in ipairs({'WARRIOR','PALADIN','HUNTER','ROGUE','PRIEST','SHAMAN','MAGE','WARLOCK','DRUID','unknown'}) do
  local candidates=R.Candidates(class);local x=R.Features({class=class},0,{})
  for i,name in ipairs(R.families) do
   local status=candidates[name].status
   eq(x[30+i*2],status~='unknown' and 1 or 0,'association feature agrees with public candidate')
   eq(x[31+i*2],status=='conditional' and 1 or 0,'conditional feature agrees')
  end
 end
 for _,id in ipairs({339,1062,5195,5196,9852,9853}) do eq(R.Classify(id),current and 3 or nil,'root vocabulary delta') end
 for _,id in ipairs({16689,16810,16811,16812,16813,17329,19975,19974,19973,19972,19971,19970}) do eq(R.Classify(id),nil,'activation/proc excluded') end
 return '5,135 witness age/expiry combinations, public association-feature mapping, six root additions, twelve excluded activation/proc IDs.'
end)

test('out_of_order_multi_witness_projection_is_pure_and_anchor_immutable',function()
 local c=core();local actor=ctx(c,100)
 for _,w in ipairs({{id='future',at=103,expires=120},{id='old',at=96,expires=120},{id='latest',at=99,expires=100.25}}) do ck(c:Aura({id=w.id,recipient='P',at=w.at,expires=w.expires,spellID=22812})) end
 c:Tick(100,true);local window=assert(c.actors.P.window);local anchored=ns.Copy(window.x);local snapshot=ns.Copy(c)
 for _,t in ipairs({104,95,100.5,98,103,100,108,97}) do
  local context=c:GetContext('P',t);local x=R.Features(actor,t,context);local best=t>=103 and 103 or t>=99 and 99 or t>=96 and 96 or nil
  eq(context.defensiveWitness and context.defensiveWitness.at,best,'latest nonfuture witness')
  if t==100.5 then eq(x[47],0,'expired newer witness blocks old');eq(x[48],0) end
 end
 deep(c,snapshot,'queries cannot mutate state');ck(c:Aura({id='latest',recipient='P',at=101,expires=120,spellID=22812,newApplication=true}))
 deep(window.x,anchored,'new application cannot rewrite input');c:Tick(102.25,true);deep(window.x,anchored,'resolution cannot rewrite input')
 local saved=c:Export();deep(saved.examples[1].x,anchored,'export preserves anchored semantics')
 local d=core();ck(d:Restore(saved));deep(d.examples[1].x,anchored,'same-version restore preserves anchored semantics')
 return 'Future-first and stale query order, expired-latest selection, renewal, resolution, export, restore preserve one anchored vector.'
end)

test('current_schema_invalid_tail_is_atomic_with_live_candidate_and_model',function()
 local c=core();ck(c:Restore(makeSave(12)));ck(train(c))
 ctx(c,10);c:Tick(10,true);ctx(c,11);ck(c:Cast({id='live',actor='P',at=11,family=3}));c:Tick(12.25,true);c:Tick(12.25,false);ctx(c,13);c:Tick(13,true)
 ck(c.model and c.candidate and c.actors.P.window,'live model, replay, and pending anchor');local source=makeSave(256)
 local changes={function(s) s.examples[256].x[47]=1.0001 end,function(s) s.examples[256].x[48]=0/0 end,
  function(s) s.examples[256].x[49]=0 end,function(s) s.examples[256].mask[6]=1 end,function(s) s.examples[256].y[6]=.5 end,
  function(s) s.examples[256].regime='self' end,function(s) s.examples[128]=nil end,function(s) s.examples[257]=s.examples[1] end,
  function(s) s.examples[1.5]=s.examples[1] end,function(s) s.examples=setmetatable(s.examples,{}) end}
 for _,change in ipairs(changes) do
  local save=ns.Copy(source);change(save);local before=ns.Copy(c);local model,candidate,window,examples=c.model,c.candidate,c.actors.P.window,c.examples
  local ok,why=c:Restore(save);eq(ok,false,'reject malformed tail');eq(why,'invalid_examples')
  eq(c.model,model,'serving identity');eq(c.candidate,candidate,'candidate identity');eq(c.actors.P.window,window,'window identity');eq(c.examples,examples,'corpus identity');deep(c,before,'failed import atomic full state')
 end
 local save=ns.Copy(source);save.compat='semantic-key-that-is-not-this-version';save.examples=false
 local before=ns.Copy(c);before.stats.incompatibleSaves=(before.stats.incompatibleSaves or 0)+1
 local ok,why=c:Restore(save);eq(ok,false);eq(why,'incompatible');deep(c,before,'key rejected before malformed payload')
 local prior=c.candidate.model;train(c);eq(c.model,prior,'original candidate still publishes')
 return 'Ten invalid same-version tails/array shapes at 256 rows plus wrong-key malformed payload; full live state and references preserved.'
end)

test('support_masks_count_one_epoch_and_no_enemy_leakage',function()
 local save=makeSave(22)
 for i,w in ipairs(save.examples) do
  w.regime=i<=10 and 'player' or 'other';for f=1,6 do w.mask[f]=true;w.y[f]=i<=2 and 1 or 0 end
  w.y[2]=i==1 and 1 or 0;w.mask[4]=i<=9;w.y[4]=i<=2 and 1 or 0;w.mask[5]=false;w.y[5]=1
 end
 local c=core();ck(c:Restore(save));ck(train(c));eq(c.model.updates,40,'four epochs ten player rows');eq(c.model.positives[3],2);eq(c.model.totals[3],10)
 eq(c.model.positives[5],0);eq(c.model.totals[5],0,'masked positives do not count');eq(c.model.totals[4],9,'one fewer negative stays unsupported')
 ctx(c,10);c:Tick(10,false);local f=c:Forecast('P',10)
 for _,head in ipairs({1,3,6}) do ck(type(f.outputs[head].score)=='number','sufficient head exposed');ck(f.outputs[head].linear~=nil and f.outputs[head].frequency~=nil) end
 for _,head in ipairs({2,4,5}) do eq(f.outputs[head].score,nil,'below support withheld') end
 local status=c:Status();eq(status.trainingExamples,10);eq(status.families[3].positive,2);eq(status.families[3].negative,8);deep(c.model,modelFor(save),'exact ordered masked replay')
 local d=core();local exported=c:Export();ck(d:Restore(exported));ck(train(d));deep(c.model,d.model,'same-version deterministic restart')
 exported.examples[1].x[47]=.123;eq(c.examples[1].x[47],save.examples[1].x[47],'export detached')
 return 'Exact support threshold, insufficient-positive and insufficient-negative withholding, masked positives and enemy rows excluded, frequency counted once.'
end)

test('full_live_descriptor_capacity_then_late_correction_after_real_fifo_eviction',function()
 local c=core();ck(c:Aura({id='start-witness',recipient='P',at=8,expires=10000,spellID=22812}));local first
 for i=1,256 do local w=liveRow(c,i,i%10==0);if i==1 then first=w end end
 eq(#c.examples,256);ck(train(c));eq(#c.modelDependencies,256,'full descriptor capacity');local model=c.model;local version=c.modelVersion
 for i=257,264 do liveRow(c,i,false);eq(c.model,model,'real row eviction retains serving');eq(#c.modelDependencies,256);eq(#c.examples,256) end
 ck(c.examples[1]~=first and c.examples[1].anchor>first.anchor,'first training row evicted');ctx(c,c.now);c:Tick(c.now,true);local forecast=c:Forecast('P',c.now)
 ck(type(forecast.outputs[3].score)=='number','old model shadow score before correction');ck(forecast.modelRefreshPending,'old snapshot pending')
 ck(c:Cast({id='late-first-root',actor='P',at=11,family=3}),'late event accepted');eq(c.model,nil,'guard withdraws model');eq(#c.modelDependencies,0);eq(c.actors.P.forecast,nil,'cache withdrawn')
 local f=c:Forecast('P',c.now);for i=1,6 do eq(f.outputs[i].score,nil,'no stale numbers') end
 ck(train(c));eq(c.modelVersion,version+1);eq(#c.modelDependencies,256,'replacement guards bounded');deep(c.model,modelFor(c:Export()),'replacement equals clean replay')
 return '264 actual Context/Tick windows; all 256 serving descriptors survive 8 FIFO evictions then withdraw on a new late positive for the evicted negative row.'
end)

test('late_network_overflow_is_atomic_and_masked_heads_untouched',function()
 local m=assert(M.New(48,12,6,C.seed));local x=R.Features({class='DRUID',role='self',combat=true},10,{defensiveWitness={at=3}})
 ck(m:Learn(x,{1,0,1,0,0,1},{true,true,true,true,true,true}));local before=ns.Copy(m);ck(m:Learn(x,{0,1,0,1,1,0},{false,false,true,false,false,false},false))
 for _,head in ipairs({1,2,4,5,6}) do
  deep(m.outputWeights[head],before.outputWeights[head],'masked neural head unchanged');deep(m.linearWeights[head],before.linearWeights[head],'masked linear head unchanged');eq(m.outputBiases[head],before.outputBiases[head]);eq(m.linearBiases[head],before.linearBiases[head])
 end
 deep(m.positives,before.positives,'statistics suppression');deep(m.totals,before.totals)
 -- Data-only failure control after output-head candidate work, no method patches.
 m.regularization=1e308;m.hiddenWeights[12][48]=10
 local state=ns.Copy(m);local hw,ow,totals=m.hiddenWeights,m.outputWeights,m.totals
 local ok,why=m:Learn(x,{1,0,0,0,0,0},{true,false,false,false,false,false})
 eq(ok,false,'overflow rejected');eq(why,'nonfinite_update');deep(m,state,'late failure atomic');eq(m.hiddenWeights,hw);eq(m.outputWeights,ow);eq(m.totals,totals)
 return 'Omitted-head parameters untouched; overflowing last hidden weight aborts the entire candidate update including output and statistics changes.'
end)
return out
