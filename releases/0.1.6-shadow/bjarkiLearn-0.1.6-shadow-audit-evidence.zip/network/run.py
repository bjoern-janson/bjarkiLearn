"""Independent bounded persistence/model audit; all production files read only."""
import hashlib, importlib, json, sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
sys.path.insert(0,'C:/Users/Mewn/Documents/Codex/2026-10-16/let/work/deps')
SOURCES={'current016':ROOT/'source/bjarkiLearn','baseline015':ROOT/'verification/baseline/source/bjarkiLearn'}
def hashes(path):
 return {p.relative_to(path).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(path.rglob('*')) if p.is_file()}
def plain(x):
 return {str(k):plain(v) for k,v in x.items()} if hasattr(x,'items') else x
before={name:hashes(path) for name,path in SOURCES.items()}
(HERE/'before-hashes.json').write_text(json.dumps(before,indent=2)+'\n',encoding='utf-8')
results=[]
for engine in ('lua51','lua54'):
 Runtime=importlib.import_module('lupa.'+engine).LuaRuntime
 for source_name,source in SOURCES.items():
  lua=Runtime(unpack_returned_tuples=True);ns=lua.table()
  for name in ('Bootstrap.lua','Rules.lua','Network.lua','Core.lua'):
   lua.execute((source/name).read_text(encoding='utf-8-sig'),'bjarkiLearn',ns)
  cases=lua.execute((HERE/'probes.lua').read_text(encoding='utf-8-sig'),ns,source_name)
  for _,case in cases.items(): results.append({'engine':engine,'source':source_name,**plain(case)})
  print(engine,source_name,'completed',flush=True)
after={name:hashes(path) for name,path in SOURCES.items()}
(HERE/'after-hashes.json').write_text(json.dumps(after,indent=2)+'\n',encoding='utf-8')
report={'source_roots':{name:str(p) for name,p in SOURCES.items()},'input_source_unchanged':before==after,
 'script_hashes':{name:hashlib.sha256((HERE/name).read_bytes()).hexdigest() for name in ('run.py','probes.lua')},
 'cases':results,'summary':{'passed':sum(r['passed'] for r in results),'total':len(results),'checks':sum(r['checks'] for r in results)},
 'limits':['Unmodified Bootstrap, Rules, Network and Core running in actual Lua 5.1/5.4 through Lupa.','No production method monkeypatches. Synthetic inputs enter documented Core methods; numeric failure controls change model instance data only.','No live WoW, secret-value runtime, calibration or usefulness evidence. Main preference retention is source-reviewed; native tests are in parent suite.']}
(HERE/'results.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'summary':report['summary'],'unchanged':before==after,'failures':[r for r in results if not r['passed']]},indent=2))
sys.exit(0 if all(r['passed'] for r in results) and before==after else 1)
