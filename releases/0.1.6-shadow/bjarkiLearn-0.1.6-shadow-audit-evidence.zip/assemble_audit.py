"""Assemble an audit report from fresh results without modifying addon files."""
from pathlib import Path
import hashlib,json,zipfile
ROOT=Path(__file__).resolve().parent
SOURCE=ROOT/'source/bjarkiLearn'
def read(name):return json.loads((ROOT/name).read_text(encoding='utf-8-sig'))
def sha(data):return hashlib.sha256(data).hexdigest()
def hashes(root):return {p.relative_to(root).as_posix():sha(p.read_bytes()) for p in sorted(root.rglob('*')) if p.is_file()}
def runtime(h):return {n:v for n,v in h.items() if n.endswith('.lua')}
manifest=read('input-manifest.json');current=hashes(SOURCE)
assert current==manifest['source_hashes'],'Extracted install changed'
assert current==hashes(ROOT/'verification/source/bjarkiLearn'),'Verification source differs'
packed=read('verification/reports-016/verification.json')
assert packed['passed'] and packed['execution']=='full fresh run','Wait for the full packaged rerun'
assert packed['source_hashes']==current
assert packed['inherited']['unexpected_failures']==[]
core=read('core/results.json');native=read('native/final.json');network=read('network/results.json');integration=read('integration/results.json')
core_cases=[r for run in core['runs'] for r in run['results']]
assert len(core_cases)==40 and all(x['passed'] for x in core_cases) and all(core['source_unchanged'].values())
assert core['source_hashes']['exact016']==current
assert native['summary']['total']==native['summary']['passed']==148
assert all(x['unchanged'] for x in native['source_trees'].values())
assert native['source_trees']['current']['before']==current
assert network['summary']['total']==network['summary']['passed']==24 and network['input_source_unchanged']
assert read('network/before-hashes.json')['current016']==current
assert integration['passed'] and integration['source_unchanged'] and len(integration['cases'])==16
assert integration['source_hashes']==runtime(current)
assert len(integration['comparisons'])==24
original=ROOT.parents[1]/'outputs/bjarkiLearn-0.1.6-shadow.zip'
assert sha(original.read_bytes())==manifest['inputs'][original.name]['sha256'],'Original ZIP changed'
report={
 'verdict':'No confirmed remaining bug or unintended regression found in this bounded offline audit.',
 'confirmed_findings':[],'source_sha256':manifest['inputs'][original.name]['sha256'],'source_files':14,'source_hashes':current,
 'packaged_rerun':{'passed':True,'execution':packed['execution'],'repair_cases':packed['semantic'],'independent_cases':packed['independent'],'syntax':{'passed':12,'total':12},'inherited_baseline_jobs':39,'inherited_candidate_jobs':39,'inherited_unexpected_failures':[],'scoped_repetition_cases':86,'recency_adapted_executions':149},
 'new_independent_checks':{'core':{'passed':40,'total':40,'current016':20,'baseline015':20,'mixed_operations':11200},'native':{'passed':148,'total':148,'current016':74,'baseline015':74,'assertions':native['summary']['checks']},'network_persistence':{'passed':24,'total':24,'current016':12,'baseline015':12,'assertions':network['summary']['checks']},'integration':{'passed':16,'total':16,'exact_comparisons':24,'current016_only':True}},
 'limitations':['Ordinary Lua 5.1/5.4 with modeled WoW host APIs; not live-client validation.','Native secret-value/taint behavior, frame-time cost and predictive usefulness remain unverified.','Intentional old-save rejection, sealed-history limits, bounded identity retirement and latest-witness selection are not new findings.','Historical obsolete assertions remain failed or excluded claims, not silently counted as passing.'],
 'files_edited':'Audit scripts/reports only. The addon ZIP, extracted addon source, installed game and GitHub repositories were not changed.'
}
(ROOT/'audit-summary.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
text='''bjarkiLearn 0.1.6-shadow independent repeat audit

Verdict: no confirmed remaining bugs or unintended regressions found in this
bounded source and offline-execution audit. No addon changes were made.

Exact input install SHA-256:
065eed18d4e45d07ab86659f3bf5ca795e6cac945c3edb8ee2c33ff61591bc97

All 14 extracted files match the delivered ZIP and the verification source.
The six Lua files, both TOCs, metadata, load references and ZIP CRCs were checked.

Fresh packaged verification
-42/42 repair cases;34/34 original independent comparison cases;12/12 Lua syntax.
-All39 inherited leaf jobs rerun against exact015 and016, with exact expected
 historical failures and recency adaptations classified separately.
-149 adapted group executions and86 same-version invariant/repetition cases pass.
-No unexpected inherited failure. Original tests and baseline hashes preserved.

Additional independent audit (counts include baseline controls where shown)
-Core:40/40 scenario executions =20 current016 +20 exact015. Four seeded streams
 per version/engine total11,200 mixed actions, outcome oracle, corrections,
 maturity, retirement, nonoverlap, capacity, immutability and clean replay.
-Native:148/148 executions =74 current016 +74 exact015. Root aliases, unreadable
 inputs, class/form recovery, event deadlines, reset/bus replay, startup warnings,
 settings, public copies and stopped callbacks pass.
-Network/persistence:24/24 executions =12 current016 +12 exact015. Dense age/expiry
 grid, malformed final-row save atomicity, support/masks, deterministic replay,
 finite-update atomicity and all256 serving descriptors under actual FIFO pressure.
-Integration:16/16 actual native traces on016, plus24 exact comparisons. All six
 Entangling Roots ranks and mixed ranks match an existing registered-root control;
 alias duplicates, actual SharedEvidence, session resets, disable/enable, supported
 scores, clean save/reload and cross-Lua state equality are exercised.

Findings
No confirmed actionable defect. The new root cast coverage and Druid candidate
are consistent. Recency and known-evidence remain distinct at age eight; unknown
or expired evidence is not treated as a confirmed absence. Old learning is rejected
atomically while enabled preference survives; current saves rebuild correctly.
Correction, immutable-anchor and bounded-history guarantees held in the probes.

Limits
These tests run ordinary Lua5.1/5.4 with modeled native APIs. They do not establish
live WoW event delivery, secret enforcement, taint safety, rendering, frame cost,
calibration or useful forecasts. Shadow outputs remain unusable for UI changes.
Intentional rejection of old saves and limits on sealed/discarded identities are
not regressions. Cross-version numeric equality is not asserted for deliberately
changed feature-dependent models. No claim of exhaustive bug absence is made.

Evidence
Read core/review.txt, native/REPORT.txt, network/REPORT.md, integration/results.json
and audit-summary.json. reports/full-packaged-run.log records the fresh full run.
verification/ holds the extracted original verification bundle, with current run
outputs refreshed. Its historical bundle-files.json describes the original input;
the audit-payload-hashes.json manifest covers this audit's actual payload instead.
All new scripts operate only on the audit tree. Existing report paths may name the
original local workspace; source hashes bind the artifacts independently of paths.
'''
(ROOT/'AUDIT.txt').write_text(text,encoding='utf-8')
output=ROOT.parents[1]/'outputs';output.mkdir(exist_ok=True)
(output/'bjarkiLearn-0.1.6-shadow-AUDIT.txt').write_text(text,encoding='utf-8')
files={}
for p in sorted(ROOT.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(ROOT);parts=rel.parts
 if '__pycache__' in parts or p.suffix=='.pyc' or 'runs' in parts:continue
 if p.name in ('write-probe.txt','probe-write.txt'):continue
 files[rel.as_posix()]=p.read_bytes()
files['audit-payload-hashes.json']=(json.dumps({n:sha(v) for n,v in files.items()},indent=2)+'\n').encode()
archive=output/'bjarkiLearn-0.1.6-shadow-audit-evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,v in files.items():z.writestr(n,v)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and len(z.namelist())==len(files)
 assert all(z.read(n)==v for n,v in files.items())
print(json.dumps({'verdict':report['verdict'],'archive':str(archive),'sha256':sha(archive.read_bytes()),'files':len(files),'bytes':archive.stat().st_size,'crc_and_bytes_verified':True},indent=2))
