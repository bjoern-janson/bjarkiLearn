-- Independent native host model. All learner modules and bus execute unchanged.
local ns={}
World={now=10,combat=true,unitCombat=true,ids={player='Player-1-100',target='Player-1-200'},
 classes={player='DRUID',target='ROGUE'},forms={},dead={},chat={},frames={}}
Opaque={};Inaccessible={}
issecretvalue=function(v) return rawequal(v,Opaque) end
issecrettable=function(v) return rawequal(v,Opaque) end
canaccessvalue=function(v) return not rawequal(v,Inaccessible) end
GetTime=function() return World.now end
InCombatLockdown=function() return World.combat end
UnitGUID=function(u) return World.ids[u] end
UnitIsPlayer=function(u) local id=World.ids[u];if type(id)=='string' then return id:sub(1,7)=='Player-' end end
UnitClassBase=function(u) return World.classes[u] end
UnitCanAttack=function(_,u) return u~='player' end
UnitAffectingCombat=function() return World.unitCombat end
UnitHealth=function() return 75 end
UnitHealthMax=function() return 100 end
UnitPower=function() return 50 end
UnitPowerMax=function() return 100 end
UnitIsDeadOrGhost=function(u) return World.dead[u] or false end
UnitPowerType=function(u) return 0,World.forms[u] or 'MANA' end
SlashCmdList={}
DEFAULT_CHAT_FRAME={AddMessage=function(_,s) World.chat[#World.chat+1]=s end}
CreateFrame=function()
 local f={scripts={},events={}}
 function f:RegisterEvent(e) self.events[e]=true end
 function f:SetScript(k,v) self.scripts[k]=v end
 World.frames[#World.frames+1]=f;return f
end
for _,name in ipairs({'Bootstrap.lua','Rules.lua','Network.lua','Core.lua','Adapter.lua','Main.lua'}) do
 assert(loadfile(LEARN_ROOT..'/'..name))('bjarkiLearn',ns)
end
NS=ns;Runtime=ns.Runtime;CURRENT=ns.Config.version=='0.1.6-shadow'
function Check(v,s) CHECKS=(CHECKS or 0)+1;if not v then error(s or 'check failed',2) end end
function Equal(a,b,s) Check(a==b,(s or 'equal')..': '..tostring(a)..' ~= '..tostring(b)) end
function Event(e,...) if Runtime.frame.events[e] then Runtime.frame.scripts.OnEvent(Runtime.frame,e,...) end end
function Init() Event('ADDON_LOADED','bjarkiLearn') end
function Advance(t) World.now=t;Runtime.frame.scripts.OnUpdate(Runtime.frame,.1) end
function Start() Init();Advance(10);Check(not Runtime.faulted) end
function Command(s) SlashCmdList.BJARKILEARN(s) end
function Finish()
 for _,t in ipairs({10.5,11,11.5,12}) do Advance(t) end
 World.combat=false;World.unitCombat=false;Advance(12.3)
end
function PlayerRow()
 for _,w in ipairs(Runtime.core.examples) do if w.regime=='player' then return w end end
end
function LoadBus() assert(loadfile(BUS_PATH))('bjarkiPortraits',{}) end
function Publish(id,at,recipient,spell,expiry)
 return BjarkiEvidenceV1:Publish({source='bjarkiPortraits',kind='aura-positive',isHelpful=true,
  recipientGUID=recipient or World.ids.player,unit='target',spellId=spell or 22812,
  auraInstanceID=id,observedAt=at,expirationTime=expiry,duration=20})
end
function Serialize(v)
 if type(v)~='table' then return tostring(v) end
 local keys={};for k in pairs(v) do keys[#keys+1]=k end
 table.sort(keys,function(a,b)return tostring(a)<tostring(b)end)
 local out={};for _,k in ipairs(keys) do out[#out+1]=tostring(k)..'='..Serialize(v[k]) end
 return '{'..table.concat(out,',')..'}'
end

