-- New cases use actual Main frame callbacks and the unchanged v1 bus.
CASES={}
local function Case(name,fn) CASES[name]=fn end
local function denseMasks(row,known,positive)
 for i=1,6 do Equal(row.mask[i],known or i==positive,'mask '..i);Equal(row.y[i],i==positive and 1 or 0,'label '..i) end
end
for _,spell in ipairs({339,1062,5195,5196,9852,9853}) do
 local rank=spell
 Case('root alias dedup plus class fallback rank '..rank,function()
  UnitClassBase=function() return Opaque end
  UnitClass=function(u) return Opaque,World.classes[u] end
  World.ids.target=World.ids.player;World.ids.focus=World.ids.player
  World.classes.target='MAGE';World.classes.focus='WARRIOR';World.forms.player='ENERGY'
  Start();local actor=Runtime.core.actors[World.ids.player];local input=Serialize(actor.window.x)
  World.now=10.2
  for _,unit in ipairs({'focus','target','player'}) do Event('UNIT_SPELLCAST_SUCCEEDED',unit,'root-alias',rank) end
  Equal(BjarkiLearn:GetContext('target').class,'DRUID');Equal(BjarkiLearn:GetContext('focus').role,'self')
  Equal(BjarkiLearn:GetContext('target').form,'cat')
  Equal(Runtime.core:Status().casts or 0,CURRENT and 1 or 0)
  Equal(Runtime.adapter.stats.casts,CURRENT and 3 or 0)
  World.ids.target=nil;Event('PLAYER_TARGET_CHANGED')
  World.ids.focus='Player-1-300';Event('PLAYER_FOCUS_CHANGED')
  Equal(Runtime.adapter.coverage,true);Equal(Serialize(actor.window.x),input)
  Finish();denseMasks(assert(PlayerRow()),true,CURRENT and 3 or nil)
  Check(not Runtime.faulted)
 end)
end
Case('unreadable root identity then readable duplicate recovers only positive',function()
 Start();World.now=10.2
 Event('UNIT_SPELLCAST_SUCCEEDED','player',Opaque,339)
 Event('UNIT_SPELLCAST_SUCCEEDED','player','root-recovered',339)
 Finish();denseMasks(assert(PlayerRow()),not CURRENT,CURRENT and 3 or nil)
 Equal(Runtime.adapter.stats.rejected,CURRENT and 1 or 0)
 Check(not Runtime.faulted)
end)
Case('irrelevant known spell with unreadable cast ID does not gap root coverage',function()
 Start();World.now=10.2
 Event('UNIT_SPELLCAST_SUCCEEDED','player',Opaque,19975)
 Event('UNIT_SPELLCAST_SUCCEEDED','player',Inaccessible,16689)
 Finish();denseMasks(assert(PlayerRow()),true,nil);Equal(Runtime.adapter.stats.rejected,0)
end)
Case('unreadable root spell followed by optional context loss preserves positive',function()
 Start();World.now=10.2;Event('UNIT_SPELLCAST_SUCCEEDED','player','unreadable-spell',Opaque)
 World.classes.player=Opaque;World.forms.player=Opaque
 Event('UNIT_SPELLCAST_SUCCEEDED','player','readable-root',9853)
 Equal(BjarkiLearn:GetContext('player').class,nil);Equal(BjarkiLearn:GetContext('player').form,nil)
 Finish();denseMasks(assert(PlayerRow()),false,CURRENT and 3 or nil)
 Equal(Runtime.core.actors[World.ids.player].window,nil)
end)
Case('class and form recovery changes current context but leaves anchor immutable',function()
 World.forms.player='ENERGY';Start()
 local actor=Runtime.core.actors[World.ids.player];local anchored=Serialize(actor.window.x)
 Equal(BjarkiLearn:GetContext('player').form,'cat')
 World.forms.player='RAGE';Advance(10.25);Equal(BjarkiLearn:GetContext('player').form,'bear')
 World.dead.player=Opaque;Advance(10.5);Equal(BjarkiLearn:GetContext('player').form,nil)
 World.dead.player=false;World.classes.player=Inaccessible;Advance(10.75)
 Equal(BjarkiLearn:GetContext('player').class,nil);Equal(BjarkiLearn:GetContext('player').form,nil)
 World.classes.player='DRUID';Advance(11)
 Equal(BjarkiLearn:GetContext('player').form,'bear');Equal(Serialize(actor.window.x),anchored)
 Equal(actor.window.x[44],1);Equal(actor.window.x[45],0);Equal(actor.window.x[46],1)
 Check(not Runtime.faulted)
end)
Case('fallback class second result alone supplies semantic class',function()
 UnitClassBase=nil;local mode=1
 UnitClass=function() if mode==1 then return 'Druid',Opaque elseif mode==2 then error('host unavailable') else return Opaque,'DRUID' end end
 Start();Equal(BjarkiLearn:GetContext('player').class,nil)
 mode=2;Advance(10.25);Equal(BjarkiLearn:GetContext('player').class,nil)
 mode=3;Advance(10.5);Equal(BjarkiLearn:GetContext('player').class,'DRUID')
 Check(not Runtime.faulted)
end)
Case('unreadable clock during startup recovers native collection with explicit bus reconnect',function()
 LoadBus();Check(Publish(1,10));World.now=Opaque;Init()
 Equal(Runtime.enabled,true);Equal(BjarkiLearn:GetContext('player'),nil)
 Equal(Runtime.adapter.stats.busConnected,false)
 Advance(10);Equal(BjarkiLearn:GetContext('player').actor,World.ids.player)
 Event('ADDON_LOADED','other-addon')
 Equal(Runtime.adapter.stats.busConnected,true);Equal(BjarkiLearn:GetContext('player').defensiveWitness.at,10)
 World.now=10.2;Event('UNIT_SPELLCAST_SUCCEEDED','player','root-after-clock',339)
 Finish();denseMasks(assert(PlayerRow()),true,CURRENT and 3 or nil)
 Check(not Runtime.faulted)
end)
Case('unreadable clock drops cast and restores context without inventing a root',function()
 Start();World.now=Opaque
 Event('UNIT_SPELLCAST_SUCCEEDED','player','lost-root',339)
 Runtime.frame.scripts.OnUpdate(Runtime.frame,.1)
 Equal(BjarkiLearn:GetContext('player'),nil);Equal(BjarkiLearn:Forecast('player'),nil)
 Advance(10.25);Check(BjarkiLearn:GetContext('player').fresh)
 Finish();denseMasks(assert(PlayerRow()),false,nil);Equal(Runtime.core.occurrences['cast:lost-root'],nil)
end)
Case('world reset after two aliases replays root context separately from cast labels',function()
 LoadBus();Start();World.now=10.2
 Event('UNIT_SPELLCAST_SUCCEEDED','player','before-world-root',339)
 Check(Publish(33,10.2));World.ids.target=World.ids.player;World.ids.focus=World.ids.player
 Event('PLAYER_TARGET_CHANGED');Event('PLAYER_FOCUS_CHANGED')
 Event('PLAYER_ENTERING_WORLD')
 Equal(BjarkiEvidenceV1:Status().listeners,1);Equal(Runtime.core.occurrences['cast:before-world-root'],nil)
 Equal(BjarkiLearn:GetContext('player').defensiveWitness.at,10.2)
 local row=assert(PlayerRow());denseMasks(row,false,CURRENT and 3 or nil)
 Check(row.sealed and row.actor==nil);Equal(Runtime.adapter.coverage,true)
 Advance(10.3);World.now=10.4;Event('UNIT_SPELLCAST_SUCCEEDED','target','after-world-root',339)
 Equal(Runtime.core:Status().casts or 0,CURRENT and 2 or 0)
 Check(not Runtime.faulted)
end)
Case('old callback cannot resurrect evidence through disable reset or reenable',function()
 LoadBus();Start();local old=Runtime.adapter.callback
 Check(Publish(10,10));Command('disable')
 Equal(BjarkiEvidenceV1:Status().listeners,0);Equal(BjarkiLearn:GetContext('player'),nil)
 local n=Runtime.core:Status().occurrences
 old({source='bjarkiPortraits',kind='aura-positive',isHelpful=true,recipientGUID=World.ids.player,spellId=22812,auraInstanceID=11,observedAt=10.1})
 Equal(Runtime.core:Status().occurrences,n)
 Command('reset');Equal(Runtime.core:Status().occurrences,0);Equal(Runtime.enabled,false)
 old({source='bjarkiPortraits',kind='aura-positive',isHelpful=true,recipientGUID=World.ids.player,spellId=22812,auraInstanceID=12,observedAt=10.1})
 Equal(Runtime.core:Status().occurrences,0)
 Command('enable');Equal(BjarkiEvidenceV1:Status().listeners,1)
 Equal(BjarkiLearn:GetContext('player').defensiveWitness.at,10)
 old({source='bjarkiPortraits',kind='aura-positive',isHelpful=true,recipientGUID=World.ids.player,spellId=22812,auraInstanceID=13,observedAt=10.1})
 Equal(Runtime.core:Status().occurrences,1)
end)
Case('equal timestamp bus refresh is idempotent while expiry metadata revises',function()
 LoadBus();Start();Check(Publish(10,10,nil,22812,20));local c=Runtime.core
 local revision=BjarkiLearn:GetContext('player').revision
 Check(Publish(10,10,nil,22812,20));Equal(BjarkiLearn:GetContext('player').revision,revision)
 Check(Publish(10,10,nil,22812,18));Check(BjarkiLearn:GetContext('player').revision>revision)
 Equal(BjarkiLearn:GetContext('player').defensiveWitness.expires,18)
 Equal(c:Status().auraWitnesses,1);Equal(c:Status().auraRevisions,1)
 Equal(Runtime.adapter.stats.auras,3)
 for i=1,6 do Equal(c.actors[World.ids.player].window.x[19+i*2],0) end
end)
Case('public projections remain independent through model context and status copies',function()
 LoadBus();Start();Check(Publish(10,10))
 World.now=10.2;Event('UNIT_SPELLCAST_SUCCEEDED','player','public-root',339)
 Advance(10.25)
 local ctx=BjarkiLearn:GetContext('player');local forecast=BjarkiLearn:Forecast('player');local status=BjarkiLearn:Status()
 ctx.candidates.root.status='changed';ctx.defensiveWitness.at=0;ctx.history[3]=0
 forecast.outputs[3].candidate.status='changed';forecast.outputs[3].score=1;forecast.usable=true
 status.adapter.busConnected=false;status.core.families[3].positive=999
 Equal(BjarkiLearn:GetContext('player').candidates.root.status,CURRENT and 'candidate' or 'unknown')
 Equal(BjarkiLearn:GetContext('player').defensiveWitness.at,10)
 Equal(BjarkiLearn:GetContext('player').history[3],CURRENT and 10.2 or nil)
 Equal(BjarkiLearn:Forecast('player').usable,false);Equal(BjarkiLearn:Status().core.families[3].positive,0)
 Equal(BjarkiLearn:Status().adapter.busConnected,true)
 Equal(BjarkiLearn:GetContext('Player-1-not-bound'),nil);Equal(BjarkiLearn:GetContext(Opaque),nil)
 Equal(BjarkiLearn:Forecast(Inaccessible),nil)
end)
for _,kind in ipairs({'none','valid','incompatible','invalid'}) do
 for _,enabled in ipairs({false,true}) do
  local shape,setting=kind,enabled
  Case('startup restore reason '..shape..' enabled '..tostring(setting),function()
   if shape~='none' then
    local save={schema=NS.Config.schema,compat=NS.Config.compat,examples={}}
    if shape=='incompatible' then save.compat='other-version' end
    if shape=='invalid' then save.examples={[2]={}} end
    bjarkiLearnDB={enabled=setting,learning=save}
   end
   Init();local reason=(shape=='incompatible' and 'incompatible' or shape=='invalid' and 'invalid_examples' or nil)
   Equal(Runtime.enabled,shape=='none' or setting)
   Equal(Runtime:Status().restoreReason,CURRENT and reason or nil)
   Equal(#World.chat,CURRENT and reason and 1 or 0)
   Event('ADDON_LOADED','bjarkiLearn');Equal(#World.chat,CURRENT and reason and 1 or 0)
   Command('reset');Command('enable');Command('disable')
   Equal(Runtime:Status().restoreReason,CURRENT and reason or nil)
   Equal(bjarkiLearnDB.enabled,false);Equal(bjarkiLearnDB.learning.compat,NS.Config.compat)
   Equal(#bjarkiLearnDB.learning.examples,0)
   Check(not Runtime.faulted)
  end)
 end
end
for _,mode in ipairs({'missing','opaque','throwing','blocked-function'}) do
 local shape=mode
 Case('startup rejection notice tolerates chat '..shape,function()
  bjarkiLearnDB={enabled=false,learning={schema=1,compat='old'}}
  if shape=='missing' then DEFAULT_CHAT_FRAME=nil
  elseif shape=='opaque' then DEFAULT_CHAT_FRAME=Opaque
  elseif shape=='throwing' then DEFAULT_CHAT_FRAME={AddMessage=function()error('chat unavailable')end}
  else DEFAULT_CHAT_FRAME={AddMessage=Inaccessible} end
  Init();Check(Runtime.initialized);Equal(Runtime.enabled,false);Check(not Runtime.faulted)
  Equal(Runtime:Status().restoreReason,CURRENT and 'incompatible' or nil)
  Command('status');Check(not Runtime.faulted)
 end)
end
for _,mode in ipairs({'table','false','opaque','inaccessible'}) do
 local shape=mode
 Case('preexisting public global '..shape..' preserved on rejected restore',function()
  local existing=shape=='table' and {protocol='other'} or shape=='false' and false or shape=='opaque' and Opaque or Inaccessible
  -- Lua and/or cannot represent false in the selector above.
  if shape=='false' then existing=false end
  BjarkiLearn=existing;bjarkiLearnDB={enabled=true,learning={schema=1,compat='old'}}
  Init();Equal(BjarkiLearn,existing);Equal(Runtime:Status().publicAvailable,false)
  Command('reset');Equal(BjarkiLearn,existing);Check(not Runtime.faulted)
 end)
end


for _,before in ipairs({false,true}) do
 local first=before
 Case('deadline root event before update '..tostring(first),function()
  Start();for _,t in ipairs({10.5,11,11.5}) do Advance(t) end
  World.now=12
  if first then Event('UNIT_SPELLCAST_SUCCEEDED','player','deadline-root',339);Advance(12)
  else Advance(12);Event('UNIT_SPELLCAST_SUCCEEDED','player','deadline-root',339) end
  World.combat=false;World.unitCombat=false;Advance(12.25)
  denseMasks(assert(PlayerRow()),true,CURRENT and 3 or nil)
  if CURRENT then Equal(PlayerRow().lead[3],2) end
  Equal(Runtime.core:Status().casts or 0,CURRENT and 1 or 0)
 end)
end
Case('bus replay exact eight-second boundary followed by future live witness',function()
 LoadBus();Check(Publish(100,2,nil,22812,20));Start()
 local actor=Runtime.core.actors[World.ids.player]
 Equal(actor.window.x[47],CURRENT and 0 or 1);Equal(actor.window.x[48],1)
 Check(Publish(101,10.5,nil,22812,21))
 Equal(BjarkiLearn:GetContext('player').defensiveWitness.at,2)
 Advance(10.125);Equal(BjarkiLearn:Forecast('player').expires,10.5)
 Equal(actor.window.x[47],CURRENT and 0 or 1);Equal(actor.window.x[48],1)
 Advance(10.5);Equal(BjarkiLearn:GetContext('player').defensiveWitness.at,10.5)
 Event('PLAYER_ENTERING_WORLD');Equal(BjarkiLearn:GetContext('player').defensiveWitness.at,10.5)
 Equal(Runtime.core:Status().occurrences,1);Equal(BjarkiEvidenceV1:Status().listeners,1)
 Check(not Runtime.faulted)
end)
Case('native clock zero is a valid anchor and aura observation',function()
 LoadBus();Check(Publish(100,0,nil,22812,10));World.now=0;Init();Advance(0)
 local actor=Runtime.core.actors[World.ids.player]
 Equal(actor.window.anchor,0);Equal(actor.window.x[47],1);Equal(actor.window.x[48],1)
 World.now=.1;Event('UNIT_SPELLCAST_SUCCEEDED','player','root-at-zero-clock',339)
 for _,t in ipairs({.5,1,1.5,2}) do Advance(t) end
 World.combat=false;World.unitCombat=false;Advance(2.25)
 denseMasks(assert(PlayerRow()),true,CURRENT and 3 or nil)
 Equal(Runtime:Status().errors,0)
end)


