"""Independent bounded native probes against immutable learner modules."""
import argparse, hashlib, importlib, json, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--source',type=Path,required=True)
p.add_argument('--baseline',type=Path,required=True)
p.add_argument('--bus',type=Path,required=True)
p.add_argument('--output',type=Path,required=True)
p.add_argument('--lupa-path',action='append',default=[])
a=p.parse_args()
for path in a.lupa_path:sys.path.insert(0,path)
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def tree(p):return {f.relative_to(p).as_posix():sha(f) for f in sorted(p.rglob('*')) if f.is_file()}
trees={name:dict(path=str(path.resolve()),before=tree(path.resolve())) for name,path in [('current',a.source),('baseline',a.baseline)]}
host=(ROOT/'harness.lua').read_text(encoding='utf-8-sig');cases=(ROOT/'probes.lua').read_text(encoding='utf-8-sig')
results=[]
for engine in ('lua51','lua54'):
 Lua=importlib.import_module('lupa.'+engine).LuaRuntime
 for version,path in [('current',a.source),('baseline',a.baseline)]:
  def new():
   lua=Lua(unpack_returned_tuples=True);lua.globals().LEARN_ROOT=path.resolve().as_posix()
   lua.globals().BUS_PATH=a.bus.resolve().as_posix();lua.execute(host);lua.execute(cases);return lua
  probe=new()
  for name in sorted(probe.globals().CASES.keys()):
   lua=new();error=None
   try:lua.globals().CASES[name]()
   except Exception as exc:error=str(exc)
   results.append(dict(engine=engine,source=version,case=name,passed=error is None,checks=lua.globals().CHECKS or 0,error=error))
for name,t in trees.items():t['unchanged']=tree(Path(t['path']))==t['before']
report=dict(source_trees=trees,bus=dict(path=str(a.bus.resolve()),sha256=sha(a.bus)),
 harness_hashes={f.name:sha(f) for f in [ROOT/'harness.lua',ROOT/'probes.lua',ROOT/'run.py']},
 summary=dict(passed=sum(x['passed'] for x in results),total=len(results),checks=sum(x['checks'] for x in results)),cases=results,
 claim_ceiling='Actual Main/Adapter/Rules/Bootstrap/Core/Network and unchanged SharedEvidence on Lua 5.1/5.4. Host/opaque values modeled; no live native availability, secret enforcement, latency, or gameplay claim.')
a.output.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(summary=report['summary'],unchanged={k:v['unchanged'] for k,v in trees.items()},failures=[x for x in results if not x['passed']]),indent=2))
sys.exit(0 if all(x['passed'] for x in results) and all(x['unchanged'] for x in trees.values()) else 1)

