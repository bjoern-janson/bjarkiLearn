"""Independent Core audit probes; no runtime source or packaged test modifications."""
import hashlib, importlib, json, sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
AUDIT=HERE.parent
sys.path.insert(0, 'C:/Users/Mewn/Documents/Codex/2026-10-16/let/work/deps')
SOURCES={'exact016':AUDIT/'source/bjarkiLearn','exact015':AUDIT/'verification/baseline/source/bjarkiLearn'}
def hashes(path):
    return {p.relative_to(path).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(path.rglob('*')) if p.is_file()}
def plain(x):
    if not hasattr(x,'items'): return x
    keys=list(x.keys())
    if keys and all(isinstance(k,(int,float)) for k in keys): return [plain(x[i]) for i in range(1,len(keys)+1)]
    return {str(k):plain(v) for k,v in x.items()}
before={name:hashes(path) for name,path in SOURCES.items()}
report={'source_hashes':before,'runs':[],'claim_ceiling':'Actual unmodified Lua modules under Lua 5.1 and 5.4, using private normalized Core API. Not live WoW event/taint/frame-time evidence.'}
for name,path in SOURCES.items():
    for engine in ('lua51','lua54'):
        Runtime=importlib.import_module('lupa.'+engine).LuaRuntime
        lua=Runtime(unpack_returned_tuples=True)
        ns=lua.table()
        for filename in ('Bootstrap.lua','Rules.lua','Network.lua','Core.lua'):
            lua.execute(path.joinpath(filename).read_text(encoding='utf-8-sig'),'bjarkiLearn',ns)
        results=plain(lua.execute(HERE.joinpath('probes.lua').read_text(encoding='utf-8-sig'),ns))
        report['runs'].append({'version':name,'engine':engine,'results':results})
        print(json.dumps({'version':name,'engine':engine,'passed':sum(r['passed'] for r in results),'total':len(results),'failures':[r for r in results if not r['passed']]}),flush=True)
report['source_unchanged']={name:hashes(path)==before[name] for name,path in SOURCES.items()}
report['probe_hashes']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (HERE/'run_probes.py',HERE/'probes.lua')}
HERE.joinpath('results.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
sys.exit(0 if all(report['source_unchanged'].values()) and all(r['passed'] for run in report['runs'] for r in run['results']) else 1)
