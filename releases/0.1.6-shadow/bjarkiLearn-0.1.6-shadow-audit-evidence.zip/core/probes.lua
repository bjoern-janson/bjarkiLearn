local ns=...
local results={}
local checks=0
local function check(v,msg) checks=checks+1;assert(v,msg or 'check failed') end
local function eq(a,b,msg) check(a==b,(msg or 'equality')..': '..tostring(a)..' versus '..tostring(b)) end
local function same(a,b,path)
 path=path or 'state';eq(type(a),type(b),path)
 if type(a)~='table' then eq(a,b,path);return end
 for k,v in pairs(a) do same(v,b[k],path..'.'..tostring(k)) end
 for k in pairs(b) do check(a[k]~=nil,path..' extra '..tostring(k)) end
end
local function test(name,fn)
 local before=checks;local ok,detail=pcall(fn)
 results[#results+1]={name=name,passed=ok,checks=checks-before,detail=ok and detail or nil,error=not ok and tostring(detail) or nil}
end
local function fresh() local c=ns.Core.New();c:SetCoverage(true);return c end
local function context(c,id,t,role)
 return c:Context({actor=id,at=t,class='DRUID',role=role or 'self',combat=true,health=.65,power=.45,bound=true})
end
local function cast(c,id,actor,t,f,revision,lo,hi,retracted)
 return c:Cast({id=id,actor=actor,at=t,family=f or 3,revision=revision or 1,minAt=lo,maxAt=hi,retracted=retracted})
end
local function open(c,id,t,role) context(c,id,t,role);c:Tick(t,true);return assert(c.actors[id].window) end
local function train(c)
 for _=1,300 do if not c.dirty then break end;c:_Train() end
 check(not c.dirty and not c.candidate,'rebuild completes');return c.model
end
local function closed(c,id,t) local w=open(c,id,t);c:Tick(t+2.25,nil);check(w.y~=nil);return w end
local function canonical(c) local d=fresh();assert(d:Restore(c:Export()));train(d);same(c.model,d.model,'clean rebuild') end
-- Independent set calculation: this does not call Core's label/reconciliation helpers.
local function oracle(c,w)
 if w.sealed then return end
 for family=1,6 do
  local positive,ambiguous,lead=false,false,nil
  for _,e in pairs(c.occurrences) do
   if e.kind=='cast' and not e.retracted and e.actor==w.actor and e.family==family then
    if e.maxAt>w.anchor and e.minAt<=w.deadline then
     if e.minAt>w.anchor and e.maxAt<=w.deadline and e.maxAt<=c.evidenceTime then
      positive=true;lead=math.min(lead or math.huge,e.minAt-w.anchor)
     else ambiguous=true end
    end
   end
  end
  eq(w.y[family],positive and 1 or 0,'oracle label')
  eq(w.mask[family],positive or (not ambiguous and w.coverage[family] and not w.lost[family]),'oracle mask')
  eq(w.lead[family],lead,'oracle lead')
 end
end
local function invariants(c)
 check(#c.actorOrder<=16 and #c.occurrenceOrder<=128 and #c.examples<=256 and #c.modelDependencies<=256,'caps')
 local ids={}
 for _,id in ipairs(c.actorOrder) do check(not ids[id] and c.actors[id]~=nil,'actor membership');ids[id]=true end
 ids={};for _,id in ipairs(c.occurrenceOrder) do check(not ids[id] and c.occurrences[id]~=nil,'occurrence membership');ids[id]=true end
 if c.candidate then check(c.dirty and c.candidate.revision==c.corpusRevision and #c.candidate.data<=256,'candidate bounds/revision') end
 if c.model then check(c.model:Valid());eq(c:Status().modelRefreshPending,c.modelCorpusRevision~=c.corpusRevision)
 else eq(#c.modelDependencies,0,'orphan guards') end
 local intervals={}
 for _,w in ipairs(c.examples) do
  check(#w.x==48);for i=1,48 do check(type(w.x[i])=='number' and w.x[i]>=0 and w.x[i]<=1,'feature bound') end
  oracle(c,w)
  if not w.sealed then local p=intervals[w.actor];if p then check(w.anchor>=p.deadline,'nonoverlap') end;intervals[w.actor]=w end
 end
 for id,a in pairs(c.actors) do if a.window and intervals[id] then check(a.window.anchor>=intervals[id].deadline,'pending nonoverlap') end end
end

test('mixed_interval_permutations',function()
 for _,order in ipairs({{1,2,3},{3,1,2},{2,3,1}}) do
  local c=fresh();local w=open(c,'A',10)
  local e={{'wide',10,9.75,10.25},{'certain',11,10.75,11.25},{'late',12,11.75,12.25}}
  for _,i in ipairs(order) do local v=e[i];assert(cast(c,v[1],'A',v[2],3,1,v[3],v[4])) end
  c:Tick(12.25,nil);eq(w.y[3],1);eq(w.mask[3],true);eq(w.lead[3],.75)
  assert(cast(c,'certain','A',11,3,2,10.75,11.25,true));eq(w.y[3],0);eq(w.mask[3],false)
  assert(cast(c,'wide','A',10,3,2,9.75,10.25,true));eq(w.mask[3],false)
  assert(cast(c,'late','A',12,3,2,11.75,12));eq(w.y[3],1);eq(w.mask[3],true);eq(w.lead[3],1.75)
  invariants(c);train(c);canonical(c)
 end
 return 'Three orders; positive wins independently of ambiguous evidence; retraction and narrowing reconcile.'
end)
test('noop_lead_only_candidate_and_serving_guards',function()
 local c=fresh();local w=closed(c,'A',10);assert(cast(c,'one','A',11,3));assert(cast(c,'two','A',11.5,3))
 for i=1,5 do closed(c,'A',13+i*3) end
 c:_Train();local job=assert(c.candidate);local rev=c.corpusRevision;local wr=w.revision
 assert(cast(c,'one','A',11.25,3,2));eq(c.candidate,job);eq(c.corpusRevision,rev);eq(w.revision,wr);eq(w.lead[3],1.25)
 assert(cast(c,'one','A',11.25,3,9));eq(c.candidate,job);eq(c.corpusRevision,rev)
 train(c);local serving=c.model;assert(cast(c,'one','A',11.25,3,10));eq(c.model,serving)
 assert(cast(c,'one','A',11.4,3,11));eq(c.model,nil);invariants(c);train(c);canonical(c)
 return 'Candidate survives lead-only change; serving guards withdraw changed timestamp; semantic noops preserve both.'
end)
test('future_scalar_revision_and_rollback',function()
 local c=fresh();local w=open(c,'A',10);assert(cast(c,'f1','A',11,3));assert(cast(c,'f2','A',11.5,6))
 assert(cast(c,'f1','A',11,3,2,nil,nil,true));assert(cast(c,'f2','A',20,6,2))
 c:Tick(11.25,nil);eq(c.nextCastAt,20);assert(cast(c,'f2','A',11.75,6,3))
 c:Tick(12.25,nil);eq(w.y[6],1);eq(w.y[3],0);eq(c.nextCastAt,nil)
 local x=ns.Copy(w.x);c:Tick(1,nil);check(w.sealed);same(w.x,x);eq(w.y[6],1);eq(c.evidenceTime,1);eq(c.nextCastAt,nil);eq(#c.occurrenceOrder,0)
 train(c);canonical(c);return 'Due scalar survives retraction/retiming; rollback retains observed positive only in sealed history.'
end)
test('gap_positive_transfer_and_retraction',function()
 local c=fresh();local a=open(c,'A',10);local b=open(c,'B',10);c:Gap('test','A');c:Tick(12.25,nil)
 eq(a.mask[3],false);eq(b.mask[3],true);assert(cast(c,'m','B',11,3));train(c);check(c.model~=nil)
 assert(cast(c,'m','A',11,6,2));eq(c.model,nil);eq(a.y[6],1);eq(a.mask[6],true);eq(a.mask[3],false);eq(b.y[3],0);eq(b.mask[3],true)
 assert(cast(c,'m','A',11,6,3,nil,nil,true));eq(a.y[6],0);eq(a.mask[6],false);invariants(c);train(c);canonical(c)
 return 'Actor/family correction transfers positive across covered and censored windows; retraction restores censored mask.'
end)
test('capacity_pause_recreation_and_late_cast',function()
 local c=fresh();local w=open(c,'A',10);for i=1,16 do context(c,'E'..i,10.1,'hostile') end
 check(w.y~=nil and c.actors.A==nil);eq(c.openAfter,12.25)
 context(c,'A',10.2);c:Tick(10.2,true);eq(c.actors.A.window,nil)
 context(c,'A',12.249);c:Tick(12.249,true);eq(c.actors.A.window,nil)
 context(c,'A',12.25);c:Tick(12.25,true);eq(c.actors.A.window.anchor,12.25)
 assert(cast(c,'late','A',11,3));eq(w.y[3],1);eq(w.mask[3],true)
 local x=ns.Copy(w.x);context(c,'A',12.3,'hostile');same(w.x,x);invariants(c)
 return 'Capacity pause reaches resolveAt even after recreation; retained early row still accepts observed positive.'
end)
test('maximum_floor_and_retained_identity',function()
 local c=fresh();closed(c,'A',10);assert(cast(c,'b','A',80,3));assert(cast(c,'b','B',40,6,2));assert(cast(c,'b','A',11,3,3))
 for i=1,128 do assert(c:Aura({recipient='noise',id='f'..i,at=20,spellID=5277})) end
 eq(c.evidenceFloor,80);local ok,why=cast(c,'new-stale','A',12,3);eq(ok,false);eq(why,'outside_retained_history')
 assert(cast(c,'retained','A',81,3));assert(cast(c,'retained','A',11,3,2));eq(c.examples[1].y[3],1)
 assert(cast(c,'retained','A',11,3,3,nil,nil,true));eq(c.examples[1].y[3],0);eq(c.examples[1].mask[3],false)
 invariants(c);train(c);canonical(c);return 'Superseded high timestamp survives retirement; retained ID can correct below floor without granting fresh-ID authority.'
end)
test('copy_and_anchor_isolation',function()
 local c=fresh();context(c,'A',10);assert(c:Aura({recipient='A',id='d',at=8,spellID=22812,expires=11}));local w=open(c,'A',10);local x=ns.Copy(w.x)
 local a=c:GetContext('A',10);a.history[3]=999;a.defensiveWitness.at=0;a.candidates.root.status='changed'
 local f=c:Forecast('A',10);f.outputs[1].candidate.status='changed';local s=c:Status();s.families[1].positive=999;s.gapReasons.changed=1
 eq(c:GetContext('A',10).defensiveWitness.at,8);eq(c:GetContext('A',10).history[3],nil);check(c:GetContext('A',10).candidates.root.status~='changed');check(c:Forecast('A',10).outputs[1].candidate.status~='changed')
 assert(c:Aura({recipient='A',id='d',at=10.5,spellID=22812,expires=20}));same(w.x,x);c:Tick(12.25,nil)
 local save=c:Export();save.examples[1].x[47]=.123;save.examples[1].mask[1]=false;same(w.x,x);eq(w.mask[1],true)
 local w2=open(c,'A',13);if ns.Config.version=='0.1.6-shadow' then check(w2.x[47]~=w.x[47]) end
 invariants(c);return 'All projection/export copies isolate mutation; corrected aura does not rewrite anchored input.'
end)
test('queries_cannot_mature_future',function()
 local c=fresh();local w=open(c,'A',10);assert(cast(c,'f','A',11,3));for i=1,16 do context(c,'X'..i,10.1,'hostile') end
 eq(w.y[3],0);eq(w.mask[3],false);local rev=c.corpusRevision
 for _,t in ipairs({100,0,11,10.5,1000}) do c:GetContext('X16',t);c:Forecast('X16',t);c:Status();c:Export() end
 eq(c.evidenceTime,10.1);eq(c.corpusRevision,rev);eq(w.y[3],0);context(c,'X16',11,'hostile');eq(w.y[3],1);eq(w.mask[3],true)
 invariants(c);train(c);canonical(c);return 'Nonmonotone reads never advance the watermark; Context does.'
end)
test('seal_during_candidate',function()
 local c=fresh();for i=1,8 do local w=closed(c,'A',10+i*3);if i%3==0 then assert(cast(c,'p'..i,'A',w.anchor+1,3)) end end
 c:_Train();local job=assert(c.candidate);local rev=c.corpusRevision;c:ResetSession(c.now);eq(c.candidate,job);eq(c.corpusRevision,rev)
 train(c);eq(#c.modelDependencies,0);canonical(c);local model=c.model;local export=c:Export()
 context(c,'A',c.now+1);assert(cast(c,'p3','A',20,3));same(c:Export(),export);eq(c.model,model)
 return 'Sealing during valid copied candidate replay preserves result and removes raw correction guards.'
end)
test('mixed_stream_outcome_oracle',function()
 for _,seed in ipairs({7,91,431,2177}) do
  local rng=seed;local function random(n) rng=(rng*16807)%2147483647;return 1+math.floor(rng/2147483647*n) end
  local c=fresh();local t=10;local serial=0
  for step=1,700 do
   local op=random(10);local actor='A'..random(20)
   if op<=3 then t=t+random(3)*.125;context(c,actor,t,random(5)==1 and 'hostile' or 'self');c:Tick(t,true)
   elseif op<=6 then
    local existing={};for _,key in ipairs(c.occurrenceOrder) do if c.occurrences[key].kind=='cast' then existing[#existing+1]=c.occurrences[key] end end
    local e=#existing>0 and existing[random(#existing)] or nil;local id,revision
    if e and random(3)==1 then id=e.id;revision=e.revision+random(3) else serial=serial+1;id='c'..serial;revision=1 end
    local at=math.max(0,t+(random(21)-14)*.125);local width=random(5)==1 and .25 or 0
    cast(c,id,actor,at,random(6),revision,math.max(0,at-width),at+width,random(8)==1)
   elseif op==7 then serial=serial+1;c:Aura({id='a'..serial,recipient=actor,spellID=22812,at=math.max(0,t+(random(9)-6)*.125),expires=t+3})
   elseif op==8 then c:Gap('synthetic-gap',actor)
   elseif op==9 then c:GetContext(actor,t+10);c:Forecast(actor,math.max(0,t-5))
   else t=t+.5;c:Tick(t,nil) end
   if step%25==0 then invariants(c) end
   if step==350 then c:ResetSession(t) end
  end
  invariants(c);train(c);canonical(c)
 end
 return 'Four 700-operation streams; periodic full outcome/capacity/nonoverlap checks; four final clean replays.'
end)
return results
