bjarkiLearn 0.1.6-shadow verification bundle

Install the separate bjarkiLearn-0.1.6-shadow.zip. This evidence bundle is not an addon installation.

Reproduce from this directory:
  python -m pip install -r requirements-test.txt
  python run_all.py
  python build_release.py --output dist

An existing Lupa installation can be supplied with --lupa-path PATH. Both lua51 and lua54 are required. The full run is deliberately comprehensive and may take several minutes. The original historical fixtures and reports remain under prior/ and audit015/; raw failed obsolete expectations are not relabeled as passes. inherited/classification.py is the fail-closed gate. For validating already-completed reports without re-executing them use run_all.py --collect-existing.

Start reading at source/bjarkiLearn/VERIFICATION.md, reports-016/verification.json, tests-016/REPORT.txt, inherited/README.md and review-016/final-review.txt. The final whole-source diff is review-016/whole-source.diff. Package source hashes are in package-v0.1.6.json; bundle-files.json hashes every evidence payload file other than itself.

New semantics: six Entangling Roots cast ranks plus Druid root candidate, and separate eight-second witness recency/known inputs. Older learning is rejected because its lost timing/label evidence cannot be reconstructed; the enabled preference is retained. Same-version save/reload rebuilds the new learning.

Offline results do not establish live-client behavior or predictive usefulness. No remote repository publication or game installation occurred in this task.
