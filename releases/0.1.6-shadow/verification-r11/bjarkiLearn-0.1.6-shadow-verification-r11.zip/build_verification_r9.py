"""Run the canonical revision-10 builder in this compatibility namespace.

An isolated namespace preserves platform-model and legacy module callers.
"""
from pathlib import Path as _Path

_implementation = _Path(__file__).with_name('build_verification_r10.py')
exec(compile(_implementation.read_bytes(), str(_implementation), 'exec'), globals())
