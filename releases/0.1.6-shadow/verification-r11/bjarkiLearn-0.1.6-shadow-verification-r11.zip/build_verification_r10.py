"""Compatibility entry point with isolated module globals; canonical builder is r11."""
from pathlib import Path as _Path
_implementation = _Path(__file__).with_name('build_verification_r11.py')
exec(compile(_implementation.read_bytes(), str(_implementation), 'exec'), globals())
