bjarkiLearn 0.1.6-shadow - verification revision 11

Verification tooling only. All fourteen addon installation files remain identical
to the original 0.1.6-shadow addon ZIP. This archive contains tests and evidence;
use the original addon ZIP to install.

Revision-11 repairs the three confirmed revision-10 tooling bugs:
1. The optional completed-copy checker compares resolved source/output paths with
   the same namespace-aware comparison as the canonical builder. It rejects source
   descendants before writes and retains safe native-distinct Unicode siblings.
2. Every checker child uses the existing environment helper before its working
   directory changes. Relative PYTHONPATH directories/ZIPs and explicit dependency
   precedence remain intact; UTF-8 logs and active assertions are preserved.
3. Windows payload capture rejects reserved device-name components before file
   predicates, descent, or exclusions can silently lose them. This covers files,
   directories, ordinary/extended roots, case/extension variants and documented
   COM/LPT superscripts. Near names and non-ASCII lookalikes remain supported.

Reserved names follow a Windows transport-portability policy, including extensions.
This host loses a physical bare NUL file during ordinary capture/extraction, but
its current APIs do round-trip some reserved names with extensions. Rejecting the
documented reserved family keeps the archive usable across ordinary Win32 tools;
the tests and characterization reports do not claim every such name fails here.
The policy applies only on Windows; POSIX keeps those names as ordinary payload.
Microsoft naming rules: https://learn.microsoft.com/en-us/windows/win32/fileio/naming-a-file

Reproduce:
  python -m pip install -r requirements-test.txt
  python -B run_all.py
  python -B build_verification_r11.py --output ../verification-dist

Both commands accept --lupa-path or inherited PYTHONPATH. Run with assertions enabled.
The full runner now executes 26 real mandatory jobs, including 18 checker and 20
reserved-payload regression cases. All 51 old root acceptance assertions remain.
New acceptance gates require exact case inventories, strict pass values, correct
source hashes and truthful producer/platform scope; completed-run seals bind both
new reports and job receipts. Old builders delegate to the canonical r11 builder,
retaining module-local compatibility globals used by unchanged platform models.

After the full run, exercise all 19 completed-copy controls against a fresh copy:
  python -B verification-r10/check_completed.py --bundle . --output ../r11-controls
The output must not exist and must be outside the source bundle. This retained
entry-point path now uses revision11 names. Add --lupa-path if needed. The original
fifteen controls remain, with four additional real NUL file/directory controls.

Exact changed r10 files are under verification-r11/history/. New repair, review,
red/green, mutation and final CLI evidence is under verification-r11/evidence/.
The completed run remains authoritative in reports-016; supplemental evidence is
covered by the final ZIP inventory. Local seals establish byte consistency, not
cryptographic execution attestation. No job or report substitution is used in the
full run or the completed-copy CLI run.

Validation scope: native Windows and ordinary Lua5.1/5.4 with modeled WoW APIs.
POSIX policy models are labeled separately from actual native execution. Native
POSIX full-suite, physical second-drive/UNC-share I/O and live WoW remain unverified.

The following retained text describes earlier revisions and their original counts.
----- Preserved revision-10 explanation -----

bjarkiLearn 0.1.6-shadow - verification revision 10

Revision-10 repairs the two confirmed verification-r9 tooling bugs:
- Equivalent resolved Windows ordinary and extended drive/UNC namespace anchors
  compare consistently for protected-output checks, including reversed spellings
  and missing descendants. Native-distinct Unicode components stay distinct.
- Every enumerated payload name is validated before file predicates or directory
  descent can skip unpaired trailing-dot/space entries. Unsupported Windows names
  fail explicitly; ordinary supported payload and POSIX suffix names are retained.

The new 22-case required suite adds native filesystem controls and a separately
labeled UNC path model. All 48 prior root acceptance predicates and all prior test
sources are preserved. The complete runner executes 24 real jobs.

Install files and Lua runtime remain byte-for-byte 0.1.6-shadow. To reproduce:
  python -m pip install -r requirements-test.txt
  python -B run_all.py
  python -B build_verification_r10.py --output ../verification-dist

Both commands accept --lupa-path. Original evidence remains in historical folders.
Exact pre-repair builder, runner, completion state and README are in
verification-r10/history/. The new red/green evidence and final controls are in
verification-r10/evidence/. Old builder entry points delegate to r10 while retaining
isolated compatibility module globals for the unchanged platform-model tests.

After the full run, completed-copy CLI controls can be reproduced separately:
  python -B verification-r10/check_completed.py --bundle . --output ../r10-controls
Add --lupa-path if needed. The output directory must not already exist. These tests
run real collectors/builders; they do not substitute job reports or the Lua runtime.

Validation scope remains native Windows plus ordinary Lua 5.1/5.4 with modeled WoW
APIs. UNC cases are path-comparison models, not network-share I/O. Native POSIX full
suite, physical second-drive execution and live WoW behavior remain unverified.
Repository publication is recorded separately from these package verification checks.

The remaining explanation below describes the preserved r9 checks and workflow;
its original 23-job/r9 entry-point counts apply to that earlier revision.

----- Preserved explanation of revision 9 -----

bjarkiLearn 0.1.6-shadow - verification revision 9

Verification tooling only. All 14 addon installation files, including the six Lua
runtime modules, remain byte-identical to the original 0.1.6-shadow addon ZIP.
This archive contains tests and evidence; use the original addon ZIP to install.

Reproduce from the extracted directory:
  python -m pip install -r requirements-test.txt
  python -B run_all.py
  python -B build_verification_r9.py --output dist

Both Lupa lua51 and lua54 are required. Supply an existing dependency directory with
--lupa-path PATH, or use inherited PYTHONPATH. Caller-relative entries are anchored
before child working-directory changes; an explicit dependency path takes precedence.
Optimized Python is rejected because the original assertions must execute.

Revision-9 repairs
1. Generated metadata exclusions use the host's filename comparison rules. Windows
   case aliases of the root bundle-files.json cannot become a second archived
   inventory. Unbound reports-016/validation-existing.json case aliases stay out of
   the payload. Manifest-bound validation evidence remains captured with its original
   spelling and bytes; exact snapshot validation still decides whether it matches
   the completed run. Nested inventory names, unrelated files, and POSIX case
   distinctions remain supported. Windows filenames with trailing dots/spaces in a
   component are rejected before capture because ordinary Win32 extraction can
   merge those distinct extended-path entries and overwrite inventory bytes. POSIX
   keeps those names as ordinary payload. This related boundary was confirmed by
   independent review using a real completed-r8 builder and native extraction.
2. The output guard resolves paths, then compares host-normalized path components.
   Native-distinct Unicode directories such as smo[KELVIN SIGN]e are accepted beside
   protected smoke. Real protected roots, case aliases, descendants, and resolving
   links remain rejected before the collector, directory creation, or publication.

Two additional mandatory suites exercise generated metadata (19 cases) and output
paths (24 cases). All 46 revision-8 root assertion predicates and every previous test
source remain. The complete runner executes 23 jobs. Original changed root files and
the prior README are preserved exactly under verification-r9/history/. All eight old
root builder entry points delegate to the same revision-9 acceptance/publication path.
The r8 entry point loads canonical r9 source into its own namespace, preserving
module-local platform models used by unchanged r8 tests; no implementation is copied.

Validate a completed revision-9 run without repeating its full test jobs:
  python -B run_all.py --collect-existing

Run the ten existing workflow controls against isolated copies:
  python -B verification-r4/test_workflow.py --bundle . --output ../workflow-controls

Those focused crash/read-only controls retain their disclosed archived-output
substitutions for unrelated jobs. They do not substitute for the full run, which
executes all 23 real jobs normally. The current standalone r4 workflow imports its
dependency helper from its own bundle, including when targeting historical archives.

Preserved protections
Completed-run seals bind executable inputs, mandatory job receipts, and authoritative
reports and leaf logs. The collector revalidates original semantic assertions,
classifiers and negative controls, full-state aligned comparisons, frozen inputs,
and Lua syntax. Captured bytes are checked again before publication. Local manifests
establish consistency, not cryptographic execution attestation.

Full runs and collectors use a nonblocking OS bundle lock. Full runs execute in unique
sibling stages so abandoned children cannot write into a replacement run. Completion
is published last after hashes and ownership checks. Persistent lock files must not
be deleted while another invocation may use their directory.

Packaging validates staged ZIP and receipt files, locks the output directory and
restores the previous pair after a caught publication failure. This is caught-error
rollback, not crash-atomic replacement of two files. Recoverable backups are retained
if the OS refuses rollback. Outputs may use dist, the bundle root, or an external
directory; payload/input directories remain forbidden. Owned publications, lock
files, transaction artifacts and unbound generated metadata are not evidence payload.

Current authoritative evidence
  reports-016/run-manifest.json
  reports-016/verification.json
  reports-016/full-suite.log
  reports-016/full-suite-exit.json
  reports-016/*-safety.json
  reports-016/inherited/
  verification-r9/evidence/                 Repair, reproduction and review evidence
  bundle-files.json                        SHA-256 of every payload file except itself

Supplemental evidence can be attached after completion without changing executable
inputs. It is covered by the final archive inventory; the completed-run seal covers
its declared inputs and outputs. Historical reports describe their original runs.
Historical documentation and evidence remain under verification-r2 through r8,
verification-r9/history, prior, audit015 and baseline.

Validation scope
The release run uses real Lupa on Windows and ordinary Lua 5.1/5.4 with modeled WoW
APIs. Tests label POSIX comparison models and optional native link capabilities
separately. No native POSIX full-suite, physical second-drive, live WoW, rendering,
taint-safety, or predictive-usefulness claim is made. The Windows read-only tests
remain platform-specific. No repository changes are published by this repair.
