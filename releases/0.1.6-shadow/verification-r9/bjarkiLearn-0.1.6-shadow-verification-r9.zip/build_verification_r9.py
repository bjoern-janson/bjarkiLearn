"""Package a completed revision-9 run and the exact evidence bytes it verified."""

from pathlib import Path
import argparse
import hashlib
import json
import os
import subprocess
import sys
import zipfile

import verification_state
from verification_lock import BUNDLE_LOCK_NAME, PUBLISH_LOCK_NAME
from verification_publish import publish_archive_pair
from verification_environment import child_environment


ROOT = Path(__file__).resolve().parent
ARCHIVE_NAME = 'bjarkiLearn-0.1.6-shadow-verification-r9.zip'
RECEIPT_NAME = 'bjarkiLearn-0.1.6-shadow-verification-r9-receipt.json'
PAYLOAD_FOLDERS = (
    'source', 'baseline', 'prior', 'audit015', 'tests-016', 'inherited',
    'review-016', 'smoke', 'reports-016', 'docs', 'verification-r2',
    'verification-r3', 'verification-r4', 'verification-r5', 'verification-r6', 'verification-r7', 'verification-r8', 'verification-r9',
)
CACHE_PARTS = {'__pycache__', '.pytest_cache', '.mypy_cache', '.ruff_cache',
               '.cache', 'tmp', 'temp', '.tmp'}
EXCLUDED_FILENAMES = {BUNDLE_LOCK_NAME, PUBLISH_LOCK_NAME,
    'bjarkiLearn-0.1.6-shadow.zip', 'bjarkiLearn-0.1.6-shadow-receipt.json',
    'bjarkiLearn-0.1.6-shadow-verification.zip',
    'bjarkiLearn-0.1.6-shadow-verification-receipt.json',
    *('bjarkiLearn-0.1.6-shadow-verification-r' + str(revision) + suffix
      for revision in (1, 2, 3, 4, 5, 6, 7, 8, 9) for suffix in ('.zip', '-receipt.json'))}


def own_publication_file(name):
    name = os.path.normcase(name)
    owned_names = {os.path.normcase(own) for own in EXCLUDED_FILENAMES}
    if name in owned_names:
        return True
    # Root output is supported. A concurrent builder may be capturing while a
    # publisher has private backups, and failed OS rollback may retain a backup.
    # Neither is evidence payload, even though the prior ZIP's bytes are valid.
    return (Path(name).suffix in {'.tmp', '.bak'}
            and any(name.startswith('.' + own + '.') for own in owned_names))


def validate_output(root, output):
    """Resolve aliases before any directory, lock or collector write occurs."""
    root, output = Path(root).resolve(), Path(output).resolve()
    # WindowsPath equality folds some native-distinct Unicode names. Compare
    # resolved components with the host's filename rules, not Unicode folding.
    output_parts = tuple(os.path.normcase(part) for part in output.parts)
    for folder in PAYLOAD_FOLDERS:
        protected = (root / folder).resolve()
        protected_parts = tuple(os.path.normcase(part) for part in protected.parts)
        if output_parts[:len(protected_parts)] == protected_parts:
            raise ValueError('Output directory overlaps bundle payload/input tree: ' + str(output))
    return output


def sha(data):
    return hashlib.sha256(data).hexdigest()


def json_bytes(value):
    return (json.dumps(value, indent=2) + '\n').encode('utf-8')


def collect_payload(root, manifest=None):
    """Capture once; subsequent checks and ZIP writes use only these bytes."""
    root = Path(root).resolve()
    bound = set()
    if manifest is not None:
        bound.update(manifest['input_hashes'])
        bound.update(manifest['output_hashes'])
    bound = {os.path.normcase(name) for name in bound}
    files = {}

    def capture(path):
        rel = path.relative_to(root)
        name = rel.as_posix()
        # Extended Windows filenames can exist on disk yet alias another file
        # through the ordinary Win32 reads/extraction used by this bundle.
        if os.path.sep == '\\' and any(part.endswith((' ', '.')) for part in rel.parts):
            raise RuntimeError('Payload name cannot round-trip through Win32 extraction: ' + name)
        if any(part in CACHE_PARTS for part in rel.parts):
            return
        if path.suffix.lower() in {'.pyc', '.pyo', '.tmp', '.temp', '.partial'}:
            return
        if rel.parts[:2] == ('inherited', 'runs'):
            return
        # Compare full relative identities: nested names are ordinary payload.
        # Preserve captured spelling so exact snapshot checks remain authoritative.
        metadata_name = os.path.normcase(name)
        if (metadata_name == os.path.normcase('reports-016/validation-existing.json')
                and metadata_name not in bound):
            return
        if metadata_name == os.path.normcase('bundle-files.json'):
            return
        if own_publication_file(path.name):
            return
        if path.is_symlink() or not path.resolve().is_relative_to(root):
            raise RuntimeError('Payload paths must stay inside the bundle: ' + name)
        files[name] = path.read_bytes()

    for folder in PAYLOAD_FOLDERS:
        for path in sorted((root / folder).rglob('*')):
            if path.is_file():
                capture(path)
    for path in sorted(root.iterdir()):
        if path.is_file():
            capture(path)
    return files


def validate_install(files):
    """Retain the existing exact fourteen-file runtime contract."""
    contract = json.loads(files['inherited/aligned-contract.json'])
    source = {
        name.removeprefix('source/bjarkiLearn/'): sha(data)
        for name, data in files.items()
        if name.startswith('source/bjarkiLearn/')
    }
    if len(source) != 14 or source != contract['source']:
        raise RuntimeError('Captured addon differs from the pinned fourteen-file 0.1.6 runtime')
    # Preserve the original builders' independent-review acceptance checks.
    review = json.loads(files['review-016/final-source.json'])
    if review['source_hashes'] != source or not review['tested_runtime_unchanged']:
        raise RuntimeError('Final source review is stale')
    for name in ('review-016/final-review.txt', 'verification-r2/independent-review.txt'):
        if name not in files:
            raise RuntimeError('Missing independent final review: ' + name)
    if json.loads(files['verification-r2/full-suite-exit.json'])['exit_code'] != 0:
        raise RuntimeError('Historical revision-2 verification did not complete')
    return source


def write_archive(path, files):
    with zipfile.ZipFile(path, 'w', compression=zipfile.ZIP_DEFLATED,
                         compresslevel=9) as archive:
        for name, data in sorted(files.items()):
            entry = zipfile.ZipInfo(name, date_time=(2026, 10, 29, 0, 0, 0))
            entry.compress_type = zipfile.ZIP_DEFLATED
            entry.external_attr = 0o100644 << 16
            archive.writestr(entry, data, compress_type=zipfile.ZIP_DEFLATED,
                             compresslevel=9)


def validate_archive(path, files, manifest):
    with zipfile.ZipFile(path) as archive:
        if archive.testzip() is not None:
            raise RuntimeError('Staged archive CRC verification failed')
        names = archive.namelist()
        if len(names) != len(files) or set(names) != set(files):
            raise RuntimeError('Staged archive inventory differs from captured payload')
        archived = {name: archive.read(name) for name in names}
    if archived != files:
        raise RuntimeError('Staged archive bytes differ from captured payload')
    expected = {name: sha(data) for name, data in archived.items()
                if name != 'bundle-files.json'}
    if json.loads(archived['bundle-files.json']) != expected:
        raise RuntimeError('Staged archive inventory manifest verification failed')
    verification_state.verify_snapshot(archived, manifest)
    validate_install(archived)


def build(root, output, lupa_path=None):
    root = Path(root).resolve()
    output = validate_output(root, output)
    if sys.flags.optimize:
        raise RuntimeError('Verification packaging requires Python assertions enabled')
    if lupa_path is not None:
        lupa_path = Path(lupa_path).resolve()
    before = verification_state.validate_completed(root)
    command = [sys.executable, '-B', str(root / 'run_all.py'), '--collect-existing']
    environment = child_environment(lupa_path)
    if lupa_path is not None:
        command.extend(['--lupa-path', str(lupa_path)])
    # Run the real collector: its existing per-case, classifier, frozen-input,
    # aligned-proof and syntax gates remain the authority for acceptance.
    subprocess.run(command, cwd=root, env=environment, check=True)
    manifest = verification_state.validate_completed(root)
    if manifest != before:
        raise RuntimeError('Completed run changed while collecting verification evidence')
    files = collect_payload(root, manifest)
    # A file may change after collector validation. Validate the actual captured
    # bytes, including the run manifest, before creating any archive.
    verification_state.verify_snapshot(files, manifest)
    source = validate_install(files)
    files['bundle-files.json'] = json_bytes({name: sha(data)
                                           for name, data in sorted(files.items())})
    target = output / ARCHIVE_NAME

    def prepare(staged, staged_receipt):
        write_archive(staged, files)
        validate_archive(staged, files, manifest)
        result = dict(
            path=str(target), sha256=sha(staged.read_bytes()),
            bytes=staged.stat().st_size, files=len(files),
            runtime_version='0.1.6-shadow', verification_revision=9,
            run_id=manifest['run_id'], install_files_unchanged=len(source),
            collector_revalidated=True,
            captured_run_inputs_and_outputs_verified=True,
            crc_inventory_manifest_and_every_archived_byte_verified=True,
        )
        # A receipt write failure must occur before either deliverable changes.
        staged_receipt.write_bytes(json_bytes(result))
        if json.loads(staged_receipt.read_bytes()) != result:
            raise RuntimeError('Staged publication receipt verification failed')
        return result

    # The helper holds an OS lock throughout staging and caught-error rollback.
    # The real collector above owns its own bundle lock; do not nest that lock.
    return publish_archive_pair(output, ARCHIVE_NAME, RECEIPT_NAME, prepare)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=ROOT / 'dist')
    parser.add_argument('--lupa-path', type=Path,
                        help='Optional Lupa dependency directory (resolved to an absolute path).')
    arguments = parser.parse_args(argv)
    result = build(ROOT, arguments.output, arguments.lupa_path)
    print(json.dumps(result, indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
