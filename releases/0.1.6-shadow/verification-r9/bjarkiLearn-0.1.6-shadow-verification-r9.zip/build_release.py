"""Compatibility entry point; package the verified revision-4 evidence bundle."""

from build_verification_r4 import main


if __name__ == '__main__':
    raise SystemExit(main())
