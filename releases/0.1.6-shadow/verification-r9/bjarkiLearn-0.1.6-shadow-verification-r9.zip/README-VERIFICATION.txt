bjarkiLearn 0.1.6-shadow - verification revision 9

Verification tooling only. All 14 addon installation files, including the six Lua
runtime modules, remain byte-identical to the original 0.1.6-shadow addon ZIP.
This archive contains tests and evidence; use the original addon ZIP to install.

Reproduce from the extracted directory:
  python -m pip install -r requirements-test.txt
  python -B run_all.py
  python -B build_verification_r9.py --output dist

Both Lupa lua51 and lua54 are required. Supply an existing dependency directory with
--lupa-path PATH, or use inherited PYTHONPATH. Caller-relative entries are anchored
before child working-directory changes; an explicit dependency path takes precedence.
Optimized Python is rejected because the original assertions must execute.

Revision-9 repairs
1. Generated metadata exclusions use the host's filename comparison rules. Windows
   case aliases of the root bundle-files.json cannot become a second archived
   inventory. Unbound reports-016/validation-existing.json case aliases stay out of
   the payload. Manifest-bound validation evidence remains captured with its original
   spelling and bytes; exact snapshot validation still decides whether it matches
   the completed run. Nested inventory names, unrelated files, and POSIX case
   distinctions remain supported. Windows filenames with trailing dots/spaces in a
   component are rejected before capture because ordinary Win32 extraction can
   merge those distinct extended-path entries and overwrite inventory bytes. POSIX
   keeps those names as ordinary payload. This related boundary was confirmed by
   independent review using a real completed-r8 builder and native extraction.
2. The output guard resolves paths, then compares host-normalized path components.
   Native-distinct Unicode directories such as smo[KELVIN SIGN]e are accepted beside
   protected smoke. Real protected roots, case aliases, descendants, and resolving
   links remain rejected before the collector, directory creation, or publication.

Two additional mandatory suites exercise generated metadata (19 cases) and output
paths (24 cases). All 46 revision-8 root assertion predicates and every previous test
source remain. The complete runner executes 23 jobs. Original changed root files and
the prior README are preserved exactly under verification-r9/history/. All eight old
root builder entry points delegate to the same revision-9 acceptance/publication path.
The r8 entry point loads canonical r9 source into its own namespace, preserving
module-local platform models used by unchanged r8 tests; no implementation is copied.

Validate a completed revision-9 run without repeating its full test jobs:
  python -B run_all.py --collect-existing

Run the ten existing workflow controls against isolated copies:
  python -B verification-r4/test_workflow.py --bundle . --output ../workflow-controls

Those focused crash/read-only controls retain their disclosed archived-output
substitutions for unrelated jobs. They do not substitute for the full run, which
executes all 23 real jobs normally. The current standalone r4 workflow imports its
dependency helper from its own bundle, including when targeting historical archives.

Preserved protections
Completed-run seals bind executable inputs, mandatory job receipts, and authoritative
reports and leaf logs. The collector revalidates original semantic assertions,
classifiers and negative controls, full-state aligned comparisons, frozen inputs,
and Lua syntax. Captured bytes are checked again before publication. Local manifests
establish consistency, not cryptographic execution attestation.

Full runs and collectors use a nonblocking OS bundle lock. Full runs execute in unique
sibling stages so abandoned children cannot write into a replacement run. Completion
is published last after hashes and ownership checks. Persistent lock files must not
be deleted while another invocation may use their directory.

Packaging validates staged ZIP and receipt files, locks the output directory and
restores the previous pair after a caught publication failure. This is caught-error
rollback, not crash-atomic replacement of two files. Recoverable backups are retained
if the OS refuses rollback. Outputs may use dist, the bundle root, or an external
directory; payload/input directories remain forbidden. Owned publications, lock
files, transaction artifacts and unbound generated metadata are not evidence payload.

Current authoritative evidence
  reports-016/run-manifest.json
  reports-016/verification.json
  reports-016/full-suite.log
  reports-016/full-suite-exit.json
  reports-016/*-safety.json
  reports-016/inherited/
  verification-r9/evidence/                 Repair, reproduction and review evidence
  bundle-files.json                        SHA-256 of every payload file except itself

Supplemental evidence can be attached after completion without changing executable
inputs. It is covered by the final archive inventory; the completed-run seal covers
its declared inputs and outputs. Historical reports describe their original runs.
Historical documentation and evidence remain under verification-r2 through r8,
verification-r9/history, prior, audit015 and baseline.

Validation scope
The release run uses real Lupa on Windows and ordinary Lua 5.1/5.4 with modeled WoW
APIs. Tests label POSIX comparison models and optional native link capabilities
separately. No native POSIX full-suite, physical second-drive, live WoW, rendering,
taint-safety, or predictive-usefulness claim is made. The Windows read-only tests
remain platform-specific. No repository changes are published by this repair.
