"""Compatibility entry point; all packaging uses revision-7 acceptance gates."""

from build_verification_r7 import *


if __name__ == '__main__':
    raise SystemExit(main())
