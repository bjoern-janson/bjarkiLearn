"""Classifier acceptance/rejection controls; on-disk evidence never changes."""
import contextlib, io, runpy, sys, argparse
from pathlib import Path
import run

def report(data, suite):
    return next(iter(next(j for j in data['jobs'] if j['suite']==suite)['reports'].values()))

def retired_error(data):
    next(r for r in report(data,'audit012_core') if r['passed'] is False)['error']='injected different defect with same case name'

def reload_failure(data):
    next(r for r in report(data,'audit015_integration')['comparisons'] if r['kind']=='native_saved_reload')['passed']=False

def runtime_change(data):data['source_before']['Rules.lua']='0'*64
def failed_aligned(data):data['cases'][0]['passed']=False
def missing_aligned(data):data['cases'].pop()
def duplicate_aligned(data):data['cases'][-1]=dict(data['cases'][0])
def wrong_aligned_hash(data):data['source_hashes']['Rules.lua']='0'*64
def wrong_reference_hash(data):data['reference_hashes']['Core.lua']='0'*64
def wrong_ledger(data):data['adaptations'][0]['replacement']='unexpected semantics'
def wrong_verifier(data):data['verifier_hashes']['aligned.py']='0'*64
def no_preservation(data):data['source_unchanged']=False
def reduced_coverage(data):
    # Internally consistent aggregate still cannot bypass original case coverage.
    data['cases'][0]['equalLeaves']-=1;data['counts']['equalLeaves']-=1
def wrong_raw_identity(data):report(data,'refactor_differential')['cases'][0]['name']='unexpected case'
def raw_pass(data):report(data,'refactor_differential')['cases'][0]['passed']=True
def scoped_failure(data):data['cases'][0]['passed']=False
def absence(data):raise FileNotFoundError('injected missing aligned proof')
def first_error(data, text):
    for row in report(data,'refactor_differential')['cases']:row['error']=text

# Preserve all three original negative controls, then challenge the new proof.
CONTROLS=[
 ('same_case_different_error_rejected','raw.json',retired_error,1),
 ('new_within_release_reload_failure_rejected','raw.json',reload_failure,1),
 ('changed_runtime_hash_rejected','raw.json',runtime_change,1),
 ('failed_aligned_case_rejected','aligned-reference.json',failed_aligned,1),
 ('missing_aligned_case_rejected','aligned-reference.json',missing_aligned,1),
 ('duplicated_aligned_case_rejected','aligned-reference.json',duplicate_aligned,1),
 ('changed_aligned_runtime_rejected','aligned-reference.json',wrong_aligned_hash,1),
 ('changed_reference_rejected','aligned-reference.json',wrong_reference_hash,1),
 ('changed_adaptation_rejected','aligned-reference.json',wrong_ledger,1),
 ('changed_verifier_rejected','aligned-reference.json',wrong_verifier,1),
 ('missing_preservation_rejected','aligned-reference.json',no_preservation,1),
 ('reduced_assertion_coverage_rejected','aligned-reference.json',reduced_coverage,1),
 ('changed_raw_case_rejected','raw.json',wrong_raw_identity,1),
 ('unexpected_raw_pass_rejected','raw.json',raw_pass,1),
 ('existing_scoped_failure_rejected','scoped-repetition.json',scoped_failure,1),
 ('absent_aligned_proof_rejected','aligned-reference.json',absence,1),
 ('metadata_first_diagnostic_accepted','raw.json',lambda d:first_error(d,'export.compat old ~= features48-v2'),0),
 ('root_feature_first_diagnostic_accepted','raw.json',lambda d:first_error(d,'nativeDelivery.core.actors.Player-1-Q.window.x.36 0 ~= 1'),0),
 ('witness_first_diagnostic_accepted','raw.json',lambda d:first_error(d,'pure.core.actors.P.window.x.47 1 ~= 0.875'),0),
]

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output-dir',type=Path,default=run.REPORTS);args=parser.parse_args()
    original_read,original_save=run.read,run.save;results=[]
    for name,target,mutate,expected in CONTROLS:
        captured=[]
        def read(path):
            data=original_read(path)
            if path==run.REPORTS/target:mutate(data)
            return data
        run.read=read;run.save=lambda path,data:captured.append(data)
        output=io.StringIO();exit_code=None
        try:
            with contextlib.redirect_stdout(output):runpy.run_path(str(Path(__file__).with_name('classification.py')),run_name='__main__')
        except SystemExit as exc:exit_code=exc.code
        finally:run.read,run.save=original_read,original_save
        ok=(exit_code==expected and len(captured)==1 and captured[0]['passed']==(expected==0)
            and bool(captured[0]['unexpected_failures'])==(expected!=0))
        results.append(dict(name=name,passed=ok,exit_code=exit_code,expected_exit=expected,
            reasons=captured[0]['unexpected_failures'] if captured else []))
    result=dict(passed=all(r['passed'] for r in results),cases=results,total=len(results),
        negative_controls=16,diagnostic_order_controls=3,
        scope='In-memory report mutations. Original three rejection controls preserved; raw first-error text cannot alter a decision backed by the complete pinned aligned proof.')
    original_save(args.output_dir/'classification-negative-controls.json',result)
    print(result)
    return int(not result['passed'])

if __name__=='__main__':raise SystemExit(main())
