"""Run original rich traces as per-release deterministic repeatability controls.

Old cross-version equality is explicitly not claimed. Every assertion and full
snapshot comparison remains, but both namespaces load the SAME exact candidate.
The sole fixture expectation update is the explicit semantic compatibility key.
"""
from pathlib import Path
import argparse,hashlib,importlib,json,sys
from run import ROOT,PRIOR,REPORTS,hashes,save
p=argparse.ArgumentParser();p.add_argument('--source',type=Path,default=ROOT/'source/bjarkiLearn');p.add_argument('--lupa-path',type=Path);a=p.parse_args()
if a.lupa_path:sys.path.insert(0,str(a.lupa_path))
source=a.source.resolve();before=hashes(source);rows=[];changes=[]
old='learn1/forever16001-provisional1/features48-v1/cast-delivery-v1/h2/player-combat-v1/mlp12-sgd4-v1'
new='learn1/forever16001-provisional2/features48-v2/cast-delivery-v2/h2/player-combat-v1/mlp12-sgd4-v1'
fixtures=[('refactor_invariants_and_repetition',PRIOR/'tests-refactor/independent/probes.lua'),('audit015_randomized_repetition',ROOT/'audit015/audit/core/differential.lua'),('review014_invariants_and_repetition',PRIOR/'review-0.1.4/probes.lua'),('audit014_invariants_and_repetition',PRIOR/'tests-refactor/legacy/audit014/core/probes.lua')]
def plain(v):return {str(k):plain(x) for k,x in v.items()} if hasattr(v,'items') else v
for name,path in fixtures:
 original=path.read_text(encoding='utf-8-sig');code=original
 if name=='refactor_invariants_and_repetition':
  assert original.count(old)==1;code=original.replace(old,new)
  changes.append(dict(file=path.relative_to(ROOT).as_posix(),original=old,replacement=new,count=1,reason='Fixed-resource test must require exact0.1.6 semantic key; all other assertions unchanged.',original_sha256=hashlib.sha256(original.encode()).hexdigest(),execution_sha256=hashlib.sha256(code.encode()).hexdigest()))
 for engine in ('lua51','lua54'):
  lua=importlib.import_module('lupa.'+engine).LuaRuntime(unpack_returned_tuples=True)
  def load():
   ns=lua.table()
   for file in ('Bootstrap.lua','Rules.lua','Network.lua','Core.lua','Adapter.lua'):lua.execute((source/file).read_text(encoding='utf-8-sig'),'bjarkiLearn',ns)
   return ns
  result=lua.execute(code,load(),load())
  rows.extend(dict(suite=name,engine=engine,**plain(r)) for _,r in result.items())
after=hashes(source)
report=dict(passed=before==after and all(r['passed'] for r in rows),source_hashes=before,source_unchanged=before==after,cases=rows,total=len(rows),passed_count=sum(r['passed'] for r in rows),adaptations=changes,scope='Per-release candidate assertions and deterministic repeatability of full original traces. Two independent candidate namespaces; NOT old/new model equivalence and NOT replacement evidence of feature semantic correctness. Original cross-version failures remain in raw reports.')
save(REPORTS/'scoped-repetition.json',report)
print(json.dumps({'passed':report['passed'],'total':len(rows),'failures':[r for r in rows if not r['passed']]}))
sys.exit(0 if report['passed'] else 1)

