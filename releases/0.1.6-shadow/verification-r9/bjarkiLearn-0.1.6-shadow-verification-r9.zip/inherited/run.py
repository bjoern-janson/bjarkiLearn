"""Execute all inherited leaf suites without fail-fast; preserve raw failures."""
from pathlib import Path
import argparse, hashlib, importlib.util, json, os, shutil, subprocess, sys, tempfile, time
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent;PRIOR=ROOT/'prior';REPORTS=ROOT/'reports-016/inherited'
IGNORE=shutil.ignore_patterns('runs','__pycache__','*.pyc')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def hashes(root):return {p.relative_to(root).as_posix():sha(p) for p in sorted(root.rglob('*')) if p.is_file() and not {'runs','__pycache__'}.intersection(p.relative_to(root).parts)}
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def save(p,data):
 p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
def stage(source,label):
 scratch=Path(tempfile.mkdtemp(prefix=label+'-',dir=HERE/'runs'));legacy=scratch/'legacy';legacy.mkdir()
 shutil.copytree(PRIOR/'tests-refactor/legacy/audit014',legacy/'audit014',ignore=IGNORE)
 shutil.copyfile(PRIOR/'tests-refactor/legacy/audit014-hashes.json',legacy/'audit014-hashes.json')
 spec=importlib.util.spec_from_file_location('prior_stage',PRIOR/'tests-refactor/legacy/run.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
 mod.HERE=legacy # Only staging output changes; ROOT remains read-only prior.
 target,provenance=mod.stage(source,True,label)
 for name in ('tests-refactor/independent','review-0.1.5'):shutil.copytree(PRIOR/name,target/name,ignore=IGNORE)
 for name in ('tests-refactor/contracts.py','tests-refactor/contracts.lua'):
  (target/name).parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(PRIOR/name,target/name)
 shutil.copytree(ROOT/'audit015/audit',target/'audit015/audit',ignore=IGNORE)
 shutil.copytree(PRIOR/'fixtures',target/'audit015/verification/fixtures',ignore=IGNORE)
 pin=target/'audit015/audit/core/run.py';old="SOURCE_CORE = '3766ae3f630f5f4aa072242411d9768a3b7899a39ea9bf5a43bdb3010afa800a'";new='SOURCE_CORE = '+repr(sha(source/'Core.lua'))
 text=pin.read_text();assert text.count(old)==1;pin.write_text(text.replace(old,new),encoding='utf-8')
 additions=[{'file':'audit015/audit/core/run.py','original':old,'replacement':new,'reason':'Retarget exact source guard; baseline remains pinned. No assertions changed.'}]
 pin=target/'audit014/integration/run.py';old="baseline=r/'verification/baseline-0.1.3/source/bjarkiLearn'";new="baseline=r/'baseline-0.1.4/source/bjarkiLearn'"
 text=pin.read_text();assert text.count(old)==1;pin.write_text(text.replace(old,new),encoding='utf-8')
 additions.append({'file':'audit014/integration/run.py','original':old,'replacement':new,'reason':'Identical baseline redirect used by prior 0.1.5 aggregate; all comparisons retained.'})
 provenance['additional_execution_adaptations']=additions;save(target/'inherited-stage.json',provenance)
 return target,provenance
def jobs(t):
 s=str(t/'source/bjarkiLearn');b=str(t/'baseline-0.1.4/source/bjarkiLearn');rows=[]
 def job(name,path,extra=(),output=None):return {'name':name,'argv':[path,*extra],'reports':[output or 'fresh-reports/'+name+'.json']}
 for name,path,out in [('main','review-main/run.py','review-main/results.json'),('warm','review-main/run_warm.py','review-main/warm-results.json'),('core','review-core/probe_core.py','review-core/results.json'),('network','review-network/audit_network.py','review-network/results.json'),('adapter','review-adapter/probe.py','review-adapter/results.json')]:
  code="import run_existing;run_existing.ensure_runtime();row,raw=run_existing.execute_runner("+repr(name)+','+repr(path)+','+repr(out)+");raise SystemExit(row['exit_code'])"
  rows.append(job('existing_'+name,'-c',[code],out))
 def regular(name,path,extra=()):
  out='fresh-reports/'+name+'.json';rows.append(job(name,path,['--source',s,'--output',str(t/out),*extra],out))
 regular('retention','tests/run_retention.py');regular('long_integration','review-integration/run.py')
 rows.append(job('fresh_review010','review-fresh/run.py',output='review-fresh/results.json'))
 regular('audit_controls','run_audit_controls.py');regular('registration','new-tests/registration/run.py');regular('restore','new-tests/restore/run.py')
 regular('seeds','new-tests/seeds/run_seed_regressions.py',['--baseline',str(t/'baseline-0.1.1/source/bjarkiLearn')])
 regular('fresh_review012','review-0.1.2/run.py');regular('audit012_core','audit-0.1.2/core/run.py')
 regular('audit012_native','audit-0.1.2/native/run.py',['--bus',str(t/'fixtures/SharedEvidence.lua')]);regular('audit012_network_restore','audit-0.1.2/network-restore/run.py')
 regular('reset_core','tests-reset/run_core.py');regular('reset_native','tests-reset/native/run.py');regular('review013','review-0.1.3/run.py')
 regular('audit013_core','audit-0.1.3/audit/core/run.py');regular('audit013_native','audit-0.1.3/audit/native/run.py');regular('audit013_network','audit-0.1.3/audit/network-restore/run.py')
 regular('audit013_integration','audit-0.1.3/audit/integration/run.py',['--baseline',str(t/'baseline-0.1.3/source/bjarkiLearn')])
 regular('temporal','tests-time/run.py');regular('temporal_independent','tests-time/independent/run.py');regular('normalized_legacy','tests-time/run_normalized_legacy.py');regular('reset_repro','tests-reset/run_repro.py');regular('review014','review-0.1.4/run.py')
 regular('audit014_core','audit014/core/run.py',['--baseline',str(t/'baseline-0.1.3/source/bjarkiLearn')]);regular('audit014_native','audit014/native/run.py',['--bus',str(t/'fixtures/SharedEvidence.lua')]);regular('audit014_network_restore','audit014/network-restore/run.py');regular('audit014_integration','audit014/integration/run.py')
 regular('refactor_contracts','tests-refactor/contracts.py');regular('refactor_differential','tests-refactor/independent/run.py',['--baseline',b])
 rows.append(job('policy_matrix','review-0.1.5/run_policy_matrix.py',output='review-0.1.5/policy-matrix-results.json'))
 for name in ('core','native','network-restore','integration'):regular('audit015_'+name,'audit015/audit/'+name+'/run.py',['--baseline',b])
 return rows
def execute(target,label,selected,env):
 output=REPORTS/label;output.mkdir(parents=True,exist_ok=True);result=[]
 for job in selected:
  for name in job['reports']:
   p=target/name;p.parent.mkdir(parents=True,exist_ok=True)
   if p.exists():p.unlink()
  start=time.perf_counter();log=output/(job['name']+'.txt');print(label+': '+job['name'],flush=True)
  with log.open('w',encoding='utf-8') as stream:process=subprocess.run([sys.executable,*job['argv']],cwd=target,env=env,stdout=stream,stderr=subprocess.STDOUT)
  reports={name:read(target/name) for name in job['reports'] if (target/name).exists()}
  row={'suite':job['name'],'exit_code':process.returncode,'seconds':round(time.perf_counter()-start,3),'command':job['argv'],'log':str(log.relative_to(ROOT)),'reports':reports}
  save(output/(job['name']+'.json'),row);result.append(row);print(label+': '+job['name']+' exit='+str(process.returncode),flush=True)
 save(output/'jobs.json',result);return result
def main():
 p=argparse.ArgumentParser();p.add_argument('--source',type=Path,default=ROOT/'source/bjarkiLearn');p.add_argument('--lupa-path',type=Path);p.add_argument('--mode',choices=['raw','baseline','adapted'],default='raw');p.add_argument('--stage',type=Path);p.add_argument('--only',nargs='*');a=p.parse_args()
 (HERE/'runs').mkdir(parents=True,exist_ok=True);REPORTS.mkdir(parents=True,exist_ok=True)
 frozen={n:hashes(ROOT/n) for n in ('prior','baseline','audit015')};source=(ROOT/'baseline/source/bjarkiLearn') if a.mode=='baseline' else a.source.resolve();before=hashes(source)
 env=dict(os.environ);env['PYTHONDONTWRITEBYTECODE']='1'
 if a.lupa_path:env['PYTHONPATH']=str(a.lupa_path)+os.pathsep+env.get('PYTHONPATH','')
 target,provenance=stage(source,a.mode) if not a.stage else (a.stage,read(a.stage/'inherited-stage.json'))
 if a.mode=='adapted':
  from semantics import apply
  provenance['semantic_adaptations']=apply(target)
 selected=jobs(target)
 if a.only:selected=[j for j in selected if j['name'] in a.only]
 results=execute(target,a.mode,selected,env);after=hashes(source);unchanged={n:frozen[n]==hashes(ROOT/n) for n in frozen}
 report={'mode':a.mode,'stage':str(target),'source':str(source),'source_before':before,'source_after':after,'source_unchanged':before==after,'preserved_trees_unchanged':unchanged,'preserved_tree_hashes':frozen,'provenance':provenance,'jobs':results,'execution_completed':True,'all_jobs_exit_zero':all(j['exit_code']==0 for j in results),'claim_ceiling':'Raw execution only. Nonzero exits and historical comparisons are not passes. See classification. Offline Lua5.1/5.4 with modeled WoW APIs.'}
 report['staged_source_hashes_after']=hashes(target/'source/bjarkiLearn');report['staged_source_unchanged']=provenance['staged_source_hashes']==report['staged_source_hashes_after'];assert report['staged_source_unchanged'],'Staged source changed'
 save(REPORTS/(a.mode+'.json'),report);assert all(unchanged.values()),'Preserved source changed'
 assert {n:h for n,h in before.items() if n.endswith('.lua')}=={n:h for n,h in after.items() if n.endswith('.lua')},'Runtime changed during tests'
 print(json.dumps({'mode':a.mode,'jobs':len(results),'nonzero':[j['suite'] for j in results if j['exit_code']],'preserved_trees_unchanged':unchanged}),flush=True)
if __name__=='__main__':main()


