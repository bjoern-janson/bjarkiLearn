"""Independent semantic boundaries and exercised candidate-only fault controls.

Original fixtures and runtime files remain byte-identical. Each fault runs in a
fresh Lua namespace against the same aligned reference and unmodified case body.
The paired clean run must pass, and the fault must be exercised and rejected.
"""
from pathlib import Path
import argparse
import hashlib
import importlib
import json
import sys

sys.dont_write_bytecode = True
import aligned
from run import REPORTS, hashes, save, sha


PREFIX = '''local ns = ...
__alignedMutationHits = 0
local function hit() __alignedMutationHits = __alignedMutationHits + 1 end
'''

MUTATIONS = [
    ('druid_root_feature36', 'native_adapter_cast_aura_aliases_and_reset', '''
local original = ns.Rules.Features
ns.Rules.Features = function(actor, now, evidence)
    local x = original(actor, now, evidence)
    if actor.class == "DRUID" and x[36] == 1 then x[36] = 0; hit() end
    return x
end
'''),
    ('witness_recency_feature47', 'asof_cast_aura_projections_are_copied_and_pure', '''
local original = ns.Rules.Features
ns.Rules.Features = function(actor, now, evidence)
    local x = original(actor, now, evidence)
    if x[48] == 1 and x[47] < 1 then x[47] = 1; hit() end
    return x
end
'''),
    ('unrelated_feature35', 'asof_cast_aura_projections_are_copied_and_pure', '''
local original = ns.Rules.Features
ns.Rules.Features = function(actor, now, evidence)
    local x = original(actor, now, evidence)
    x[35] = 1 - x[35]; hit()
    return x
end
'''),
    ('forecast_target_metadata', 'actor_revision_and_cached_forecast_invalidation', '''
local original = ns.Core.Forecast
ns.Core.Forecast = function(self, ...)
    local forecast = original(self, ...)
    if forecast then forecast.target = "cast-delivery-control-corruption"; hit() end
    return forecast
end
'''),
    ('model_weight_scalar', 'training_candidate_exact_state_and_correction_cancellation', '''
local original = ns.Models.New
ns.Models.New = function(...)
    local model = original(...)
    if model then model.hiddenWeights[1][1] = model.hiddenWeights[1][1] + 0.125; hit() end
    return model
end
'''),
    ('corrected_lead', 'lead_only_change_updates_lead_without_label_revision', '''
local original = ns.Core.Cast
ns.Core.Cast = function(self, raw)
    local ok, reason = original(self, raw)
    if ok and raw.revision == 2 then
        for _, row in ipairs(self.examples) do
            if row.actor == raw.actor and row.lead and row.lead[1] then
                row.lead[1] = row.lead[1] + 0.125; hit()
            end
        end
    end
    return ok, reason
end
'''),
    ('reset_sealed_row', 'reset_seals_rows_and_clears_transient_guards', '''
local original = ns.Core.ResetSession
ns.Core.ResetSession = function(self, ...)
    local result = original(self, ...)
    if self.examples[1] and self.examples[1].sealed then
        self.examples[1].sealed = false; hit()
    end
    return result
end
'''),
]


# Expected recencies are explicit dyadic values, independently specified rather
# than copied from either implementation's feature formula. Ordinary unrelated
# features are checked against the frozen baseline for every class and slot.
DIRECT_ORACLES = r'''
local old, reference, candidate = ...
local rows = {}
local function test(name, fn)
    local checks = 0
    local function equal(actual, expected, label)
        checks = checks + 1
        assert(actual == expected, label..": "..tostring(actual).." ~= "..tostring(expected))
    end
    local ok, reason = pcall(function() fn(equal) end)
    rows[#rows+1] = {name=name, passed=ok, assertions=checks, error=not ok and tostring(reason) or nil}
end
local cases = {
    {"absent", false, 0, 0},
    {"future", {at=10.125}, 0, 0},
    {"new", {at=10}, 1, 1},
    {"age_one_no_expiry", {at=9}, 0.875, 1},
    {"age_four", {at=6}, 0.5, 1},
    {"age_eight_known_zero", {at=2}, 0, 1},
    {"older_than_eight", {at=1.875}, 0, 0},
    {"expiry_equal", {at=9, expires=10}, 0, 0},
    {"expiry_future", {at=9, expires=10.125}, 0.875, 1},
    {"already_expired", {at=9, expires=9.875}, 0, 0},
}
for _, impl in ipairs({{"reference", reference}, {"candidate", candidate}}) do
    local label, ns = impl[1], impl[2]
    for _, case in ipairs(cases) do
        test(label.."/witness/"..case[1], function(eq)
            local x = ns.Rules.Features({class="PRIEST"}, 10,
                {defensiveWitness=case[2] or nil})
            eq(#x, 48, "feature count")
            eq(x[47], case[3], "recency")
            eq(x[48], case[4], "known")
        end)
    end
    test(label.."/witness/explicit_evidence_overrides_actor", function(eq)
        local actor = {class="PRIEST", defensiveWitness={at=10}}
        local x = ns.Rules.Features(actor, 10, {defensiveWitness={at=10.125}})
        eq(x[47], 0, "future explicit evidence recency"); eq(x[48], 0, "future evidence known")
        x = ns.Rules.Features(actor, 10, {})
        eq(x[47], 0, "empty evidence recency"); eq(x[48], 0, "empty evidence known")
        x = ns.Rules.Features(actor, 10)
        eq(x[47], 1, "actor fallback recency"); eq(x[48], 1, "actor fallback known")
    end)
    for _, class in ipairs({"WARRIOR","PALADIN","HUNTER","ROGUE","PRIEST",
                            "SHAMAN","MAGE","WARLOCK","DRUID","UNKNOWN"}) do
        test(label.."/class_preservation/"..class, function(eq)
            local actor = {class=class, role="hostile", combat=true, health=0.5,
                power=0.75, form="cat"}
            local evidence = {history={[1]=9,[2]=11,[4]=0}, defensiveWitness={at=9,expires=15}}
            local before = old.Rules.Features(actor, 10, evidence)
            local after = ns.Rules.Features(actor, 10, evidence)
            eq(#before, 48, "old count"); eq(#after, 48, "new count")
            for i=1,48 do
                local expected = before[i]
                if i==36 and class=="DRUID" then expected=1 end
                if i==47 then expected=0.875 end
                eq(after[i], expected, "feature "..i)
            end
            local oldCandidates = old.Rules.Candidates(class)
            local newCandidates = ns.Rules.Candidates(class)
            for _, family in ipairs(old.Rules.families) do
                local expected = oldCandidates[family]
                local expectedStatus = class=="DRUID" and family=="root" and "candidate" or expected.status
                local expectedReason = class=="DRUID" and family=="root"
                    and "class association; availability unknown" or expected.reason
                eq(newCandidates[family].status, expectedStatus, family.." status")
                eq(newCandidates[family].reason, expectedReason, family.." reason")
                eq(newCandidates[family].basis, "forever-provisional-class-v2", family.." basis")
            end
        end)
    end
    for _, id in ipairs({339,1062,5195,5196,9852,9853}) do
        test(label.."/root_cast/"..id, function(eq)
            eq(old.Rules.Classify(id), nil, "frozen baseline vocabulary")
            eq(ns.Rules.Classify(id), 3, "declared root family")
        end)
    end
    test(label.."/unchanged_cast_vocabulary", function(eq)
        for _, id in ipairs({8122,853,122,15487,1766,22812,999999}) do
            eq(ns.Rules.Classify(id), old.Rules.Classify(id), "unchanged spell "..id)
        end
    end)
end
return rows
'''


def direct_oracles(engine, texts):
    lua = importlib.import_module('lupa.' + engine).LuaRuntime(unpack_returned_tuples=True)
    namespaces = []
    for kind in ('old', 'reference', 'candidate'):
        ns = lua.table()
        for name in ('Bootstrap.lua', 'Rules.lua'):
            text = texts[name] if kind == 'reference' else (
                (aligned.REFERENCE if kind == 'old' else aligned.SOURCE) / name
            ).read_text(encoding='utf-8')
            lua.execute(text, 'bjarkiLearn', ns)
        namespaces.append(ns)
    result = lua.execute(DIRECT_ORACLES, *namespaces)
    return [dict(aligned.plain(result[i]), runtime=engine) for i in range(1, len(result) + 1)]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--lupa-path', type=Path)
    args = parser.parse_args()
    if args.lupa_path:
        sys.path.insert(0, str(args.lupa_path))
    contract, texts, ledger = aligned.preparation()
    controls, oracle_rows, errors = [], [], []
    for engine in contract['engines']:
        for name, case, fault in MUTATIONS:
            telemetry = {}
            clean = aligned.execute(engine, texts, only=case)
            mutated = aligned.execute(engine, texts, mutation=PREFIX + fault,
                                      only=case, telemetry=telemetry)
            identity = lambda rows: len(rows) == 1 and rows[0].get('name') == case and rows[0].get('runtime') == engine
            passed = (identity(clean) and identity(mutated)
                      and clean[0].get('passed') is True
                      and mutated[0].get('passed') is False
                      and bool(mutated[0].get('error'))
                      and telemetry.get('mutation_hits', 0) > 0)
            controls.append(dict(name=name, case=case, runtime=engine, passed=passed,
                clean=clean, mutated=mutated, mutation_hits=telemetry.get('mutation_hits', 0),
                mutation_sha256=hashlib.sha256((PREFIX + fault).encode()).hexdigest()))
            if not passed:
                errors.append(engine + '/' + name + ': paired exercised rejection failed')
        oracle_rows.extend(direct_oracles(engine, texts))
    source_unchanged = hashes(aligned.SOURCE) == contract['source']
    reference_unchanged = hashes(aligned.REFERENCE) == contract['reference']
    probe_unchanged = sha(aligned.PROBE) == contract['probe_sha256']
    if not (source_unchanged and reference_unchanged and probe_unchanged):
        errors.append('Source, frozen reference, or original fixture changed')
    if len(controls) != 14 or len(oracle_rows) != 112:
        errors.append('Control/oracle case inventory mismatch')
    errors.extend(row['runtime'] + '/' + row['name'] + ': ' + row.get('error', 'oracle failed')
                  for row in oracle_rows if row.get('passed') is not True)
    report = dict(passed=not errors, errors=errors, controls=controls, oracle_cases=oracle_rows,
        paired_mutation_controls=len(controls), controls_passed=sum(row['passed'] for row in controls),
        clean_runs_passed=sum(len(row['clean']) == 1 and row['clean'][0].get('passed') is True for row in controls),
        exercised_mutations_rejected=sum(row['passed'] for row in controls),
        oracle_cases_total=len(oracle_rows), oracle_cases_passed=sum(row['passed'] for row in oracle_rows),
        oracle_assertions=sum(row['assertions'] for row in oracle_rows),
        source_hashes=contract['source'], reference_hashes=contract['reference'],
        source_unchanged=source_unchanged, reference_unchanged=reference_unchanged,
        original_probe_unchanged=probe_unchanged, probe_sha256=sha(aligned.PROBE),
        verifier_hashes={**aligned.verifier_hashes(), 'aligned_controls.py': sha(Path(__file__))},
        adaptations=ledger,
        scope='Offline paired sensitivity controls and explicit feature/vocabulary boundaries. Candidate faults are in-memory and intentionally rejected, never accepted runtime changes. Original fixture assertions and comparison remain unchanged.')
    save(REPORTS / 'aligned-controls.json', report)
    print(json.dumps({key:report[key] for key in ('passed', 'errors', 'paired_mutation_controls',
        'controls_passed', 'clean_runs_passed', 'exercised_mutations_rejected',
        'oracle_cases_total', 'oracle_cases_passed', 'oracle_assertions')}, indent=2))
    return int(bool(errors))


if __name__ == '__main__':
    raise SystemExit(main())
