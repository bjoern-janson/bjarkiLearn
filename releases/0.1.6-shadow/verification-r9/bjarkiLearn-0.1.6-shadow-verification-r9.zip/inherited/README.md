# Inherited verification for 0.1.6

`run.py` expands the preserved 0.1.5 aggregates into all 39 leaf jobs, then runs every job even if an earlier one fails. The original `prior/`, exact `baseline/source/bjarkiLearn`, and independent `audit015/` trees are read-only. Every run hashes them before and after. Disposable stages live under `inherited/runs/`; exclude those directories and every `__pycache__` from delivery. Reports live under `reports-016/inherited/`.

The source is copied byte-for-byte into each stage. No production shim or production-method replacement is introduced by this runner. The preserved contracts suite already contains a deliberate private-method interception as part of its original no-projection-on-write test; it is unchanged.

Each staged fixture starts with the prior runner's documented private-view adaptations, whose baseline equivalence was established for the 0.1.5 refactor. The exact inherited adaptation manifest is embedded in every new stage report. Two additional execution adaptations retarget an independent audit's fixed source hash to the exact candidate hash and preserve the prior integration wrapper's 0.1.4 baseline path redirect. Neither removes an assertion. Each leaf report and stdout/stderr is copied to the report directory, including failures. Expected output files are removed before execution so no old report can be mistaken for a fresh run.

Run with Python 3 and Lupa providing lua51 and lua54:

```text
python -B inherited/run.py --mode baseline --lupa-path /path/to/lupa
python -B inherited/run.py --mode raw --lupa-path /path/to/lupa
python -B inherited/run.py --mode adapted --only temporal temporal_independent audit014_native audit013_network --lupa-path /path/to/lupa
python -B inherited/scoped.py --lupa-path /path/to/lupa
python -B inherited/aligned.py --lupa-path /path/to/lupa
python -B inherited/aligned_controls.py --lupa-path /path/to/lupa
```

`baseline` executes against exact 0.1.5 with the inherited expectations. `raw` executes against exact 0.1.6 with those same expectations. Three prior future-positive reset observations (six Lua-engine executions) have been superseded since 0.1.4; their failed original assertions are retained and never counted as passing controls. The unchanged normalized-clock controls still test their supported counterparts.

`semantics.py` lists each exact-count expected-value adaptation for recency at the original timestamps. It changes only six expressions in four staged fixture files: 9-to-10 recency is .875, 9.5-to-10.25 recency is .90625, and 11-to-12.5 recency is .8125. Eligibility-bit, immutable-input, projection, positive/negative/censored-label, and other assertions remain intact. Raw failures remain in separate reports. Baseline execution with original values supplies a control; semantic-specific 0.1.6 tests are separately required.

Old whole-model or whole-public-state equivalence across releases is no longer a valid invariant: compatibility metadata, candidate association inputs, witness recency, and therefore trained parameters can change. The raw comparisons are still executed and recorded. They are classified as retired comparison claims, not successful tests. Their within-release reload checks, cross-Lua checks, and focused lifecycle assertions remain applicable and are inspected separately.

`scoped.py` retains the original refactor assertions and full trace comparisons, but loads two independent namespaces of the exact 0.1.6 candidate. It changes the explicit old compatibility-string expectation to the explicit new string. Its result means same-release repeatability and execution of the original invariants. It does not establish 0.1.5/0.1.6 model equivalence or validate intended changed semantics by itself.

These are offline ordinary-Lua executions with modeled WoW APIs. They do not establish live-client behavior, prediction quality, frame time, or secret-value/taint enforcement.



## Recorded result and classification

The full exact 0.1.5 baseline and raw 0.1.6 candidate runs each completed all 39 leaf jobs. The baseline has only its six already-retired future-positive failures. Candidate raw failures are retained by name in `classification.json`; no old whole-state equality failure is counted as a pass.

The six explicit recency expectation updates pass 149 group executions across four inherited jobs. The expanded same-release scoped suite passes 86 cases, including the original refactor, randomized 0.1.5 audit, fresh 0.1.4 review and 0.1.4 audit traces. The unchanged synthetic reconciliation policy matrix passes 46,080 exact policy-state comparisons. These quantities use different units and are deliberately not combined into one test total.

Within the independent 0.1.5 audit, current 0.1.6 alone passes 30 focused Core cases, 112 native cases, 24 network/restore cases and 6 native reload/cross-Lua comparisons. Reports also run the older baseline controls, so combined source-plus-baseline counts are 60, 224, 48 and 12 respectively. Historical version labels inside unchanged runners retain their old names; actual source paths/hashes identify the tested releases.

Run `python -B inherited/classification.py` after the six execution steps. The classifier requires all 39 leaf-job identities, original baseline failures with their exact error strings, raw recency failure signatures, the exact adaptation ledger, all applicable assertions and per-release reload/cross-Lua checks, exact runtime hashes and preserved original inventories. It writes `reports-016/inherited/classification.json` and exits nonzero for unexplained failures. Release-document edits during execution are recorded separately from immutable staged source and runtime hashes.

Verification revision 2 adds `aligned.py`: all 56 original differential cases compare exact full state against a pinned frozen reference with only the declared 0.1.6 semantics adapted before training. Each case must preserve the original passing baseline's assertion/checkpoint/model/leaf counts. No new fields are masked; original raw failures remain diagnostics. Their first-error text no longer controls acceptance.

`aligned_controls.py` exercises 14 paired candidate faults and 112 direct semantic oracle cases. `verify_gate.py` preserves the original three negative controls and expands the gate checks to 16 rejection controls and three first-diagnostic acceptance controls. No on-disk runtime or original fixture is modified. See the root README-VERIFICATION.txt and reports-016/verification.json for revision 2 provenance and fresh results.

