"""Narrow 0.1.6 expected-value updates in disposable fixtures only."""
from pathlib import Path
import hashlib,json
ADAPTATIONS=[
 ('audit-0.1.3/audit/network-restore/probes.lua',"zero[47]==1 and zero[48]==1,'positive witness'","zero[47]==.875 and zero[48]==1,'positive witness'",1,'Witness99 at query100: 1-1/8=.875; known bit and expiry check unchanged.'),
 ('tests-time/projections.lua',"x[47]==1,'future witness hid valid earlier witness'","x[47]==.875,'future witness hid valid earlier witness'",1,'Witness at9, anchor10: 1-(10-9)/8=.875; future publication must not hide it.'),
 ('tests-time/independent/probes.lua','eq(c.actors.P.window.x[47],1); eq(c.actors.P.window.x[48],1)','eq(c.actors.P.window.x[47],.875); eq(c.actors.P.window.x[48],1)',1,'Witness at9, anchor10. Eligibility remains1.'),
 ('audit014/native/probes.lua','Equal(target.window.anchor,10.25);Equal(target.window.x[47],1)','Equal(target.window.anchor,10.25);Equal(target.window.x[47],.90625)',1,'Native witness9.5, anchor10.25: 1-.75/8=.90625.'),
 ('audit014/native/probes.lua','Check(row~=nil);Equal(row.x[47],1)','Check(row~=nil);Equal(row.x[47],.90625)',1,'Retained input remains the original9.5/10.25 anchored recency.'),
 ('audit014/native/probes.lua','Equal(target.window.anchor,12.5);Equal(target.window.x[47],1)','Equal(target.window.anchor,12.5);Equal(target.window.x[47],.8125)',1,'Witness11 enters later12.5 anchor: 1-1.5/8=.8125; old missing input remains unchanged.'),
]
def apply(target):
 rows=[]
 for name,old,new,count,reason in ADAPTATIONS:
  p=target/name;before=p.read_bytes();assert before.count(old.encode())==count,(name,old)
  after=before.replace(old.encode(),new.encode());p.write_bytes(after)
  rows.append(dict(file=name,original=old,replacement=new,count=count,reason=reason,before_sha256=hashlib.sha256(before).hexdigest(),after_sha256=hashlib.sha256(after).hexdigest()))
 return rows

