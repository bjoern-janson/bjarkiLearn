"""Full original differential, with declared 0.1.6 semantics in a frozen reference.

Only reference text in memory and the harness's one schema expectation change.
Candidate code, all original assertions and exact full-state comparison remain.
No candidate output is used to compute the reference.
"""
from pathlib import Path
import argparse, collections, hashlib, importlib, json, sys
from run import ROOT, PRIOR, REPORTS, hashes, read, save, sha

SOURCE = ROOT/'source/bjarkiLearn'
REFERENCE = PRIOR/'baseline-0.1.4/source/bjarkiLearn'
PROBE = PRIOR/'tests-refactor/independent/probes.lua'
CONTRACT = Path(__file__).with_name('aligned-contract.json')
MODULES = ('Bootstrap.lua','Rules.lua','Network.lua','Core.lua','Adapter.lua')
OLD = 'learn1/forever16001-provisional1/features48-v1/cast-delivery-v1/h2/player-combat-v1/mlp12-sgd4-v1'
NEW = 'learn1/forever16001-provisional2/features48-v2/cast-delivery-v2/h2/player-combat-v1/mlp12-sgd4-v1'
# Exact reference-only adaptations. Each is required exactly once; no wildcards.
ADAPTATIONS = [
 ('Bootstrap.lua', OLD, NEW, 'Declared saved-learning compatibility key.'),
 ('Core.lua', 'target="cast-delivery-v1"', 'target="cast-delivery-v2"', 'Declared forecast target metadata.'),
 ('Rules.lua', 'basis="forever-provisional-class-v1"', 'basis="forever-provisional-class-v2"', 'Declared class-association basis metadata.'),
 ('Rules.lua', '1242634})', '1242634,339,1062,5195,5196,9852,9853})', 'Six declared Entangling Roots cast IDs.'),
 ('Rules.lua', 'DRUID = {stun="conditional",defensive="candidate"}', 'DRUID = {stun="conditional",root="candidate",defensive="candidate"}', 'Druid root possibility and its feature; other classes unchanged.'),
 ('Rules.lua', 'push(fresh and 1 or 0); push(fresh and 1 or 0)', 'push(fresh and (8-(now-witness.at))/8 or 0); push(fresh and 1 or 0)', 'Independent recency calculation from reference witness; existing freshness/known rules retained.'),
 ('probes.lua', OLD, NEW, 'Exact schema assertion follows declared semantics; every other assertion unchanged.'),
]

def plain(value):
    return {str(k):plain(v) for k,v in value.items()} if hasattr(value,'items') else value

def preparation():
    assert sha(CONTRACT)=='a4dae388915f0b6813f26b9c110f2755b52a8c5d660cd9671948b833655d6674', 'Frozen alignment contract changed'
    contract = read(CONTRACT)
    assert hashes(SOURCE)==contract['source'], 'Candidate install differs from pinned 0.1.6'
    assert hashes(REFERENCE)==contract['reference'], 'Frozen reference changed'
    assert sha(PROBE)==contract['probe_sha256'], 'Original harness changed'
    texts = {name:(REFERENCE/name).read_text(encoding='utf-8') for name in MODULES}
    texts['probes.lua'] = PROBE.read_text(encoding='utf-8')
    ledger=[]
    for name,old,new,reason in ADAPTATIONS:
        assert texts[name].count(old)==1, ('Reference adaptation count', name,old)
        before=texts[name]; texts[name]=before.replace(old,new)
        ledger.append(dict(file=name,original=old,replacement=new,count=1,reason=reason,
            before_sha256=hashlib.sha256(before.encode()).hexdigest(),after_sha256=hashlib.sha256(texts[name].encode()).hexdigest()))
    return contract,texts,ledger

def execute(engine, texts, mutation=None, only=None, telemetry=None):
    lua=importlib.import_module('lupa.'+engine).LuaRuntime(unpack_returned_tuples=True)
    reference,candidate=lua.table(),lua.table()
    for name in MODULES:
        lua.execute(texts[name],'bjarkiLearn',reference)
        lua.execute((SOURCE/name).read_text(encoding='utf-8'),'bjarkiLearn',candidate)
    if mutation: lua.execute(mutation,candidate)
    code=texts['probes.lua']
    if only:
        # Mutation sensitivity controls only. Production proof runs all 28 cases.
        old='local function test(name,fn) cases[#cases+1]={name=name,fn=fn} end'
        assert code.count(old)==1
        code=code.replace(old,'local function test(name,fn) if name=='+json.dumps(only)+' then cases[#cases+1]={name=name,fn=fn} end end')
    cases=lua.execute(code,reference,candidate)
    if telemetry is not None:
        telemetry['mutation_hits']=int(lua.globals().__alignedMutationHits or 0)
    return [dict(plain(cases[i]),runtime=engine) for i in range(1,len(cases)+1)]

def validate(report):
    """Validate complete evidence, not an aggregate boolean or a first error."""
    contract,texts,ledger=preparation()
    errors=[]
    def need(ok,why):
        if not ok:errors.append(why)
    expected=collections.Counter((n,e) for n in contract['cases'] for e in contract['engines'])
    rows=report.get('cases',[])
    need(collections.Counter((r.get('name'),r.get('runtime')) for r in rows)==expected,'aligned case identity/count mismatch')
    need(report.get('passed') is True and all(r.get('passed') is True for r in rows),'aligned comparison failed')
    need(report.get('source_hashes')==contract['source'] and report.get('reference_hashes')==contract['reference'],'aligned input hash mismatch')
    need(report.get('source_unchanged') is True and report.get('reference_unchanged') is True,'aligned input preservation missing')
    need(report.get('probe_sha256')==contract['probe_sha256'] and report.get('adaptations')==ledger,'aligned harness/adaptation mismatch')
    need(report.get('verifier_hashes')==verifier_hashes(),'aligned verifier provenance mismatch')
    fields=('checkpoints','equalLeaves','assertions','modelSnapshots','candidateSnapshots')
    for r in rows:
        need(all(type(r.get(k)) is int and r[k]>=0 for k in fields),'aligned evidence counts invalid')
        need(r.get('checkpoints',0)>0 and r.get('equalLeaves',0)>0 and r.get('assertions',0)>0,'aligned comparisons missing')
    totals={k:sum(r.get(k,0) for r in rows) for k in fields}
    need(report.get('counts')==dict(cases=56,passed=56,**totals),'aligned aggregate count mismatch')
    need(totals['modelSnapshots']>0 and totals['candidateSnapshots']>0,'aligned trained/in-flight model evidence missing')
    return errors

def verifier_hashes():
    return {name:sha(Path(__file__).with_name(name)) for name in ('aligned.py','aligned-contract.json')}

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--lupa-path',type=Path);a=p.parse_args()
    if a.lupa_path:sys.path.insert(0,str(a.lupa_path))
    contract,texts,ledger=preparation(); rows=[]
    for engine in contract['engines']:rows.extend(execute(engine,texts))
    counts={k:sum(r.get(k,0) for r in rows) for k in ('checkpoints','equalLeaves','assertions','modelSnapshots','candidateSnapshots')}
    report=dict(passed=all(r['passed'] for r in rows),cases=rows,counts=dict(cases=len(rows),passed=sum(r['passed'] for r in rows),**counts),
        source_hashes=contract['source'],reference_hashes=contract['reference'],
        source_unchanged=hashes(SOURCE)==contract['source'],reference_unchanged=hashes(REFERENCE)==contract['reference'],
        probe_sha256=sha(PROBE),adaptations=ledger,verifier_hashes=verifier_hashes(),
        scope='Exact scalar full-state equality against frozen 0.1.4 with declared 0.1.6 feature/vocabulary/metadata adaptations applied before training. Original comparator and all assertions retained. Not unchanged cross-version equality or live-client proof.')
    errors=validate(report);report['validation_errors']=errors;report['passed']=not errors
    save(REPORTS/'aligned-reference.json',report)
    print(json.dumps(dict(passed=report['passed'],counts=report['counts'],errors=errors,failures=[r for r in rows if not r['passed']]),indent=2))
    return int(bool(errors))

if __name__=='__main__':raise SystemExit(main())
