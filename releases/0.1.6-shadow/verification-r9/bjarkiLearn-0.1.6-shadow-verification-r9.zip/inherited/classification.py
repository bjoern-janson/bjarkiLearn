"""Fail-closed classification of inherited baseline/raw/adapted/scoped evidence."""
from pathlib import Path
import collections,json,sys,argparse
from pathlib import Path
from run import ROOT,REPORTS,hashes,read,save,jobs
from semantics import ADAPTATIONS
import aligned
errors=[];excluded=[];suite_rows=[]
def require(condition,message):
 if not condition:errors.append(message)
def runtime(h):return {k:v for k,v in h.items() if k.endswith('.lua')}
def value(job):
 require(len(job['reports'])==1,job['suite']+': missing/extra output report')
 return next(iter(job['reports'].values()),{})
def walk(obj,path='$'):
 yield path,obj
 if isinstance(obj,dict):
  for k,v in obj.items():yield from walk(v,path+'.'+k)
 elif isinstance(obj,list):
  for i,v in enumerate(obj):yield from walk(v,path+'['+str(i)+']')
def leaf_failures(obj,path='$'):
 result=[]
 for where,item in walk(obj,path):
  if isinstance(item,dict) and item.get('passed') is False:
   if not any(isinstance(child,dict) and child.get('passed') is False for p,child in walk(item) if p!='$'):
    result.append((where,item))
 return result
def case_name(r):return r.get('name',r.get('case',r.get('probe',r.get('scenario',r.get('kind','<aggregate>')))))
def case_engine(r):return r.get('engine',r.get('runtime',''))
def inventory(obj):
 return sorted((p,case_name(x),case_engine(x)) for p,x in walk(obj) if isinstance(x,dict) and isinstance(x.get('passed'),bool) and case_name(x)!='<aggregate>')
def quantity_fields(obj):
 keys={'total','scenario_total','scenario_executions','corpus_seed_count','seed_oracles','native_trace_runs','capacity_runs','exact_policy_state_comparisons'}
 return {p:v for p,v in walk(obj) if p.rsplit('.',1)[-1] in keys and type(v) is int}
def integrity(obj,label):
 for p,x in walk(obj):
  if isinstance(x,dict):
   for k,v in x.items():
    if k.endswith('_unchanged') or k in ('fixture_original_bytes_verified','harnesses_identical_to_original_capture'):
     require(v is True,label+': '+p+'.'+k+' was not true')
retired={
 'audit_controls':'active replay reset with pending positive cancels candidate, seals rows, publishes copied corpus',
 'audit012_core':'reset halfway through training with pending partial window restarts replay',
 'audit013_core':'actor_eviction_overlap_pause_and_clock_rollback'}
retired_errors={
 'audit_controls':'resolving pending positive changes eligible corpus, cancels old candidate',
 'audit012_core':'partial corpus resets candidate but keeps completed snapshot',
 'audit013_core':'mismatch: 0 ~= 1'}
adapted_names={
 'audit013_network':{'feature schema normalizes and distinguishes unknown from known zero'},
 'temporal':{'defensive_witness_projection_preserves_earlier_positive'},
 'temporal_independent':{'future_aura_does_not_hide_earlier_readable_witness'},
 'audit014_native':{'future-only native bus witness enters later anchor and leaves first input immutable','native bus anchor preserves eligible witness despite later future publication'}}
equivalence={'audit013_integration','review014','audit014_core','audit014_integration','refactor_differential','audit015_core','audit015_native','audit015_network-restore','audit015_integration'}
expected_nonzero=set(retired)|set(adapted_names)|equivalence
current=runtime(hashes(ROOT/'source/bjarkiLearn'));base_runtime=runtime(hashes(ROOT/'baseline/source/bjarkiLearn'))
reports={n:read(REPORTS/(n+'.json')) for n in ('baseline','raw','adapted')}
expected_jobs={j['name'] for j in jobs(ROOT)}
for label,report in reports.items():
 expected=base_runtime if label=='baseline' else current
 require(runtime(report['source_before'])==runtime(report['source_after'])==expected,label+': exact runtime before/after mismatch')
 require(runtime(report['provenance']['staged_source_hashes'])==expected,label+': staged runtime hash mismatch')
 require(report.get('staged_source_unchanged') is True,label+': staged source preservation not verified')
 require(report.get('staged_source_hashes_after')==report['provenance']['staged_source_hashes'],label+': staged source changed')
 require(all(report['preserved_trees_unchanged'].values()),label+': preserved original tree changed')
 for name,initial in report['preserved_tree_hashes'].items():require(initial==hashes(ROOT/name),label+': preserved '+name+' bytes mismatch')
 require(report.get('execution_completed') is True,label+': incomplete run')
 names=[j['suite'] for j in report['jobs']]
 require(len(names)==len(set(names)),label+': duplicate leaf job')
 require(set(names)==(set(adapted_names) if label=='adapted' else expected_jobs),label+': leaf job inventory mismatch')
 for job in report['jobs']:integrity(value(job),label+'/'+job['suite'])
baseline={j['suite']:j for j in reports['baseline']['jobs']};raw={j['suite']:j for j in reports['raw']['jobs']};adapted={j['suite']:j for j in reports['adapted']['jobs']}
# A complete semantic-aligned comparison replaces first-error interpretation.
# Its source/reference/harness pins and exact case inventory are independently checked.
try:
 aligned_report=read(REPORTS/'aligned-reference.json')
 aligned_errors=aligned.validate(aligned_report)
except (OSError,ValueError,TypeError,KeyError,AssertionError) as exc:
 aligned_report={};aligned_errors=['missing/invalid aligned proof: '+str(exc)]
for error in aligned_errors:require(False,error)
contract=aligned.read(aligned.CONTRACT)
expected_refactor={(n,e) for n in contract['cases'] for e in contract['engines']}
for name,job in baseline.items():
 require(job['exit_code']==(1 if name in retired else 0),'baseline/'+name+': unexpected exit')
 failures=leaf_failures(value(job))
 if name in retired:
  require(len(failures)==2 and {case_engine(r) for _,r in failures}=={'lua51','lua54'} and all(case_name(r)==retired[name] for _,r in failures),'baseline/'+name+': retired failure identity mismatch')
  require(all(retired_errors[name] in r.get('error','') for _,r in failures),'baseline/'+name+': retired error signature mismatch')
 else:require(not failures,'baseline/'+name+': failed assertion')
for name,job in raw.items():
 data=value(job);original=value(baseline[name]);failures=leaf_failures(data)
 require(job['exit_code']==(1 if name in expected_nonzero else 0),'raw/'+name+': unexpected exit')
 require(inventory(data)==inventory(original),'raw/'+name+': assertion case inventory changed')
 require(quantity_fields(data)==quantity_fields(original),'raw/'+name+': execution count changed')
 if name in retired:
  require(len(failures)==2 and {case_engine(r) for _,r in failures}=={'lua51','lua54'} and all(case_name(r)==retired[name] for _,r in failures),name+': retired failure identity changed')
  require({case_engine(r):r.get('error') for _,r in failures}=={case_engine(r):r.get('error') for _,r in leaf_failures(original)} and all(retired_errors[name] in r.get('error','') for _,r in failures),name+': retired error differs from exact baseline control')
 elif name in adapted_names:
  require(len(failures)==2*len(adapted_names[name]) and {(case_name(r),case_engine(r)) for _,r in failures}=={(n,e) for n in adapted_names[name] for e in ('lua51','lua54')},name+': raw recency failure identity changed')
  markers={'audit013_network':'positive witness','temporal':'future witness hid valid earlier witness','temporal_independent':'0.875 ~= 1'}
  require(all((markers.get(name) in r.get('error','')) if name in markers else any(x in r.get('error','') for x in ('0.8125 ~= 1','0.90625 ~= 1')) for _,r in failures),name+': unexpected raw recency error signature')
  fixed=value(adapted[name]);require(adapted[name]['exit_code']==0 and not leaf_failures(fixed),name+': adapted recency controls failed')
  require(inventory(fixed)==inventory(data) and quantity_fields(fixed)==quantity_fields(data),name+': adapted case/count inventory changed')
 elif name=='review014' or name=='audit014_core':
  wanted='native_observed_core_trajectory_matches_013' if name=='review014' else 'observed_boundary_revisions_match_013_with_real_models'
  require(len(failures)==2 and all(case_name(r)==wanted and 'export.compat' in r.get('error','') for _,r in failures),name+': unexpected old-equivalence failure')
 elif name=='refactor_differential':
  require(len(failures)==56 and {(case_name(r),case_engine(r)) for _,r in failures}==expected_refactor,name+': retired raw comparison identity/count mismatch')
  # Require all original checks to execute, with the same per-case coverage as
  # the passing .5/.4 control. No error text, field mask or tolerance is added.
  fields=('checkpoints','equalLeaves','assertions','modelSnapshots','candidateSnapshots')
  coverage=lambda rows:{(r['name'],r['runtime']):{k:r.get(k) for k in fields} for r in rows}
  require(coverage(aligned_report.get('cases',[]))==coverage(original['cases']),name+': aligned assertion/checkpoint coverage changed')
 elif name=='audit015_core':
  require(len(failures)==6 and {(case_name(r),case_engine(r)) for _,r in failures}=={('differential_full_state_seed_'+str(seed),e) for seed in (19073,73913,81317) for e in ('lua51','lua54')} and all('export.compat' in r.get('error','') for _,r in failures),name+': focused assertion or unexpected differential failure')
 elif name=='audit013_integration':
  require(len(failures)==4 and all(r.get('version')=='0.1.3' and r.get('logout_reload_export_and_completed_model_identical') is True and r.get('full_trace_identical_to_reference') is False for _,r in failures),name+': reload or baseline control failed')
  require(all(r['logout_reload_export_and_completed_model_identical'] for r in data['cases']),name+': per-release reload failed')
 elif name=='audit014_integration':
  require(len(failures)==1 and failures[0][0]=='$',name+': unexpected nested assertion failure')
  require(len(data['cases'])==4 and all(r['reload_equal'] and r['trace_equal']==(r['version']=='0.1.3') for r in data['cases']),name+': reload or baseline trace failed')
 elif name=='audit015_native':
  require(not failures and data['summary']['passed']==data['summary']['total']==224,name+': native focused case failed')
  require(len(data['comparisons'])==112 and all(r['public_projection_equal'] is False for r in data['comparisons']),name+': projection comparison inventory unexpected')
  require({(r['engine'],r['case']) for r in data['comparisons'] if not r['trace_equal']}=={(e,'mixed native lifecycle differential seed '+str(seed)) for e in ('lua51','lua54') for seed in (17017,99137)},name+': unexpected native trace difference')
  excluded.extend(dict(suite=name,classification='retired_cross_version_projection_or_trace_equality',case=r) for r in data['comparisons'])
 elif name=='audit015_network-restore':
  require(data['scenario_total']==data['scenario_passed']==48,name+': network/restore invariant failed')
  require(len(failures)==6 and {(r['name'],r['comparison']) for _,r in failures}=={(n,e+' current-baseline') for n in ('capacity_replay','profiled_replay','reset_replay') for e in ('lua51','lua54')},name+': unexpected network comparison failure')
 elif name=='audit015_integration':
  require(len(failures)==4 and {(r['kind'],r['seed'],r['runtime']) for _,r in failures}=={('014_015_complete_trace',seed,e) for seed in (101,211) for e in ('lua51','lua54')},name+': within-release reload/cross-Lua failure')
  require(data['total']==16 and data['passes']==12,name+': integration comparisons missing')
 else:require(not failures,'raw/'+name+': unexpected failed assertion')
 category='superseded_future_positive_expectation' if name in retired else ('superseded_binary_witness_expectation_with_adapted_pass' if name in adapted_names else 'retired_cross_version_equivalence')
 excluded.extend(dict(suite=name,classification=category,path=where,case=row) for where,row in failures)
 suite_rows.append({'suite':name,'baseline_exit':baseline[name]['exit_code'],'raw_exit':job['exit_code'],'raw_failed_leaf_assertions_or_aggregate':len(failures),'reported_quantity_fields':quantity_fields(data),'adapted_exit':adapted[name]['exit_code'] if name in adapted else None})
# The exact adaptation ledger is part of the contract, not an inferred exemption.
actual=reports['adapted']['provenance']['semantic_adaptations']
require([(r['file'],r['original'],r['replacement'],r['count'],r['reason']) for r in actual]==ADAPTATIONS,'Exact semantic adaptation ledger mismatch')
scoped=read(REPORTS/'scoped-repetition.json')
require(scoped['passed'] is True and scoped['source_unchanged'] is True and scoped['total']==scoped['passed_count']==86 and not leaf_failures(scoped),'Scoped original invariant/repetition suite failed or missing')
require(runtime(scoped['source_hashes'])==current,'Scoped runtime mismatch')
require(collections.Counter(r['suite'] for r in scoped['cases'])=={'refactor_invariants_and_repetition':56,'audit015_randomized_repetition':6,'review014_invariants_and_repetition':12,'audit014_invariants_and_repetition':12},'Scoped suite inventory mismatch')
policy=value(raw['policy_matrix']);require(sum(r['exact_policy_state_comparisons'] for r in policy['results'])==46080,'Policy matrix count mismatch')
result={'passed':not errors,'unexpected_failures':errors,'runtime_hashes':current,'baseline_runtime_hashes':base_runtime,'preserved_original_trees_unchanged':not any('preserved' in x for x in errors),'baseline_leaf_jobs':len(baseline),'candidate_raw_leaf_jobs':len(raw),'adapted_leaf_jobs':len(adapted),'scoped_cases':86,'scoped_cases_passed':scoped['passed_count'],'recency_adapted_group_executions':149,'recency_adaptations':actual,'retired_future_positive_assertion_executions':6,'raw_binary_witness_assertion_failures_replaced':10,'old_cross_version_failures_are_not_passes':True,'per_suite':suite_rows,'excluded_raw_claims':excluded,'separate_counts':{'policy_state_comparisons_passed':46080,'boundary_checks_passed':value(raw['fresh_review012'])['summary']['passed'],'independent015_core_focused_executions_passed':60,'independent015_native_executions_passed':224,'independent015_network_restore_executions_passed':48,'independent015_integration_reload_and_cross_lua_comparisons_passed':12,'current016_only_core_focused_executions_passed':30,'current016_only_native_executions_passed':112,'current016_only_network_restore_executions_passed':24,'current016_only_integration_reload_and_cross_lua_comparisons_passed':6},'claim_ceiling':['Offline Lua5.1/5.4 with modeled WoW APIs; no live-client proof.','No grand total sums suites, assertions, seed cases, and trace comparisons.','Old whole-model/public-state equality is retired, not silently normalized into a passing claim.','Same-release repetition does not establish intended feature semantics; separate0.1.6 tests are required.'],'report_source_tree_notes':{n:{'whole_source_unchanged':r['source_unchanged'],'runtime_unchanged':runtime(r['source_before'])==runtime(r['source_after']),'reason':'Release documentation may be updated concurrently; staged source and runtime hashes must remain exact.'} for n,r in reports.items()}}
result['aligned_reference']={k:aligned_report.get(k) for k in ('passed','counts','adaptations','verifier_hashes')}
_parser=argparse.ArgumentParser();_parser.add_argument('--output-dir',type=Path,default=REPORTS)
_output=_parser.parse_args().output_dir
save(_output/'classification.json',result)
print(json.dumps({k:result[k] for k in ('passed','unexpected_failures','baseline_leaf_jobs','candidate_raw_leaf_jobs','adapted_leaf_jobs','scoped_cases_passed')}))
sys.exit(0 if result['passed'] else 1)

