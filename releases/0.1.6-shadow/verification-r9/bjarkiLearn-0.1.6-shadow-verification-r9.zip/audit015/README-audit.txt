bjarkiLearn 0.1.5 independent audit evidence

Read AUDIT.txt and audit-summary.json first. Production source is under source/bjarkiLearn; the unchanged original verification source/tests and fresh reports are under verification. The exact frozen 0.1.4 source and archive are included there. Independent reviews, new tests and raw outputs live under audit/.

Requirements: Python 3.10+ and Lupa 2.8 with both lua51 and lua54. No WoW installation is required or simulated in full. The packaged verification requirements file is verification/requirements-test.txt.

From the extracted bundle root:
  python run_audit.py --lupa-path /path/to/site-packages
This executes the complete packaged suite and all four independent suites. It can take several minutes. If Lupa is already on PYTHONPATH, --lupa-path is optional. Local fallback paths in some older runners are historical conveniences, not mandatory installation locations.

To run only the new independent suites using existing packaged reports:
  python run_audit.py --skip-packaged --lupa-path /path/to/site-packages

To validate stored reports and unchanged sources without executing tests:
  python run_audit.py --summarize
The output explicitly distinguishes summarization from test execution.

To rebuild the install package from the verified source:
  cd verification
  python build_release.py --output ../package-rebuild
The install ZIP should reproduce SHA-256 608ff7b953b0fa705ee11b0b517dfc0f433eaff6c0b7532d4a36f830d74184df. A new verification bundle can differ because reports contain fresh paths/timings.

The original external verification ZIP is not duplicated in this audit bundle. Its hash and validated extraction are recorded. package-rebuild contains the byte-identical rebuilt install ZIP and release validation metadata. Temporary fixture copies and Python caches are omitted. Initial probe-development failures remain with explicit explanations; they are not production findings.

All claims are bounded offline evidence; live client behavior and prediction usefulness remain unverified.
