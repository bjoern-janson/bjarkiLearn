local ns=...
local results={}
local function eq(a,b,label) assert(a==b,(label or 'value')..': '..tostring(a)..' ~= '..tostring(b)) end
local function same(a,b,path)
 path=path or '';eq(type(a),type(b),path)
 if type(a)~='table' then eq(a,b,path);return end
 for k,v in pairs(a) do same(v,b[k],path..'.'..tostring(k)) end
 for k in pairs(b) do assert(a[k]~=nil,path..' unexpected key '..tostring(k)) end
end
local function test(name,fn)
 local ok,v=pcall(fn);results[#results+1]={name=name,passed=ok,detail=ok and v or nil,error=not ok and tostring(v) or nil}
end
local function core() local c=ns.Core.New();c:SetCoverage(true);return c end
local function ctx(c,id,t,role)
 return c:Context({actor=id,at=t,role=role or 'self',class='DRUID',combat=true,bound=true,health=.8,power=.6,form='bear'})
end
local function cast(c,id,actor,at,f,rev,lo,hi,retracted)
 return c:Cast({id=id,actor=actor,at=at,family=f or 1,revision=rev or 1,minAt=lo,maxAt=hi,retracted=retracted})
end
local function aura(c,id,at) return c:Aura({id=id,recipient='AURA',at=at,spellID=22812}) end
local function train(c)
 for i=1,2048 do c:Tick(c.now,false);if not c.dirty then break end end
 assert(not c.dirty and not c.candidate,'replay incomplete');return c.model
end
local function row(c,actor,t,f)
 ctx(c,actor,t);c:Tick(t,true);local w=c.actors[actor].window
 if f then ctx(c,actor,t+1);assert(cast(c,actor..':'..t,actor,t+1,f)) end
 c:Tick(t+2.25,true);assert(w.y);return w
end
local function fillers(c,n,x)
 for i=1,n do c:_Resolve({actor='F',anchor=0,deadline=2,regime='other',x=ns.Copy(x),coverage={},lost={},predictions={neural={},linear={},frequency={}},revision=1}) end
end
local function oracleModel(c)
 local d=core();assert(d:Restore(c:Export()));train(d);same(c.model,d.model,'clean replay')
end

test('three_reconciliation_triggers_preserve_ordinary_snapshot',function()
 local c=core();local w=row(c,'P',10,1);assert(train(c));local model=c.model
 local corpus=c.corpusRevision
 local ok,why=cast(c,'P:10','P',11,1,1);eq(ok,false);eq(why,'duplicate');eq(c.corpusRevision,corpus);eq(c.model,model)
 assert(cast(c,'P:10','P',11,1,2));eq(c.corpusRevision,corpus);eq(c.model,model)
 for i=1,128 do assert(aura(c,'a'..i,20+i)) end
 eq(w.mask[1],false);eq(w.y[1],0);eq(c.model,model);eq(c:Status().modelRefreshPending,true)
 assert(c.corpusRevision>corpus);train(c);oracleModel(c)
 return 'Duplicate/semantic revisions preserve serving; cast retirement censors replay while preserving serving; next completed model equals clean corpus replay.'
end)

test('old_and_new_actor_family_time_reattribution',function()
 local scenarios=0
 for direction=1,2 do for family=1,6 do
  local c=core();local p=row(c,'P',10,1);local q=row(c,'Q',14,2);train(c);local model=c.model
  local actor,at,from,to
  if direction==1 then actor,at,from,to='Q',15,p,q else actor,at,from,to='P',11,q,p end
  local id=direction==1 and 'P:10' or 'Q:14'
  assert(cast(c,id,actor,at,family,2));eq(c.model,nil);eq(from.y[direction],0);eq(to.y[family],1)
  assert(model);train(c);oracleModel(c);scenarios=scenarios+1
 end end
 return scenarios..' full old/new reassignment and clean-model comparisons across all six families.'
end)

test('serving_guards_survive_replay_eviction_and_use_both_sides',function()
 for side=1,2 do
  local c=core();local w=row(c,'P',10,1)
  if side==2 then assert(cast(c,'outside','Q',50,6)) end
  train(c);local serving=c.model;fillers(c,256,w.x);eq(c.model,serving)
  if side==1 then assert(cast(c,'P:10','Q',50,6,2)) else assert(cast(c,'outside','P',11,6,2)) end
  eq(c.model,nil);eq(#c.modelDependencies,0)
 end
 return 'Two directions: old dependency moved outside and unrelated evidence moved into an evicted serving window; 256 synthetic unrelated replay rows each.'
end)

test('same_labels_do_not_hide_serving_correction',function()
 local c=core();local w=row(c,'P',10,1);assert(cast(c,'other','P',11.5,1));train(c)
 local y,mask,revision=ns.Copy(w.y),ns.Copy(w.mask),w.revision
 assert(cast(c,'P:10','Q',50,6,2));same(w.y,y);same(w.mask,mask);eq(w.revision,revision);eq(c.model,nil)
 train(c);oracleModel(c)
 return 'Another positive keeps labels/masks unchanged while a timestamp/actor correction still withdraws serving generation.'
end)

test('lead_only_refinement_preserves_candidate_without_serving_model',function()
 local c=core();local w=row(c,'P',10,1)
 for i=1,8 do row(c,'P',14+4*i) end
 c:Tick(c.now,false);local candidate=c.candidate;assert(candidate and not c.model)
 local corpus,revision=c.corpusRevision,w.revision
 assert(cast(c,'P:10','P',11.75,1,2));eq(c.candidate,candidate);eq(c.corpusRevision,corpus);eq(w.revision,revision);eq(w.lead[1],1.75)
 train(c);oracleModel(c)
 return 'Lead-only correction keeps label revision, corpus revision and partial candidate; eventual model equals clean replay.'
end)

test('other_actor_labels_do_not_dirty_player_candidate',function()
 local c=core();row(c,'P',10,1)
 ctx(c,'E',14,'hostile');c:Tick(14,true);local e=c.actors.E.window;c:Tick(16.25,true)
 c:Tick(c.now,false);local candidate=c.candidate;local model=c.model;local corpus=c.corpusRevision
 assert(cast(c,'enemy','E',15,5));eq(e.y[5],1);eq(e.mask[5],true);eq(c.corpusRevision,corpus);eq(c.candidate,candidate);eq(c.model,model)
 return 'Enemy positive revises diagnostics without altering the player replay candidate or serving model.'
end)

test('maturity_batches_multiple_actors_once_from_one_context',function()
 local c=core();ctx(c,'P',10);ctx(c,'Q',10);c:Tick(10,true)
 local p,q=c.actors.P.window,c.actors.Q.window
 assert(cast(c,'p','P',11,1));assert(cast(c,'q','Q',11,2))
 for i=1,16 do ctx(c,'R'..i,10.25,'hostile') end
 eq(p.y[1],0);eq(q.y[2],0);local corpus=c.corpusRevision
 ctx(c,'R16',11,'hostile');eq(p.y[1],1);eq(q.y[2],1);eq(c.corpusRevision,corpus+1)
 eq(c.nextCastAt,nil);local revision=c.corpusRevision;ctx(c,'R16',11.5,'hostile');eq(c.corpusRevision,revision)
 return 'One shared Context time trigger matures two retired actors and advances corpus once, with no repeat invalidation.'
end)

test('maturity_cancels_partial_candidate_and_old_serving_snapshot',function()
 for stage=1,2 do
  local c=core();ctx(c,'P',10);c:Tick(10,true);local w=c.actors.P.window
  ctx(c,'P',10.125);assert(cast(c,'known','P',10.125,1));assert(cast(c,'future','P',11,2))
  for i=1,16 do ctx(c,'R'..i,10.25,'hostile') end
  if stage==2 then train(c);assert(c.model) end
  for i=1,8 do c:_Resolve({actor='past',anchor=0,deadline=2,regime='player',x=ns.Copy(w.x),coverage={true,true,true,true,true,true},lost={},predictions={neural={},linear={},frequency={}},revision=1}) end
  c:Tick(10.25,false);assert(c.candidate);ctx(c,'R16',11,'hostile')
  eq(c.candidate,nil);eq(c.model,nil);eq(w.y[2],1);train(c);oracleModel(c)
 end
 return 'Future maturity cancels a partial replay with/without prior serving generation; 8 synthetic past rows force partial work.'
end)

test('unknown_revision_censors_without_reintroducing_identity',function()
 local c=core();local w=row(c,'P',10,1);train(c)
 local ok,why=cast(c,'forgotten','P',100,3,9);eq(ok,false);eq(why,'revision_history_lost');eq(c.occurrences['cast:forgotten'],nil)
 eq(w.mask[3],false);eq(w.lost[3],true);eq(c.model,nil);train(c);oracleModel(c)
 assert(cast(c,'real-positive','P',11.5,3));eq(w.y[3],1);eq(w.mask[3],true)
 return 'Unknown correction withdraws and censors the stated actor/family without storing uncertain identity; independent retained positive can legitimately restore that family.'
end)

test('latestever_survives_retime_retraction_and_actor_move',function()
 local c=core();ctx(c,'P',10);assert(cast(c,'e','P',100,1));assert(cast(c,'e','Q',20,2,2));assert(cast(c,'e','R',5,6,3,nil,nil,true))
 for i=1,128 do assert(aura(c,'evict'..i,10)) end
 eq(c.evidenceFloor,100);local ok,why=cast(c,'e','R',100,6);eq(ok,false);eq(why,'outside_retained_history')
 ok,why=cast(c,'e','R',101,6,4);eq(ok,false);eq(why,'revision_history_lost')
 assert(cast(c,'fresh','P',101,1));assert(cast(c,'fresh','P',4,1,2));eq(c.occurrences['cast:fresh'].at,4)
 eq(c.evidenceFloor,100);ctx(c,'P',150);eq(c.nextCastAt,nil)
 return 'Floor includes every historical maxAt through actor/family change and retraction; unknown <=floor rejected while retained revision authority remains valid.'
end)

test('partial_interval_matrix_with_positive_override',function()
 local times={9.5,10,10.5,11,12,12.5};local checks=0
 for _,lo in ipairs(times) do for _,hi in ipairs(times) do if lo<=hi then
  for coverage=0,1 do for positive=0,1 do
   local c=core();c:SetCoverage(coverage==1);ctx(c,'P',10);c:Tick(10,true);local w=c.actors.P.window
   assert(cast(c,'uncertain','P',(lo+hi)/2,4,1,lo,hi));if positive==1 then assert(cast(c,'certain','P',11.5,4)) end
   c:Tick(12.25,true)
   local inside=lo>10 and hi<=12
   local crossing=hi>10 and lo<=12 and not inside
   local expectedPositive=inside or positive==1
   local expectedMask=expectedPositive or (coverage==1 and not crossing)
   eq(w.y[4],expectedPositive and 1 or 0);eq(w.mask[4],expectedMask)
   for f=1,6 do if f~=4 then eq(w.y[f],0);eq(w.mask[f],coverage==1) end end
   checks=checks+1
  end end
 end end end
 return checks..' independently classified interval/coverage/positive-override combinations, including anchor/deadline ties.'
end)

test('retained_past_evidence_projected_without_private_mirrors',function()
 local c=core();ctx(c,'P',10);assert(cast(c,'old','P',8,1));assert(cast(c,'future','P',11,1))
 assert(c:Aura({id='old',recipient='P',at=9,spellID=22812,expires=20}))
 assert(c:Aura({id='future',recipient='P',at=12,spellID=5277,expires=20}))
 local context=c:GetContext('P',10);eq(context.history[1],8);eq(context.defensiveWitness.at,9)
 context.history[1]=999;context.defensiveWitness.at=999;eq(c:GetContext('P',10).history[1],8)
 c:Tick(10,true);local w=c.actors.P.window;local x=ns.Copy(w.x);eq(c.actors.P.forecast.expires,11)
 c:GetContext('P',500);c:Forecast('P',500);eq(c.evidenceTime,10)
 ctx(c,'P',11);c:Tick(11,true);eq(c:GetContext('P',11).history[1],11);same(w.x,x)
 return 'Old eligible witnesses remain visible behind future IDs; query copies cannot mutate state or mature labels; future cast expires forecast at 11; anchored input stays immutable.'
end)

test('retirement_plus_stale_replay_withdraws_guard',function()
 local c=core();local w=row(c,'P',10,1);train(c);local serving=c.model
 for i=1,128 do assert(aura(c,'evict'..i,20)) end
 eq(c.model,serving);eq(w.mask[1],false);local corpus=c.corpusRevision
 local ok,why=cast(c,'P:10','P',11,1);eq(ok,false);eq(why,'outside_retained_history')
 eq(c.model,nil);eq(c.corpusRevision,corpus+1);eq(w.y[1],0);eq(w.mask[1],false)
 return 'Rejected below-floor replay still reaches serving guards after routine evidence retirement; authority is never restored.'
end)

test('actor_retirement_recreation_cannot_overlap_pending_window',function()
 local c=core();ctx(c,'P',10);c:Tick(10,true);local old=c.actors.P.window
 for i=1,16 do ctx(c,'E'..i,10.1,'hostile') end
 eq(c.actors.P,nil);eq(c.openAfter,12.25);ctx(c,'P',10.2);c:Tick(10.2,true);eq(c.actors.P.window,nil)
 ctx(c,'P',12.25);c:Tick(12.25,true);assert(c.actors.P.window);eq(c.actors.P.window.anchor,12.25)
 assert(old.deadline<c.actors.P.window.anchor);eq(old.mask[1],false)
 return 'Recreated retired actor cannot open through original resolution boundary; next legal window starts 12.25.'
end)

test('sealed_session_boundary_retains_observed_not_future_positive',function()
 local c=core();ctx(c,'P',10);c:Tick(10,true);local w=c.actors.P.window
 ctx(c,'P',10.5);assert(cast(c,'past','P',10.5,1));assert(cast(c,'future','P',11.5,2))
 local x=ns.Copy(w.x);c:ResetSession(2);eq(w.y[1],1);eq(w.mask[1],true);eq(w.y[2],0);eq(w.mask[2],false)
 eq(w.actor,nil);eq(w.coverage,nil);eq(w.lost,nil);eq(w.sealed,true);same(w.x,x);eq(c.evidenceTime,2);eq(c.nextCastAt,nil);eq(c.evidenceFloor,-1)
 ctx(c,'P',20);assert(cast(c,'future','P',11.5,2));eq(w.y[2],0)
 return 'Clock rollback preserves already observed positives, never imports an unobserved future positive, and deidentified old rows remain sealed.'
end)

return results
