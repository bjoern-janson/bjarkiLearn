local current,baseline=...
local results={}
local function eq(a,b,label) assert(a==b,(label or '')..': '..tostring(a)..' ~= '..tostring(b)) end
local function same(a,b,path)
 path=path or '';eq(type(a),type(b),path)
 if type(a)~='table' then eq(a,b,path);return end
 for k,v in pairs(a) do same(v,b[k],path..'.'..tostring(k)) end
 for k in pairs(b) do assert(a[k]~=nil,path..' unexpected key '..tostring(k)) end
end
local function canonical(ns,c)
 local out=ns.Copy(c)
 for _,actor in pairs(out.actors) do actor.history=nil;actor.defensiveWitness=nil end
 return out
end
local function scenario(seed)
 local a,b=current.Core.New(),baseline.Core.New();local t=10;local checks=0;local fullChecks=0;local operation=''
 local function draw(n) seed=(seed*48271)%2147483647;return seed%n+1 end
 local function both(name,fn)
  operation=name
  local ar,ae=fn(a);local br,be=fn(b)
  if type(ar)~='table' then eq(ar,br,name..' return');eq(ae,be,name..' reason') end
  checks=checks+1
  if checks<=100 or checks%8==0 then
   same(canonical(current,a),canonical(baseline,b),name..' state');fullChecks=fullChecks+1
  end
  if checks<=100 or checks%32==0 then
   local as,bs=a:Status(),b:Status();as.version=nil;bs.version=nil;same(as,bs,name..' status')
   same(a:Export(),b:Export(),name..' export')
  end
 end
 local function context(c,id,now,role,bound)
  return c:Context({actor=id,at=now,class='DRUID',role=role or 'self',combat=true,health=.75,power=.5,form='cat',bound=bound~=false})
 end
 both('coverage',function(c) c:SetCoverage(true) end)
 -- A completed supported real model precedes randomized changes.
 for i=1,12 do
  t=10+i*3
  both('seed context '..i,function(c) context(c,'P',t) end)
  both('seed open '..i,function(c) c:Tick(t,true) end)
  if i<=3 then
   both('seed clock '..i,function(c) context(c,'P',t+1) end)
   both('seed cast '..i,function(c) return c:Cast({id='seed'..i,actor='P',at=t+1,family=1}) end)
  end
  both('seed resolve '..i,function(c) c:Tick(t+2.25,true) end)
 end
 t=t+2.25
 for i=1,50 do both('seed training '..i,function(c) c:Tick(t,false) end) end
 assert(a.model and a.model.positives[1]>=2 and a.model.totals[1]-a.model.positives[1]>=8)
 for step=1,1800 do
  t=t+.125;local kind=draw(12)
  if step%600==0 then
   both('reset '..step,function(c) c:ResetSession(t) end)
  elseif step%401==0 then
   both('restore '..step,function(c) return c:Restore(c:Export()) end)
  elseif kind<=4 then
   local id='cast'..draw(180);local old=a.occurrences['cast:'..id]
   local revision=old and (draw(5)==1 and old.revision or old.revision+1) or (draw(9)==1 and 2 or 1)
   local actor=draw(3)==1 and 'P' or 'A'..draw(20);local family=draw(6)
   local at=t+(draw(41)-20)*.125;local spread=draw(4)==1 and .375 or 0
   local retracted=draw(8)==1
   local raw={id=id,actor=actor,at=at,minAt=at-spread,maxAt=at+spread,family=family,revision=revision,retracted=retracted}
   both('cast '..step,function(c) return c:Cast(raw) end)
  elseif kind==5 then
   local raw={recipient=draw(2)==1 and 'P' or 'A'..draw(20),id='aura'..draw(100),at=t+(draw(9)-4)*.25,spellID=draw(2)==1 and 22812 or 5277,expires=t+5,newApplication=draw(3)==1}
   both('aura '..step,function(c) return c:Aura(raw) end)
  elseif kind==6 or kind==7 then
   local actor=kind==6 and 'P' or 'A'..draw(20);local now=t+(draw(9)-4)*.125
   local role=draw(4)==1 and 'hostile' or 'self';local bound=draw(8)~=1
   both('context '..step,function(c) return context(c,actor,now,role,bound) end)
  elseif kind==8 then
   local actor=draw(2)==1 and 'P' or nil
   both('gap '..step,function(c) c:Gap('probe_gap',actor) end)
  elseif kind==9 then
   both('read '..step,function(c)
    same(a:GetContext('P',t),b:GetContext('P',t),'context projection')
    local af,bf=a:Forecast('P',t+.25),b:Forecast('P',t+.25);same(af,bf,'forecast projection')
   end)
  else
   local combat=kind==10
   both('pre-tick context '..step,function(c) return context(c,'P',t) end)
   both('tick '..step,function(c) c:Tick(t,combat) end)
  end
 end
 same(canonical(current,a),canonical(baseline,b),'final state');fullChecks=fullChecks+1
 return checks,a:Status(),fullChecks
end
for _,seed in ipairs({19073,73913,81317}) do
 local ok,checks,stats,fullChecks=pcall(scenario,seed)
 results[#results+1]={name='differential_full_state_seed_'..seed,passed=ok,
  detail=ok and (checks..' return-equivalent transitions; '..fullChecks..' full-state comparisons (every 8 transitions after 100 warmup checks); Status/Export every 32. 1800 mixed actions, default caps, real models, revisions, future intervals, gaps, restore and three resets.') or nil,
  comparisons=ok and checks or nil,fullStateComparisons=ok and fullChecks or nil,error=not ok and tostring(checks) or nil,
  trainingSteps=ok and stats.trainingSteps or nil,occurrenceEvictions=ok and (stats.occurrenceEvictions or 0) or nil,
  actorEvictions=ok and (stats.actorEvictions or 0) or nil,invalidations=ok and (stats.invalidations or 0) or nil}
end
return results

