# Independent Core audit of bjarkiLearn 0.1.5

Scope: whole Core.lua and Rules.lua, the 0.1.4-to-0.1.5 Core diff, and the implementation/API contracts. Review covered occurrence replacement, old/new actor/family/time reassignment, exact and uncertain timing, observed-time maturity, actor and occurrence capacity, immutable window inputs, replay retirement, serving dependencies, candidate invalidation, copied projections, and reset/sealing. The numeric algorithm and native adapter were assigned to other audit agents.

No confirmed remaining Core bug or refactor regression was found in this review. This is a bounded code-and-modeled-execution result, not live WoW validation or a claim of predictive usefulness.

The focused probes use real Network.lua models, including exact comparison with a separately restored and rebuilt clean replay. Where synthetic `_Resolve` rows force replay retirement or a partial training candidate, the case description identifies that construction. No source files, archive contents, or existing verification files were edited.

The new runner checks the exact Core SHA-256 hashes before execution and hashes every source/baseline file again afterward:

- 0.1.5: `3766ae3f630f5f4aa072242411d9768a3b7899a39ea9bf5a43bdb3010afa800a`
- Frozen 0.1.4: `9dc55ae29fd69e76448bd8c83e8386edbaa1bff00009dbd98dc8532678c4dc01`

Fresh execution passed 66/66 case groups: 60 focused executions and six differential traces. Those traces completed 14,154 paired transitions and 2,300 exact full-state comparisons. Both complete source trees retained their pre-run hashes. Raw outcomes are in results.json (identical to report.json).

## New coverage

Fifteen focused scenario groups run independently against both releases under real Lua 5.1 and 5.4 via Lupa. They include an 84-combination interval/coverage/positive-override matrix and 12 actor/family/time reassignment scenarios with clean-model comparisons, in addition to:

- Duplicate and semantically unchanged revisions preserving the serving model.
- Routine occurrence retirement censoring replay while retaining the completed serving snapshot.
- Corrections reaching both sides of serving dependencies after 256 replay rows retire.
- Correction guards withdrawing a model even when another positive keeps the label unchanged.
- Lead-only refinements preserving a partial candidate, corpus revision and row revision when no serving model is affected.
- Enemy-only label revisions leaving the player training state intact.
- A single shared clock trigger maturing two retired actors in one corpus update.
- Maturity cancelling a partial candidate with and without an old serving generation.
- Unknown revisions censoring without reintroducing an occurrence identity.
- `latestEver` surviving backdating, actor/family changes and retraction before eviction.
- Historical query projection, future cache expiry, independent returned copies and immutable anchored inputs.
- Rejected below-floor replay still withdrawing an affected serving generation.
- Actor recreation respecting the retired pending window's resolution boundary.
- Clock rollback preserving observed positives, excluding unobserved future positives, and sealing old rows.

Three deterministic differential seeds each perform 1,800 mixed actions after training a supported real model. Each runs against both releases in each Lua engine. Return values are compared at every transition; full Core state is compared every eight transitions after the first 100, and Status/Export every 32. Public projection checks also occur within the trace. Full state is compared at the end. Only the deliberately removed private actor history/witness mirrors and the version field are excluded. The final JSON reports the actual transition and full-state comparison counts, capacity retirements, training steps and invalidations.

The first attempt to compare the full state after every operation was stopped because of execution cost. It supplies no result or pass count. The saved runner implements the bounded sampling schedule above; the focused boundary cases remain unsampled.

## Interpretation limits

The registry time floor's conservative rejection after a future identity retires, sealed old-session rows being outside later correction authority, and a serving snapshot retaining retired training influence until successful replacement are explicitly documented choices. They were not reported as defects. Source review found no internal consumer of the removed mirrors; projections continue to come from the occurrence registry. The three new reconciliation entrypoints preserve the earlier correction-versus-retirement invalidation distinction.

This suite exercises normalized private Core calls. It does not establish native event availability, live scheduling budgets, protected-value behavior in the game, held-out prediction quality, or consumer benefit. Read the raw `report.json` for exact outcomes rather than interpreting scenario counts as independent real-world evidence.

## Reproduction

Run `run.py --source <exact-0.1.5-addon-directory> --baseline <frozen-0.1.4-addon-directory> --output <new-json-file>`. Python requires Lupa with `lua51` and `lua54`; pass `--lupa-path <directory>` when its installation differs from the bundled default. The runner reads production and baseline files only and writes the requested result JSON.

