"""Independent read-only Core audit against exact extracted addon roots."""
import argparse, hashlib, importlib, json, sys
from pathlib import Path
SOURCE_CORE = '3766ae3f630f5f4aa072242411d9768a3b7899a39ea9bf5a43bdb3010afa800a'
BASELINE_CORE = '9dc55ae29fd69e76448bd8c83e8386edbaa1bff00009dbd98dc8532678c4dc01'
p = argparse.ArgumentParser()
p.add_argument('--source', type=Path, required=True)
p.add_argument('--baseline', type=Path, required=True)
p.add_argument('--output', type=Path, required=True)
p.add_argument('--lupa-path', type=Path, default=Path('C:/Users/Mewn/Documents/Codex/2026-10-16/let/work/deps'))
a = p.parse_args(); sys.path.insert(0, str(a.lupa_path)); root = Path(__file__).resolve().parent
def hashes(path):
    return {f.relative_to(path).as_posix(): hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(path.rglob('*')) if f.is_file()}
before, base_before = hashes(a.source), hashes(a.baseline)
assert before['Core.lua'] == SOURCE_CORE, 'Unexpected 0.1.5 Core hash'
assert base_before['Core.lua'] == BASELINE_CORE, 'Unexpected frozen 0.1.4 Core hash'
results = []
for engine in ('lua51', 'lua54'):
    module = importlib.import_module('lupa.' + engine)
    def load(lua, path):
        ns = lua.table()
        for f in ('Bootstrap.lua', 'Rules.lua', 'Network.lua', 'Core.lua'):
            lua.execute((path / f).read_text(encoding='utf-8-sig'), 'bjarkiLearn', ns)
        return ns
    for label, path in (('0.1.5', a.source), ('0.1.4', a.baseline)):
        lua = module.LuaRuntime(unpack_returned_tuples=True)
        rows = lua.execute((root / 'probes.lua').read_text(encoding='utf-8'), load(lua,path))
        for _, row in rows.items(): results.append({'engine': engine, 'source_version': label, **dict(row.items())})
        print(engine, label, 'focused cases completed', flush=True)
    lua = module.LuaRuntime(unpack_returned_tuples=True)
    rows = lua.execute((root / 'differential.lua').read_text(encoding='utf-8'), load(lua,a.source), load(lua,a.baseline))
    for _, row in rows.items(): results.append({'engine': engine, 'source_version': '0.1.5_vs_0.1.4', **dict(row.items())})
    print(engine, 'differential cases completed', flush=True)
report = {'source': str(a.source.resolve()), 'baseline': str(a.baseline.resolve()),
    'source_hashes': before, 'baseline_hashes': base_before,
    'source_unchanged': before == hashes(a.source), 'baseline_unchanged': base_before == hashes(a.baseline),
    'total': len(results), 'passed': sum(bool(r['passed']) for r in results), 'cases': results,
    'limits': ['Real Lua 5.1 and Lua 5.4 via Lupa; synthetic normalized private Core inputs, not live WoW.',
      'Real Network.lua models trained. Some probes construct private _Resolve rows and identify this explicitly.',
      'Differential equivalence excludes removed actor history/witness mirrors and version metadata.',
      'No production or preexisting verification files modified.']}
a.output.parent.mkdir(parents=True, exist_ok=True)
a.output.write_text(json.dumps(report, indent=2)+'\n', encoding='utf-8')
print(json.dumps({k:report[k] for k in ('total','passed','source_unchanged','baseline_unchanged')},indent=2))
print(json.dumps({'failures':[r for r in results if not r['passed']]},indent=2))
sys.exit(int(report['passed'] != report['total'] or not report['source_unchanged'] or not report['baseline_unchanged']))

