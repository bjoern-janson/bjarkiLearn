from pathlib import Path
import argparse,hashlib,importlib,json,sys
try:import lupa
except ImportError:sys.path.insert(0,'C:/Users/Mewn/Documents/Codex/2026-10-16/let/work/deps')
p=argparse.ArgumentParser();p.add_argument('--source',required=True,type=Path);p.add_argument('--baseline',required=True,type=Path);p.add_argument('--output',required=True,type=Path);a=p.parse_args()
r=Path(__file__).resolve().parent
harness=(r/'harness.lua').read_text(encoding='utf-8');trace=(r/'trace.lua').read_text(encoding='utf-8')
def hashes(path):return {f.relative_to(path).as_posix():hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(path.rglob('*')) if f.is_file()}
def plain(value):return {k:plain(v) for k,v in value.items()} if hasattr(value,'items') else value
def lua_value(lua,value):return lua.table_from({k:lua_value(lua,v) for k,v in value.items()}) if isinstance(value,dict) else value
def canonical(v):
 if isinstance(v,dict):return {str(type(k).__name__)+':'+str(k):canonical(x) for k,x in v.items()}
 return v
def digest(v):return hashlib.sha256(json.dumps(canonical(v),sort_keys=True,separators=(',',':')).encode()).hexdigest()
def execute(engine,source,seed,saved=None):
 lua=importlib.import_module('lupa.'+engine).LuaRuntime(unpack_returned_tuples=True)
 lua.globals().LEARN_ROOT=source.resolve().as_posix();lua.globals().BUS_PATH=(r/'SharedEvidence.lua').as_posix();lua.globals().TRACE_SEED=seed
 lua.execute(harness)
 if saved is not None:lua.globals().SAVED=lua_value(lua,saved)
 return plain(lua.execute(trace))
before={'source':hashes(a.source),'baseline':hashes(a.baseline)};results=[];runs=[];references={}
for seed in (101,211):
 for engine in ('lua51','lua54'):
  pair={}
  for name,source in (('0.1.4',a.baseline),('0.1.5',a.source)):
   data=execute(engine,source,seed);reload=execute(engine,source,seed,data['saved']);pair[name]=data
   same=reload['model']==data['model'] and reload['export']==data['export']
   results.append({'kind':'native_saved_reload','seed':seed,'runtime':engine,'version':name,'passed':same})
   key=(seed,name)
   if key in references:results.append({'kind':'cross_lua_complete_trace','seed':seed,'version':name,'passed':data==references[key]})
   else:references[key]=data
   runs.append({'seed':seed,'runtime':engine,'version':name,'trace_digest':digest(data),'model_digest':digest(data['model']),'checks':data['checks']+reload['checks'],'snapshots':len(data['snapshots']),'updates':data['updates'],'examples':len(data['export']['examples'])})
   print(seed,engine,name,'reload',same,flush=True)
  results.append({'kind':'014_015_complete_trace','seed':seed,'runtime':engine,'passed':pair['0.1.4']==pair['0.1.5']})
after={'source':hashes(a.source),'baseline':hashes(a.baseline)}
out={'passed':all(x['passed'] for x in results) and before==after,'total':len(results),'passes':sum(x['passed'] for x in results),'source_hashes':before['source'],'baseline_hashes':before['baseline'],'source_unchanged':before==after,'runs':runs,'comparisons':results,'scope':'Two 160-cycle actual Main/Adapter/Core native traces per release and Lua runtime; future bus publication, aliases, unreadable cast/clock, disable-enable, world resets, full replay and fresh native save/reload. Exact full normalized Core state and public projections at 9 checkpoints. Only removed actor mirrors and version metadata normalized.'}
a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8');print(json.dumps({'passed':out['passed'],'passes':out['passes'],'total':out['total'],'checks':sum(x['checks'] for x in runs),'failures':[x for x in results if not x['passed']]},indent=2));sys.exit(0 if out['passed'] else 1)
