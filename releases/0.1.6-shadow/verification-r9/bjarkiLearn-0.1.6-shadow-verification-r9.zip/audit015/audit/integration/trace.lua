local seed=TRACE_SEED or 101
local checks=0
local function check(v,m) checks=checks+1;assert(v,m) end
local function plainCore()
 local copy=NS.Copy(Runtime.core)
 for _,a in pairs(copy.actors) do a.history=nil;a.defensiveWitness=nil end
 return copy
end
local function status()
 local s=BjarkiLearn:Status();s.version="metadata";s.core.version="metadata";return s
end
local function sample(label)
 local public={}
 for _,unit in ipairs({"player","target","focus"}) do
  public[unit]={context=BjarkiLearn:GetContext(unit),forecast=BjarkiLearn:Forecast(unit)}
 end
 return {label=label,state=plainCore(),status=status(),public=public,export=Runtime.core:Export()}
end
local function bound()
 local c=Runtime.core
 check(#c.actorOrder<=16 and #c.occurrenceOrder<=128 and #c.examples<=256 and #c.modelDependencies<=256,"bounded state")
 check(not Runtime.faulted and Runtime.errors==0,"native handler fault")
end
local snapshots={}
World.classes.focus='PRIEST'
World.ids.focus='Player-1-300'
if SAVED then
 bjarkiLearnDB=SAVED;World.combat=false;World.unitCombat=false;Init()
 for i=1,700 do Advance(10+i*.125);bound() end
 check(Runtime.core.model and not Runtime.core.dirty and not Runtime.core.candidate,'reload training completed')
 Event('PLAYER_LOGOUT')
 return {checks=checks,model=NS.Copy(Runtime.core.model),export=Runtime.core:Export(),saved=bjarkiLearnDB}
end
LoadBus();Init();Advance(10)
local names={8122,853,122,15487,1766,22812}
for cycle=1,160 do
 local base=10+(cycle-1)*3
 World.now=base;World.combat=true;World.unitCombat=true
 World.ids.target='Player-1-'..(200+math.floor((cycle+seed)%43))
 World.ids.focus=cycle%11==0 and World.ids.player or 'Player-1-'..(400+math.floor((cycle+seed)%29))
 if cycle%13==0 then World.ids.focus=nil end
 Event('PLAYER_TARGET_CHANGED');Event('PLAYER_FOCUS_CHANGED');Advance(base)
 for step=1,22 do
  local t=base+step*.125
  World.now=t
  if step==3 or step==10 or step==18 then
   local unit=step==3 and 'player' or (step==10 and 'target' or 'focus')
   if World.ids[unit] then
    local id='Cast-'..seed..'-'..cycle..'-'..step
    local spell=names[1+(cycle+step+seed)%6]
    if cycle%5==0 or unit~='player' then
     Event('UNIT_SPELLCAST_SUCCEEDED',unit,id,spell)
     if cycle%7==0 then Event('UNIT_SPELLCAST_SUCCEEDED',unit,id,spell) end
    end
   end
  end
  if step==5 and cycle%9==0 then
   local at=t+.5
   check(BjarkiEvidenceV1:Publish({source='bjarkiPortraits',kind='aura-positive',isHelpful=true,recipientGUID=World.ids.target,unit='target',
    spellId=22812,auraInstanceID=1000+cycle,observedAt=at,expirationTime=at+7,newApplication=false}),'future bus publication')
   local ctx=BjarkiLearn:GetContext('target')
   check(not ctx.defensiveWitness or ctx.defensiveWitness.at<=t,'future witness leaked')
  end
  if step==9 and cycle%17==0 then Event('UNIT_SPELLCAST_SUCCEEDED','player',Opaque,8122) end
  if step==12 and cycle%23==0 then
   Runtime:Command('disable');check(BjarkiLearn:GetContext('player')==nil,'disabled projection')
   Runtime:Command('enable')
  end
  if step==14 and cycle%31==0 then Event('PLAYER_ENTERING_WORLD') end
  if step==16 and cycle%37==0 then
   local original=GetTime;GetTime=function() return Opaque end
   Runtime:Update();check(BjarkiLearn:Forecast('player')==nil,'unreadable clock projection');GetTime=original
  end
  if step==21 then World.combat=false;World.unitCombat=false end
  Advance(t);bound()
 end
 if cycle%20==0 then snapshots[#snapshots+1]=sample('cycle'..cycle) end
end
World.combat=false;World.unitCombat=false
local final=World.now
for i=1,700 do Advance(final+i*.125);bound() end
check(#Runtime.core.examples==256,'retained replay reached capacity')
check(Runtime.core.model and not Runtime.core.dirty and not Runtime.core.candidate,'final replay completed')
snapshots[#snapshots+1]=sample('final')
local current=BjarkiLearn:GetContext('player');current.history[1]=99999;current.class='MAGE'
check(BjarkiLearn:GetContext('player').class=='DRUID','public copy changed collection')
Event('PLAYER_LOGOUT')
return {checks=checks,snapshots=snapshots,model=NS.Copy(Runtime.core.model),export=Runtime.core:Export(),saved=bjarkiLearnDB,status=status(),updates=Runtime.updates}
