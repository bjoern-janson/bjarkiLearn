-- Actual addon modules; only the unavailable WoW host is modeled.
local ns={}
World={now=10,combat=true,ids={player='Player-1-100',target='Player-1-200'},classes={player='DRUID',target='ROGUE'},unitCombat=true,frames={},chat={}}
Opaque=setmetatable({}, {__tostring=function() error('opaque formatted') end})
Inaccessible=setmetatable({}, {__tostring=function() error('inaccessible formatted') end})
issecretvalue=function(v) return rawequal(v,Opaque) end
issecrettable=function(v) return rawequal(v,Opaque) end
canaccessvalue=function(v) return not rawequal(v,Inaccessible) end
GetTime=function() return World.now end
InCombatLockdown=function() return World.combat end
UnitGUID=function(u) return World.ids[u] end
UnitIsPlayer=function(u) return World.ids[u]~=nil end
UnitClassBase=function(u) return World.classes[u] end
UnitCanAttack=function(_,u) return u~='player' end
UnitAffectingCombat=function() return World.unitCombat end
UnitHealth=function() return 75 end
UnitHealthMax=function() return 100 end
UnitPower=function() return 50 end
UnitPowerMax=function() return 100 end
UnitIsDeadOrGhost=function() return false end
UnitPowerType=function() return 0,'MANA' end
SlashCmdList={}
DEFAULT_CHAT_FRAME={AddMessage=function(_,s) World.chat[#World.chat+1]=s end}
CreateFrame=function()
 local f={scripts={},events={}}
 function f:RegisterEvent(e) self.events[e]=true end
 function f:SetScript(k,v) self.scripts[k]=v end
 World.frames[#World.frames+1]=f;return f
end
for _,file in ipairs({'Bootstrap.lua','Rules.lua','Network.lua','Core.lua','Adapter.lua','Main.lua'}) do assert(loadfile(LEARN_ROOT..'/'..file))('bjarkiLearn',ns) end
NS=ns;Runtime=ns.Runtime
function Check(v,s) CHECKS=(CHECKS or 0)+1;if not v then error(s or 'check failed',2) end end
function Equal(a,b,s) Check(a==b,(s or 'equal')..': '..tostring(a)..' ~= '..tostring(b)) end
function Init() Runtime.frame.scripts.OnEvent(Runtime.frame,'ADDON_LOADED','bjarkiLearn') end
function Event(e,...) Runtime.frame.scripts.OnEvent(Runtime.frame,e,...) end
function Advance(t) World.now=t;Runtime.frame.scripts.OnUpdate(Runtime.frame,.1) end
function EndFirst()
 Advance(10.5);Advance(11);Advance(11.5);Advance(12);World.combat=false;World.unitCombat=false;Advance(12.3)
end
function PlayerExample() for _,w in ipairs(Runtime.core.examples) do if w.regime=='player' then return w end end end
function ExpectPlayerMasks(value)
 local w=assert(PlayerExample(),'missing player example');for i=1,6 do Equal(w.mask[i],value,'player family mask '..i) end
end
function LoadBus() assert(loadfile(BUS_PATH))('bjarkiPortraits',{}) end
function PublishAura(instance,at)
 return BjarkiEvidenceV1:Publish({source='bjarkiPortraits',kind='aura-positive',isHelpful=true,recipientGUID=World.ids.target,unit='target',spellId=5277,auraInstanceID=instance,observedAt=at or World.now,duration=10,expirationTime=20,newApplication=false})
end
