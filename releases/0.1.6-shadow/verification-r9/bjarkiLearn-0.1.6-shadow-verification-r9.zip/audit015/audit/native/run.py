"""Read-only native-entrypoint audit; actual addon modules with modeled WoW host."""
import argparse, hashlib, importlib, json, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--source',required=True,type=Path)
p.add_argument('--baseline',type=Path)
p.add_argument('--output',required=True,type=Path)
p.add_argument('--bus',type=Path,default=ROOT.parents[1]/'verification/fixtures/SharedEvidence.lua')
p.add_argument('--lupa-path',action='append',default=[])
a=p.parse_args()
for path in a.lupa_path:sys.path.insert(0,path)
bus=a.bus.resolve()
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def hashes(root):return {f.relative_to(root).as_posix():sha(f) for f in sorted(root.rglob('*')) if f.is_file()}
harness=(ROOT/'harness.lua').read_text(encoding='utf-8-sig')
probes=(ROOT/'probes.lua').read_text(encoding='utf-8-sig')
sources={'current':a.source.resolve()}
if a.baseline:sources['baseline']=a.baseline.resolve()
results=[];trees={}
for label,source in sources.items():
 before=hashes(source)
 for engine in ('lua51','lua54'):
  LuaRuntime=importlib.import_module('lupa.'+engine).LuaRuntime
  discovery=LuaRuntime(unpack_returned_tuples=True);discovery.execute(probes)
  for name in sorted(discovery.globals().CASES.keys()):
   lua=LuaRuntime(unpack_returned_tuples=True);lua.globals().LEARN_ROOT=source.as_posix();lua.globals().BUS_PATH=bus.as_posix();error=None;projection=None;trace=None
   try:
    lua.execute(probes);case=lua.globals().CASES[name]
    if case['setup']:case['setup']()
    lua.execute(harness);case['run']();projection=lua.globals().Snapshot();trace=lua.globals().TRACE
   except Exception as exc:error=str(exc)
   results.append(dict(source=label,engine=engine,case=name,passed=error is None,checks=lua.globals().CHECKS or 0,error=error,projection_hash=hashlib.sha256(projection.encode()).hexdigest() if projection else None,trace_hash=hashlib.sha256('\n'.join(trace[i] for i in range(1,len(trace)+1)).encode()).hexdigest() if trace else None))
 after=hashes(source);trees[label]=dict(path=str(source),before=before,after=after,unchanged=before==after)
comparisons=[]
if a.baseline:
 for current in [x for x in results if x['source']=='current']:
  base=next(x for x in results if x['source']=='baseline' and x['engine']==current['engine'] and x['case']==current['case'])
  comparisons.append(dict(engine=current['engine'],case=current['case'],public_projection_equal=current['projection_hash']==base['projection_hash'],trace_equal=current['trace_hash']==base['trace_hash']))
report=dict(comparisons=comparisons,source_trees=trees,fixture=dict(path=str(bus),sha256=sha(bus)),harness_hashes={f.name:sha(f) for f in (ROOT/'harness.lua',ROOT/'probes.lua',ROOT/'run.py')},summary=dict(passed=sum(x['passed'] for x in results),total=len(results),checks=sum(x['checks'] for x in results)),cases=results,claim_ceiling='Actual Main/Adapter/Bootstrap/Rules/Network/Core plus unchanged SharedEvidence under Lua 5.1/5.4. Host APIs and failures are modeled, not live WoW verification or prediction-usefulness evidence.')
a.output.resolve().parent.mkdir(parents=True,exist_ok=True)
a.output.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
failures=[x for x in results if not x['passed']]
differences=[x for x in comparisons if not x['public_projection_equal'] or not x['trace_equal']]
print(json.dumps(dict(summary=report['summary'],source_unchanged=all(t['unchanged'] for t in trees.values()),failures=failures,differences=differences),indent=2))
sys.exit(0 if not failures and not differences and all(t['unchanged'] for t in trees.values()) else 1)


