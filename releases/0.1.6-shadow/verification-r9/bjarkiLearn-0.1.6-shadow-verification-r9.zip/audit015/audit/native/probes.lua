CASES={}
function Case(name,run,setup) CASES[name]={run=run,setup=setup} end
Case('live future bus publish preserves earlier witness and expires forecast at maturity',function()
 LoadBus();Init();Advance(10)
 Check(Publish(1,9,nil,5277,18));Check(Publish(2,10.5,nil,22812,20))
 Equal(BjarkiLearn:GetContext('target').defensiveWitness.at,9)
 Advance(10.125);local f=BjarkiLearn:Forecast('target');Equal(f.expires,10.5)
 World.now=10.49;Equal(BjarkiLearn:GetContext('target').defensiveWitness.spellID,5277)
 Equal(BjarkiLearn:Forecast('target').reason,nil)
 World.now=10.5;Equal(BjarkiLearn:GetContext('target').defensiveWitness.spellID,22812)
 Equal(BjarkiLearn:Forecast('target').reason,'expired')
 Advance(10.5);Equal(BjarkiLearn:Forecast('target').at,10.5)
 Equal(Runtime.core.stats.casts,nil);Equal(BjarkiEvidenceV1:Status().errors,0)
end)
Case('replay filters future publication while later live publication is accepted',function()
 LoadBus();Check(Publish(1,10.5,nil,22812,20));Init();Advance(10)
 Equal(Runtime.adapter.stats.auras,0);Equal(Runtime.core:Status().occurrences,0)
 Check(Publish(2,10.5,nil,5277,20));Equal(Runtime.adapter.stats.auras,1)
 Equal(Runtime.core:Status().occurrences,1);Equal(BjarkiLearn:GetContext('target').defensiveWitness,nil)
 Advance(10.5);Equal(BjarkiLearn:GetContext('target').defensiveWitness.spellID,5277)
 Event('PLAYER_ENTERING_WORLD');Equal(Runtime.core:Status().occurrences,2)
 Equal(Runtime.core.stats.casts,nil);Equal(BjarkiEvidenceV1:Status().listeners,1)
end)
Case('public queries at varied clocks do not mutate the core or train',function()
 LoadBus();Init();Advance(10);Check(Publish(1,9,nil,5277,18));Check(Publish(2,11,nil,22812,20))
 World.now=10.2;Event('UNIT_SPELLCAST_SUCCEEDED','player','observed',22812)
 local before=Serialize(Runtime.core);local updates=Runtime.updates
 for _,t in ipairs({10.2,10.9,11,12,10.2,9,100}) do
  World.now=t
  for _,u in ipairs({'player','target','focus','Player-1-999'}) do
   local c=BjarkiLearn:GetContext(u);local f=BjarkiLearn:Forecast(u)
   if c then c.history[6]=999;c.candidates.defensive.status='foreign';c.defensiveWitness={at=999} end
   if f then f.outputs[1]={score=999};f.modelVersion=999 end
  end
  local s=BjarkiLearn:Status();s.core.gapReasons.foreign=999;s.adapter.casts=999
 end
 Equal(Serialize(Runtime.core),before);Equal(Runtime.updates,updates)
 World.now=10.2;Equal(BjarkiLearn:GetContext('player').history[6],10.2)
 Equal(BjarkiLearn:GetContext('target').defensiveWitness.at,9)
end)
Case('native history feeds the next anchor after all six cast families',function()
 World.combat=false;World.unitCombat=false;Init();Advance(10)
 local spells={8122,853,122,15487,1766,22812}
 for i,spell in ipairs(spells) do World.now=10+i*.02;Event('UNIT_SPELLCAST_SUCCEEDED','player','family-'..i,spell) end
 local c=BjarkiLearn:GetContext('player')
 for i=1,6 do Equal(c.history[i],10+i*.02) end
 World.combat=true;World.unitCombat=true;Advance(10.25)
 local row=Runtime.core.actors[World.ids.player].window
 for i=1,6 do Equal(row.x[19+i*2],1);Check(row.x[18+i*2]>0) end
 Equal(Runtime.core.stats.casts,6);Check(not Runtime.faulted)
end)
Case('retired native actor rebinds from retained registry evidence',function()
 World.combat=false;World.unitCombat=false;Init();Advance(10)
 World.now=10.05;Event('UNIT_SPELLCAST_SUCCEEDED','target','old-target',5277)
 local original=World.ids.target
 for i=1,20 do
  World.now=10.05+i*.03;World.ids.target='Player-1-'..(200+i);Event('PLAYER_TARGET_CHANGED')
 end
 Equal(Runtime.core.actors[original],nil);Check(Runtime.core.stats.actorEvictions>0)
 World.ids.target=original;World.now=10.7;Event('PLAYER_TARGET_CHANGED')
 Equal(BjarkiLearn:GetContext('target').history[6],10.05)
 World.combat=true;World.unitCombat=true;Advance(10.75)
 Equal(Runtime.core.actors[original].window.x[31],1);Check(Runtime.core.actors[original].window.x[30]>0)
 Check(Runtime.core:Status().actors<=16);Check(not Runtime.faulted)
end)
Case('bus capacity retirement removes native cast history from future features',function()
 LoadBus();World.combat=false;World.unitCombat=false;Init();Advance(10)
 World.now=10.05;Event('UNIT_SPELLCAST_SUCCEEDED','player','retired',22812)
 Equal(BjarkiLearn:GetContext('player').history[6],10.05)
 for i=1,128 do Check(Publish(i,10.1,'Player-1-999',5277,20)) end
 Equal(BjarkiLearn:GetContext('player').history[6],nil)
 Equal(Runtime.core:Status().occurrences,128);Equal(Runtime.core.stats.occurrenceEvictions,1)
 World.combat=true;World.unitCombat=true;Advance(10.25)
 Equal(Runtime.core.actors[World.ids.player].window.x[31],0)
 Equal(Runtime.core.actors[World.ids.player].window.x[30],0)
 Check(not Runtime.faulted)
end)
Case('alias changes between same-time deliveries preserve dedup and self context',function()
 World.ids.target=World.ids.player;World.ids.focus=World.ids.player;Init();Advance(10)
 World.now=10.2;Event('UNIT_SPELLCAST_SUCCEEDED','target','same-cast',22812)
 World.ids.target='Player-1-201';Event('PLAYER_TARGET_CHANGED')
 Event('UNIT_SPELLCAST_SUCCEEDED','focus','same-cast',22812)
 World.ids.focus=nil;Event('PLAYER_FOCUS_CHANGED')
 Event('UNIT_SPELLCAST_SUCCEEDED','player','same-cast',22812)
 Equal(Runtime.core.stats.casts,1);Equal(Runtime.core.stats.duplicateCasts,2)
 Equal(BjarkiLearn:GetContext('player').regime,'player');Check(Runtime.adapter.coverage)
 FinishFirst();local row=FirstPlayer();Equal(row.y[6],1)
 for i=1,6 do Equal(row.mask[i],true) end
end)
Case('failure in adapter event pauses collection and enable recovers with one listener',function()
 LoadBus();Init();Advance(10);local old=Runtime.adapter;local callback=old.callback
 old.OnEvent=function() error('injected adapter failure') end
 Event('PLAYER_TARGET_CHANGED');Equal(Runtime.errors,1);Check(Runtime.faulted);Check(old.stopped)
 Equal(BjarkiEvidenceV1:Status().listeners,0);Equal(BjarkiLearn:GetContext('player'),nil)
 local seen=old.stats.auras;Check(Publish(2,10,nil,5277,20));Equal(old.stats.auras,seen)
 Command('enable');Check(Runtime.adapter~=old);Check(not Runtime.faulted)
 Equal(BjarkiEvidenceV1:Status().listeners,1);Equal(Runtime.adapter.stats.auras,1)
 callback({});Equal(old.stats.auras,seen);Equal(Runtime.errors,1)
end)
Case('failure in update pauses without exposing a stale forecast and reset recovers',function()
 LoadBus();Init();Advance(10);Runtime.adapter.Tick=function() error('injected tick failure') end
 Advance(10.25);Equal(Runtime.errors,1);Check(Runtime.faulted)
 Equal(BjarkiLearn:Forecast('player'),nil);Equal(BjarkiEvidenceV1:Status().listeners,0)
 Command('reset');Check(not Runtime.faulted);Check(Runtime.enabled)
 Equal(Runtime.core:Status().examples,0);Equal(BjarkiEvidenceV1:Status().listeners,1)
 Advance(10.5);Check(BjarkiLearn:GetContext('player').fresh)
end)
Case('unreadable clock during disable enable cannot produce absence labels',function()
 LoadBus();Init();Advance(10);World.now=10.2;Event('UNIT_SPELLCAST_SUCCEEDED','player','pre-gap',22812)
 World.now=Opaque;Command('disable');Check(not Runtime.enabled);Command('enable');Check(Runtime.enabled)
 Equal(BjarkiLearn:Forecast('player'),nil);Equal(BjarkiEvidenceV1:Status().listeners,0)
 Advance(10.5);Advance(11);Advance(11.5);Advance(12);Advance(12.3)
 local row=FirstPlayer();Equal(row.y[6],1);Equal(row.mask[6],true)
 for i=1,5 do Equal(row.mask[i],false) end
 Check(not Runtime.faulted);Check(BjarkiLearn:GetContext('player').fresh)
 Event('ADDON_LOADED','unrelated');Equal(BjarkiEvidenceV1:Status().listeners,1)
end)
Case('world reset with a future live bus row replays only clock-eligible rows',function()
 LoadBus();Init();Advance(10);Check(Publish(1,9,nil,5277,18));Check(Publish(2,11,nil,22812,20))
 World.now=10.2;Event('UNIT_SPELLCAST_SUCCEEDED','player','world-positive',22812)
 local session=Runtime.core.session;Event('PLAYER_ENTERING_WORLD')
 Equal(Runtime.core.session,session+1);Equal(Runtime.core:Status().occurrences,1)
 Equal(BjarkiLearn:GetContext('target').defensiveWitness.at,9)
 Equal(BjarkiLearn:GetContext('player').history[6],nil)
 local row=FirstPlayer();Check(row.sealed);Equal(row.actor,nil);Equal(row.y[6],1)
 for i=1,5 do Equal(row.mask[i],false) end
 Advance(11);Equal(BjarkiLearn:GetContext('target').defensiveWitness.at,9)
 Event('PLAYER_ENTERING_WORLD');Equal(Runtime.core:Status().occurrences,2)
 Equal(BjarkiLearn:GetContext('target').defensiveWitness.at,11)
end)
Case('combat event callbacks never execute optimizer samples including restored data',function()
 Init();Advance(10);FinishFirst();World.combat=false;World.unitCombat=false;Advance(12.5)
 Check(Runtime.core:Status().trainingSteps>0);Event('PLAYER_LOGOUT')
 local saved=bjarkiLearnDB
 BjarkiLearn=nil;Runtime=NS.Main.New();bjarkiLearnDB=saved;World.combat=true;World.unitCombat=true
 Init();Equal(Runtime.core:Status().trainingSteps,0)
 for _,event in ipairs({'PLAYER_REGEN_DISABLED','PLAYER_REGEN_ENABLED','PLAYER_ALIVE','PLAYER_DEAD','PLAYER_TARGET_CHANGED','PLAYER_FOCUS_CHANGED','PLAYER_ENTERING_WORLD'}) do
  Event(event);Equal(Runtime.core:Status().trainingSteps,0)
 end
 Advance(12.75);Equal(Runtime.core:Status().trainingSteps,0)
 World.combat=nil;Advance(13);Equal(Runtime.core:Status().trainingSteps,0)
 World.combat=false;Advance(13.25);Check(Runtime.core:Status().trainingSteps>0)
end)
for _,entry in ipairs({
 {'UnitGUID','identity'}, {'UnitIsPlayer','optional'}, {'UnitClassBase','optional'},
 {'UnitCanAttack','optional'}, {'UnitAffectingCombat','combat'}, {'UnitHealth','optional'},
 {'UnitHealthMax','optional'}, {'UnitPower','optional'}, {'UnitPowerMax','optional'},
 {'UnitIsDeadOrGhost','optional'}, {'UnitPowerType','optional'}, {'InCombatLockdown','lockdown'},
}) do
 for _,mode in ipairs({'opaque','inaccessible','throws'}) do
  local name,kind,shape=entry[1],entry[2],mode
  Case('native boundary '..name..' '..shape,function()
   Init();Advance(10);local original=_G[name]
   _G[name]=function() if shape=='throws' then error('host unavailable') end
    local value=shape=='opaque' and Opaque or Inaccessible;return value,value end
   Advance(10.25);World.now=10.3;Event('UNIT_SPELLCAST_SUCCEEDED','player','boundary-cast',22812)
   _G[name]=original;FinishFirst();Check(not Runtime.faulted)
   local row=FirstPlayer()
   if kind=='identity' then
    for i=1,6 do Equal(row.mask[i],false) end
   else
    Equal(row.y[6],1);Equal(row.mask[6],true)
    for i=1,5 do Equal(row.mask[i],kind~='combat' and kind~='lockdown') end
   end
  end)
 end
end
for _,mode in ipairs({'false','throws','opaque','number','true','nil'}) do
 local shape=mode
 Case('native registration '..mode..' survives world reset and enable',function()
  Init();Advance(10);local expected=shape=='true' or shape=='nil'
  Equal(Runtime.adapter.coverage,expected)
  Event('PLAYER_ENTERING_WORLD');Equal(Runtime.adapter.coverage,expected)
  Command('disable');Command('enable');Equal(Runtime.adapter.coverage,expected)
  Advance(10);FinishFirst();local row;for _,w in ipairs(Runtime.core.examples) do if w.regime=='player' and not w.sealed then row=w end end;Check(row~=nil)
  for i=1,6 do Equal(row.mask[i],expected) end
  Check(not Runtime.faulted)
 end,function() REGISTRATION={UNIT_SPELLCAST_SUCCEEDED=shape} end)
end

for _,initialSeed in ipairs({17017,99137}) do
 local seed=initialSeed
 Case('mixed native lifecycle differential seed '..seed,function()
  LoadBus();Init();Advance(10);TRACE={};local randomState=seed
  local function rng(max) randomState=(randomState*16807)%2147483647;return randomState%max+1 end
  local spells={8122,853,122,15487,1766,22812,99999}
  for step=1,320 do
   World.now=10+step*.125
   World.combat=step%64<40;World.unitCombat=World.combat
   local action=rng(12)
   if action<=3 then
    local unit=({'player','target','focus'})[rng(3)]
    Event('UNIT_SPELLCAST_SUCCEEDED',unit,'trace-cast-'..rng(35),spells[rng(#spells)])
   elseif action==4 or action==5 then
    local unit=action==4 and 'target' or 'focus';local id=rng(24)
    World.ids[unit]=id==1 and nil or id==2 and World.ids.player or 'Player-1-'..(200+id)
    World.classes[unit]=({'DRUID','ROGUE','PRIEST','MAGE'})[rng(4)]
    Event(action==4 and 'PLAYER_TARGET_CHANGED' or 'PLAYER_FOCUS_CHANGED')
   elseif action==6 and World.ids.target then
    Check(Publish(rng(40),World.now+(rng(3)-2)*.5,nil,rng(2)==1 and 5277 or 22812,World.now+10))
   elseif action==7 then Event('PLAYER_REGEN_ENABLED')
   elseif action==8 then Event('PLAYER_REGEN_DISABLED')
   elseif action==9 then Event('UNIT_SPELLCAST_SUCCEEDED',Opaque,'unreadable',22812)
   elseif action==10 then Event('ADDON_LOADED','unrelated')
   elseif action==11 then Command('disable');Command('enable')
   elseif action==12 then Event('PLAYER_ENTERING_WORLD') end
   Advance(World.now)
   local s=BjarkiLearn:Status();Check(not s.faulted);Check(s.core.actors<=16);Check(s.core.occurrences<=128)
   Check(s.core.examples<=256);Check(BjarkiEvidenceV1:Status().listeners<=1)
   for _,unit in ipairs({'target','focus'}) do
    local c=BjarkiLearn:GetContext(unit);local f=BjarkiLearn:Forecast(unit)
    if c and c.regime=='other' and f then for _,o in ipairs(f.outputs) do Equal(o.score,nil) end end
   end
   TRACE[#TRACE+1]=Snapshot()
  end
 end)
end
