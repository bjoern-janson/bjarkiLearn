local ns,seeds=...
local C,R,M=ns.Config,ns.Rules,ns.Models
local cases,checks,fingerprints={},0,{}
local function ck(v,message) checks=checks+1;assert(v,message or 'assertion') end
local function eq(a,b)
 if type(a)~=type(b) then return false end
 if type(a)~='table' then return a==b end
 for k,v in next,a do if not eq(v,b[k]) then return false end end
 for k in next,b do if a[k]==nil then return false end end
 return true
end
local function same(a,b,message) ck(eq(a,b),message) end
local function case(name,fn)
 local prior=checks;debugprofilestop=nil
 local ok,detail=pcall(fn)
 cases[#cases+1]={name=name,passed=ok,checks=checks-prior,error=not ok and tostring(detail) or nil,detail=ok and detail or nil}
end
local function vector(n,value) local out={};for i=1,n do out[i]=value end;return out end
local function modelState(m)
 if not m then return 'nil' end
 local out={}
 local function put(v)
  if type(v)=='table' then for i=1,#v do put(v[i]) end else out[#out+1]=string.format('%.17g',v) end
 end
 for _,name in ipairs({'schemaVersion','inputs','hidden','outputs','seed','rngState','learningRate','regularization','linearRegularization','gradientClip','hiddenWeights','hiddenBiases','outputWeights','outputBiases','linearWeights','linearBiases','positives','totals','updates'}) do put(m[name]) end
 return table.concat(out,'\n')
end
local function newCore() local c=ns.Core.New();c:SetCoverage(true);return c end
local function context(c,t,extra)
 local raw={actor='P',at=t,role='self',class='PRIEST',combat=true,bound=true,health=.7,power=.3}
 if extra then for k,v in pairs(extra) do raw[k]=v end end
 return assert(c:Context(raw))
end
local function cast(c,id,t,f,r,other)
 local raw={id=id,actor='P',at=t,family=f or 1,revision=r or 1}
 if other then for k,v in pairs(other) do raw[k]=v end end
 return c:Cast(raw)
end
local function settle(c,t)
 for i=1,2000 do c:Tick(t or c.now,false);if not c.dirty then break end end
 ck(not c.dirty and c.candidate==nil,'candidate finishes')
 if c.model then ck(c.model:Valid(),'published model valid') end
 return c.model
end
local function makeSave(n)
 local rows={}
 for i=1,n do
  local actor={class=(i%2==0 and 'DRUID' or 'PRIEST'),role='self',health=(i%11)/10,power=(i%7)/6,combat=i%3~=0}
  if i%2==0 then actor.form='cat' end
  local y,mask,p={},{},{neural={},linear={},frequency={}}
  for f=1,6 do
   y[f]=(i+f)%4==0 and 1 or 0;mask[f]=(i+f)%7~=0
   if i%3==0 then p.neural[f]=.2;p.linear[f]=.4;p.frequency[f]=.6 end
  end
  rows[i]={x=R.Features(actor,i,{}),y=y,mask=mask,regime=i%9==0 and 'other' or 'player',predictions=p}
 end
 return {schema=C.schema,compat=C.compat,examples=rows}
end
local function expectedModel(save)
 local m=assert(M.New(C.featureCount,C.hiddenCount,C.outputCount,C.seed))
 for epoch=1,C.epochs do
  for _,row in ipairs(save.examples) do
   if row.regime=='player' then ck(m:Learn(row.x,row.y,row.mask,epoch==1),'oracle replay update') end
  end
 end
 return m
end
local function refs(c)
 return {examples=c.examples,actors=c.actors,actorOrder=c.actorOrder,occurrences=c.occurrences,
  occurrenceOrder=c.occurrenceOrder,model=c.model,candidate=c.candidate,modelDependencies=c.modelDependencies,
  corpusRevision=c.corpusRevision,modelCorpusRevision=c.modelCorpusRevision,modelVersion=c.modelVersion,
  evidenceTime=c.evidenceTime,nextCastAt=c.nextCastAt,evidenceFloor=c.evidenceFloor,openAfter=c.openAfter,
  dirty=c.dirty,session=c.session,now=c.now}
end
local function sameRefs(a,b)
 for k,v in pairs(a) do ck(v==b[k],'state/reference changed: '..k) end
 for k,v in pairs(b) do ck(v==a[k],'state/reference added: '..k) end
end
case('integer seed normalization agrees with Python exact modulo at safe-integer extremes',function()
 local states={}
 for _,pair in ipairs(seeds) do
  local m=assert(M.New(1,1,1,pair[1]))
  ck(m.seed==pair[2],'incorrect exact seed remainder: '..string.format('%.17g',pair[1]))
  ck(m:Valid(),'initialized seed is valid');states[#states+1]=modelState(m)
 end
 for _,seed in ipairs({0.5,-0.5,9007199254740992,-9007199254740992,math.huge,-math.huge,0/0,'1',true,{}}) do
  local m,reason=M.New(1,1,1,seed);ck(m==nil and reason=='invalid_seed','reject malformed/out-of-range seed')
 end
 fingerprints.seed_initializations=table.concat(states,'\n---\n')
end)
case('all model state fields and parameter structures reject invalid state without arithmetic or mutation',function()
 local original=assert(M.New(3,2,2,19));local fields={}
 for name in pairs(original) do fields[#fields+1]=name end
 for _,name in ipairs(fields) do
  local m=original:Copy();m[name]=nil;local before=ns.Copy(m)
  ck(m:Predict({0,.3,1})==nil,'missing model field rejected: '..name)
  ck(not m:Learn({0,.3,1},{1,0},{true,true}),'learning rejects missing field: '..name)
  same(before,m,'invalid model remains unchanged')
 end
 local mutators={
  function(m) m.hiddenWeights[1][1]=math.huge end,function(m) m.outputWeights[1][1]=0/0 end,
  function(m) m.linearWeights[1][4]=0 end,function(m) m.hiddenBiases[0]=0 end,
  function(m) m.outputBiases.tag=0 end,function(m) m.hiddenWeights[1]=setmetatable(m.hiddenWeights[1],{}) end,
  function(m) m.learningRate=0 end,function(m) m.gradientClip=-1 end,
  function(m) m.regularization=-1 end,function(m) m.linearRegularization=math.huge end,
  function(m) m.positives[1]=1 end,function(m) m.totals[1]=1 end,
  function(m) m.updates=9007199254740992 end,function(m) m.extra=true end}
 for _,change in ipairs(mutators) do
  local m=original:Copy();change(m);local weights,totals=m.hiddenWeights,m.totals
  ck(m:Predict({0,.3,1})==nil,'bad model prediction rejected')
  ck(not m:Learn({0,.3,1},{1,0},{true,true}),'bad model update rejected')
  ck(weights==m.hiddenWeights and totals==m.totals,'bad model rejects before replacing parameter tables')
 end
end)
case('malformed observations and late numerical failure leave trained state and table identities intact',function()
 local m=assert(M.New(3,2,2,31));ck(m:Learn({.4,.2,1},{1,0},{true,true}))
 local bad={-0.01,1.01,math.huge,-math.huge,0/0,true,'0',{},function() end}
 for _,v in ipairs(bad) do
  for kind=1,3 do if not (kind==3 and type(v)=='boolean') then
   local x,y,mask={.4,.2,1},{1,0},{true,true}
   if kind==1 then x[2]=v elseif kind==2 then y[2]=v else mask[2]=v end
   local before=modelState(m);local hw,ow,tw=m.hiddenWeights,m.outputWeights,m.totals
   ck(not m:Learn(x,y,mask),'invalid observation rejected')
   ck(modelState(m)==before and m.hiddenWeights==hw and m.outputWeights==ow and m.totals==tw,'observation rejection atomic')
  end end
 end
 local before=modelState(m);ck(m:Learn({.4,.2,1},{1,0},{false,false}),'empty mask is valid no-op');ck(modelState(m)==before,'empty mask changes no state')
 m.learningRate=1e308;m.gradientClip=1e308;m.regularization=1e308;m.hiddenWeights[2][3]=10
 local state=modelState(m);local hw,ow,tw=m.hiddenWeights,m.outputWeights,m.totals
 local ok,reason=m:Learn({.4,.2,1},{1,0},{true,true})
 ck(not ok and reason=='nonfinite_update','overflow fails closed')
 ck(modelState(m)==state and m.hiddenWeights==hw and m.outputWeights==ow and m.totals==tw,'overflow after candidate work is atomic')
end)
case('one shared hidden unit and all-six-head trajectories respect support masks and recordStatistics',function()
 local a=assert(M.New(48,1,6,-2147483647));local b=a:Copy()
 local totals,positives=vector(6,0),vector(6,0)
 for step=1,100 do
  local x,y,mask={},{},{}
  for k=1,48 do x[k]=((k*7+step*3)%23)/22 end
  for f=1,6 do
   y[f]=(step+f)%3==0 and 1 or 0;mask[f]=(step+f)%4~=0
   if mask[f] then totals[f]=totals[f]+1;positives[f]=positives[f]+y[f] end
  end
  ck(a:Learn(x,y,mask,true));ck(b:Learn(x,y,mask,false))
  for _,field in ipairs({'hiddenWeights','hiddenBiases','outputWeights','outputBiases','linearWeights','linearBiases'}) do same(a[field],b[field],'statistics must not alter gradients') end
 end
 same(a.totals,totals,'exact observed counts');same(a.positives,positives,'exact positive counts')
 same(b.totals,vector(6,0),'statistics disabled');same(b.positives,vector(6,0),'no unsupported positives')
 ck(a.updates==100 and b.updates==100,'optimizer count includes each observed row')
 fingerprints.shared_hidden_trajectory=modelState(a)
end)
case('feature index meanings survive context normalization and evidence age boundaries',function()
 local c=newCore();local a=context(c,0,{class='DRUID',form='bear',health=0,power=0,combat=false})
 local x=R.Features(a,0,{history={[1]=0,[3]=1},defensiveWitness={at=0,expires=8}})
 ck(#x==48,'fixed shape');for i=1,48 do ck(type(x[i])=='number' and x[i]>=0 and x[i]<=1,'normalized feature '..i) end
 ck(x[9]==1 and x[10]==1 and x[11]==1 and x[12]==0 and x[13]==0,'class and role positions')
 ck(x[14]==0 and x[15]==1 and x[16]==0 and x[17]==1 and x[18]==0 and x[19]==1,'known false and known zeros')
 ck(x[20]==1 and x[21]==1 and x[24]==0 and x[25]==0,'time-zero history kept and future history absent')
 ck(x[44]==0 and x[45]==1 and x[46]==1 and x[47]==1 and x[48]==1,'bear and positive witness')
 x=R.Features(a,8,{history={[1]=0},defensiveWitness={at=0,expires=8}});ck(x[47]==0 and x[48]==0,'witness excluded exactly at expiry')
 x=R.Features(a,30,{history={[1]=0}});ck(x[20]==0 and x[21]==1,'old history known even when recency vanishes')
 local unknown=assert(c:Context({actor='P',at=31,role='wrong',class='wrong',combat=0,health=-1,power=2,form='humanoid'}))
 x=R.Features(unknown,31,{})
 for i=1,19 do ck(x[i]==0,'unknown optional value is zero with unknown bit: '..i) end
 for i=44,48 do ck(x[i]==0,'unknown form and witness') end
end)
case('incremental replay under profiling yields is identical to full ordered replay',function()
 local save=makeSave(37);local c=newCore();ck(c:Restore(save),'restore corpus');local expected=expectedModel(save)
 local clock=0;debugprofilestop=function() clock=clock+2;return clock end
 local ticks=0
 while c.dirty and ticks<1000 do
  local old=c.model;local steps=c.stats.trainingSteps or 0;c:Tick(0,false);ticks=ticks+1
  ck((c.stats.trainingSteps or 0)-steps<=1,'budget produces at most one sample in this clock')
  if c.dirty then ck(c.model==old and c.modelVersion==0,'no partially trained model publication') end
 end
 debugprofilestop=nil;ck(not c.dirty and c.model~=nil,'budgeted replay eventually finishes')
 same(c.model,expected,'incremental publication equals direct replay')
 ck(c.modelVersion==1 and c.modelCorpusRevision==c.corpusRevision,'one atomic serving generation')
 ck(#c.modelDependencies==0,'restored rows retain no raw correction descriptors')
 fingerprints.profiled_replay=modelState(c.model)
end)
case('invalid outer restore arrays preserve live serving model candidate and pending window',function()
 local c=newCore();ck(c:Restore(makeSave(13)));settle(c,0)
 context(c,10);c:Tick(10,true);ck(cast(c,'first',11,1));context(c,11);c:Tick(12.25,false)
 context(c,13);c:Tick(13,true)
 ck(c.model~=nil and c.candidate~=nil and c.actors.P.window~=nil,'all lifecycle stages are active')
 local valid=makeSave(3)
 local shapes={function(rows) rows[2]=nil end,function(rows) rows[0]=rows[1] end,
  function(rows) rows[257]=rows[1] end,function(rows) rows[1.5]=rows[1] end,function(rows) rows.foo=rows[1] end,
  function(rows) setmetatable(rows,{__index=function() error('unexpected indexed hole') end}) end,
  function(rows) rows[3].x[48]=nil end,function(rows) rows[3].y[6]=.5 end,
  function(rows) rows[3].mask[6]=0 end,function(rows) rows[3].regime='enemy' end}
 for _,change in ipairs(shapes) do
  local saved=ns.Copy(valid);change(saved.examples);local before=refs(c);local export=c:Export();local steps=c.stats.trainingSteps
  local ok,why=c:Restore(saved);ck(not ok and why=='invalid_examples','malformed save rejected')
  sameRefs(before,refs(c));same(export,c:Export(),'corpus unchanged by restore failure');ck(c.stats.trainingSteps==steps,'rejected restore does not train')
 end
 local candidate=c.candidate;settle(c,13);ck(c.model==candidate.model,'original in-flight candidate can publish after rejected imports')
end)
case('successful restore replaces all live adaptation and detaches imported corpus',function()
 local c=newCore();ck(c:Restore(makeSave(11)));settle(c,0);context(c,10);c:Tick(10,true);ck(cast(c,'pending',11,1))
 local save=makeSave(21);local expected=expectedModel(save);local old=c.model
 ck(c:Restore(save),'valid corpus atomically replaces')
 ck(c.model==nil and c.candidate==nil and c.dirty,'withdraws serving model and prior replay')
 ck(#c.actorOrder==0 and #c.occurrenceOrder==0 and #c.modelDependencies==0,'clear live identities and windows')
 for _,row in ipairs(c.examples) do ck(row.sealed==true and row.actor==nil and row.id==nil,'replacement rows sealed') end
 save.examples[1].x[1]=1-save.examples[1].x[1];save.examples[1].y[1]=1-save.examples[1].y[1]
 settle(c,10);same(c.model,expected,'caller mutation cannot alter restored candidate');ck(c.model~=old,'replacement receives its own complete model')
 ck(c:Restore({schema=C.schema,compat=C.compat,examples={}}),'empty corpus is valid explicit replacement')
 settle(c,10);ck(c.model==nil and #c.examples==0,'empty replacement cannot retain stale model')
end)
case('reset midway through replay with pending positive abandons old candidate and seals exact rebuilt corpus',function()
 local c=newCore();ck(c:Restore(makeSave(17)));c:Tick(0,false);ck(c.candidate~=nil and c.model==nil,'incomplete replay established')
 local old=c.candidate;context(c,10);c:Tick(10,true);context(c,11);ck(cast(c,'reset-positive',11,1));c:ResetSession(11.5)
 ck(c.candidate==nil and c.candidate~=old,'new eligible row discards old replay')
 ck(#c.actorOrder==0 and #c.occurrenceOrder==0 and #c.modelDependencies==0,'reset clears raw session state')
 local last=c.examples[#c.examples];ck(last.sealed and last.y[1]==1 and last.mask[1],'mature pending positive retained')
 for f=2,6 do ck(last.mask[f]==false,'pending absence is censored') end
 local exported=c:Export();local expected=expectedModel(exported);settle(c,11.5);same(c.model,expected,'only new sealed corpus publishes')
 local published=c.model;ck(cast(c,'reset-positive',11,1,1,{retracted=true}),'fresh session may reuse ordinary event ID')
 ck(c.model==published and #c.modelDependencies==0,'sealed prior session rows do not rejoin new session authority')
 fingerprints.reset_replay=modelState(c.model)
end)
case('serving support is independent of retained status counts during ordinary corpus refresh',function()
 local save=makeSave(18)
 for _,row in ipairs(save.examples) do row.regime='player';for f=1,6 do row.mask[f]=true;row.y[f]=0 end end
 for i=1,2 do save.examples[i].y[1]=1 end
 local c=newCore();ck(c:Restore(save));settle(c,0);context(c,10);c:Tick(10,false)
 local f=c:Forecast('P',10)
 ck(f.outputs[1].status=='shadow' and type(f.outputs[1].score)=='number','sufficient first head has all estimators')
 ck(f.outputs[1].linear~=nil and f.outputs[1].frequency~=nil,'comparison scores exposed together')
 for i=2,6 do ck(f.outputs[i].status=='withheld' and f.outputs[i].score==nil,'unsupported heads withheld') end
 local published=c.model;c:Tick(10,true);context(c,11);ck(cast(c,'new-supported',11,1));c:Tick(12.25,false)
 ck(c.model==published and c.candidate~=nil,'ordinary addition preserves old snapshot during rebuild')
 local status=c:Status();ck(status.families[1].positive==3 and c.model.positives[1]==2,'retained diagnostics distinguish new data from serving support')
 ck(status.modelRefreshPending and status.corpusRevision~=status.modelCorpusRevision,'pending refresh explicit');settle(c,12.25)
 ck(c.model.positives[1]==3 and not c:Status().modelRefreshPending,'publication brings model support to retained snapshot')
end)
case('retained paired Brier scores follow corrected outcomes and survive deidentified round trip',function()
 local c=newCore();context(c,0);c:Tick(0,true);context(c,1);ck(cast(c,'scored',1,1));c:Tick(2.25,true)
 local w=c.examples[1];w.predictions={neural={[1]=0,[2]=.25},linear={[1]=.5,[2]=.5},frequency={[1]=1,[2]=.75}}
 local s=c:Status()
 ck(s.families[1].scored==1 and s.families[1].neuralLoss==1 and s.families[1].linearLoss==.25 and s.families[1].frequencyLoss==0,'known positive Brier oracle')
 ck(s.families[1].lossesVsLinear==1,'paired loss count');ck(cast(c,'scored',1,1,2,{retracted=true}),'retract scored outcome')
 s=c:Status()
 ck(s.families[1].scored==1 and s.families[1].neuralLoss==0 and s.families[1].linearLoss==.25 and s.families[1].frequencyLoss==1,'revised negative replaces old score contribution')
 ck(s.families[1].winsVsLinear==1 and s.families[1].lossesVsLinear==0,'paired outcome count replaced')
 local restored=newCore();ck(restored:Restore(c:Export()));same(s.families,restored:Status().families,'deidentification preserves paired statistics')
end)
case('maximum restored corpus rollover preserves serving state until exact bounded replacement',function()
 local save=makeSave(C.maxExamples)
 for _,row in ipairs(save.examples) do row.regime='player' end
 local c=newCore();ck(c:Restore(save),'full allowed corpus accepted');settle(c,0)
 local old=c.model;local oldExport=c:Export();local oldVersion=c.modelVersion
 context(c,10);c:Tick(10,true);c:Tick(12.25,false)
 ck(#c.examples==C.maxExamples and c.stats.exampleEvictions==1,'one oldest replay row retired')
 ck(c.model==old and c.modelVersion==oldVersion and c.candidate~=nil,'eviction retains old model while replacement trains')
 same(c.examples[1].x,oldExport.examples[2].x,'FIFO oldest row removed without changing remaining inputs')
 ck(c:Status().modelRefreshPending,'retirement marks serving snapshot as older')
 local current=c:Export();local expected=expectedModel(current)
 settle(c,12.25);same(c.model,expected,'full-capacity replay matches exact retained data')
 ck(c.model~=old and c.modelVersion==oldVersion+1,'only complete replacement published')
 ck(c.model.updates==C.maxExamples*C.epochs,'each eligible retained row trained once per epoch')
 ck(#c.modelDependencies==1,'sealed restored rows do not enlarge live correction registry')
 context(c,13);ck(cast(c,'post-retirement',11,1),'late positive overlaps the one live trained window')
 ck(c.model==nil and c.candidate==nil and c.dirty,'live correction withdraws completed replacement')
 fingerprints.capacity_replay=modelState(expected)
end)
return {cases=cases,fingerprints=fingerprints}
