"""Independent numeric/restore lifecycle probes; production trees are read-only."""
import argparse, hashlib, importlib, json, random, sys
from pathlib import Path

def hashes(root):
    return {p.relative_to(root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(root.rglob('*')) if p.is_file()}

def plain(value):
    if hasattr(value, 'items'):
        keys = list(value.keys())
        if keys and all(isinstance(k, int) for k in keys) and sorted(keys) == list(range(1, len(keys) + 1)):
            return [plain(value[i]) for i in range(1, len(keys) + 1)]
        return {str(k): plain(v) for k, v in value.items()}
    return value

p = argparse.ArgumentParser()
p.add_argument('--source', required=True, type=Path)
p.add_argument('--baseline', required=True, type=Path)
p.add_argument('--output', required=True, type=Path)
p.add_argument('--lupa-path', type=Path, default=Path('C:/Users/Mewn/Documents/Codex/2026-10-16/let/work/deps'))
a = p.parse_args()
sys.path.insert(0, str(a.lupa_path))
paths = {'current': a.source.resolve(), 'baseline': a.baseline.resolve()}
for label, root in paths.items():
    if a.output.resolve().is_relative_to(root): raise ValueError('Output must not be inside source tree')
before = {label: hashes(root) for label, root in paths.items()}
rng = random.Random(73013015)
modulus = 2147483647
seeds = {0, 1, -1, modulus, -modulus, modulus-1, -modulus+1, 9007199254740991, -9007199254740991}
seeds.update((9007199254740991-i)*sign for i in range(100) for sign in (-1,1))
seeds.update(rng.randrange(-9007199254740991,9007199254740992) for _ in range(100))
seed_expected = [(seed,seed%modulus or 1) for seed in sorted(seeds)]
runs, fingerprints = [], {}
probe_source = Path(__file__).with_name('probes.lua').read_text(encoding='utf-8')
for label, root in paths.items():
    fingerprints[label] = {}
    for engine in ('lua51','lua54'):
        lua = importlib.import_module('lupa.'+engine).LuaRuntime(unpack_returned_tuples=True)
        ns = lua.table()
        for name in ('Bootstrap.lua','Rules.lua','Network.lua','Core.lua'):
            lua.execute((root/name).read_text(encoding='utf-8-sig'),'bjarkiLearn',ns)
        seed_table = lua.table_from([lua.table_from(pair) for pair in seed_expected])
        result = plain(lua.execute(probe_source,ns,seed_table))
        runs.extend(dict(release=label,runtime=engine,**item) for item in result['cases'])
        fingerprints[label][engine] = result['fingerprints']
comparisons=[]
for label,engines in fingerprints.items():
    for key in sorted(engines['lua51']):
        comparisons.append({'name':key,'comparison':label+' cross-runtime','passed':engines['lua51'][key]==engines['lua54'][key]})
for engine in ('lua51','lua54'):
    for key in sorted(fingerprints['current'][engine]):
        comparisons.append({'name':key,'comparison':engine+' current-baseline','passed':fingerprints['current'][engine][key]==fingerprints['baseline'][engine][key]})
after={label:hashes(root) for label,root in paths.items()}
report={'sources':{label:str(root) for label,root in paths.items()},'source_hashes_before':before,'source_hashes_after':after,
        'source_unchanged':before==after,'seed_oracles':len(seed_expected),'scenario_total':len(runs),
        'scenario_passed':sum(x['passed'] for x in runs),'assertions':sum(x['checks'] for x in runs),
        'results':runs,'comparisons':comparisons,
        'fingerprint_sha256':{label:{engine:{key:hashlib.sha256(value.encode()).hexdigest() for key,value in f.items()}
                                    for engine,f in engines.items()} for label,engines in fingerprints.items()}}
a.output.parent.mkdir(parents=True,exist_ok=True)
a.output.write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps({key:report[key] for key in ('source_unchanged','seed_oracles','scenario_total','scenario_passed','assertions')}))
for item in runs+comparisons:
    if not item['passed']: print(json.dumps(item))
sys.exit(0 if report['source_unchanged'] and all(x['passed'] for x in runs+comparisons) else 1)
