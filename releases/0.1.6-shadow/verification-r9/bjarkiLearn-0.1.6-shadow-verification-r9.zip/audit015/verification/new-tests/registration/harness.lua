-- Real Main/Adapter/Core; only the unavailable WoW host is replaced.
local ns={}
World={now=10,combat=true,unitCombat=true,guid='Player-1-100',class='PRIEST',health=100,power=80,frames={}}
local secret=setmetatable({}, {__tostring=function() error('secret formatted') end})
local inaccessible=setmetatable({}, {__tostring=function() error('inaccessible formatted') end})
issecretvalue=function(value) return rawequal(value,secret) end
canaccessvalue=function(value) return not rawequal(value,inaccessible) end
GetTime=function() return World.now end
InCombatLockdown=function() return World.combat end
UnitGUID=function(unit) if unit=='player' then return World.guid end end
UnitIsPlayer=function(unit) return UnitGUID(unit)~=nil end
UnitClassBase=function() return World.class end
UnitAffectingCombat=function() return World.unitCombat end
UnitCanAttack=function(_,unit) return unit~='player' end
UnitHealth=function() return World.health end
UnitHealthMax=function() return 100 end
UnitPower=function() return World.power end
UnitPowerMax=function() return 100 end
UnitIsDeadOrGhost=function() return false end
UnitPowerType=function() return 0,'MANA' end
SlashCmdList={}
DEFAULT_CHAT_FRAME={AddMessage=function() end}
CreateFrame=function()
 local f={scripts={},events={}}
 function f:RegisterEvent(event)
  local mode=event==FAILED_EVENT and RETURN_MODE or 'nil'
  if mode=='throw' then error('registration unavailable') end
  if mode=='false' then return false end
  if mode=='secret' then return secret end
  if mode=='inaccessible' then return inaccessible end
  if mode=='string' then return 'registered' end
  if mode=='number' then return 1 end
  if mode=='table' then return {} end
  self.events[event]=true
  if mode=='true' then return true end
 end
 -- Intentionally no IsEventRegistered: no new API may be required.
 function f:SetScript(key,fn) self.scripts[key]=fn end
 World.frames[#World.frames+1]=f
 return f
end
for _,name in ipairs({'Bootstrap.lua','Rules.lua','Network.lua','Core.lua','Adapter.lua','Main.lua'}) do
 assert(loadfile(LEARN_ROOT..'/'..name))('bjarkiLearn',ns)
end
NS=ns; Runtime=ns.Runtime
function Init() Runtime:Dispatch('ADDON_LOADED','bjarkiLearn') end
function Advance(t) World.now=t; Runtime:Update() end
function Event(name,...) Runtime:Dispatch(name,...) end
function Check(value,message)
 if not value then error(message or 'check failed',2) end
 CHECKS=(CHECKS or 0)+1
end
function Equal(a,b,message)
 Check(a==b,(message or 'equality')..': expected '..tostring(b)..', actual '..tostring(a))
end
function FinishFirstWindow()
 Advance(10.5); Advance(11); Advance(11.5); Advance(12)
 World.combat=false; World.unitCombat=false; Advance(12.3)
 Equal(Runtime.core:Status().examples,1,'exactly one completed first window')
end
