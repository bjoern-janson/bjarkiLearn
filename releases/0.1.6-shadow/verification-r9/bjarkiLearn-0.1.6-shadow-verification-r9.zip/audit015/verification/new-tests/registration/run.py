"""F1: pcall success cannot authorize failed registration or negative labels.

The real Main/Adapter/Core is loaded. Only external WoW host calls are mocked.
Each fixture names the broken behavior it catches, with hand-derived outcomes.
"""
from pathlib import Path
import argparse
import hashlib
import importlib
import json
import sys

ROOT = Path(__file__).resolve().parent
p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--source', required=True, type=Path)
p.add_argument('--output', required=True, type=Path)
p.add_argument('--lupa-path', action='append', default=[])
args = p.parse_args()
for path in args.lupa_path:
    sys.path.insert(0, path)
try:
    import lupa
except ImportError:
    fallback = Path('C:/Users/Mewn/Documents/Codex/2026-10-16/let/work/deps')
    if fallback.exists():
        sys.path.insert(0, str(fallback))
    import lupa
source, output = args.source.resolve(), args.output.resolve()
hashes = lambda: {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(source.glob('*.lua'))}
before, cases = hashes(), []

def case(name, mode, code, event='UNIT_SPELLCAST_SUCCEEDED'):
    cases.append(dict(name=name, mode=mode, code=code, event=event))

# Literal expected outcomes are independent of addon helpers.
for mode, registered, negative, censored in [
    ('true', True, 1, 0), ('nil', True, 1, 0),
    ('false', False, 0, 1), ('throw', False, 0, 1),
    ('secret', False, 0, 1), ('inaccessible', False, 0, 1),
    ('string', False, 0, 1), ('number', False, 0, 1), ('table', False, 0, 1),
]:
    flag = 'true' if registered else 'false'
    case(f'{mode}: registration authority', mode, f'''
        Init(); Check(Runtime.initialized and Runtime.enabled,'normal initialization');
        Check(not Runtime.faulted,'registration failure is not a runtime fault');
        Equal(Runtime:Status().castRegistered,{flag},'native cast registration');
        Equal(Runtime:Status().adapter.registered,{flag},'adapter registration');
        Equal(Runtime:Status().adapter.coverage,{flag},'coverage authority');
    ''')
    diagnostic = 'Equal(errors[1],"UNIT_SPELLCAST_SUCCEEDED","failed event diagnostic");' if not registered else ''
    case(f'{mode}: failure diagnostic', mode, f'''
        Init(); local errors=Runtime:Status().registrationErrors;
        Equal(#errors,{0 if registered else 1},'diagnostic failure count');
        {diagnostic}
        Equal(Runtime:Status().errors,0,'no runtime fault counter');
    ''')
    case(f'{mode}: first window absence labels', mode, f'''
        Init(); Advance(10); Equal(Runtime.core:Status().pending,1,'first pending window');
        FinishFirstWindow();
        for _,family in ipairs(Runtime.core:Status().families) do
            Equal(family.positive,0,'no fabricated positives');
            Equal(family.negative,{negative},'first-window negative authority');
            Equal(family.censored,{censored},'first-window censoring');
        end
        Check(not Runtime.faulted,'window collection stays operational');
    ''')
    case(f'{mode}: positive cast survives registration outcome', mode, f'''
        Init(); Advance(10); World.now=10.5;
        Event('UNIT_SPELLCAST_SUCCEEDED','player','Cast-registration-test',8122);
        FinishFirstWindow(); local status=Runtime.core:Status();
        Equal(status.casts,1,'readable delivered cast retained');
        Equal(status.families[1].positive,1,'observed fear positive retained');
        Equal(status.families[1].negative,0,'observed fear is not negative');
        Equal(status.families[1].censored,0,'observed fear is not censored');
        Equal(status.families[2].negative,{negative},'unobserved family authority');
        Equal(status.families[2].censored,{censored},'unobserved family censoring');
        Check(not Runtime.faulted,'cast collection stays operational');
    ''')

for mode in ('false','throw','secret','inaccessible','string','number','table'):
    case(f'{mode}: other event failure preserves cast stream', mode, '''
        Init(); local status=Runtime:Status();
        Equal(#status.registrationErrors,1,'other event failure reported');
        Equal(status.registrationErrors[1],'PLAYER_ALIVE','other event name');
        Equal(status.castRegistered,true,'otherwise valid cast registration');
        Equal(status.adapter.coverage,true,'otherwise valid cast coverage');
        Advance(10); FinishFirstWindow();
        for _,family in ipairs(Runtime.core:Status().families) do
            Equal(family.negative,1,'valid first-window absence retained');
            Equal(family.censored,0,'other event does not censor cast stream');
        end
        Check(not Runtime.faulted,'other event failure is not a runtime fault');
    ''', event='PLAYER_ALIVE')

runs = []
for engine in ('lua51', 'lua54'):
    LuaRuntime = importlib.import_module('lupa.'+engine).LuaRuntime
    for fixture in cases:
        lua = LuaRuntime(unpack_returned_tuples=True)
        lua.globals().LEARN_ROOT = source.as_posix()
        lua.globals().RETURN_MODE = fixture['mode']
        lua.globals().FAILED_EVENT = fixture['event']
        error = None
        try:
            lua.execute((ROOT/'harness.lua').read_text(encoding='utf-8-sig'))
            lua.execute(fixture['code'])
        except Exception as exc:
            error = str(exc)
        runs.append(dict(engine=engine, case=fixture['name'], passed=error is None,
                         checks=lua.globals().CHECKS or 0, error=error))
report = dict(source=str(source), source_hashes=before, source_unchanged=before==hashes(),
              summary=dict(passed=sum(r['passed'] for r in runs), total=len(runs),
                           checks=sum(r['checks'] for r in runs)), cases=runs)
output.parent.mkdir(parents=True, exist_ok=True)
output.write_text(json.dumps(report, indent=2)+'\n', encoding='utf-8')
print(json.dumps(dict(summary=report['summary'], source_unchanged=report['source_unchanged'],
                     failures=[r for r in runs if not r['passed']]), indent=2))
sys.exit(0 if report['source_unchanged'] and all(r['passed'] for r in runs) else 1)
