F1 registration regression tests

Run from the workspace with an installed Lupa exposing lua51 and lua54:
  python work/learn-shadow-0.1.2-build/new-tests/registration/run.py --source PATH_TO_ADDON --output REPORT.json
Use --lupa-path DIRECTORY when Lupa is installed outside the active interpreter.
The optional Windows fallback is used only when an ordinary import fails.

Scope: real Bootstrap, Rules, Network, Core, Adapter, and Main files are loaded
into a fresh Lua runtime for each test. WoW external host functions are mocked.
The host deliberately has no IsEventRegistered method.

43 cases per Lua engine, 86 total:
- Nine cast-registration outcomes: true, legacy nil, false, exception, secret,
  inaccessible, string, number, table.
- Each outcome independently checks runtime/adapter coverage authority,
  failed-event diagnostics, actual first-window absence labels, and retention
  of a readable positive cast with correct censoring of unobserved families.
- Seven failure outcomes on PLAYER_ALIVE independently check diagnostics and
  preservation of otherwise valid native cast coverage and negative labels.

Baseline evidence: baseline-red.json
- 0.1.1 baseline: 26/86 passed; 60 expected failures, 374 successful assertions.
- Lua 5.1 and 5.4 agree: true, nil, and exception controls pass.
- Explicit false, secret/inaccessible and unexpected return types reproduce
  erroneous registration authority, missing diagnostics and invalid negatives.
- Source SHA-256 hashes match before and after all cases.

These are offline host-contract integration tests. The safe secret/inaccessible
sentinels model the addon's accessibility boundary and are not native WoW secret
values. No report here establishes live client event delivery or runtime support.

Green evidence: green.json, all 86/86 cases pass with 914 successful assertions.
Source SHA-256 hashes match before and after the green run.
