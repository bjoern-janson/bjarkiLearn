"""Real Network.New regressions using Python's exact integer modulo oracle.

The break caught here is Lua 5.1 quotient-based % rounding extreme negative
accepted seeds to the wrong remainder. No alternate constructor or normalization
is injected into Lua. The expected model is the actual constructor initialized
with the independently calculated small seed.
"""
from __future__ import annotations
import argparse
import hashlib
import importlib
import json
import math
from pathlib import Path
import random
import sys
import time

MODULUS = 2147483647
MAX_SEED = 9007199254740991
DEFAULT_SEED = 73013
INPUTS, HIDDEN, OUTPUTS = 3, 4, 2
INITIAL_DRAWS = INPUTS * HIDDEN + HIDDEN * OUTPUTS


def corpus(random_count):
    seeds = {0, 1, -1, DEFAULT_SEED, -DEFAULT_SEED}
    fixtures = {
        -9007199254740991: 2143289344,
        -9007199254740990: 2143289345,
        -2147483648: 2147483646,
        -2147483647: 1,
        -1: 2147483646,
        0: 1,
        1: 1,
        2147483647: 1,
        2147483648: 1,
        9007199254740991: 4194303,
    }
    for seed, expected in fixtures.items():
        assert (seed % MODULUS or 1) == expected, (seed, expected)
    seeds.update(fixtures)
    for offset in range(65):
        seeds.update((MAX_SEED - offset, -MAX_SEED + offset))
    # Neighbors of modulus multiples, including the largest in-range multiple.
    for multiple in (0, 1, 2, 3, 17, 1024, 65536, MAX_SEED // MODULUS):
        for offset in range(-3, 4):
            for sign in (-1, 1):
                seed = sign * (multiple * MODULUS + offset)
                if abs(seed) <= MAX_SEED:
                    seeds.add(seed)
    for exponent in range(54):
        for offset in (-1, 0, 1):
            for sign in (-1, 1):
                seed = sign * ((1 << exponent) + offset)
                if abs(seed) <= MAX_SEED:
                    seeds.add(seed)
    rng = random.Random(73013)
    for _ in range(random_count):
        seeds.add(rng.randrange(-MAX_SEED, MAX_SEED + 1))
    return sorted(seeds)


def freeze(value):
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return float(value).hex()
    if hasattr(value, 'items'):
        return tuple(sorted(((key, freeze(item)) for key, item in value.items()),
                            key=lambda entry: (type(entry[0]).__name__, str(entry[0]))))
    return value


def load_runtime(engine, source):
    try:
        module = importlib.import_module('lupa.' + engine)
    except ModuleNotFoundError:
        sys.path.insert(0, r'C:/Users/Mewn/Documents/Codex/2026-10-16/let/work/deps')
        module = importlib.import_module('lupa.' + engine)
    lua = module.LuaRuntime(unpack_returned_tuples=True)
    namespace = lua.table()
    lua.compile((source / 'Network.lua').read_text(encoding='utf-8-sig'))(
        'bjarkiLearn', namespace)
    snapshot = lua.eval('''function(models, seed, inputs, hidden, outputs)
        inputs, hidden, outputs = inputs or 3, hidden or 4, outputs or 2
        local model, reason = models.New(inputs, hidden, outputs, seed)
        if not model then return nil, reason end
        local valid, invalidReason = model:Valid()
        if not valid then return nil, invalidReason end
        local all = {}
        local points, pattern = {{}, {}, {}}, {0.2,0.5,0.9}
        for input = 1, inputs do
            points[1][input], points[2][input], points[3][input] = 0, pattern[(input-1)%3+1], 1
        end
        for index, x in ipairs(points) do
            local prediction, predictionReason = model:Predict(x)
            if not prediction then return nil, predictionReason end
            all[index] = prediction
        end
        return model, all
    end''')
    return lua, namespace.Models, snapshot


def take_snapshot(models, snapshot, seed, shape=(INPUTS, HIDDEN, OUTPUTS)):
    model, predictions = snapshot(models, seed, *shape)
    if model is None:
        raise AssertionError('constructor/model/prediction rejected: ' + str(predictions))
    return model, (freeze(model), freeze(predictions))


def expected_rng_state(seed, draw_count=INITIAL_DRAWS):
    # Exact integer recurrence verifies the stream's final initialized state.
    state = seed
    for _ in range(draw_count):
        state = (state * 16807) % MODULUS
    return state


def run(source, baseline, random_count):
    seeds = corpus(random_count)
    report = {
        'source': str(source.resolve()),
        'baseline': str(baseline.resolve()) if baseline else None,
        'source_sha256': hashlib.sha256((source / 'Network.lua').read_bytes()).hexdigest(),
        'oracle': 'Python arbitrary-precision int modulo; zero maps to one',
        'claim_ceiling': 'Offline Lua runtime regressions; no live WoW execution',
        'accepted_range': [-MAX_SEED, MAX_SEED],
        'corpus_seed_count': len(seeds),
        'random_draw_count': random_count,
        'initial_rng_draws_per_model': INITIAL_DRAWS,
        'failures': [],
        'runtimes': {},
    }
    failures = report['failures']
    cross_runtime = {}
    failure_counts = {}

    def fail(kind, **details):
        failure_counts[kind] = failure_counts.get(kind, 0) + 1
        if failure_counts[kind] <= 5:
            failures.append({'kind': kind, **details})

    for engine in ('lua51', 'lua54'):
        lua, models, snapshot = load_runtime(engine, source)
        info = {'version': lua.eval('_VERSION'), 'representations': {},
                'invalid_inputs_checked': 0, 'baseline_defaults_compared': 0}
        report['runtimes'][engine] = info
        reference = {}
        representations = ('double',) if engine == 'lua51' else ('integer', 'float')
        for representation in representations:
            checked = 0
            draws_checked = 0
            probe = 73013 if representation == 'integer' else 73013.0
            actual_numeric_type = lua.eval('function(x) return math.type and math.type(x) or type(x) end')(probe)
            expected_numeric_type = representation if engine == 'lua54' else 'number'
            if actual_numeric_type != expected_numeric_type:
                fail('wrong_input_representation', runtime=engine, representation=representation, actual=actual_numeric_type)
            for seed in seeds:
                normalized = seed % MODULUS or 1
                requested = float(seed) if representation != 'integer' else seed
                try:
                    actual_model, actual = take_snapshot(models, snapshot, requested)
                    if actual_model.seed != normalized:
                        fail('wrong_normalized_seed', runtime=engine,
                             representation=representation, seed=seed,
                             expected=normalized, actual=actual_model.seed)
                    draws_checked += INITIAL_DRAWS
                    expected_state = expected_rng_state(normalized)
                    if actual_model.rngState != expected_state:
                        fail('wrong_initial_rng_state', runtime=engine,
                             representation=representation, seed=seed,
                             expected=expected_state, actual=actual_model.rngState)
                    if normalized not in reference:
                        _, reference[normalized] = take_snapshot(models, snapshot, normalized)
                    if actual != reference[normalized]:
                        fail('model_or_prediction_differs_from_oracle_seed', runtime=engine,
                             representation=representation, seed=seed, normalized=normalized)
                    if engine == 'lua51':
                        cross_runtime[seed] = actual
                    elif seed in cross_runtime and actual != cross_runtime[seed]:
                        fail('cross_runtime_model_or_prediction_mismatch', runtime=engine,
                             representation=representation, seed=seed)
                except Exception as exc:
                    fail('accepted_seed_rejected_or_exception', runtime=engine,
                         representation=representation, seed=seed, error=str(exc))
                checked += 1
            info['representations'][representation] = {
                'input_lua_numeric_type': actual_numeric_type,
                'accepted_seeds_checked': checked,
                'initial_rng_draws_checked': draws_checked,
            }
        # Nil remains constructor seed=1; the addon's default 73013 is separate.
        _, omitted = take_snapshot(models, snapshot, None)
        _, one = take_snapshot(models, snapshot, 1)
        if omitted != one:
            fail('omitted_seed_default_changed', runtime=engine)
        if baseline:
            _, old_models, old_snapshot = load_runtime(engine, baseline)
            for seed in (None, DEFAULT_SEED, float(DEFAULT_SEED)):
                _, current = take_snapshot(models, snapshot, seed)
                _, previous = take_snapshot(old_models, old_snapshot, seed)
                if current != previous:
                    fail('baseline_default_model_or_prediction_changed', runtime=engine, seed=seed)
                info['baseline_defaults_compared'] += 1
            production_shape = (48, 12, 6)
            production_model, production = take_snapshot(models, snapshot, DEFAULT_SEED, production_shape)
            _, old_production = take_snapshot(old_models, old_snapshot, DEFAULT_SEED, production_shape)
            if production != old_production:
                fail('production_default_model_or_prediction_changed', runtime=engine)
            production_draws = 48 * 12 + 12 * 6
            if production_model.rngState != expected_rng_state(DEFAULT_SEED, production_draws):
                fail('production_default_rng_state_incorrect', runtime=engine)
            if engine == 'lua51':
                cross_runtime['production_default'] = production
            elif production != cross_runtime['production_default']:
                fail('production_default_cross_runtime_mismatch', runtime=engine)
            info['baseline_defaults_compared'] += 1
            info['production_default_control'] = {
                'dimensions': list(production_shape), 'seed': DEFAULT_SEED,
                'initial_rng_draws': production_draws,
                'baseline_complete_state_and_three_predictions_identical': production == old_production,
            }
        invalid = {
            'above_max_integer': MAX_SEED + 1,
            'below_min_integer': -MAX_SEED - 1,
            'above_max_float': float(MAX_SEED + 1),
            'below_min_float': float(-MAX_SEED - 1),
            'fraction': 0.5,
            'negative_fraction': -1.25,
            'nan': math.nan,
            'positive_infinity': math.inf,
            'negative_infinity': -math.inf,
            'numeric_string': '73013',
            'empty_string': '',
            'true': True,
            'false': False,
            'table': lua.table(),
        }
        for name, value in invalid.items():
            result = models.New(INPUTS, HIDDEN, OUTPUTS, value)
            if not isinstance(result, tuple) or result != (None, 'invalid_seed'):
                fail('invalid_seed_accepted_or_wrong_reason', runtime=engine, case=name)
            info['invalid_inputs_checked'] += 1
    report['failure_counts'] = failure_counts
    report['failure_count'] = sum(failure_counts.values())
    report['status'] = 'PASS' if not failure_counts else 'FAIL'
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, required=True, help='Directory containing Network.lua')
    parser.add_argument('--baseline', type=Path, help='Frozen 0.1.1 source for default comparisons')
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--random-count', type=int, default=2048)
    args = parser.parse_args()
    started = time.perf_counter()
    report = run(args.source, args.baseline, args.random_count)
    report['elapsed_seconds'] = round(time.perf_counter() - started, 3)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({key: report[key] for key in
                      ('status', 'corpus_seed_count', 'failure_count', 'failure_counts', 'elapsed_seconds')}))
    print('Report:', args.output.resolve())
    return 0 if report['status'] == 'PASS' else 1


if __name__ == '__main__':
    raise SystemExit(main())




