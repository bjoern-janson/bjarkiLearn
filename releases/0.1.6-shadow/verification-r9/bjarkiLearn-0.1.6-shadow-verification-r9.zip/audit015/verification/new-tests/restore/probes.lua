local ns=...
local cases,checks={},0
local function ck(v,msg) checks=checks+1; assert(v,msg) end
local function clone(v,memo)
 if type(v)~='table' then return v end
 memo=memo or {}; if memo[v] then return memo[v] end
 local t={}; memo[v]=t
 for k,x in pairs(v) do t[clone(k,memo)]=clone(x,memo) end
 return setmetatable(t,getmetatable(v))
end
local function equal(a,b,seen)
 if type(a)~=type(b) then return false end
 if type(a)~='table' then return a==b end
 seen=seen or {}; if seen[a]==b then return true end; seen[a]=b
 for k,v in pairs(a) do if not equal(v,b[k],seen) then return false end end
 for k in pairs(b) do if a[k]==nil then return false end end
 return getmetatable(a)==getmetatable(b)
end
local function context(c,t)
 c:Context({actor='P',at=t,role='self',class='PRIEST',combat=true,bound=true,health=.8,power=.7})
end
local function window(c,t,positive)
 context(c,t); c:Tick(t,true)
 if positive then ck(c:Cast({actor='P',id='cast-'..t,at=t+1,family=1}),'accepted real cast') end
 c:Tick(t+2.25,true)
end
local function finish(c,t) for n=1,270 do c:Tick(t,false) end end
local base=ns.Core.New(); base:SetCoverage(true)
for n=1,12 do window(base,n*4,n<=3) end
finish(base,55)
ck(base.model and not base.candidate and not base.dirty,'real completed serving model')
local save=base:Export()
local function live()
 local c=clone(base); window(c,60,false); c:Tick(63,false)
 context(c,64); c:Tick(64,true)
 ck(c.model and c.candidate and c.actors.P.window,'real serving, replay, pending window state')
 return c
end
local function run(name,fn)
 local before=checks; local ok,detail=pcall(fn)
 issecretvalue=nil; issecrettable=nil; canaccessvalue=nil
 cases[#cases+1]={name=name,passed=ok,checks=checks-before,detail=ok and detail or nil,error=not ok and tostring(detail) or nil}
end
local malformed={
 {'first hole',function(t) t[1]=nil end},
 {'middle hole',function(t) t[2]=nil end},
 {'trailing gap',function(t) t[13]=clone(t[1]);t[12]=nil end},
 {'only second entry',function(t) local x=t[1];for k in pairs(t) do t[k]=nil end;t[2]=x end},
 {'beyond capacity',function(t) t[257]=clone(t[1]) end},
 {'huge index',function(t) t[1000000000]=clone(t[1]) end},
 {'fractional index',function(t) t[1.5]=clone(t[1]) end},
 {'string key',function(t) t.note='unexpected' end},
 {'zero index',function(t) t[0]=clone(t[1]) end},
 {'negative index',function(t) t[-1]=clone(t[1]) end},
 {'table key',function(t) t[{}]=clone(t[1]) end},
 {'plain metatable',function(t) setmetatable(t,{}) end},
 {'virtual hole',function(t) local x=t[2];t[2]=nil;setmetatable(t,{__index=function(_,k) if k==2 then return x end end}) end},
 {'protected metatable',function(t) setmetatable(t,{__metatable='opaque'}) end},
 {'unreadable second row',function(t) local hidden=t[2];issecrettable=function(v) return v==hidden end end},
 {'unreadable collection',function(t) issecrettable=function(v) return v==t end end},
 {'bad later record',function(t) t[12].x[5]='bad' end},
}
for _,def in ipairs(malformed) do
 run('reject '..def[1]..' atomically',function()
  local c=live(); local input=clone(save);def[2](input.examples)
  local snapshot=clone(c); local exported=clone(c:Export());local refs={}
  for k,v in pairs(c) do if type(v)=='table' then refs[k]=v end end
  local ok,reason=c:Restore(input)
  ck(ok==false and reason=='invalid_examples','must reject malformed save instead of accepting a prefix')
  for k,v in pairs(refs) do ck(c[k]==v,'live reference replaced: '..k) end
  ck(equal(c,snapshot),'rejection mutated live state or replay progress')
  ck(equal(c:Export(),exported),'rejection changed export')
 end)
end
run('valid dense restore keeps all rows sealed and independent',function()
 local c=live(); local input=clone(save)
 ck(c:Restore(input)==true,'dense save accepted');ck(#c.examples==12,'all rows retained')
 ck(c.model==nil and c.candidate==nil and c.dirty,'valid restore withdraws old serving and replay')
 ck(#c.actorOrder==0 and #c.occurrenceOrder==0,'valid restore clears raw identities')
 for _,row in ipairs(c.examples) do ck(row.sealed and not row.actor and not row.id,'import sealed and deidentified') end
 input.examples[1].x[1]=.456;ck(c.examples[1].x[1]~=.456,'copied vectors independent from input')
 finish(c,70);ck(c.model and c.model.totals[1]==12 and c.model.positives[1]==3,'restored corpus replays correctly')
end)
run('empty save is valid replacement',function()
 local c=live();local input=clone(save);input.examples={}
 ck(c:Restore(input)==true,'empty accepted');ck(#c.examples==0 and not c.model and not c.candidate,'empty import clears prior corpus')
 finish(c,70);ck(c.model==nil and not c.dirty,'empty corpus finishes without model')
end)
run('capacity dense save accepts all 256 rows',function()
 local c=live();local input=clone(save)
 for n=13,256 do input.examples[n]=clone(input.examples[1]) end
 ck(c:Restore(input)==true and #c.examples==256,'maximum dense import accepted')
 for _,row in ipairs(c.examples) do ck(row.sealed and row.revision==1,'bounded sealed import') end
end)
return {cases=cases,checks=checks}
