local ns={}
World={now=10,combat=true,unitCombat=true,guid='Player-1-100',class='PRIEST',health=100,power=80,registered={},chat={},frames={}}
GetTime=function() return World.now end
InCombatLockdown=function() return World.combat end
UnitGUID=function(unit) if unit=='player' then return World.guid elseif unit=='target' then return World.target elseif unit=='focus' then return World.focus end end
UnitIsPlayer=function(unit) return UnitGUID(unit)~=nil end
UnitClassBase=function(unit) return World.class end
UnitAffectingCombat=function(unit) return World.unitCombat end
UnitCanAttack=function(_,unit) return unit~='player' end
UnitHealth=function() return World.health end
UnitHealthMax=function() return 100 end
UnitPower=function() return World.power end
UnitPowerMax=function() return 100 end
UnitIsDeadOrGhost=function() return false end
UnitPowerType=function() return 0,'MANA' end
SlashCmdList={}
DEFAULT_CHAT_FRAME={AddMessage=function(_,message) World.chat[#World.chat+1]=message end}
CreateFrame=function()
 local f={scripts={},events={}}
 function f:RegisterEvent(event) if event=='UNIT_SPELLCAST_SUCCEEDED' and FAIL_CAST_REG then error('registration unavailable') end;self.events[event]=true end
 function f:SetScript(key,fn) self.scripts[key]=fn end
 World.frames[#World.frames+1]=f
 return f
end
for _,name in ipairs({'Bootstrap.lua','Rules.lua','Network.lua','Core.lua','Adapter.lua','Main.lua'}) do assert(loadfile(LEARN_ROOT..'/'..name))('bjarkiLearn',ns) end
NS=ns
Runtime=ns.Runtime
function Init() Runtime:Dispatch('ADDON_LOADED','bjarkiLearn') end
function Advance(t) World.now=t;Runtime:Update() end
function Event(name,...) Runtime:Dispatch(name,...) end
function Check(value,message) if not value then error(message or 'check failed',2) end; CHECKS=(CHECKS or 0)+1 end
function Equal(a,b,message) Check(a==b,(message or 'equality')..': expected '..tostring(b)..', actual '..tostring(a)) end
function NoIdentities(value)
 if type(value)=='table' then for key,item in pairs(value) do NoIdentities(key);NoIdentities(item) end
 elseif type(value)=='string' then Check(not value:find('Player%-') and not value:find('Cast%-'),'persisted raw identity') end
end
