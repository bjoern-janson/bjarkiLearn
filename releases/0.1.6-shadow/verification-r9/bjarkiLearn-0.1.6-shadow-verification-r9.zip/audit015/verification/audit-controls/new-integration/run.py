from pathlib import Path
import sys,json,hashlib,importlib
ROOT=Path(__file__).resolve().parent
AUDIT=ROOT.parent.parent
sys.path.insert(0,'C:/Users/Mewn/Documents/Codex/2026-10-16/let/work/deps')
base_harness=(AUDIT/'verification/review-integration/harness.lua').read_text()
cases=['register_false','register_throw_control','alias_handoff_unknown_player','post_fault_bus_callback','world_bus_replay_and_copy','unknown_combat_gap_recovered']
sources={'0.1.1':AUDIT/'source/bjarkiLearn','0.1.0':AUDIT/'verification/baseline/source/bjarkiLearn'}
def plain(v):
    if hasattr(v,'items'): return {str(k):plain(x) for k,x in v.items()}
    return v
hashes=lambda:{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for s in sources.values() for p in s.glob('*.lua')}
before=hashes(); results=[]
for version,source in sources.items():
    for engine in ['lua51','lua54']:
        for case in cases:
            lua=importlib.import_module('lupa.'+engine).LuaRuntime(unpack_returned_tuples=True)
            lua.globals().LEARN_ROOT=source.as_posix()
            lua.globals().BUS_PATH=(AUDIT/'verification/fixtures/SharedEvidence.lua').as_posix()
            lua.globals().CASE=case
            lua.globals().FAIL_CAST_REG=case=='register_throw_control'
            harness=base_harness
            if case=='register_false':
                harness=harness.replace("if event=='UNIT_SPELLCAST_SUCCEEDED' and FAIL_CAST_REG then", "if event=='UNIT_SPELLCAST_SUCCEEDED' then return false end; if event=='UNIT_SPELLCAST_SUCCEEDED' and FAIL_CAST_REG then")
            try:
                lua.execute(harness)
                result=plain(lua.execute((ROOT/'probes.lua').read_text()))
                results.append(dict(version=version,engine=engine,case=case,completed=True,observed=result))
            except Exception as e:
                results.append(dict(version=version,engine=engine,case=case,completed=False,error=str(e)))
out={'source_unchanged':before==hashes(),'cases':results}
(ROOT/'results.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
sys.exit(0 if out['source_unchanged'] and all(r['completed'] for r in results) else 1)
