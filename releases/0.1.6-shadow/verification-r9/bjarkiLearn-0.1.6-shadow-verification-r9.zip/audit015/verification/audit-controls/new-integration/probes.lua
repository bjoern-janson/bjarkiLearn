local name = CASE
local P = 'Player-1-100'
if name == 'register_false' then
  Init(); Advance(10)
  for i=1,9 do Advance(10+i*.25) end
  local s=Runtime:Status()
  assert(World.frames[1].events.UNIT_SPELLCAST_SUCCEEDED==nil)
  assert(s.castRegistered==true and s.adapter.coverage==true)
  assert(#s.registrationErrors==0)
  for _,f in ipairs(s.core.families) do assert(f.negative==1) end
  return {actualRegistered=false,reportedRegistered=s.castRegistered,coverage=s.adapter.coverage,
    negatives=s.core.families[1].negative,registrationErrors=#s.registrationErrors}
elseif name == 'register_throw_control' then
  Init(); Advance(10)
  for i=1,9 do Advance(10+i*.25) end
  local s=Runtime:Status()
  assert(not s.castRegistered and not s.adapter.coverage and #s.registrationErrors==1)
  for _,f in ipairs(s.core.families) do assert(f.negative==0 and f.censored==1) end
  return {reportedRegistered=s.castRegistered,coverage=s.adapter.coverage,
    negatives=s.core.families[1].negative,registrationErrors=#s.registrationErrors}
elseif name == 'alias_handoff_unknown_player' then
  World.target=P; World.focus=P; Init(); Advance(10)
  World.now=10.2; World.guid=nil; Event('PLAYER_TARGET_CHANGED')
  Advance(10.25)
  assert(not Runtime.adapter.coverage)
  assert(Runtime.core.actors[P].regime=='other')
  World.guid=P; Advance(10.5)
  assert(Runtime.adapter.coverage and Runtime.core.actors[P].regime=='player')
  for i=3,9 do Advance(10+i*.25) end
  local w=Runtime.core.examples[1]
  for i=1,6 do assert(not w.mask[i]) end
  return {restoredCoverage=true,oldWindowCensored=true}
elseif name == 'post_fault_bus_callback' then
  Init(); Advance(10)
  Runtime.adapter.OnEvent=function() error('deliberate boundary error') end
  Event('PLAYER_ALIVE')
  local stopped=Runtime.adapter
  assert(stopped.stopped and Runtime.faulted and not Runtime.core.coverage)
  stopped:OnAura({source='bjarkiPortraits',kind='aura-positive',isHelpful=true,
    recipientGUID=P,spellId=22812,auraInstanceID=1,observedAt=10.1})
  assert(Runtime.core:Status().occurrences==0)
  Runtime:Command('enable'); Advance(10.25)
  assert(not Runtime.faulted and Runtime.adapter~=stopped and Runtime.adapter.coverage)
  return {stoppedCallbackIgnored=true,explicitEnableResumes=true}
elseif name == 'world_bus_replay_and_copy' then
  Init(); Advance(10)
  assert(loadfile(BUS_PATH))('bjarkiPortraits',{})
  local bus=BjarkiEvidenceV1
  assert(bus:Publish({source='bjarkiPortraits',kind='aura-positive',isHelpful=true,
    recipientGUID=P,unit='target',spellId=22812,auraInstanceID=55,observedAt=10,
    expirationTime=20,duration=10,newApplication=false}))
  Event('ADDON_LOADED','bjarkiPortraits')
  assert(Runtime.core:Status().occurrences==1)
  local c=BjarkiLearn:GetContext('player'); c.defensiveWitness.expires=0
  assert(BjarkiLearn:GetContext('player').defensiveWitness.expires==20)
  World.now=10.25; Event('PLAYER_ENTERING_WORLD')
  assert(Runtime.core:Status().occurrences==1 and bus:Status().listeners==1)
  assert(BjarkiLearn:GetContext('player').defensiveWitness.expires==20)
  Runtime:Command('disable'); assert(bus:Status().listeners==0)
  Runtime:Command('enable'); assert(bus:Status().listeners==1)
  return {worldReplayRestored=true,copiesIsolated=true,listeners=bus:Status().listeners}
elseif name == 'unknown_combat_gap_recovered' then
  Init(); Advance(10)
  World.combat=nil; Advance(10.25)
  World.now=10.3; Event('UNIT_SPELLCAST_SUCCEEDED','player','cast-observed-in-gap',8122)
  World.combat=true
  for i=2,9 do Advance(10+i*.25) end
  local w=Runtime.core.examples[1]
  assert(w.mask[1] and w.y[1]==1)
  for i=2,6 do assert(not w.mask[i]) end
  return {observedPositiveRetained=true,absenceCensored=true}
end
error('unknown case '..tostring(name))
