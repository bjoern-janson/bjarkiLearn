"""Independent audit: executes unmodified production source in both runtimes."""
import json, sys
from pathlib import Path
sys.path.insert(0, r'C:\Users\Mewn\Documents\Codex\2026-10-16\let\work\deps')
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
SOURCES = {'0.1.1': ROOT/'source'/'bjarkiLearn', '0.1.0': ROOT/'verification'/'baseline'/'source'/'bjarkiLearn'}
PRELUDE = r'''
local ns=...
local function ctx(c,t,actor,role)
 return c:Context({actor=actor or 'P',at=t,role=role or 'self',class='PRIEST',combat=true,bound=true})
end
local function event(c,id,t,family,revision,actor,lo,hi,retracted)
 return c:Cast({id=id,at=t,family=family or 1,revision=revision or 1,actor=actor or 'P',minAt=lo,maxAt=hi,retracted=retracted})
end
local function clone(v)
 if type(v)~='table' then return v end
 local o={}; for k,x in pairs(v) do o[k]=clone(x) end
 return setmetatable(o,getmetatable(v))
end
local function settle(c,t)
 for n=1,300 do c:Tick(t,false) end
 assert(c.model and not c.dirty and not c.candidate,'real model did not finish replay')
end
local function warm()
 local c=ns.Core.New(); c:SetCoverage(true)
 for n=1,10 do
  local t=n*3; ctx(c,t); c:Tick(t,true)
  if n<=2 then assert(event(c,'positive-'..n,t+.5)) end
  c:Tick(t+2.25,true)
 end
 settle(c,33)
 assert(c.model.positives[1]==2 and c.model.totals[1]==10)
 return c
end
local function removeAllOriginalRows(c)
 for n=1,256 do
  local t=40+n*3; ctx(c,t); c:Tick(t,true); c:Tick(t+2.25,true)
 end
 assert(#c.examples==256 and c.examples[1].anchor>30)
end
'''
PROBES = {
'masked_family_correction_still_withdraws_shared_model': r'''
local c=ns.Core.New(); c:SetCoverage(true); ctx(c,10); c:Tick(10,true)
assert(event(c,'boundary',10.5,2,1,'P',10,10.5))
c:Tick(12.25,true); settle(c,13)
assert(c.examples[1].mask[1] and not c.examples[1].mask[2])
assert(event(c,'boundary',10.5,2,2))
assert(c.model==nil and c.candidate==nil,'masked-family correction kept shared model')
assert(c.examples[1].y[2]==1 and c.examples[1].mask[2])
return 'family 2 initially masked, other heads trained; correction withdrew whole shared model'
''',
'formerly_all_masked_window_becomes_trainable': r'''
local c=warm(); ctx(c,40); c:Tick(40,true); c:Gap('all-unknown','P'); c:Tick(42.25,true)
settle(c,43); assert(event(c,'late',41,2))
assert(c.model==nil,'new positive on retained formerly masked row must withdraw')
return 'late evidence makes formerly excluded retained window trainable and withdraws serving'
''',
'old_actor_new_actor_and_time_extremes': r'''
local base=warm()
for _,case in ipairs({
 {t=500,actor='Enemy',family=1},
 {t=1,actor='P',family=2},
 {t=3.5,actor='P',family=1,lo=3,hi=3.5},
 {t=3.5,actor='P',family=1,lo=3.5,hi=6},
 {t=3.5,actor='P',family=1,retracted=true},
}) do
 local c=clone(base)
 assert(event(c,'positive-1',case.t,case.family,2,case.actor,case.lo,case.hi,case.retracted))
 assert(c.model==nil and not c.candidate,'old-side dependency missed')
end
local c=clone(base); assert(event(c,'outside',500,2,1,'Enemy')); assert(c.model)
assert(event(c,'outside',4,2,2,'P')); assert(c.model==nil,'new-side dependency missed')
return 'old/new identities and times; backdate, future move, family shift, uncertain boundaries, retraction'
''',
'retired_rows_guards_and_unrelated_evidence': r'''
local c=warm(); local model=c.model; removeAllOriginalRows(c)
assert(c.model==model,'routine row retirement interrupted serving')
assert(event(c,'unrelated',2000,4,1,'Enemy')); assert(c.model==model,'unrelated actor withdrew')
assert(event(c,'late',4,4)); assert(c.model==nil,'retired negative dependency missed')
return 'all original rows removed; unrelated event preserves, late new family in old row withdraws'
''',
'anchor_point_no_overlap_deadline_point_overlap': r'''
local base=warm(); local c=clone(base); local model=c.model
assert(event(c,'at-anchor',3,6)); assert(c.model==model,'anchor point invalidates excluded target')
c=clone(base); assert(event(c,'at-deadline',5,6)); assert(c.model==nil,'deadline point missed')
return 'target boundary is (anchor,deadline] for serving dependency checks'
''',
'stale_floor_uses_historical_high_time': r'''
local c=warm(); assert(event(c,'moved',2000,3,1,'Enemy'))
assert(event(c,'moved',1000,3,2,'Enemy'))
for n=1,130 do assert(event(c,'fill-'..n,3000+n,3,1,'Enemy')) end
assert(c.evidenceFloor>=2000,'backdating forgot superseded maximum')
local ok,why=event(c,'old-revision-one',1500,2,1,'P')
assert(not ok and why=='outside_retained_history')
return 'retirement floor remembers accepted high timestamps despite later backdate'
''',
'candidate_data_restarts_on_changed_label': r'''
local c=warm(); ctx(c,40); c:Tick(40,true); c:Tick(42.25,true); c:Tick(43,false)
assert(c.candidate and c.model)
assert(event(c,'late-new',41,2)); assert(not c.candidate and not c.model)
settle(c,44); assert(c.model.positives[2]==1)
return 'immutable candidate copy canceled, fresh replay includes revised family label'
''',
'routine_occurrence_retirement_preserves_serving': r'''
local c=warm(); local model=c.model
for n=1,130 do assert(event(c,'flood-'..n,1000+n,2,1,'Enemy')) end
assert(c.model==model and #c.occurrenceOrder==128)
assert(not c.examples[1].mask[1] and c.examples[1].y[1]==0)
assert(c.dirty,'retirement must schedule clean replay')
settle(c,33); assert(c.model~=model and c.model.totals[1]==8)
return 'cast eviction preserves serving, censors forgotten positives; clean replay removes influence'
''',
'sealed_session_boundary_preserves_model': r'''
local c=warm(); local model=c.model; c:ResetSession(0)
assert(c.model==model and (not c.modelDependencies or #c.modelDependencies==0))
for _,w in ipairs(c.examples) do assert(w.sealed and not w.actor and not w.coverage and not w.lost) end
assert(event(c,'positive-1',3.5,1)); assert(c.model==model)
return 'sealed old session intentionally cannot be revised by reused new-session occurrence'
''',
'immutable_input_ignores_later_history_correction': r'''
local c=warm(); ctx(c,40); c:Tick(40,true); local w=c.actors.P.window; local x=clone(w.x)
assert(event(c,'positive-1',1,1,2)); for i=1,48 do assert(w.x[i]==x[i]) end
assert(c.actors.P.history[1]==6.5)
return 'history correction updates current history while original input vector stays unchanged'
''',
'no_combat_or_unknown_combat_training': r'''
local c=warm(); ctx(c,40); c:Tick(40,true); c:Tick(42.25,true)
local steps=c.stats.trainingSteps
for n=1,20 do c:Tick(43,true); c:Tick(43,nil) end
assert(c.stats.trainingSteps==steps and not c.candidate and c.dirty)
return 'neither true nor unknown combat starts training'
''',
}
OBSERVATIONS = {
'future_exact_cast_enters_earlier_anchor_input': r'''
local c=ns.Core.New(); c:SetCoverage(true); ctx(c,10)
assert(event(c,'future',11,1))
c:Tick(10,true); local w=c.actors.P.window
assert(w.x[20]==1 and w.x[21]==1,'did not reproduce future-history feature')
c:Tick(12.25,true)
assert(w.y[1]==1 and w.mask[1],'same future event did not become target')
return 'private Core event at 11 appears as recent/known input at anchor 10 and positive target in (10,12]'
''',
}
results=[]
for release,source in SOURCES.items():
 for runtime in ('lua51','lua54'):
  module=__import__(f'lupa.{runtime}',fromlist=['LuaRuntime'])
  for group,probes in [('required_invariants',PROBES),('bounded_observations',OBSERVATIONS)]:
   for name,body in probes.items():
    lua=module.LuaRuntime(unpack_returned_tuples=True); ns=lua.table()
    for filename in ('Bootstrap.lua','Rules.lua','Network.lua','Core.lua'):
     lua.execute((source/filename).read_text(encoding='utf-8'),'bjarkiLearn',ns)
    row=dict(release=release,runtime=runtime,group=group,probe=name)
    try: row.update(passed=True,detail=lua.execute(PRELUDE+body,ns))
    except Exception as exc: row.update(passed=False,error=str(exc))
    results.append(row)
(HERE/'results.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
for row in results: print(json.dumps(row))
raise SystemExit(any(not r['passed'] for r in results if r['release']=='0.1.1'))

