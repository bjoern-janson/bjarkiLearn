Portable audit controls

Run:
  python run_audit_controls.py --source PATH_TO_ADDON --output REPORT.json
Use --lupa-path DIRECTORY if the interpreter cannot otherwise import Lupa.
Lupa must provide lua51 and lua54. No old workspace path is needed for fixtures.

The original Python and Lua audit files plus Main harness and SharedEvidence
fixture are preserved byte-for-byte here. original-hashes.json records the
SHA-256 hashes verified against copied bytes. The portable wrapper extracts
literal correction bodies and integration case names with Python AST; no
path-dependent original Python runner is executed or rewritten.

Included controls total 40 executions across Lua 5.1 and 5.4:
- 22 correction invariant executions (11 per engine)
- 8 lifecycle control executions (4 per engine)
- 10 Main/Adapter/Core integration controls (5 per engine)

Explicit exclusions recorded in every report:
- future_exact_cast_enters_earlier_anchor_input: separate private Core timing
  observation, omitted from execution.
- malformed sparse save accepted and silently truncates retained rows
  (robustness observation): unchanged lifecycle Lua executes it; its original
  assertion result is reported only as an excluded superseded observation.
  It is never counted as a passing control or regression.
- register_false: superseded failed-registration defect observation, omitted
  from execution. The new F1 desired-behavior tests cover its repaired contract.

Current source run: current-results.json, 40/40 controls pass. Source and fixture
hashes are unchanged by execution. The excluded sparse-save observation fails
its old buggy-behavior assertion after the save repair, as expected.

All results are offline tests with controlled host stubs, not live client proof.
