local ns=...
local cases,checks={},0
local function ck(v,msg) checks=checks+1; assert(v,msg) end
local function context(c,t,id,role)
 return c:Context({actor=id or 'P',at=t,role=role or 'self',class='PRIEST',combat=true,bound=true,health=.8,power=.7})
end
local function window(c,t,id,role,positive)
 context(c,t,id,role); c:Tick(t,true)
 if positive then ck(c:Cast({actor=id or 'P',id='cast-'..t..'-'..(id or 'P'),at=t+1,family=1}),'cast accepted') end
 c:Tick(t+2.25,true)
end
local function finish(c,t)
 for n=1,270 do c:Tick(t,false) end
 ck(c.model and not c.candidate and not c.dirty,'complete real replay')
end
local function warm()
 local c=ns.Core.New(); c:SetCoverage(true)
 for n=1,12 do window(c,n*4,nil,nil,n<=3) end
 finish(c,55)
 return c
end
local function run(name,fn)
 local before=checks; local ok,detail=pcall(fn)
 cases[#cases+1]={name=name,passed=ok,checks=checks-before,detail=ok and detail or nil,error=not ok and tostring(detail) or nil}
end
run('real other-only churn empties replay and clears serving without fabricated state',function()
 local c=warm(); local old=c.model
 for n=1,260 do
  window(c,60+n*4,'Other','hostile',false)
  ck(c.model==old,'combat preserves completed snapshot')
  ck(#c.examples<=256 and #c.actorOrder<=16 and #c.occurrenceOrder<=128,'collection bounds')
  ck(c:Status().trainingSteps==48,'combat never trains')
 end
 ck(c:Status().trainingExamples==0,'genuinely empty eligible replay')
 ck(c:Status().modelRefreshPending==true,'empty-current corpus reports pending while combat')
 c:Tick(1105,false)
 ck(c.model==nil and c.candidate==nil and not c.dirty,'empty eligible replay removes completed snapshot')
 local s=c:Status()
 ck(s.modelDependencyCount==nil or s.modelDependencyCount==0,'no correction registry')
 ck(s.modelCorpusRevision==nil and s.modelExamples==nil and not s.modelRefreshPending,'no stale serving metadata')
 return 'No direct mutation of examples or private dirty call; 260 enemy windows retire every player row.'
end)
run('role transition preserves anchor regime, censors negative gap and does not train hostile rows',function()
 local c=warm(); local old=c.model
 context(c,60); c:Tick(60,true)
 local w=c.actors.P.window; local x=w.x
 context(c,60.5,'P','hostile')
 ck(w.regime=='player' and w.x==x and w.x[11]==1,'anchor player role is immutable')
 ck(c:Forecast('P',60.5).outputs[1].score==nil,'cached player projection removed immediately on role change')
 ck(c:Cast({actor='P',id='role-cast',at=61,family=1}),'native observation remains actor-attributed')
 context(c,62.25,'P','hostile'); c:Tick(62.25,true)
 ck(w.mask[1] and w.y[1]==1 and not w.mask[2],'observed positive survives; absence censored by role gap')
 ck(c.actors.P.window.regime=='other','next window uses current regime')
 local nonplayer=c.actors.P.window
 context(c,63,'P','self'); c:Tick(64.5,false)
 ck(nonplayer.regime=='other' and not nonplayer.mask[1],'hostile anchor never becomes player training')
 ck(c.model==old,'ordinary new player data retains serving during short candidate')
 finish(c,65)
 ck(c.model.totals[1]==13 and c.model.totals[2]==12,'player positive only joins eligible family, other row excluded')
 return 'Anchored regime and inputs retained intentionally, role changes withdraw cached scores immediately.'
end)
run('mixed sealed and new generation guards contain only current-session windows',function()
 local c=warm(); c:ResetSession(0)
 for n=1,3 do window(c,n*4,nil,nil,n==1) end
 finish(c,20)
 if c.modelDependencies then
  ck(#c.modelDependencies==3,'only current-session descriptors')
  for _,d in ipairs(c.modelDependencies) do ck(d.anchor>=4 and d.anchor<=12,'new-session descriptor range') end
 end
 ck(c.model.totals[1]==15 and c.model.positives[1]==4,'sealed and new rows both replay')
 local model=c.model
 ck(c:Cast({actor='P',id='past-sealed',at=49,family=2}),'new-session unrelated timestamp accepted')
 ck(c.model==model,'sealed old timestamp has no raw identity dependency')
 ck(c:Cast({actor='P',id='late-current',at=6,family=2}),'deadline new evidence accepted')
 ck(c.model==nil,'current session generation guard active')
 return 'Same actor string across sessions neither recreates sealed dependency nor disables new guards.'
end)
run('active replay reset with pending positive cancels candidate, seals rows, publishes copied corpus',function()
 local c=warm()
 window(c,60,nil,nil,false); c:Tick(63,false)
 ck(c.candidate~=nil,'candidate active')
 context(c,64); c:Tick(64,true)
 ck(c:Cast({actor='P',id='partial-positive',at=65,family=1}),'pending positive')
 c:ResetSession(0)
 ck(c.candidate==nil,'resolving pending positive changes eligible corpus, cancels old candidate')
 for _,w in ipairs(c.examples) do ck(w.sealed and w.actor==nil and w.coverage==nil and w.lost==nil,'all rows sealed and deidentified') end
 finish(c,0)
 ck(c.model.positives[1]==4 and c.model.totals[1]==14,'partial positive retained, absence censored')
 ck(c.model.totals[2]==13,'partial absent head not counted')
 ck(not c.modelDependencies or #c.modelDependencies==0,'no raw guards for sealed generation')
 return 'Pending positive changes replay at reset; canceled old candidate cannot silently publish.'
end)
run('malformed sparse save accepted and silently truncates retained rows (robustness observation)',function()
 local c=warm(); local save=c:Export(); local before=#save.examples
 save.examples[2]=nil
 local ok,why=c:Restore(save)
 ck(ok and #c.examples==1 and before==12,'sparse save accepted with tail discarded')
 ck(c.model==nil,'successful truncated restore withdraws serving')
 return 'Observed existing behavior: a hole at row 2 makes Restore succeed and drops rows 3-12. Not a repair regression; valid Export emits dense arrays.'
end)
return {cases=cases,checks=checks}

