import json, sys
from pathlib import Path
sys.path.insert(0, r'C:/Users/Mewn/Documents/Codex/2026-10-16/let/work/deps')
ROOT=Path(__file__).resolve().parent
AUDIT=ROOT.parent.parent
SOURCES={'0.1.1':AUDIT/'source'/'bjarkiLearn','0.1.0':AUDIT/'verification'/'baseline'/'source'/'bjarkiLearn'}
results=[]
for version, source in SOURCES.items():
 for runtime in ('lua51','lua54'):
  module=__import__(f'lupa.{runtime}',fromlist=['LuaRuntime'])
  lua=module.LuaRuntime(unpack_returned_tuples=True)
  ns=lua.table()
  for name in ('Bootstrap.lua','Rules.lua','Network.lua','Core.lua'):
   lua.execute((source/name).read_text(encoding='utf-8'),'bjarkiLearn',ns)
  report=lua.execute((ROOT/'probes.lua').read_text(encoding='utf-8'),ns)
  for _,case in report['cases'].items():
   row={'source':version,'runtime':runtime,**dict(case.items())}
   results.append(row)
   print(json.dumps(row))
(ROOT/'results.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
