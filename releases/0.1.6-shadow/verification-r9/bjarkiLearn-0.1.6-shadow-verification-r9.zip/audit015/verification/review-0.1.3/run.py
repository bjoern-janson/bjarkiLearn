import argparse, hashlib, importlib, json, sys
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--lupa-path',action='append',default=[]);a=p.parse_args()
for path in a.lupa_path: sys.path.insert(0,path)
root=Path(__file__).resolve().parent
def hashes(): return {str(f.relative_to(a.source)):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(a.source.rglob('*')) if f.is_file()}
before=hashes();results=[]
for engine in ('lua51','lua54'):
    lua=importlib.import_module('lupa.'+engine).LuaRuntime(unpack_returned_tuples=True);ns=lua.table()
    for f in ('Bootstrap.lua','Rules.lua','Network.lua','Core.lua'): lua.execute((a.source/f).read_text(encoding='utf-8'),'bjarkiLearn',ns)
    for _,case in lua.execute((root/'probes.lua').read_text(encoding='utf-8-sig'),ns).items(): results.append({'engine':engine,**dict(case.items())})
report={'total':len(results),'passed':sum(r['passed'] for r in results),'cases':results,'source_hashes':before,'source_unchanged':hashes()==before}
a.output.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');print(json.dumps(report,indent=2));sys.exit(0 if report['passed']==report['total'] and report['source_unchanged'] else 1)
