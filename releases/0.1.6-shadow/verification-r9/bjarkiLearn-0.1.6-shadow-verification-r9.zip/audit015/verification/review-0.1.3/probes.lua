local ns=...
local function context(c,id,t,health,role,bound)
  assert(c:Context{actor=id,at=t,health=health,role=role or 'hostile',class='PRIEST',combat=true,bound=bound~=false})
end
local function cast(c,id,actor,t,family,revision,retracted)
  return c:Cast{id=id,actor=actor,at=t,family=family,revision=revision or 1,retracted=retracted}
end
local function invariant(c)
  local seen={}; local n=0
  for i,id in ipairs(c.actorOrder) do assert(c.actors[id] and not seen[id]);seen[id]=true;n=n+1 end
  for id in pairs(c.actors) do assert(seen[id]) end
  assert(n<=16)
end
local function saved(n)
  local s={schema=ns.Config.schema,compat=ns.Config.compat,examples={}}
  for j=1,n do
    local x=ns.Rules.Features({history={},class='PRIEST',role='self',regime='player',health=j/1000},0)
    local y,m={},{};for k=1,6 do y[k]=(j<=3 and k==1) and 1 or 0;m[k]=true end
    s.examples[j]={x=x,y=y,mask=m,regime=j%3==0 and 'other' or 'player'}
  end
  return s
end
local function sealed(c)
  invariant(c); assert(#c.actorOrder==0 and next(c.occurrences)==nil)
  for _,w in ipairs(c.examples) do assert(w.sealed and w.actor==nil and w.id==nil and w.coverage==nil and w.lost==nil) end
end
local function finish(c,t)
  for i=1,1100 do if not c.dirty and not c.candidate then break end;c:Tick(t,false) end
  assert(not c.dirty and not c.candidate and c.model)
end
local cases={}
local function test(name,f)
  local ok,result=pcall(f);cases[#cases+1]={name=name,passed=ok,error=not ok and tostring(result) or nil}
end
test('full mixed corpus, nonlexical opposite discoveries, skipped window actors',function()
  for reverse=0,1 do
    local c=ns.Core.New();assert(c:Restore(saved(256)));c:SetCoverage(true)
    local ids=reverse==0 and {'zeta','B','10','Alpha'} or {'Alpha','10','B','zeta'}
    for i,id in ipairs(ids) do context(c,id,10,.5+i/10,i%2==0 and 'self' or 'hostile',i~=2) end
    invariant(c);c:Tick(10,true)
    for i,id in ipairs(ids) do if i~=2 then assert(cast(c,'positive-'..i,id,11,i)) end end
    c:ResetSession(11);sealed(c);assert(#c.examples==256)
    for i=1,253 do assert(c.examples[i].x[16]==(i+3)/1000) end
    for j,i in ipairs{1,3,4} do
      local w=c.examples[253+j];assert(w.x[16]==.5+i/10)
      assert(w.regime==(i%2==0 and 'player' or 'other'))
      for k=1,6 do assert(w.y[k]==(k==i and 1 or 0));assert(w.mask[k]==(k==i)) end
    end
    assert(c.stats.exampleEvictions==3);finish(c,20)
    local count=0;for _,w in ipairs(c.examples) do if w.regime=='player' then count=count+1 end end
    assert(c.modelExamples==count)
  end
end)
test('actor churn removes nonfirst oldest and appends recreated identity once',function()
  local c=ns.Core.New();c:SetCoverage(true)
  for i=1,16 do context(c,'actor-'..i,10,i/20) end
  for i=1,16 do if i~=8 then context(c,'actor-'..i,11,i/20) end end
  context(c,'new',11,.9);invariant(c);assert(not c.actors['actor-8'])
  context(c,'actor-8',12,.4);invariant(c);assert(not c.actors['actor-1'])
  for _,id in ipairs(c.actorOrder) do local a=c.actors[id];context(c,id,12,a.health) end
  c:Tick(12,true);c:ResetSession(13);sealed(c)
  local expected={2,3,4,5,6,7,9,10,11,12,13,14,15,16,18,8}
  for i,n in ipairs(expected) do assert(c.examples[i].x[16]==n/20) end
  assert(#c.examples==16 and c.stats.actorEvictions==2)
end)
test('pending-only retraction before reset preserves existing replay and seals corrected mask',function()
  local c=ns.Core.New();assert(c:Restore(saved(24)));c:SetCoverage(true)
  c:Tick(1,false);assert(c.candidate and not c.model);local candidate=c.candidate;local revision=c.corpusRevision
  context(c,'z-player',10,.2,'self');context(c,'A-other',10,.8);c:Tick(10,true)
  assert(cast(c,'pre-reset','z-player',11,2));assert(cast(c,'pre-reset','z-player',11,2,2,true))
  assert(c.candidate==candidate and c.corpusRevision==revision and c.dirty)
  assert(cast(c,'other','A-other',11,3))
  c:ResetSession(11);sealed(c)
  local w=c.examples[25];assert(w.regime=='player' and w.y[2]==0)
  for k=1,6 do assert(not w.mask[k]) end
  assert(c.examples[26].y[3]==1 and c.examples[26].mask[3]);finish(c,20)
  assert(c.modelExamples==16)
end)
test('new session immediate correction withdraws completed model and replacement candidate',function()
  local c=ns.Core.New();assert(c:Restore(saved(24)));finish(c,1)
  c:SetCoverage(true);context(c,'Z-self',10,.4,'self');context(c,'A-other',10,.8);c:Tick(10,true)
  assert(cast(c,'before','Z-self',11,1));c:ResetSession(11);sealed(c)
  assert(c.model and c.dirty);finish(c,12)
  context(c,'Z-self',20,.4,'self');c:Tick(20,true);assert(cast(c,'after','Z-self',21,1))
  c:Tick(22.25,false);assert(c.model and c.candidate)
  assert(cast(c,'after','Z-self',21,1,2,true));assert(not c.model and not c.candidate)
  local last=c.examples[#c.examples];assert(not last.sealed and last.y[1]==0 and last.mask[1])
  assert(c.examples[25].y[1]==1 and c.examples[25].sealed)
  c:ResetSession(23);sealed(c);finish(c,24)
end)
test('fully censored reset preserves valid replay until FIFO eviction changes corpus',function()
  for _,n in ipairs{24,256} do
    local c=ns.Core.New();assert(c:Restore(saved(n)));c:Tick(1,false)
    local candidate=assert(c.candidate);local revision=c.corpusRevision
    context(c,'Z',10,.7,'self');context(c,'A',10,.3);c:Tick(10,true)
    c:ResetSession(11);sealed(c)
    if n==24 then assert(c.candidate==candidate and c.corpusRevision==revision)
    else assert(not c.candidate and c.corpusRevision==revision+2) end
    finish(c,12)
    local rows=0;for _,w in ipairs(c.examples) do if w.regime=='player' and w.mask[1] then rows=rows+1 end end
    assert(c.modelExamples==rows and #c.modelDependencies==0)
  end
end)
return cases
