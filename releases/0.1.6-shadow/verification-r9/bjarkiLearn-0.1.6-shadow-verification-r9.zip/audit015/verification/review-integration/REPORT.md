# Main and Adapter regression tests for 0.1.1

This directory owns independent integration tests only. Production source is read via `--source` and is never modified by this runner. The harness is copied from the independent 0.1.0 Main audit, then every runtime module is loaded from the selected source.

## Reproduction

```powershell
& 'C:/Users/Mewn/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe' 'work/learn-shadow-0.1.1-build/review-integration/run.py' --source 'work/learn-shadow-0.1.0-audit/source/bjarkiLearn' --output 'work/learn-shadow-0.1.1-build/review-integration/baseline-0.1.0.json'
```

Change `--source` to `work/learn-shadow-0.1.1-build/source/bjarkiLearn` and `--output` to a new results filename to test the changed source. Both Lua 5.1 and Lua 5.4 execute independently in one run. Exit status is nonzero if any assertion fails.

## Test contract

Warm 256 actual player windows through Main updates and Adapter-native cast deliveries, then rebuild outside combat. Keep a supported numeric fear head available through 320 further combat windows while both the example cap and occurrence cap force repeated routine retirement. The published model version and frequency remain frozen, training steps remain unchanged in combat, serving dependency count stays at most 256, and later retained forecasts remain paired with outcomes. Rebuild after combat and confirm its frequency reflects the recent approximately half-positive corpus.

While the candidate is in progress, apply a genuine retained-data correction and confirm its candidate is discarded before publication. After replacement, advance 257 quiet combat windows so every serving training row leaves the active corpus while a specific cast occurrence remains reconstructible. Revise that cast again; a numeric serving forecast must exist immediately beforehand and must be withheld immediately afterward. This catches a superficial change that only preserves the model through retirement without preserving its correction dependencies.

Finally exercise disable, reenable, world entry, logout save, deidentification, and a fresh Main runtime restoring the saved corpus. The restarted model must await its clean rebuild.

These are ordinary-Lua modeled native API tests; they do not establish live WoW event completeness, protected-value behavior, client performance, or predictive usefulness.

## Baseline

The original 0.1.0 source fails sustained serving availability and paired scoring: after 320 combat windows, 321 examples and 57 occurrences have been evicted, and retained scored fear windows equal zero. Its postcombat rebuild succeeds with recent-corpus frequency near 0.5. Late-correction assertions require a numeric model beforehand, so retirement-induced loss cannot vacuously satisfy them. New serving-dependency and refresh diagnostics are also asserted by the current test version.

## Changed Core result

The production Core change supplied for independent review passes **38 assertions under Lua 5.1 and 38 under Lua 5.4**. Results are in `changed-core.json`.

- All 320 combat windows preserve a supported numeric shadow forecast and its frozen published frequency/version.
- Both retention paths execute: 321 example evictions and 57 occurrence evictions. The serving dependency registry reaches 256 and stays bounded.
- All 256 retained fear windows remain paired/scored after the long combat run, compared with zero on the 0.1.0 baseline.
- Combat training steps stay fixed. The postcombat candidate is discarded on a retained-data correction and subsequently publishes a replacement reflecting the recent corpus (frequency 0.49612403100775193 versus the older snapshot's 0.10077519379844961).
- A later accepted correction whose original training row has left the corpus immediately withdraws an actually numeric serving model.
- Disable, reenable, world reset, saved-variable deidentification and fresh-runtime restore controls pass.

The reviewed implementation was still carrying 0.1.0 metadata pending the parent's version/documentation step. Results apply to that changed Core source; no claim of a live-client run or packaged 0.1.1 validation is made here. Source inspection confirmed serving descriptors are populated at successful publication, not duplicated into candidates; routine retirement takes the soft-dirty route; actual old/new cast overlaps still invalidate; ResetSession clears session-local serving descriptors.
