from pathlib import Path
import sys,json,argparse,importlib,time
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,'C:/Users/Mewn/Documents/Codex/2026-10-16/let/work/deps')
p=argparse.ArgumentParser();p.add_argument('--source',required=True);p.add_argument('--output',required=True);args=p.parse_args()
source=Path(args.source).resolve(); out={'source':str(source),'runtimes':{}}
for version in ('lua51','lua54'):
    started=time.perf_counter()
    lua=importlib.import_module('lupa.'+version).LuaRuntime(unpack_returned_tuples=True)
    lua.globals().LEARN_ROOT=source.as_posix()
    lua.globals().HARNESS_PATH=(ROOT/'harness.lua').as_posix()
    lua.execute((ROOT/'harness.lua').read_text())
    result=lua.execute((ROOT/'regression.lua').read_text())
    def plain(v):
        if hasattr(v,'items'):
            entries=dict(v.items())
            if entries and set(entries)==set(range(1,len(entries)+1)):
                return [plain(entries[k]) for k in range(1,len(entries)+1)]
            return {str(k):plain(x) for k,x in entries.items()}
        return v
    out['runtimes'][version]=plain(result)
    out['runtimes'][version]['seconds']=round(time.perf_counter()-started,3)
print(json.dumps(out,indent=2))
Path(args.output).write_text(json.dumps(out,indent=2)+'\n')
sys.exit(0 if all(r['passed'] for r in out['runtimes'].values()) else 1)
