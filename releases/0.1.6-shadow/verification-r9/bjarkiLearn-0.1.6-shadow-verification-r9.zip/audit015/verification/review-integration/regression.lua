local R={checks={},failures={},metrics={}}
local function check(value,name)
 R.checks[name]=not not value
 if not value then R.failures[#R.failures+1]=name end
end
local function step()
 Advance(World.now+.25)
end
local sequence=0
local function window(positive)
 -- Each real Core window resolves at its 2.25-second reconciliation deadline.
 local a=Runtime.core.actors[World.guid]
 assert(a and a.window,'window expected')
 local anchor=a.window.anchor
 local event
 for i=1,9 do
  World.now=anchor+i*.25
  if positive and i==2 then
   sequence=sequence+1
   local id='Cast-integration-'..sequence
   Event('UNIT_SPELLCAST_SUCCEEDED','player',id,8122)
   event={id=id,actor=World.guid,at=World.now,family=1,revision=1}
  end
  Runtime:Update()
 end
 return event
end
local function combat(value)
 World.combat=value;World.unitCombat=value
 Event(value and 'PLAYER_REGEN_DISABLED' or 'PLAYER_REGEN_ENABLED')
 step()
end
local function train(edit)
 combat(false)
 if edit then
  local job=Runtime.core.candidate
  check(job~=nil,'postcombat_candidate_starts_before_edit')
  local revision=Runtime.core.corpusRevision
  local accepted=Runtime.core:Cast({id=edit.id,actor=edit.actor,at=edit.at,
   family=edit.family,revision=2,retracted=true})
  check(accepted and Runtime.core.candidate==nil and Runtime.core.corpusRevision>revision,
   'retained_data_correction_discards_candidate')
 end
 for i=1,2000 do
  step()
  local s=Runtime.core:Status()
  if not s.dirty and not s.training and s.modelVersion>0 then return true end
 end
 return false
end
local function numeric()
 local f=BjarkiLearn:Forecast('player')
 return f and f.outputs and f.outputs[1] and f.outputs[1].score,f
end
local function bounded()
 local s=Runtime.core:Status()
 return s.examples<=256 and s.occurrences<=128 and s.actors<=16
end
local function servingDependencyCount()
 -- Parent owns implementation naming; count only explicitly exposed status data.
 local s=Runtime.core:Status()
 return s.modelDependencyCount
end
Init();step()
for i=1,256 do window(i%10==0) end
check(train(),'initial_full_corpus_train_completes')
local initial=Runtime.core:Status()
check(initial.examples==256,'initial_corpus_is_full_256')
combat(true)
local score,f=numeric()
check(type(score)=='number' and score>=0 and score<=1,'initial_supported_numeric_shadow_forecast')
check(f and f.usable==false and f.outputs[1].usable==false,'initial_forecast_remains_shadow_only')
local version=initial.modelVersion
local trainingSteps=initial.trainingSteps
local frequency=f and f.outputs[1].frequency
local maxExamples,maxOccurrences,maxServing=0,0,0
local servingCount=servingDependencyCount()
local lastEvent
local allNumeric,allCaps,allVersion,allFrequency,allDependencies=true,true,true,true,true
for i=1,320 do
 local e=window(i%2==0); if e then lastEvent=e end
 local value,forecast=numeric()
 if type(value)~='number' then allNumeric=false end
 if forecast and forecast.outputs[1] and forecast.outputs[1].frequency~=frequency then allFrequency=false end
 local s=Runtime.core:Status()
 allCaps=allCaps and bounded()
 allVersion=allVersion and s.modelVersion==version
 maxExamples=math.max(maxExamples,s.examples);maxOccurrences=math.max(maxOccurrences,s.occurrences)
 local count=servingDependencyCount();if count then maxServing=math.max(maxServing,count) end
 allDependencies=allDependencies and type(count)=="number" and count<=256
end
local after=Runtime.core:Status()
check(allNumeric,'all_320_combat_windows_keep_numeric_serving_forecast')
check(allFrequency,'combat_serving_frequency_remains_frozen')
check(allVersion,'combat_serving_model_version_remains_frozen')
check(after.trainingSteps==trainingSteps,'training_deferred_through_long_combat')
check(allCaps,'all_retention_caps_bounded')
check(maxExamples==256 and maxOccurrences==128,'both_example_and_occurrence_retirement_exercised')
check(after.families[1].scored>0,'subsequent_retained_forecasts_remain_paired_and_scored')
check(allDependencies,'serving_dependency_metadata_bounded_256')
check(after.modelRefreshPending==true,'routine_retention_reports_pending_model_refresh')
check(after.modelCorpusRevision==initial.modelCorpusRevision,'serving_corpus_revision_remains_frozen')
R.metrics.before_retention_frequency=frequency
R.metrics.after_retention_scored=after.families[1].scored
R.metrics.occurrence_evictions=after.occurrenceEvictions or 0
R.metrics.example_evictions=after.exampleEvictions or 0
R.metrics.max_serving_dependencies=maxServing
check(train(lastEvent),'postcombat_replacement_completes')
combat(true)
local newScore,newForecast=numeric()
local recentFrequency=newForecast and newForecast.outputs[1].frequency
check(type(newScore)=='number','postcombat_replacement_has_supported_numeric_forecast')
check(Runtime.core:Status().modelVersion>version,'postcombat_replacement_advances_model_version')
check(type(recentFrequency)=='number' and recentFrequency>.4 and recentFrequency<.6,
 'postcombat_replacement_uses_recent_half_positive_corpus')
R.metrics.recent_corpus_frequency=recentFrequency
-- lastEvent belongs to the published model's corpus. Quiet routine windows now
-- evict every one of those training rows without evicting its cast occurrence.
local correction=lastEvent
assert(correction and Runtime.core.occurrences['cast:'..correction.id])
local beforeQuietVersion=Runtime.core:Status().modelVersion
local beforeQuietSteps=Runtime.core:Status().trainingSteps
for i=1,257 do window(false) end
local beforeCorrection=numeric()
check(type(beforeCorrection)=='number','serving_forecast_survives_eviction_of_its_training_rows')
check(Runtime.core:Status().modelVersion==beforeQuietVersion,'quiet_retention_keeps_serving_generation')
check(Runtime.core:Status().trainingSteps==beforeQuietSteps,'quiet_retention_does_not_train_in_combat')
local stillRetained=Runtime.core.occurrences['cast:'..correction.id]
check(stillRetained~=nil,'late_correction_occurrence_still_reconstructible')
local rowRetained=false
for _,w in ipairs(Runtime.core.examples) do
 if w.actor==correction.actor and w.anchor<correction.at and w.deadline>=correction.at then rowRetained=true end
end
check(not rowRetained,'late_correction_training_row_was_evicted')
correction.revision=3;correction.retracted=false
local accepted=Runtime.core:Cast(correction)
check(accepted==true,'true_late_correction_accepted')
local corrected=numeric()
check(type(beforeCorrection)=='number' and corrected==nil,'late_correction_to_evicted_training_row_withholds_immediately')
check(type(beforeCorrection)=='number' and Runtime.core.model==nil,'late_correction_invalidates_serving_model')
-- Lifecycle controls preserve the established behavior and deidentified saves.
local count=Runtime.core:Status().examples
Runtime:Command('disable')
check(not Runtime.enabled and not Runtime.adapter,'disable_stops_adapter')
check(BjarkiLearn:Forecast('player')==nil,'disabled_public_forecast_absent')
local updates=Runtime.updates;step();check(Runtime.updates==updates,'disabled_update_stays_idle')
Runtime:Command('enable');step()
check(Runtime.enabled and Runtime.adapter and Runtime.adapter:Status().coverage,'reenable_restores_player_coverage')
check(Runtime.core:Status().examples>=count,'disable_enable_preserves_examples')
local session=Runtime.core.session
Event('PLAYER_ENTERING_WORLD');step()
check(Runtime.core.session==session+1 and Runtime.adapter:Status().coverage,'world_reset_rebinds_coverage')
Event('PLAYER_LOGOUT')
NoIdentities(bjarkiLearnDB)
local savedCount=#bjarkiLearnDB.learning.examples
check(savedCount<=256,'saved_corpus_bounded')
BjarkiLearn=nil
assert(loadfile(HARNESS_PATH))()
Init();step()
check(Runtime.enabled and Runtime.adapter:Status().coverage,'restart_restores_enabled_collection')
check(Runtime.core:Status().examples==savedCount,'restart_restores_deidentified_corpus')
check(Runtime.core.model==nil,'restart_waits_for_clean_rebuild')
R.metrics.assertions=0
for _ in pairs(R.checks) do R.metrics.assertions=R.metrics.assertions+1 end
R.passed=#R.failures==0
return R



