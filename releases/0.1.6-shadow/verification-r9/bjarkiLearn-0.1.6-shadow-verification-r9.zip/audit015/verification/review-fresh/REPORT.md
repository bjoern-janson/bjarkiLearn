Fresh independent repair review

Result: no material findings in the Core.lua change compared directly with the exact 0.1.0 archive extraction. Other production source files were byte-identical at the time of this review. Version and documentation changes were not yet present and are outside this review result.

Review traced all serving-model withdrawal and publication paths, corpus revision changes, candidate cancellation, semantic no-op casts, accepted corrections and rejected unknown/below-floor revisions, both sides of actor/time changes, example and occurrence retirement, actor removal, session reset, restore, numeric failure, cached forecast metadata, and bounded state lifetime.

The serving dependency registry contains only eligible unsealed training-window descriptors. It is bounded by the 256-row replay cap, persists across ordinary retirement, is replaced on successful publication, and is cleared on withdrawal, restore, and session sealing. Rebuilding it from the current examples is valid because every training-relevant mutation either advances corpusRevision and cancels the candidate or seals the current session, which intentionally ends correction authority. Sealed historical rows remain outside subsequent-session correction scope as before.

Independent dynamic probes: 7 scenarios passed with 165 checks per runtime, Lua 5.1 and Lua 5.4. These use real model training on 256 resolved windows. Additional coverage includes half-open interval boundaries for retired training windows, widened uncertain intervals, removal of the trained actor, reset during candidate training and subsequent sealed publication, new data canceling only the candidate, aura-driven occurrence retirement, and restore atomicity/dependency cleanup. Results are in results.json; probes.lua and run.py reproduce them. The 165 checks include 3 warm-up checks plus 162 scenario checks.

Limits: no live WoW execution, native performance measurements, or final packaged-ZIP inspection was done by this reviewer. Conservative invalidation can withdraw a serving model for overlap even when its eventual label would be unchanged; this is deliberate and preserves correction safety. Immutable feature semantics and the existing sealed-session correction boundary were accepted task constraints, not redesigned.

Documentation follow-up (0.1.1 updates)

Reviewed direct README.md, docs/API.md, docs/IMPLEMENTATION.md, and CHANGELOG.md differences, plus Bootstrap.lua and both TOC version strings. All three version declarations are 0.1.1-shadow. The new documentation accurately distinguishes serving-snapshot support from retained evaluation counts, discloses indefinite refresh deferral and failed-rebuild pending status, describes the separate bounded 256-descriptor registry, and preserves session sealing. No misleading behavioral claim was found in those changes. VERIFICATION.md was excluded as requested because release results were still being assembled. README reproducibility-bundle promises require final artifact verification by the packaging agent.

One text-encoding defect was reported to the parent: docs/API.md had CP1252 byte 0x96 at byte offset 3980 in the dependency-count range, which fails UTF-8 decoding and displays a replacement character. Requested an ASCII 0-256 range or properly encoded UTF-8. Other reviewed documents and version files decode as UTF-8. This note records the finding before the parent repair; production files were not modified by this reviewer.


Documentation encoding recheck: all 14 production files now pass strict UTF-8 decoding and contain no Unicode replacement characters. docs/API.md uses the verified ASCII range `0-256`. The reported encoding issue is closed. Core.lua SHA256 remains 92FCCF5A9756322CC03F3B9F4AE0AD6C7055324A96EF05DD0E4813DBADC7A4D1, matching the independently reviewed and tested source.
