from pathlib import Path
import sys,json,importlib
sys.path.insert(0,'C:/Users/Mewn/Documents/Codex/2026-10-16/let/work/deps')
root=Path(__file__).resolve().parent
source=root.parent/'source'/'bjarkiLearn'
def plain(v):
 if hasattr(v,'items'):
  d=dict(v.items())
  if d and set(d)==set(range(1,len(d)+1)): return [plain(d[k]) for k in range(1,len(d)+1)]
  return {str(k):plain(x) for k,x in d.items()}
 return v
out={}
for engine in ('lua51','lua54'):
 lua=importlib.import_module('lupa.'+engine).LuaRuntime(unpack_returned_tuples=True); ns=lua.table()
 for name in ('Bootstrap','Rules','Network','Core'):
  lua.execute((source/(name+'.lua')).read_text(encoding='utf-8-sig'),'bjarkiLearn',ns)
 out[engine]=plain(lua.execute((root/'probes.lua').read_text(encoding='utf-8-sig'),ns))
(root/'results.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))
sys.exit(0 if all(c['passed'] for r in out.values() for c in r['cases']) else 1)
