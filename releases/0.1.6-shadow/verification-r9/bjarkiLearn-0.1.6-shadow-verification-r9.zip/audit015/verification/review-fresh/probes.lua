local ns=...
local checks=0
local function ck(v,m) checks=checks+1; assert(v,m) end
local function context(c,t,id,role)
 c:Context({actor=id or 'P',at=t,role=role or 'self',class='PRIEST',combat=true,bound=true,health=.8,power=.7})
end
local function warm()
 local c=ns.Core.New(); c:SetCoverage(true)
 for n=1,256 do
  local t=n*4; context(c,t); c:Tick(t,true)
  if n==1 or n==3 then ck(c:Cast({id='p'..n,actor='P',at=t+1,family=1}),'cast') end
  c:Tick(t+2.25,true)
 end
 for n=1,260 do c:Tick(1030,false) end
 ck(c.model and #c.modelDependencies==256 and not c.candidate,'warm publication')
 return c
end
local base=warm()
local function clone(x)
 if type(x)~='table' then return x end
 local o={}; for k,v in pairs(x) do o[k]=clone(v) end
 return setmetatable(o,getmetatable(x))
end
local function retire(c)
 for n=1,3 do local t=1100+n*4; context(c,t); c:Tick(t,true); c:Tick(t+2.25,true) end
 ck(c.model~=nil,'retirement retains model')
end
local cases={}
local function run(name,fn)
 local before=checks; local ok,err=pcall(fn,clone(base)); cases[#cases+1]={name=name,passed=ok,error=not ok and tostring(err) or nil,checks=checks-before}
end
run('half-open guard boundaries after retirement',function(c)
 retire(c); local model=c.model
 ck(c:Cast({id='edge-excluded',actor='P',at=4,family=2}),'anchor cast accepted')
 ck(c.model==model,'anchor is excluded')
 ck(c:Cast({id='edge-included',actor='P',at=6,family=2}),'deadline cast accepted')
 ck(c.model==nil and #c.modelDependencies==0,'deadline is included')
end)
run('interval correction on retired model row',function(c)
 retire(c)
 ck(c:Cast({id='p1',actor='P',at=5,minAt=3,maxAt=7,family=1,revision=2}),'widen interval')
 ck(c.model==nil,'uncertain interval correction withdraws model')
end)
run('actor retirement cannot lose model guard',function(c)
 retire(c)
 for n=1,20 do context(c,1150+n,'Enemy'..n,'hostile') end
 ck(c.actors.P==nil and #c.actorOrder==16,'old actor retired')
 ck(#c.modelDependencies==256,'guards survive actor retirement')
 ck(c:Cast({id='p1',actor='P',at=5,family=1,revision=2,retracted=true}),'correction for absent actor')
 ck(c.model==nil,'retired actor model invalidated')
end)
run('candidate session sealing and publication',function(c)
 retire(c); c:Tick(1130,false)
 local candidate=c.candidate; ck(candidate~=nil,'candidate exists')
 c:ResetSession(0)
 ck(c.candidate==candidate and #c.modelDependencies==0,'candidate is sealed without redundant cancellation')
 for n=1,260 do c:Tick(0,false) end
 ck(c.model and not c.dirty and #c.modelDependencies==0,'sealed candidate publishes without raw actor guards')
 local model=c.model
 ck(c:Cast({id='same-old-id',actor='P',at=5,family=1}),'new session cast')
 ck(c.model==model,'new session cannot revise sealed evidence')
end)
run('new candidate data cancels rebuild but retains serving',function(c)
 retire(c); c:Tick(1130,false); local model=c.model; local candidate=c.candidate
 ck(candidate~=nil,'candidate starts')
 context(c,1140); c:Tick(1140,true); c:Tick(1142.25,true)
 ck(c.model==model and c.candidate==nil and c.dirty,'new data cancels only candidate')
 ck(c:Status().modelRefreshPending,'snapshot metadata pending')
end)
run('aura retirement and correction keep frozen feature contract',function(c)
 local model=c.model
 for n=1,130 do ck(c:Aura({id='a'..n,recipient='Enemy',at=1200+n,spellID=17}),'aura insert') end
 ck(c.model==model and #c.occurrenceOrder==128,'aura flood retirement keeps model')
 ck(c:Aura({id='a130',recipient='Enemy',at=1400,spellID=17}),'aura revise')
 ck(c.model==model,'aura context never changes immutable lessons')
end)
run('restore replaces serving registry and failed restore is atomic',function(c)
 retire(c); local before=c.model
 ck(not c:Restore({schema=-1}),'bad restore rejected')
 ck(c.model==before and #c.modelDependencies==256,'bad restore unchanged')
 ck(c:Restore(c:Export()),'valid restore')
 ck(c.model==nil and #c.modelDependencies==0 and c.candidate==nil,'restore resets all model custody')
 for n=1,260 do c:Tick(1200,false) end
 ck(c.model and #c.modelDependencies==0,'restored sealed rows publish no raw guards')
end)
return {cases=cases,checks=checks}
