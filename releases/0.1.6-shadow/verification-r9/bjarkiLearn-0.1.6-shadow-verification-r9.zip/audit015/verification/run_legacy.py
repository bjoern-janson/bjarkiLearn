"""Reproduce the repair verification against source/bjarkiLearn (Python + Lupa)."""
from pathlib import Path
import hashlib, json, subprocess, sys, time
ROOT=Path(__file__).resolve().parent
SOURCE=ROOT/'source/bjarkiLearn'
REPORTS=ROOT/'reports'
def hashes():
 return {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(SOURCE.glob('*.lua'))}
def read(path): return json.loads((ROOT/path).read_text(encoding='utf-8-sig'))
def main():
 REPORTS.mkdir(exist_ok=True)
 before=hashes(); runs=[]
 jobs=[
  ('existing',['run_existing.py']),
  ('retention',['tests/run_retention.py','--source',str(SOURCE),'--output',str(REPORTS/'retention.json')]),
  ('integration',['review-integration/run.py','--source',str(SOURCE),'--output',str(ROOT/'review-integration/changed-core.json')]),
  ('independent',['review-fresh/run.py']),
 ]
 for name,args in jobs:
  print('Running '+name+'...',flush=True); started=time.perf_counter()
  result=subprocess.run([sys.executable,str(ROOT/args[0]),*args[1:]],cwd=ROOT,capture_output=True,text=True,encoding='utf-8',errors='replace')
  (REPORTS/(name+'-final-output.txt')).write_text(result.stdout+result.stderr,encoding='utf-8')
  runs.append({'suite':name,'exit_code':result.returncode,'seconds':round(time.perf_counter()-started,3)})
  if result.returncode:
   print(result.stdout+result.stderr); raise SystemExit(result.returncode)
 old=read('reports/existing-tests.json'); retention=read('reports/retention.json'); integration=read('review-integration/changed-core.json'); fresh=read('review-fresh/results.json')
 assert old['passed'] and old['summary']['passed']==98
 assert all(r['passed'] for r in retention['runtimes'].values())
 assert all(r['passed'] for r in integration['runtimes'].values())
 assert all(c['passed'] for r in fresh.values() for c in r['cases'])
 assert len(retention['runtimes'])==len(integration['runtimes'])==len(fresh)==2
 assert before==hashes()==old['source_hashes']
 counts={'existing_audit':98,'focused_retention':sum(len(r['cases']) for r in retention['runtimes'].values()),'fresh_review':sum(len(r['cases']) for r in fresh.values()),'long_integration':len(integration['runtimes'])}
 report={'passed':True,'scenario_executions':sum(counts.values()),'counts':counts,'syntax_passed':12,'runtimes':['Lua 5.1','Lua 5.4'],'runtime_hashes':before,'source_unchanged':True,'original_harnesses_unchanged':old['harnesses_identical_to_original_capture'],'runs':runs,'long_integration':{k:v['metrics'] for k,v in integration['runtimes'].items()},'limits':['Modeled WoW APIs, not live-client verification.','Serving model can reflect evicted history until successful replacement.','Session sealing and unsupported enemy forecasts remain unchanged.']}
 (REPORTS/'verification.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
 print(json.dumps(report,indent=2))
if __name__=='__main__': main()
