from pathlib import Path
import sys,importlib,json
root=Path('work/learn-shadow-0.1.0-audit/review-main').resolve()
sys.path.insert(0,'C:/Users/Mewn/Documents/Codex/2026-10-16/let/work/deps')
results=[]
for engine in ['51','54']:
 lua=importlib.import_module('lupa.lua'+engine).LuaRuntime(unpack_returned_tuples=True)
 lua.globals().LEARN_ROOT=(root.parent/'source/bjarkiLearn').as_posix()
 try:
  lua.execute((root/'harness.lua').read_text(encoding='utf-8-sig'))
  lua.execute((root/'warm_pipeline.lua').read_text(encoding='utf-8-sig'))
  error=None
 except Exception as exc:error=str(exc)
 stats=dict(lua.globals().WARM.items()) if lua.globals().WARM else None
 results.append({'engine':engine,'passed':error is None,'checks':lua.globals().CHECKS or 0,'stats':stats,'error':error})
(root/'warm-results.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
sys.exit(0 if all(r['passed'] for r in results) else 1)
