Init()
for step=0,300 do
 local t=10+step/10
 World.now=t
 if step==5 or step==30 or step==55 then Event('UNIT_SPELLCAST_SUCCEEDED','player','Cast-warm-'..step,8122) end
 Advance(t)
end
World.combat=false;World.unitCombat=false
for step=1,60 do Advance(40+step/10) end
local status=Runtime.core:Status()
Check(status.families[1].positive>=2,'positive support')
Check(status.families[1].negative>=8,'negative support')
Check(Runtime.core.model~=nil,'trained model')
local f=BjarkiLearn:Forecast('player')
Equal(f.usable,false)
Check(type(f.outputs[1].score)=='number','supported player score')
Check(f.outputs[1].score>=0 and f.outputs[1].score<=1,'bounded neural score')
Equal(f.outputs[1].usable,false)
for i=2,6 do Equal(f.outputs[i].score,nil,'unsupported heads withheld') end
World.target='Player-1-999';Event('PLAYER_TARGET_CHANGED');Advance(46.2)
local enemy=BjarkiLearn:Forecast('target')
for _,o in ipairs(enemy.outputs) do Equal(o.score,nil);Equal(o.reason,'unsupported_enemy_coverage') end
World.combat=true;World.unitCombat=true
for step=0,30 do
 World.now=47+step/10
 if step==5 then Event('UNIT_SPELLCAST_SUCCEEDED','player','Cast-second-fight',8122) end
 Advance(World.now)
end
World.combat=false;World.unitCombat=false
for step=1,30 do Advance(50+step/10) end
Check(Runtime.core:Status().families[1].scored>=1,'pre-outcome paired scores recorded')
Runtime:Save();NoIdentities(bjarkiLearnDB)
Equal(Runtime:Status().errors,0)
WARM={positives=status.families[1].positive,negatives=status.families[1].negative,scored=Runtime.core:Status().families[1].scored,trainingSteps=Runtime.core:Status().trainingSteps}
