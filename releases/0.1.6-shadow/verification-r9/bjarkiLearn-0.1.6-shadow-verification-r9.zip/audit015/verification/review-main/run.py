from pathlib import Path
import sys,json,hashlib,importlib
root=Path(__file__).resolve().parent
source=root.parent/'source/bjarkiLearn'
sys.path.insert(0,'C:/Users/Mewn/Documents/Codex/2026-10-16/let/work/deps')
cases={
'full lifecycle cast and combat deferral': '''Init(); Check(Runtime.initialized and Runtime.enabled);Check(Runtime.castRegistered);Advance(10); Equal(Runtime.core:Status().pending,1);World.now=10.5;Event('UNIT_SPELLCAST_SUCCEEDED','player','Cast-1',8122);Advance(10.5);Advance(11);Advance(11.5);Advance(12);World.combat=false;World.unitCombat=false;Advance(12.3);local s=Runtime.core:Status();Equal(s.families[1].positive,1);Equal(s.families[2].negative,1);Equal(s.trainingSteps,4);Check(Runtime.core.model~=nil);Equal(BjarkiLearn:Forecast('player').usable,false)''',
'disable preserve evidence and prevent collection': '''Init();Advance(10);World.now=10.5;Event('UNIT_SPELLCAST_SUCCEEDED','player','Cast-disable',8122);Runtime:Command('disable');Check(not Runtime.enabled);Equal(Runtime.core:Status().families[1].positive,1);Equal(Runtime.core:Status().families[2].censored,1);Equal(BjarkiLearn:Forecast('player'),nil);Advance(11);Event('UNIT_SPELLCAST_SUCCEEDED','player','Cast-ignored',8122);Equal(Runtime.core:Status().casts,1);Runtime:Command('enable');Check(Runtime.enabled);Equal(Runtime.core:Status().pending,0);Advance(11.1);Equal(Runtime.core:Status().pending,1)''',
'registration failure withholds negative labels': '''Init();Check(not Runtime.castRegistered);Check(not Runtime.adapter.coverage);Advance(10);Advance(10.5);Advance(11);Advance(11.5);Advance(12);World.combat=false;World.unitCombat=false;Advance(12.3);for _,family in ipairs(Runtime.core:Status().families) do Equal(family.negative,0);Equal(family.censored,1) end;Check(not Runtime.faulted)''',
'fault stops public projections and can resume': '''Init();Advance(10);Runtime.adapter.OnEvent=function() error('injected failure') end;Event('PLAYER_ALIVE');Check(Runtime.faulted);Check(Runtime.adapter.stopped);Equal(BjarkiLearn:GetContext('player'),nil);Equal(BjarkiLearn:Forecast('player'),nil);Equal(Runtime:Status().errors,1);Runtime:Command('enable');Check(Runtime.enabled and not Runtime.faulted);Check(BjarkiLearn:GetContext('player')~=nil)''',
'unknown clock censors absence': '''Init();Advance(10);World.now=nil;Runtime:Update();Check(not Runtime.faulted);Advance(10.5);Advance(11);Advance(11.5);Advance(12);World.combat=false;Advance(12.3);for _,family in ipairs(Runtime.core:Status().families) do Equal(family.negative,0);Equal(family.censored,1) end''',
'unknown combat censors and defers training': '''Init();Advance(10);World.combat=nil;Advance(10.3);Advance(10.6);Advance(11);Advance(11.5);Advance(12);Advance(12.3);Equal(Runtime.core:Status().trainingSteps,0);for _,family in ipairs(Runtime.core:Status().families) do Equal(family.negative,0) end;Check(not Runtime.faulted)''',
'player identity loss censors absence': '''Init();Advance(10);World.guid=nil;Advance(10.3);Equal(BjarkiLearn:GetContext('player'),nil);Check(not Runtime.adapter.coverage);World.guid='Player-1-100';Advance(10.6);Advance(11);Advance(11.5);Advance(12);World.combat=false;Advance(12.3);Equal(Runtime.core:Status().families[1].negative,0);Equal(Runtime.core:Status().families[1].censored,1)''',
'public projections are isolated copies': '''Init();Advance(10);local c=BjarkiLearn:GetContext('player');c.class='MAGE';c.history[1]=999;Equal(BjarkiLearn:GetContext('player').class,'PRIEST');Equal(BjarkiLearn:GetContext('player').history[1],nil);local f=BjarkiLearn:Forecast('player');f.usable=true;f.outputs[1].score=1;Equal(BjarkiLearn:Forecast('player').usable,false);Equal(BjarkiLearn:Forecast('player').outputs[1].score,nil);local s=BjarkiLearn:Status();s.core.examples=999;Equal(BjarkiLearn:Status().core.examples,0)''',
'focus rebind updates public identity': '''World.focus='Player-1-200';Init();Equal(BjarkiLearn:GetContext('focus').actor,'Player-1-200');World.focus='Player-1-201';World.now=10.1;Event('PLAYER_FOCUS_CHANGED');Equal(BjarkiLearn:GetContext('focus').actor,'Player-1-201');Equal(BjarkiLearn:GetContext('Player-1-200'),nil)''',
'world entry seals partial positive and clears bindings history': '''Init();Advance(10);World.now=10.5;Event('UNIT_SPELLCAST_SUCCEEDED','player','Cast-world',8122);Event('PLAYER_ENTERING_WORLD');Equal(Runtime.core:Status().families[1].positive,1);Equal(Runtime.core:Status().families[2].censored,1);Equal(Runtime.core:Status().occurrences,0);Equal(Runtime.core:Status().pending,0);Check(Runtime.core.examples[1].sealed);Equal(Runtime.core.examples[1].actor,nil);NoIdentities(Runtime.core:Export())''',
'save disabled state and reload clean corpus': '''Init();Advance(10);World.now=10.5;Event('UNIT_SPELLCAST_SUCCEEDED','player','Cast-save',8122);Runtime:Command('disable');NoIdentities(bjarkiLearnDB);local saved=NS.Copy(bjarkiLearnDB);BjarkiLearn=nil;Runtime=NS.Main.New();bjarkiLearnDB=saved;Init();Check(Runtime.initialized and not Runtime.enabled);Equal(Runtime.core:Status().examples,1);Equal(Runtime.core:Status().actors,0);Equal(BjarkiLearn:GetContext('player'),nil);Runtime:Command('enable');Check(Runtime.enabled);Equal(Runtime.core:Status().families[1].positive,1)''',
'reset touches only learner state': '''OtherAddon={value=77};Init();Advance(10);World.now=10.5;Event('UNIT_SPELLCAST_SUCCEEDED','player','Cast-reset',8122);Runtime:Command('disable');Runtime:Command('reset');Equal(Runtime.core:Status().examples,0);Check(not Runtime.enabled);Equal(OtherAddon.value,77);Equal(#bjarkiLearnDB.learning.examples,0)''',
'existing public global respected': '''BjarkiLearn={owner='another addon'};Init();Check(not Runtime.publicAvailable);Equal(BjarkiLearn.owner,'another addon');Check(Runtime.enabled)''',
'scheduler gap censors absence': '''Init();Advance(10);Advance(12.3);World.combat=false;Advance(12.6);Equal(Runtime.core:Status().families[1].negative,0);Check(Runtime.core:Status().families[1].censored>=1)''',
}
hashes=lambda:{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in source.glob('*.lua')}
before=hashes();runs=[];syntax=[]
for engine in ['51','54']:
 LuaRuntime=importlib.import_module('lupa.lua'+engine).LuaRuntime
 lua=LuaRuntime(unpack_returned_tuples=True)
 for p in source.glob('*.lua'):
  try:lua.eval('function(p) assert(loadfile(p)) end')(p.as_posix());error=None
  except Exception as exc:error=str(exc)
  syntax.append({'engine':engine,'file':p.name,'passed':error is None,'error':error})
 for name,code in cases.items():
  lua=LuaRuntime(unpack_returned_tuples=True)
  lua.globals().LEARN_ROOT=source.as_posix()
  lua.globals().FAIL_CAST_REG=name.startswith('registration')
  try:lua.execute((root/'harness.lua').read_text(encoding='utf-8-sig'));lua.execute(code);error=None
  except Exception as exc:error=str(exc)
  runs.append({'engine':engine,'case':name,'passed':error is None,'checks':lua.globals().CHECKS or 0,'error':error})
report={'source_unchanged':before==hashes(),'source_hashes':before,'syntax':syntax,'cases':runs,'summary':{'passed':sum(r['passed'] for r in runs),'total':len(runs),'checks':sum(r['checks'] for r in runs)}}
(root/'results.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'summary':report['summary'],'syntax_passed':sum(r['passed'] for r in syntax),'failures':[r for r in runs if not r['passed']],'source_unchanged':report['source_unchanged']},indent=2))
sys.exit(0 if all(r['passed'] for r in runs+syntax) else 1)
