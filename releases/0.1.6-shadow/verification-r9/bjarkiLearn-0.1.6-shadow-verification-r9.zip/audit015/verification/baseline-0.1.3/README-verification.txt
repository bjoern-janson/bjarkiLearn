bjarkiLearn 0.1.3-shadow verification bundle

Install only the separate bjarkiLearn-0.1.3-shadow.zip in WoW. This bundle is for review and reproduction.
Requirements: Python 3 and Lupa 2.8 with lua51 and lua54 modules.

  python -m pip install -r requirements-test.txt
  python run_all.py
  python review-0.1.3/run.py --source source/bjarkiLearn --output review-0.1.3/probes.json
  python build_release.py --output dist

The separate fresh-review command reruns its ten additional focused checks.

The default runner re-executes all 464 scenario executions: 302 prior packaged cases, 66 later audit controls, 12 new Core cases and 84 native reset cases (seven histories x six GUID sets x two engines). It also runs the existing seed corpus and boundary probes, 12 repeated native trajectories, and eight runs of the original capacity reproduction. reports-0.1.3/verification.json is the authoritative current aggregate. These are offline tests with modeled WoW APIs, not live-client or predictive-accuracy proof.

The optional --reuse-repro flag accepts the reset-repro.json already produced in this build only after checking its passing results and exact runtime hashes. The release run used this option because that full trace run had just completed; the normal command above reruns every trace.

source/bjarkiLearn: exact release source and documentation.
baseline-0.1.2: unchanged input install ZIP, its exact extraction, prior aggregate runner, and audit summary.
baseline-0.1.1 and baseline: preserved earlier baselines and evidence.
tests-reset: new desired-behavior regressions, baseline RED results, and repeated audit trace wrapper.
audit-0.1.2: unchanged later audit probes, native harness and original reproduction traces. Historical observations here describe 0.1.2, not current failures.
reports-0.1.3: current final reports and logs; reports/ holds the nested legacy 136 run on current source.
reports-0.1.2 and earlier review folders: historical reports retained as provenance; current reruns of these suites are in reports-0.1.3.
review-0.1.3: fresh independent whole-change review and any focused checks.
fixtures/v0.1.2-preserved-test-hashes.json: 47 prior Lua/Python test, runner and support files preserved byte-for-byte. The original 0.1.2 run_all.py is retained as baseline-0.1.2/run_all.py.
source-changes.patch: direct 0.1.2-to-0.1.3 diff.
package.json: install archive SHA256, exact source inventory and package validation results.

The new repeated-trace runner extracts only pure helper functions from the unchanged prior integration runner using Python AST. It compares fresh runs of the same repaired source, including complete exports, completed models and public projections at every checkpoint. It excludes only version fields. This is not a claim that the repaired replay equals every old hash-dependent ordering.

To reproduce the new regression tests on unchanged 0.1.2 (expected nonzero exits):
  python tests-reset/run_core.py --source baseline-0.1.2/source/bjarkiLearn --output red-core.json
  python tests-reset/native/run.py --source baseline-0.1.2/source/bjarkiLearn --output red-native.json

Native table iteration is uncontrolled, so baseline failure counts may vary. Current fixed-order assertions must all pass. The reset policy uses existing first-seen actor order, as normal Tick does; different actor-discovery histories need not produce identical replay.

Original scripts and fixtures remain unchanged. Existing wrappers redirect machine-local paths or select historical correctness probes without changing their assertions. Historical superseded defect observations remain separate from passing correctness counts. The original 0.1.0 archive did not supply its advertised 124-case release harness; no claim is made to rerun that unavailable harness.

Live event delivery, taint/secret-value enforcement, rendering, frame cost and predictive usefulness remain unverified. Shadow outputs remain usable=false. No installed addon or remote repository was modified.
