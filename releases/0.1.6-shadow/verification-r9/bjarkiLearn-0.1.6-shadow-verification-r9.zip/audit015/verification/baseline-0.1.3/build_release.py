"""Package exact verified 0.1.3 source. Run run_all.py first."""
from pathlib import Path
import argparse, difflib, hashlib, json, zipfile
ROOT=Path(__file__).resolve().parent
SOURCE=ROOT/'source/bjarkiLearn';BASE=ROOT/'baseline-0.1.2/source/bjarkiLearn'
p=argparse.ArgumentParser();p.add_argument('--output',default=str(ROOT/'dist'));args=p.parse_args()
OUT=Path(args.output).resolve();OUT.mkdir(parents=True,exist_ok=True)
def sha(data):return hashlib.sha256(data).hexdigest()
def read(path):return json.loads((ROOT/path).read_text(encoding='utf-8'))
def dump(path,value):path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
result=read('reports-0.1.3/verification.json')
assert result['passed'] and result['scenario_executions']==464 and result['syntax_checks_passed']==12
assert result['independent_boundary_checks_passed']==22136 and result['seed_constructor_cases']==7731
assert result['native_replay_trajectories_passed']==12 and result['capacity_reproduction_runs_passed']==8
assert result['runtime_hashes']=={f.name:sha(f.read_bytes()) for f in SOURCE.glob('*.lua')}
assert result['production_default_unchanged'] and result['prior_test_source_bytes_unchanged']
expected=read('fixtures/v0.1.2-preserved-test-hashes.json')
assert len(expected)==47 and all(sha((ROOT/n).read_bytes())==h for n,h in expected.items())
review=read('review-0.1.3/release-gate.json')
assert review['accepted'] and review['material_findings']==0
assert review['runtime_hashes']==result['runtime_hashes']
independent=read('review-0.1.3/probes.json')
assert independent['passed']==independent['total']==10 and independent['source_unchanged']
assert all(independent['source_hashes'][n]==h for n,h in result['runtime_hashes'].items())
verification='''# bjarkiLearn 0.1.3-shadow verification

## Current result

**464/464 scenario executions passed across Lua 5.1 and Lua 5.4.** All six runtime Lua modules passed syntax loading on both engines (12 checks). The original capacity reproduction and native replay trajectories are now repeatable on the fixed source. These checks use modeled WoW APIs; live-client validation and predictive usefulness remain pending.

| Scenario suites | Executions across both runtimes |
| --- | ---: |
| All preserved packaged 0.1.2 suites | 302 |
| Later 0.1.2 audit correctness controls | 66 |
| New Core reset regressions | 12 |
| New native reset regressions: 7 histories x 6 GUID sets x 2 engines | 84 |

Separate seed and import/registration boundary checks also pass: 2,577 distinct seeds in three numeric representations (7,731 constructor cases), 28 invalid inputs, and the prior independent 22,136 boundary probes. These are repeated boundary inputs, not independent gameplay scenarios. Default production model initialization remains identical to the unchanged baseline.

## Reset-order repair

ResetSession previously traversed an unordered actor map. Different Lua table traversal orders could change the order of pending lessons, and later FIFO eviction could retain different player support and model scores. Reset now uses the existing first-seen actorOrder, exactly as ordinary Tick does. No sort, new history, new dependency, polling, schema or compatibility-key change was added.

The deterministic contract is identical results for identical ordered inputs. Different actor-discovery histories may retain a different order. Existing completed rows stay ahead of the pending flush; actors without pending windows are skipped. Observed positives survive, partial-window absence remains censored, and reset seals/deidentifies rows. Correction invalidation, candidate cancellation, forecast retention and the 16-actor/128-occurrence/256-example caps remain covered.

Before repair, the frozen 0.1.2 source failed 11 of 12 focused Core checks and 76 of 84 native checks in the recorded runs. The same tests now pass 12/12 and 84/84. Baseline hash order is uncontrolled, so its precise failure count may vary across processes; these RED records establish the original defect rather than a fixed baseline permutation.

The native suite uses actual frame callbacks and Main/Adapter/Core modules. It covers world transitions, disable/enable, clock-rewind robustness, target and alias rebinding, reset during real candidate training, and repeated lifecycle transitions. Complete retained exports agree across six GUID sets and both engines. The copied host harness is byte-identical to its prior audit version.

The original capacity trace was repeated in eight fresh interpreters (four per engine). Every run flushes player then other, retains 255 eligible player examples with 2 positives and 253 negatives after the later FIFO retirement, and produces exactly the same model score across both engines. The score is a synthetic equality check, not a quality claim.

The unchanged original native integration trace was repeated 12 times: continuous and lifecycle histories, three fresh runs per engine. Each trace has 1,800 update steps plus 270 finishing ticks and 31 full-state checkpoints. Status, exported history, full completed model and public diagnostics match exactly; only version fields are excluded. This compares the repaired source to repeated runs of itself. Old hash-dependent model scores are not compatibility targets.

Fresh independent whole-change review found no material finding in this repair. Its additional 10/10 focused checks cover mixed-capacity histories, actor churn, correction invalidation, and replay cancellation. Review evidence and a separate reproduction command are included in review-0.1.3 and the bundle README. The earlier sustained forecast/correction tests, import validation, registration handling and seed normalization also pass on the final runtime bytes.

## Preservation and reproduction

47 prior Lua/Python test, runner and support source files are unchanged byte-for-byte. The original 0.1.2 archive and exact extraction are preserved. Historical reports and defect observations remain labelled as prior evidence. Superseded bug observations are not counted as current passing correctness scenarios. The older 0.1.0 archive did not supply its advertised 124-case release harness, and this release does not claim that unavailable harness was rerun.

Extract bjarkiLearn-0.1.3-shadow-verification.zip and run:

```sh
python -m pip install -r requirements-test.txt
python run_all.py
python build_release.py --output dist
```

The aggregate is reports-0.1.3/verification.json. The verification bundle includes baselines, RED/GREEN reports, unchanged prior tests, new tests, source diff, hashes and independent review. Packaging checks the same 14-file inventory, both TOCs and versions, load references, strict UTF-8, CRC integrity, and exact agreement with the tested runtime bytes.

Live event delivery, taint/secret enforcement, rendering, real frame cost and predictive usefulness remain unverified in WoW. Shadow diagnostics remain usable=false. No installed addon or remote repository was modified.

## Runtime SHA-256

| File | SHA-256 |
| --- | --- |
'''
for name,h in sorted(result['runtime_hashes'].items()):verification+=f'| {name} | `{h}` |\n'
(SOURCE/'VERIFICATION.md').write_text(verification,encoding='utf-8',newline='\n')
files={p.relative_to(SOURCE).as_posix():p.read_bytes() for p in SOURCE.rglob('*') if p.is_file()}
base={p.relative_to(BASE).as_posix():p.read_bytes() for p in BASE.rglob('*') if p.is_file()}
assert set(files)==set(base) and len(files)==14
for name,data in files.items():assert '\ufffd' not in data.decode('utf-8'),name
original=ROOT/'baseline-0.1.2/bjarkiLearn-0.1.2-shadow.zip'
assert sha(original.read_bytes())=='b9a6c1a1f9cd84cfdc58844287f8b96a431936d8e5ad85c184400d5d9c061c89'
with zipfile.ZipFile(original) as z:
 assert z.testzip() is None
 assert {i.filename:z.read(i.filename) for i in z.infolist() if not i.is_dir()}=={'bjarkiLearn/'+n:b for n,b in base.items()}
load_order=['Bootstrap.lua','Rules.lua','Network.lua','Core.lua','Adapter.lua','Main.lua']
for toc in ('bjarkiLearn.toc','bjarkiLearn_Camelot.toc'):
 text=files[toc].decode('utf-8');assert text.count('## Version: 0.1.3-shadow')==1 and '## Interface: 16001' in text
 assert '## SavedVariables: bjarkiLearnDB' in text
 refs=[line.strip() for line in text.splitlines() if line.strip() and not line.startswith('#')]
 assert refs==load_order and all(ref in files for ref in refs)
assert 'version = "0.1.3-shadow"' in files['Bootstrap.lua'].decode('utf-8')
assert {n:sha(files[n]) for n in load_order}==result['runtime_hashes']
for name in ('Rules.lua','Network.lua','Adapter.lua','Main.lua'):assert files[name]==base[name]
changed=[n for n in files if files[n]!=base[n]]
patch=''.join(''.join(difflib.unified_diff(base[n].decode('utf-8').splitlines(True),files[n].decode('utf-8').splitlines(True),fromfile='0.1.2/'+n,tofile='0.1.3/'+n)) for n in sorted(changed))
(ROOT/'source-changes.patch').write_text(patch,encoding='utf-8',newline='\n')
def archive(path,entries):
 with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for name,data in sorted(entries.items()):
   info=zipfile.ZipInfo(name,(2026,10,23,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
   z.writestr(info,data)
 with zipfile.ZipFile(path) as z:
  assert z.testzip() is None
  assert len(z.namelist())==len(set(z.namelist()))==len(entries)
  assert {n:z.read(n) for n in z.namelist()}==entries
 return {'file':path.name,'sha256':sha(path.read_bytes()),'bytes':path.stat().st_size,'files':len(entries),'crc_valid':True,'exact_bytes':True}
addon=archive(OUT/'bjarkiLearn-0.1.3-shadow.zip',{'bjarkiLearn/'+n:b for n,b in files.items()})
package={'addon':addon,'version':'0.1.3-shadow','input_sha256':sha(original.read_bytes()),'original_archive_and_extraction_unchanged':True,'same_14_file_inventory':True,'toc_references_and_versions_valid':True,'strict_utf8':True,'runtime_matches_final_test_run':True,'scenario_executions_passed':464,'seed_constructor_cases_passed':7731,'independent_boundary_checks_passed':22136,'native_replay_trajectories_passed':12,'capacity_reproduction_runs_passed':8,'syntax_checks_passed':12,'fresh_review_focused_checks_passed':10,'preserved_test_source_files':len(expected),'changed_files':sorted(changed),'inventory':{n:sha(b) for n,b in sorted(files.items())}}
dump(ROOT/'package.json',package)
selected={}
folders=('source','baseline','baseline-0.1.1','baseline-0.1.2','tests','tests-reset','new-tests','review-main','review-core','review-network','review-adapter','review-integration','review-fresh','review-0.1.2','review-0.1.3','audit-controls','audit-0.1.2','fixtures','reports','reports-0.1.2','reports-0.1.3')
for folder in folders:
 for f in (ROOT/folder).rglob('*'):
  if f.is_file() and '__pycache__' not in f.parts and f.suffix!='.pyc':selected[f.relative_to(ROOT).as_posix()]=f.read_bytes()
for name in ('run_all.py','run_legacy.py','run_existing.py','run_audit_controls.py','build_release.py','requirements-test.txt','README-verification.txt','source-changes.patch','package.json','plan.txt'):
 selected[name]=(ROOT/name).read_bytes()
bundle=archive(OUT/'bjarkiLearn-0.1.3-shadow-verification.zip',selected)
release={'passed':True,'addon':addon,'verification_bundle':bundle,'package':package}
dump(OUT/'bjarkiLearn-0.1.3-shadow-release-checks.json',release)
print(json.dumps({'passed':True,'addon':addon,'verification_bundle':bundle,'changed_files':sorted(changed),'runtime_matches_final_test_run':True,'toc_versions_crc_inventory_and_bytes_valid':True},indent=2))
