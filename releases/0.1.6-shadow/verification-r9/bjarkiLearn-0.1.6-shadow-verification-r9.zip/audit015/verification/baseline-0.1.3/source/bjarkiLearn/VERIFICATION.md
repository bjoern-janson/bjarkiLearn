# bjarkiLearn 0.1.3-shadow verification

## Current result

**464/464 scenario executions passed across Lua 5.1 and Lua 5.4.** All six runtime Lua modules passed syntax loading on both engines (12 checks). The original capacity reproduction and native replay trajectories are now repeatable on the fixed source. These checks use modeled WoW APIs; live-client validation and predictive usefulness remain pending.

| Scenario suites | Executions across both runtimes |
| --- | ---: |
| All preserved packaged 0.1.2 suites | 302 |
| Later 0.1.2 audit correctness controls | 66 |
| New Core reset regressions | 12 |
| New native reset regressions: 7 histories x 6 GUID sets x 2 engines | 84 |

Separate seed and import/registration boundary checks also pass: 2,577 distinct seeds in three numeric representations (7,731 constructor cases), 28 invalid inputs, and the prior independent 22,136 boundary probes. These are repeated boundary inputs, not independent gameplay scenarios. Default production model initialization remains identical to the unchanged baseline.

## Reset-order repair

ResetSession previously traversed an unordered actor map. Different Lua table traversal orders could change the order of pending lessons, and later FIFO eviction could retain different player support and model scores. Reset now uses the existing first-seen actorOrder, exactly as ordinary Tick does. No sort, new history, new dependency, polling, schema or compatibility-key change was added.

The deterministic contract is identical results for identical ordered inputs. Different actor-discovery histories may retain a different order. Existing completed rows stay ahead of the pending flush; actors without pending windows are skipped. Observed positives survive, partial-window absence remains censored, and reset seals/deidentifies rows. Correction invalidation, candidate cancellation, forecast retention and the 16-actor/128-occurrence/256-example caps remain covered.

Before repair, the frozen 0.1.2 source failed 11 of 12 focused Core checks and 76 of 84 native checks in the recorded runs. The same tests now pass 12/12 and 84/84. Baseline hash order is uncontrolled, so its precise failure count may vary across processes; these RED records establish the original defect rather than a fixed baseline permutation.

The native suite uses actual frame callbacks and Main/Adapter/Core modules. It covers world transitions, disable/enable, clock-rewind robustness, target and alias rebinding, reset during real candidate training, and repeated lifecycle transitions. Complete retained exports agree across six GUID sets and both engines. The copied host harness is byte-identical to its prior audit version.

The original capacity trace was repeated in eight fresh interpreters (four per engine). Every run flushes player then other, retains 255 eligible player examples with 2 positives and 253 negatives after the later FIFO retirement, and produces exactly the same model score across both engines. The score is a synthetic equality check, not a quality claim.

The unchanged original native integration trace was repeated 12 times: continuous and lifecycle histories, three fresh runs per engine. Each trace has 1,800 update steps plus 270 finishing ticks and 31 full-state checkpoints. Status, exported history, full completed model and public diagnostics match exactly; only version fields are excluded. This compares the repaired source to repeated runs of itself. Old hash-dependent model scores are not compatibility targets.

Fresh independent whole-change review found no material finding in this repair. Its additional 10/10 focused checks cover mixed-capacity histories, actor churn, correction invalidation, and replay cancellation. Review evidence and a separate reproduction command are included in review-0.1.3 and the bundle README. The earlier sustained forecast/correction tests, import validation, registration handling and seed normalization also pass on the final runtime bytes.

## Preservation and reproduction

47 prior Lua/Python test, runner and support source files are unchanged byte-for-byte. The original 0.1.2 archive and exact extraction are preserved. Historical reports and defect observations remain labelled as prior evidence. Superseded bug observations are not counted as current passing correctness scenarios. The older 0.1.0 archive did not supply its advertised 124-case release harness, and this release does not claim that unavailable harness was rerun.

Extract bjarkiLearn-0.1.3-shadow-verification.zip and run:

```sh
python -m pip install -r requirements-test.txt
python run_all.py
python build_release.py --output dist
```

The aggregate is reports-0.1.3/verification.json. The verification bundle includes baselines, RED/GREEN reports, unchanged prior tests, new tests, source diff, hashes and independent review. Packaging checks the same 14-file inventory, both TOCs and versions, load references, strict UTF-8, CRC integrity, and exact agreement with the tested runtime bytes.

Live event delivery, taint/secret enforcement, rendering, real frame cost and predictive usefulness remain unverified in WoW. Shadow diagnostics remain usable=false. No installed addon or remote repository was modified.

## Runtime SHA-256

| File | SHA-256 |
| --- | --- |
| Adapter.lua | `8d202f577b5c0abce58e7655e56b37597ccb17f465233333952614370a614c88` |
| Bootstrap.lua | `5999da24947e3c5bae6360a20c5207da43574e7c4f46f64d8e3c59171b6f4f71` |
| Core.lua | `be118cd3736f8886587012a71aca9d983a5d223e469ea6a77ddbe76700197711` |
| Main.lua | `3d468590005b81484af4d548f54bf41d561165d3762c6142931e87df8596052e` |
| Network.lua | `49668680ce13803c329a816f76863b04bb752cb07e5d2759cf7076af05165c49` |
| Rules.lua | `25ef0cc8edb17cab6d251a63784589bcabc6c9485cd30e46078b404e4df8a532` |
