# Independent review of bjarkiLearn 0.1.2-shadow repairs

Result: no material functional findings in the complete functional diff against the frozen 0.1.1 source. No production edits were made by this reviewer.

Reviewed scope: Main.lua event-registration result handling (lines 32-37), Core.lua saved examples array validation and commit boundary (lines 540-576), Network.lua constructor seed normalization (lines 130-136), adjacent Safe methods, Main initialization/enable/dispatch/update paths, Adapter registration and coverage flow, and Core replay/public forecast behavior. The only other Lua change is Bootstrap version metadata. The preservation of continuity, correction invalidation, bounded history, combat deferral, and usable=false is supported by unchanged production code in those paths; full regression execution is reported separately by the release runner.

F1: pcall exception status and the readable return value are both required. Nil and true preserve the specified legacy/boolean success contracts. False, thrown failures, opaque values, and unexpected readable types cannot authorize cast coverage. Readability is tested before equality with native data. Failed registration still reports the event in registrationErrors. The existing adapter continues to accept an actually delivered readable positive observation without claiming an observation-complete stream.

F2: the examples container must have no metatable. Its raw keys are checked as readable integers in 1..256. Since valid table keys are unique and bounded, the first pass can accept at most 256 keys and must reject on the first invalid key. Reading indices 1..count then proves density. All shape and record validation precedes the state replacement and _Dirty(true) call; valid empty/dense imports retain their existing semantics. This repair concerns the outer examples collection; it does not claim a new strict schema for every optional nested diagnostics table.

F3: math.fmod returns the signed integer remainder without the quotient-rounding defect in Lua 5.1's percent operator. A negative remainder is shifted into the nonnegative domain and zero still maps to one. The accepted integer domain and default seed are unchanged. Constructor dimensions, parameter initialization, recurrence and training code are unchanged.

Independent execution: review-0.1.2/run.py passed on actual Lupa Lua 5.1 and Lua 5.4 engines, with source hashes unchanged during execution. Per engine:

- 257 dense import lengths, covering every length from 0 through 256.
- 765 sparse-array rejection executions, checking existing examples/model/candidate references and corpus revision remain unchanged.
- Five protected-metatable sentinels, including false and zero; no injected __index, __pairs or __len callback executed.
- Four additional invalid key cases: 257, positive infinity, false and numeric string.
- 10,030 custom-seed constructor cases against Python exact integer modulo and exact two-step PRNG state, including 10,000 independently seeded random values and modulus boundaries. Inputs use floating representations on both engines.
- Seven Main.New registration-result classifications, including unexpected function and coroutine results and simultaneous failures of all ten registrations.

Total: 22,136 probe executions passed. Counts are executions, not necessarily unique input shapes. Detailed per-engine counts and checked Lua source SHA-256 values are recorded in results.json.

Test quality review: the repair registration suite exercises actual Main/Adapter/Core output labels, not only a duplicate predicate. The restore suite checks real completed serving state, a replay candidate and an active window plus deep state equality on rejection; this complements this reviewer's lightweight reference checks. The seed suite uses an independent arbitrary-precision integer oracle, verifies full initialized models/predictions, includes Lua 5.4 integer and float inputs, and compares default initialization to the frozen baseline. Baseline defect assertions and desired-behavior tests are separated. No material test defect found.

Documentation: release version, changelog and implementation edits match the functional change. At the review snapshot, VERIFICATION.md still contained the previous release's metadata/hashes; the release owner was notified to regenerate it with final run/package results. This report does not claim final ZIP review.

Reproduce from the verification bundle root:

    python review-0.1.2/run.py --source source/bjarkiLearn --output reports-0.1.2/fresh-review.json

If Lupa is not installed in the selected Python environment, add --lupa-path with the directory containing the lupa package. The runner takes explicit source/output paths and does not modify source files.

Limits: these are offline Lua executions with mocked native APIs, not WoW event delivery, secret-value enforcement, taint, frame-cost or usefulness validation. Random seed probes are not an exhaustive enumeration of all accepted integers. F1 target-client applicability remains conditional on native registration failure behavior, as in the original audit. There is no demand for live-client proof to accept this scoped source repair.

## Final documentation and install ZIP check

The pending documentation check is resolved. VERIFICATION.md now identifies 0.1.2-shadow, points to the current verification bundle/commands, records 302 scenario executions plus the separately identified seed and boundary probes, and gives the exact current runtime hashes. Its numerical claims agree with reports-0.1.2/verification.json. The text preserves the distinction between mocked Lua results and unverified native/client behavior and does not claim retroactive repair of saved labels.

Independent ZIP inspection passed: SHA-256 b9a6c1a1f9cd84cfdc58844287f8b96a431936d8e5ad85c184400d5d9c061c89; 14 unique files with the same inventory as the baseline; no unexpected path entries; valid CRCs and UTF-8; each archived byte matches current source. Bootstrap and both TOCs report 0.1.2-shadow; both manifests preserve Interface 16001, SavedVariables and the six-module load order. The six archived runtime hashes match both the final aggregate test report and the regenerated VERIFICATION.md.

No material functional or final install-package findings remain. No Lua suite was rerun during this final check. The verification bundle is to be rebuilt by the release owner to include this addendum and the completed ledger; that later bundle rebuild is outside this install-ZIP check. Detailed results are in package-review.json; reproduce using check_package.py --archive <install-zip> --output <result-json> from this directory in the verification tree.
