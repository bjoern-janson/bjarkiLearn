"""Independent boundary probes; writes reports only in this directory."""
from pathlib import Path
import argparse, importlib, json, random, sys, hashlib
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--source', type=Path, required=True)
p.add_argument('--output', type=Path, required=True)
p.add_argument('--lupa-path', action='append', default=[])
args=p.parse_args()
for path in args.lupa_path: sys.path.insert(0,path)
ROOT=Path(__file__).resolve().parent
SOURCE=args.source.resolve()
hashes=lambda:{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in SOURCE.glob('*.lua')}
before=hashes(); results=[]
for engine in ('lua51','lua54'):
    lua=importlib.import_module('lupa.'+engine).LuaRuntime(unpack_returned_tuples=True)
    ns=lua.table()
    for file in ('Bootstrap.lua','Rules.lua','Network.lua','Core.lua'):
        lua.execute((SOURCE/file).read_text(encoding='utf-8-sig'),'bjarkiLearn',ns)
    report=lua.execute('''local ns=...
        local row={x={},y={},mask={},regime='player'}
        for i=1,48 do row.x[i]=i/48 end
        for i=1,6 do row.y[i]=i%2;row.mask[i]=true end
        local function input(rows) return {schema=ns.Config.schema,compat=ns.Config.compat,examples=rows} end
        local function reject(rows)
            local c=ns.Core.New();c.examples={row};c.model={marker=true};c.candidate={marker=true}
            local examples,model,candidate,rev=c.examples,c.model,c.candidate,c.corpusRevision
            local ok,reason=c:Restore(input(rows))
            assert(ok==false and reason=='invalid_examples')
            assert(c.examples==examples and c.model==model and c.candidate==candidate and c.corpusRevision==rev)
        end
        local dense,sparse=0,0
        for n=0,256 do
            local rows={}; for i=1,n do rows[i]=row end
            local c=ns.Core.New();assert(c:Restore(input(rows))==true and #c.examples==n)
            for i=1,n do assert(c.examples[i].x[48]==1 and c.examples[i].sealed) end
            dense=dense+1
            if n>1 then
                for _,hole in ipairs({1,math.floor(n/2),n-1}) do
                    local old=rows[hole];rows[hole]=nil;reject(rows);rows[hole]=old;sparse=sparse+1
                end
            end
        end
        local callbacks=0
        for _,sentinel in ipairs({false,true,0,'locked', {}}) do
            local rows=setmetatable({row},{__metatable=sentinel,__index=function() callbacks=callbacks+1;error('index') end,__pairs=function() callbacks=callbacks+1;error('pairs') end,__len=function() callbacks=callbacks+1;error('len') end})
            reject(rows)
        end
        assert(callbacks==0)
        reject({[257]=row});reject({[math.huge]=row});reject({[false]=row});reject({['1']=row})
        return {dense=dense,sparse=sparse,protected_metatables=5,invalid_keys=4}
    ''',ns)
    seedcheck=lua.eval('function(models,s) local m,e=models.New(1,1,1,s); assert(m,e);assert(m:Valid());return m.seed,m.rngState end')
    rng=random.Random(20261023);seeds=[rng.randrange(-9007199254740991,9007199254740992) for _ in range(10000)]
    mod=2147483647
    seeds += [sign*(q*mod+d) for sign in (-1,1) for q in (1,100000,4194304) for d in (-2,-1,0,1,2)]
    seeds=[s for s in seeds if abs(s)<=9007199254740991]
    for seed in seeds:
        expected=seed%mod or 1
        normalized,state=seedcheck(ns.Models,float(seed))
        assert normalized==expected,(engine,seed,normalized,expected)
        assert state==((expected*16807)%mod*16807)%mod
    lua.execute("SlashCmdList={};MODE='nil';CreateFrame=function() return {RegisterEvent=function() if MODE=='throw' then error('failure') elseif MODE=='false' then return false elseif MODE=='true' then return true elseif MODE=='zero' then return 0 elseif MODE=='function' then return function() end elseif MODE=='thread' then return coroutine.create(function() end) end end,SetScript=function() end} end")
    lua.execute((SOURCE/'Main.lua').read_text(encoding='utf-8-sig'),'bjarkiLearn',ns)
    for mode,expected in [('nil',True),('true',True),('false',False),('throw',False),('zero',False),('function',False),('thread',False)]:
        lua.globals().MODE=mode
        runtime=ns.Main.New()
        assert runtime.castRegistered==expected,(engine,mode)
        assert len(runtime.registrationErrors)==(0 if expected else 10)
    results.append({'engine':engine,'restore':dict(report.items()),'exact_seed_cases':len(seeds),'registration_cases':7,'status':'PASS'})
assert hashes()==before,'source changed during probes'
total=sum(sum(r['restore'].values())+r['exact_seed_cases']+r['registration_cases'] for r in results)
out={'summary':{'passed':total,'total':total},'source':str(SOURCE),'results':results,'source_hashes':before,'source_unchanged':True,'claim_ceiling':'Offline actual Lua modules with mocked native environment; no WoW execution'}
args.output.parent.mkdir(parents=True,exist_ok=True)
args.output.write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print(json.dumps(results,indent=2))

