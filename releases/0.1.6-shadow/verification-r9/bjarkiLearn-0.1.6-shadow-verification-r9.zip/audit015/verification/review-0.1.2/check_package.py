from pathlib import Path, PurePosixPath
import argparse,hashlib,json,zipfile
root=Path(__file__).resolve().parent.parent
p=argparse.ArgumentParser();p.add_argument('--archive',type=Path,required=True);p.add_argument('--output',type=Path,required=True);args=p.parse_args()
source=root/'source'/'bjarkiLearn'
archive=args.archive
summary=json.loads((root/'reports-0.1.2'/'verification.json').read_text())
expected='b9a6c1a1f9cd84cfdc58844287f8b96a431936d8e5ad85c184400d5d9c061c89'
actual=hashlib.sha256(archive.read_bytes()).hexdigest()
assert actual==expected
files={str(p.relative_to(source)).replace('\\','/'):p for p in source.rglob('*') if p.is_file()}
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    names=z.namelist()
    assert len(names)==len(set(names))==14
    assert set(names)=={'bjarkiLearn/'+name for name in files}
    for name in names:
        assert '..' not in PurePosixPath(name).parts and not name.startswith('/')
        blob=z.read(name);blob.decode('utf-8-sig')
        assert blob==files[name.removeprefix('bjarkiLearn/')].read_bytes()
    for toc in ('bjarkiLearn.toc','bjarkiLearn_Camelot.toc'):
        text=z.read('bjarkiLearn/'+toc).decode('utf-8-sig')
        assert '## Version: 0.1.2-shadow' in text
        assert '## Interface: 16001' in text
        assert '## SavedVariables: bjarkiLearnDB' in text
        assert [line.strip() for line in text.splitlines() if line.strip() and not line.startswith('#')]==['Bootstrap.lua','Rules.lua','Network.lua','Core.lua','Adapter.lua','Main.lua']
    verification=z.read('bjarkiLearn/VERIFICATION.md').decode('utf-8-sig')
    assert verification.startswith('# bjarkiLearn 0.1.2-shadow verification')
    assert '302/302' in verification and '22,136' in verification and '7,731' in verification
    assert 'bjarkiLearn-0.1.2-shadow-verification.zip' in verification
    for file,digest in summary['runtime_hashes'].items():
        assert hashlib.sha256(z.read('bjarkiLearn/'+file)).hexdigest()==digest
        assert f'| {file} | `{digest}` |' in verification
    assert 'version = "0.1.2-shadow"' in z.read('bjarkiLearn/Bootstrap.lua').decode()
    baseline=root/'baseline-0.1.1'/'source'/'bjarkiLearn'
    assert set(files)=={str(p.relative_to(baseline)).replace('\\','/') for p in baseline.rglob('*') if p.is_file()}
report={'status':'PASS','archive':str(archive.resolve()),'sha256':actual,'file_count':14,'crc':'PASS','inventory_matches_baseline':True,'exact_source_bytes':True,'version_and_load_order':'PASS','documented_runtime_hashes_match_archive_and_aggregate':True,'aggregate_scenarios':summary['scenario_executions'],'aggregate_boundary_checks':summary['independent_boundary_checks_passed'],'note':'No Lua suites rerun; this is a final document and install ZIP review.'}
args.output.parent.mkdir(parents=True,exist_ok=True)
args.output.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))

