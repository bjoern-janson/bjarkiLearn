import hashlib, importlib, json, pathlib, sys
ROOT=pathlib.Path(__file__).resolve().parent
SOURCE=ROOT.parent/'source'/'bjarkiLearn'
sys.path.insert(0,r'C:/Users/Mewn/Documents/Codex/2026-10-16/let/work/deps')
TESTS=r'''
local ns=...
local M,C=ns.Models,ns.Config
local cases,assertions,maxError={},0,0
local function check(v,msg) assertions=assertions+1; assert(v,msg or 'check failed') end
local function close(a,b,eps,msg) check(math.abs(a-b)<=(eps or 1e-12),(msg or 'mismatch')..': '..tostring(a)..' ~= '..tostring(b)) end
local function same(a,b)
 if type(a)~=type(b) then return false end
 if type(a)~='table' then return a==b end
 for k,v in next,a do if not same(v,b[k]) then return false end end
 for k in next,b do if a[k]==nil then return false end end
 return true
end
local function clone(a) if type(a)~='table' then return a end local b={} for k,v in next,a do b[k]=clone(v) end return b end
local function case(name,fn) fn(); cases[#cases+1]=name end
local function rejected(m,x,y,mask,flag,reason)
 local before=clone(m); local ok,why=m:Learn(x,y,mask,flag)
 check(ok==false,'unexpected success'); if reason then check(why==reason,why) end
 check(same(before,m),'rejected update mutated model')
end
case('constructor validation and PRNG',function()
 for _,d in ipairs({0,-1,0.5,257,math.huge,0/0,false,'3'}) do check(M.New(d,3,2)==nil) end
 for _,s in ipairs({0.5,9007199254740992,math.huge,0/0,false,'3'}) do check(M.New(3,3,2,s)==nil) end
 for _,s in ipairs({-9007199254740991,-2147483647,-1,0,1,73013,9007199254740991}) do
  local a,b=M.New(3,4,2,s),M.New(3,4,2,s); check(a:Valid()); check(same(a,b))
 end
 local a=M.New(1,1,1,1); close(a.hiddenWeights[1][1],(2*16807/2147483647-1)*math.sqrt(3))
end)
case('forward against independent scalar reference',function()
 local m=M.New(3,4,3,73013); local x={0.1,0.8,0.5}
 for i=1,3 do m.linearBiases[i]=0.11*i; for j=1,3 do m.linearWeights[i][j]=0.2*(i-j) end end
 local p=m:Predict(x); local h={}
 for u=1,4 do local a=m.hiddenBiases[u]; for j=1,3 do a=a+m.hiddenWeights[u][j]*x[j] end h[u]=(math.exp(a)-math.exp(-a))/(math.exp(a)+math.exp(-a)) end
 for o=1,3 do
  local n,l=m.outputBiases[o],m.linearBiases[o]
  for u=1,4 do n=n+m.outputWeights[o][u]*h[u] end
  for j=1,3 do l=l+m.linearWeights[o][j]*x[j] end
  close(p.neural[o],1/(1+math.exp(-n))); close(p.linear[o],1/(1+math.exp(-l))); close(p.frequency[o],0.5)
 end
end)
case('all parameter masked gradients against finite differences',function()
 for _,mask in ipairs({{true,false,true},{false,true,false},{true,true,true}}) do
  local m=M.New(3,4,3,17); m.learningRate=0.01; m.regularization=0.13; m.linearRegularization=0.07; m.gradientClip=1e6
  for o=1,3 do m.outputBiases[o]=0.12*(o-2); m.linearBiases[o]=0.17*(2-o); for j=1,3 do m.linearWeights[o][j]=0.14*(o-j) end end
  for u=1,4 do m.hiddenBiases[u]=0.1*(u-2) end
  local x,y={0.3,0.7,0.5},{1,0,1}
  local function objective()
   local p=m:Predict(x); local n=0; for o=1,3 do if mask[o] then n=n+1 end end
   local loss=0
   for o=1,3 do if mask[o] then
    loss=loss-(y[o]*math.log(p.neural[o])+(1-y[o])*math.log(1-p.neural[o]))/n
    loss=loss-y[o]*math.log(p.linear[o])-(1-y[o])*math.log(1-p.linear[o])
    for u=1,4 do loss=loss+0.5*m.regularization*m.outputWeights[o][u]^2 end
    for j=1,3 do loss=loss+0.5*m.linearRegularization*m.linearWeights[o][j]^2 end
   end end
   for u=1,4 do for j=1,3 do loss=loss+0.5*m.regularization*m.hiddenWeights[u][j]^2 end end
   return loss
  end
  local after=m:Copy(); check(after:Learn(x,y,mask))
  for _,f in ipairs({'hiddenWeights','hiddenBiases','outputWeights','outputBiases','linearWeights','linearBiases'}) do
   for i,v in ipairs(m[f]) do
    local row=type(v)=='table' and v or m[f]; local dst=type(v)=='table' and after[f][i] or after[f]
    for j=type(v)=='table' and 1 or i,type(v)=='table' and #v or i do
     local old=row[j]; row[j]=old+1e-5; local plus=objective(); row[j]=old-1e-5; local minus=objective(); row[j]=old
     local expected=(plus-minus)/2e-5; local actual=(old-dst[j])/m.learningRate
     maxError=math.max(maxError,math.abs(actual-expected)); close(actual,expected,1e-8,'gradient '..f..'/'..i..'/'..j)
    end
   end
  end
  check(after.updates==1); for o=1,3 do check(after.totals[o]==(mask[o] and 1 or 0)); check(after.positives[o]==(mask[o] and y[o] or 0)) end
 end
end)
case('masked heads untouched and zero mask exact no-op',function()
 local m=M.New(3,4,3,11); local before=clone(m)
 check(m:Learn({0,1,0},{0,1,1},{false,false,false})); check(same(m,before))
 check(m:Learn({0,1,0},{0,1,1},{true,false,false}))
 for o=2,3 do for _,f in ipairs({'outputWeights','outputBiases','linearWeights','linearBiases','positives','totals'}) do check(same(m[f][o],before[f][o]),f) end end
 check(not same(m.hiddenWeights,before.hiddenWeights))
 local n=m:Copy(); check(n:Learn({0,1,0},{0,1,1},{true,true,true},false)); check(same(n.totals,m.totals)); check(same(n.positives,m.positives)); check(n.updates==m.updates+1)
end)
case('coordinate clipping equals unclipped gradient clipped per parameter',function()
 local m=M.New(3,4,3,13); m.regularization=10; m.linearRegularization=10; m.gradientClip=1e6
 local raw=m:Copy(); check(raw:Learn({1,1,1},{0,1,0},{true,true,true}))
 local clipped=m:Copy(); clipped.gradientClip=0.01; check(clipped:Learn({1,1,1},{0,1,0},{true,true,true}))
 for _,f in ipairs({'hiddenWeights','hiddenBiases','outputWeights','outputBiases','linearWeights','linearBiases'}) do
  for i,v in ipairs(m[f]) do
   local row=type(v)=='table' and v or m[f]; local dst=type(v)=='table' and clipped[f][i] or clipped[f]; local ref=type(v)=='table' and raw[f][i] or raw[f]
   for j=type(v)=='table' and 1 or i,type(v)=='table' and #v or i do local g=(row[j]-ref[j])/m.learningRate; close(dst[j],row[j]-m.learningRate*math.max(-0.01,math.min(0.01,g))) end
  end
 end
end)
case('invalid inputs labels masks and settings reject atomically',function()
 local x,y,k={0.2,0.5,1},{0,1},{true,false}; local m=M.New(3,4,2,99)
 for _,bad in ipairs({{0,1},{0,1,0,1},{0,1,0,extra=1},{0,0/0,1},{0,math.huge,1},{0,-0.01,1},{0,1.01,1},setmetatable({0,0,1},{})}) do rejected(m,bad,y,k,nil,'invalid_inputs') end
 for _,bad in ipairs({{0},{0,1,0},{0,0.5},{0,true},{0,0/0},setmetatable({0,1},{})}) do rejected(m,x,bad,k,nil,'invalid_labels') end
 for _,bad in ipairs({{true},{true,false,true},{1,0},{true,0/0},setmetatable({true,false},{})}) do rejected(m,x,y,bad,nil,'invalid_mask') end
 rejected(m,x,y,k,0,'invalid_statistics_flag')
 for _,f in ipairs({'learningRate','regularization','linearRegularization','gradientClip'}) do local b=m:Copy(); b[f]=-1; rejected(b,x,y,k,nil,'invalid_model_settings') end
 local b=m:Copy(); b.hiddenWeights[1][1]=math.huge; rejected(b,x,y,k,nil,'invalid_model_parameters')
 b=m:Copy(); b.totals[1]=1; rejected(b,x,y,k,nil,'invalid_model_statistics')
 b=m:Copy(); b.extra=1; rejected(b,x,y,k,nil,'invalid_model_field')
 b=m:Copy(); b.seed=nil; rejected(b,x,y,k,nil,'missing_model_field')
end)
case('late overflow failures reject entire candidate',function()
 local x,y,k={1,1,1},{0,1},{true,true}; local m=M.New(3,4,2,43)
 m.regularization=1e308; m.hiddenWeights[4][3]=2; rejected(m,x,y,k,nil,'nonfinite_update')
 m=M.New(3,4,2,43); m.learningRate=1e308; m.gradientClip=1e308; m.linearRegularization=100; m.linearWeights[2][3]=1e308
 rejected(m,x,y,k,nil,'nonfinite_update')
 m=M.New(3,4,2,43); m.updates=9007199254740991; rejected(m,x,y,k,nil,'counter_overflow')
end)
case('stable extreme predictions and finite-dot rejection',function()
 local m=M.New(2,1,2,1); m.hiddenWeights[1]={0,0}; m.hiddenBiases[1]=1e308
 m.outputWeights={{0},{0}}; m.outputBiases={1e308,-1e308}; m.linearWeights={{0,0},{0,0}}; m.linearBiases={1e308,-1e308}
 local p=m:Predict({0,0}); check(p.neural[1]==1 and p.neural[2]==0 and p.linear[1]==1 and p.linear[2]==0)
 m.hiddenWeights[1]={1e308,1e308}; local out,reason=m:Predict({1,1}); check(out==nil and reason=='nonfinite_prediction')
 rejected(m,{1,1},{0,1},{true,true},nil,'nonfinite_prediction')
end)
case('copy ownership and input arrays independent',function()
 local m=M.New(3,4,2,19); local before=clone(m); local cp=m:Copy(); check(same(cp,m)); cp.hiddenWeights[1][1]=123; check(same(m,before))
 local x,y,k={0.2,0.5,1},{0,1},{true,false}; local saved={clone(x),clone(y),clone(k)}; check(m:Learn(x,y,k)); check(same(x,saved[1]) and same(y,saved[2]) and same(k,saved[3]))
 local plain=clone(m); check(getmetatable(m).Valid(plain)); local copied=getmetatable(m).Copy(plain); check(same(copied,m)); check(copied:Predict(x)~=nil)
end)
local function rows()
 local out={}
 for n=1,23 do
  local x,y,mask={},{},{}
  for j=1,48 do x[j]=((n*17+j*13)%101)/100 end
  for j=1,6 do y[j]=(n+j)%2; mask[j]=(n+j)%4~=0 end
  out[n]={x=x,y=y,mask=mask,regime=n%7==0 and 'other' or 'player',predictions={neural={},linear={},frequency={}},sealed=true,revision=1}
 end
 return out
end
local function finish(core) for n=1,1000 do core:_Train(); if not core.dirty then return end end error('did not finish') end
case('Core replay and export restore equal direct deterministic replay',function()
 local a=ns.Core.New(); a.examples=rows(); a:_Dirty(true); finish(a); check(a.model and a.model:Valid())
 local ref=M.New(48,12,6,C.seed)
 for epoch=1,C.epochs do for _,r in ipairs(a.examples) do if r.regime=='player' then check(ref:Learn(r.x,r.y,r.mask,epoch==1)) end end end
 check(same(a.model,ref),'incremental schedule differs from direct replay')
 local saved=a:Export(); local b=ns.Core.New(); check(b:Restore(saved)); saved.examples[1].x[1]=1; check(b.examples[1].x[1]~=1); finish(b)
 check(same(a.model,b.model),'saved corpus rebuild differs')
 local c=ns.Core.New(); c.examples=rows(); c:_Dirty(true); c:_Train(); check(c.candidate~=nil); c.examples[1].y[1]=1-c.examples[1].y[1]; c:_Dirty(true); check(c.candidate==nil); finish(c)
 local d=ns.Core.New(); d.examples=clone(c.examples); d:_Dirty(true); finish(d); check(same(c.model,d.model),'canceled rebuild contaminated clean rebuild')
 local before=clone(b.examples); local bad=b:Export(); bad.examples[5].y[1]=0.2; check(b:Restore(bad)==false); check(same(before,b.examples)); check(same(a.model,b.model))
end)
case('interacting XOR converges in neural model',function()
 local m=M.New(2,6,1,73013); local x={{0,0},{0,1},{1,0},{1,1}}; local y={{0},{1},{1},{0}}
 for epoch=1,2500 do for n=1,4 do check(m:Learn(x[n],y[n],{true},epoch==1)) end end
 for n=1,4 do local p=m:Predict(x[n]); check(y[n][1]==1 and p.neural[1]>0.9 or y[n][1]==0 and p.neural[1]<0.1,'XOR did not converge'); check(p.linear[1]>0.3 and p.linear[1]<0.7) end
 check(m.totals[1]==4 and m.positives[1]==2 and m.updates==10000)
end)
return cases,assertions,maxError
'''
results=[]
for engine in ('lua51','lua54'):
 lua=importlib.import_module('lupa.'+engine).LuaRuntime(unpack_returned_tuples=True)
 namespace=lua.table(); compiled=[]
 for name in ('Bootstrap.lua','Rules.lua','Network.lua','Core.lua','Adapter.lua','Main.lua'):
  fn=lua.compile((SOURCE/name).read_text(encoding='utf-8-sig'),name=name); compiled.append(name)
  if name in ('Bootstrap.lua','Rules.lua','Network.lua','Core.lua'): fn('bjarkiLearn',namespace)
 cases,assertions,err=lua.execute(TESTS,namespace)
 fixture=lua.execute('local ns=...; local m=ns.Models.New(3,4,2,73013); for n=1,37 do assert(m:Learn({n%2,0.3,0.7},{n%2,(n+1)%2},{true,n%3~=0},n<10)) end; return m',namespace)
 def py(v):
  if lua.eval('type')(v)=='table': return {str(k):py(val) for k,val in v.items()}
  return v
 results.append(dict(engine=engine,cases=list(cases.values()),assertions=assertions,max_gradient_absolute_error=err,compiled=compiled,fixture=py(fixture)))
 print(json.dumps({k:v for k,v in results[-1].items() if k!='fixture'}))
def compare(a,b):
 if isinstance(a,dict):
  assert a.keys()==b.keys()
  return max((compare(a[k],b[k]) for k in a),default=0)
 return abs(a-b)
cross_error=compare(results[0]['fixture'],results[1]['fixture'])
assert cross_error<1e-12,cross_error
report=dict(source_hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in SOURCE.glob('*.lua')},results=results,cross_engine_max_difference=cross_error)
(ROOT/'results.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print('cross_engine_max_difference',cross_error)

