import importlib,json,pathlib,sys
sys.path.insert(0,r'C:/Users/Mewn/Documents/Codex/2026-10-16/let/work/deps')
root=pathlib.Path(__file__).resolve().parent
source=root.parent/'source'/'bjarkiLearn'/'Network.lua'
seeds=[-9007199254740991,-9007199254740990,-9007199254000000,-2147483647,-1,0,1,73013,9007199254740991]
results={}
for engine in ('lua51','lua54'):
 lua=importlib.import_module('lupa.'+engine).LuaRuntime(unpack_returned_tuples=True)
 ns=lua.table(); lua.compile(source.read_text(encoding='utf-8-sig'))('bjarkiLearn',ns)
 results[engine]=[]
 for seed in seeds:
  m=ns.Models.New(3,4,2,seed)
  results[engine].append(dict(requested_seed=seed,expected_normalized_seed=seed%2147483647 or 1,actual_normalized_seed=m.seed,rng_state=m.rngState,first_hidden_weight=m.hiddenWeights[1][1]))
print(json.dumps(results,indent=2)); (root/'seed_portability_results.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
