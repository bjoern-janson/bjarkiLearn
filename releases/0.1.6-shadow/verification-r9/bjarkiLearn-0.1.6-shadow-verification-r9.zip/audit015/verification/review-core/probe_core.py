import json, sys
from pathlib import Path
sys.path.insert(0, r'C:\Users\Mewn\Documents\Codex\2026-10-16\let\work\deps')
ROOT=Path(__file__).resolve().parent
SOURCE=ROOT.parent/'source'/'bjarkiLearn'
PRELUDE=r'''
local ns=...
local function ctx(c,id,t,role)
 c:Context({actor=id,at=t,role=role or "self",class="PRIEST",combat=true,bound=true})
end
local function opened(t,id,role)
 local c=ns.Core.New(); c:SetCoverage(true); ctx(c,id or "P1",t,role); c:Tick(t,true); return c
end
local function resolve(c,t) c:Tick(t,false); return c.examples[1] end
'''
PROBES={
'anchor_gap_enemy':r'''
 local c=opened(10)
 c:Cast({actor="P1",id="anchor",at=10,family=1}); c:Cast({actor="P1",id="in",at=11,family=2})
 c:Gap("gap","P1"); local w=resolve(c,12.25)
 assert(w.y[1]==0 and not w.mask[1]); assert(w.y[2]==1 and w.mask[2])
 local e=opened(10,"P2","hostile"); e:Cast({actor="P2",id="enemy",at=12,family=1})
 local ew=resolve(e,12.25); assert(ew.y[1]==1 and ew.mask[1] and not ew.mask[2])
 assert(e:Status().trainingExamples==0)
 return "anchor excluded; deadline included; gap censors absence; enemy positive untrained"
''',
'uncertainty_family_retraction':r'''
 local c=opened(10); local x=c.actors.P1.window.x
 assert(c:Cast({actor="P1",id="rev",at=11,family=1,minAt=10,maxAt=11}))
 local w=resolve(c,12.25); assert(not w.mask[1] and w.y[1]==0)
 c:Cast({actor="P1",id="rev",at=11,family=1,revision=2}); assert(w.y[1]==1 and w.mask[1])
 c:Cast({actor="P1",id="rev",at=11,family=2,revision=3})
 assert(w.y[1]==0 and w.mask[1] and w.y[2]==1 and w.mask[2])
 c:Cast({actor="P1",id="rev",at=11,family=2,revision=4,retracted=true})
 assert(w.y[2]==0 and w.mask[2]); assert(w.x==x and w.x[20]==0)
 assert(#c.examples==1 and #c.occurrenceOrder==1)
 return "uncertainty corrected; family replaced; retraction applied; immutable input; one lesson"
''',
'actor_correction':r'''
 local c=opened(10); ctx(c,"P2",10,"hostile"); c:Tick(10,true)
 c:Cast({actor="P1",id="move",at=11,family=1}); c:Tick(12.25,false)
 c:Cast({actor="P2",id="move",at=11,family=1,revision=2})
 local by={}; for _,w in ipairs(c.examples) do by[w.actor]=w end
 assert(by.P1.y[1]==0 and by.P1.mask[1]); assert(by.P2.y[1]==1 and by.P2.mask[1])
 assert(c.actors.P1.history[1]==nil and c.actors.P2.history[1]==11)
 return "both actors' labels and histories corrected"
''',
'occurrence_cap_and_floor':r'''
 local c=opened(10); c:Cast({actor="P1",id="victim",at=11,family=1}); local w=resolve(c,12.25)
 for n=1,128 do c:Cast({actor="Pother",id="other"..n,at=20+n,family=2}) end
 assert(#c.occurrenceOrder==128); assert(w.y[1]==0 and not w.mask[1])
 local ok,why=c:Cast({actor="P1",id="victim",at=11,family=1})
 assert(not ok and why=="outside_retained_history" and not w.mask[1])
 ok,why=c:Cast({actor="P1",id="victim",at=11,family=1,revision=2})
 assert(not ok and why=="revision_history_lost" and c.model==nil)
 return "128 occurrence cap; dependency censored; stale event and lost revision refused"
''',
'actor_cap_nonoverlap':r'''
 local c=opened(10); for n=2,16 do ctx(c,"P"..n,10.1,"hostile") end
 ctx(c,"P17",10.2,"hostile"); assert(#c.actorOrder==16 and not c.actors.P1)
 assert(c.openAfter==12.25 and #c.examples==1)
 ctx(c,"P1",10.3); c:Tick(10.3,true); assert(c.actors.P1.window==nil)
 ctx(c,"P1",12.25); c:Tick(12.25,true); assert(c.actors.P1.window.anchor==12.25)
 return "16 actor cap; recreated actor waits for retired window"
''',
'persistence_session_reset':r'''
 local c=opened(10); c:Cast({actor="P1",id="raw-id",at=11,family=1}); resolve(c,12.25)
 ctx(c,"P1",13); c:Tick(13,true); local saved=c:Export(); assert(#saved.examples==1)
 assert(saved.examples[1].actor==nil and saved.examples[1].id==nil)
 local d=ns.Core.New(); assert(d:Restore(saved)); assert(#d.examples==1 and d.examples[1].sealed)
 assert(#d.actorOrder==0 and #d.occurrenceOrder==0)
 saved.examples[1].y[1]=0; assert(d.examples[1].y[1]==1)
 for n=1,20 do d:Tick(20+n,false) end; assert(d.model~=nil and not d.dirty)
 c:ResetSession(0); assert(#c.examples==2 and c.examples[2].sealed and not c.examples[2].mask[1])
 assert(#c.actorOrder==0 and #c.occurrenceOrder==0)
 return "pending omitted; raw identities omitted; restore copies/seals/rebuilds; reset censors partial absence"
''',
'example_cap_deterministic_replay':r'''
 local c=ns.Core.New(); c:SetCoverage(true)
 for n=1,257 do
  local t=n*3; ctx(c,"P1",t); c:Tick(t,true)
  if n%2==0 then c:Cast({actor="P1",id="e"..n,at=t+1,family=1}) end
  c:Tick(t+2.25,false)
 end
 assert(#c.examples==256 and c:Status().exampleEvictions==1)
 local d=ns.Core.New(); assert(d:Restore(c:Export()))
 for n=1,300 do c:Tick(1000+n,false); d:Tick(1000+n,false) end
 assert(c.model~=nil and d.model~=nil and not c.dirty and not d.dirty)
 local p=c.model:Predict(c.examples[1].x); local q=d.model:Predict(d.examples[1].x)
 for _,kind in ipairs({"neural","linear","frequency"}) do for i=1,6 do assert(p[kind][i]==q[kind][i]) end end
 return "256 example cap; clean save/restore replay predicts identically"
''',
}
PROBES['correction_retires_scores_and_replaces_evaluation']=r'''
 local c=ns.Core.New(); c:SetCoverage(true)
 for n=1,10 do
  local t=n*3; ctx(c,"P1",t); c:Tick(t,true)
  if n<=2 then c:Cast({actor="P1",id="support"..n,at=t+1,family=1}) end
  c:Tick(t+2.25,false)
 end
 for n=1,30 do c:Tick(33+n*.1,false) end
 assert(c.model~=nil and c.model.positives[1]==2 and c.model.totals[1]==10)
 ctx(c,"P1",40); c:Tick(40,true)
 local score=c:Forecast("P1",40).outputs[1].score; assert(type(score)=="number")
 c:Cast({actor="P1",id="outcome",at=41,family=1}); c:Tick(42.25,false)
 local before=c:Status().families[1]; assert(before.scored==1 and before.positive==3)
 local w=c.examples[#c.examples]; local saved=w.predictions.neural[1]
 c:Cast({actor="P1",id="outcome",at=41,family=1,revision=2,retracted=true})
 assert(c.model==nil and c.actors.P1.forecast==nil)
 local after=c:Status().families[1]; assert(after.scored==1 and after.positive==2 and after.negative==9)
 assert(after.neuralLoss==saved^2 and w.predictions.neural[1]==saved and #c.examples==11)
 return "correction retires model/cache immediately; same saved forecast gets replaced loss, not a duplicate row"
'''
results=[]
for engine in ('lua51','lua54'):
 module=__import__(f'lupa.{engine}',fromlist=['LuaRuntime'])
 for name,body in PROBES.items():
  lua=module.LuaRuntime(unpack_returned_tuples=True); ns=lua.table()
  for filename in ('Bootstrap.lua','Rules.lua','Network.lua','Core.lua'):
   lua.execute((SOURCE/filename).read_text(encoding='utf-8'),'bjarkiLearn',ns)
  try:
   results.append(dict(runtime=engine,probe=name,passed=True,detail=lua.execute(PRELUDE+body,ns)))
  except Exception as exc:
   results.append(dict(runtime=engine,probe=name,passed=False,error=str(exc)))
(ROOT/'results.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
for row in results: print(row)
raise SystemExit(any(not row['passed'] for row in results))

