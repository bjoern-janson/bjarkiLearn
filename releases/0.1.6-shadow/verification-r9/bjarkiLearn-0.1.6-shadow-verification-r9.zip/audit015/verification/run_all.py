"""Reproduce 0.1.5 offline verification; preserve all original test sources."""
from pathlib import Path
import argparse,hashlib,importlib,json,os,subprocess,sys,time
ROOT=Path(__file__).resolve().parent
SOURCE=ROOT/'source/bjarkiLearn';BASE=ROOT/'baseline-0.1.4/source/bjarkiLearn';REPORTS=ROOT/'reports-0.1.5'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads((ROOT/p).read_text(encoding='utf-8-sig'))
def runtime(p):return {f.name:sha(f) for f in sorted(p.glob('*.lua'))}
def verified_subset(actual,expected):assert all(actual[n]==h for n,h in expected.items())
def main():
 p=argparse.ArgumentParser();p.add_argument('--summarize',action='store_true',help='Validate and aggregate existing same-runtime reports; do not rerun tests.');p.add_argument('--lupa-path',type=Path);a=p.parse_args()
 REPORTS.mkdir(exist_ok=True);before=runtime(SOURCE);baseline=runtime(BASE)
 deps=a.lupa_path
 if deps is None:
  try:importlib.import_module('lupa.lua51')
  except ImportError:
   fallback=Path('C:/Users/Mewn/Documents/Codex/2026-10-16/let/work/deps')
   if not fallback.is_dir():raise SystemExit('Install requirements-test.txt or pass --lupa-path')
   deps=fallback
 args=['--lupa-path',str(deps)] if deps else []
 env=dict(os.environ)
 if deps:env['PYTHONPATH']=str(deps)+os.pathsep+env.get('PYTHONPATH','')
 jobs=[
  ('baseline_adaptation',['tests-refactor/legacy/run.py','--mode','baseline-equivalence','--source',str(BASE),'--output',str(ROOT/'tests-refactor/legacy/baseline-equivalence.json'),*args]),
  ('inherited_and_audit014',['tests-refactor/legacy/run.py','--mode','full','--source',str(SOURCE),'--output',str(ROOT/'tests-refactor/legacy/current-full.json'),*args]),
  ('refactor_contracts',['tests-refactor/contracts.py','--source',str(SOURCE),'--output',str(ROOT/'tests-refactor/contracts.json')]),
  ('differential',['tests-refactor/independent/run.py','--source',str(SOURCE),'--baseline',str(BASE),'--output',str(ROOT/'tests-refactor/independent/current.json'),*args]),
  ('review_policy_matrix',['review-0.1.5/run_policy_matrix.py']),
 ]
 runs=[]
 if not a.summarize:
  for name,argv in jobs:
   print('Running '+name+'...',flush=True);start=time.perf_counter()
   with (REPORTS/(name+'-output.txt')).open('w',encoding='utf-8') as stream:
    result=subprocess.run([sys.executable,str(ROOT/argv[0]),*argv[1:]],cwd=ROOT,env=env,stdout=stream,stderr=subprocess.STDOUT)
   runs.append({'suite':name,'exit_code':result.returncode,'seconds':round(time.perf_counter()-start,3)})
   if result.returncode:print((REPORTS/(name+'-output.txt')).read_text(encoding='utf-8')[-10000:]);raise SystemExit(result.returncode)
 expected=read('fixtures/v0.1.4-preserved-test-hashes.json')
 def original(n):return ROOT/('baseline-0.1.4/'+n if n in ('run_all.py','build_release.py') else n)
 assert len(expected)==76 and all(sha(original(n))==h for n,h in expected.items())
 assert before==runtime(SOURCE) and baseline==runtime(BASE)
 adapted=read('tests-refactor/legacy/baseline-equivalence.json')
 legacy=read('tests-refactor/legacy/current-full.json')
 assert adapted['passed'] and adapted['results_identical'] and adapted['original_test_sources_unchanged']
 verified_subset(adapted['source_hashes'],baseline)
 assert legacy['passed'] and legacy['original_test_sources_unchanged'] and legacy['audit014_original_files_unchanged']
 verified_subset(legacy['source_hashes'],before)
 # Release documentation may be clarified after an immutable staged run.
 # The runner explicitly records this; no such exception applies to runtime.
 if not legacy['source_unchanged']:
  assert legacy['runtime_source_unchanged'] and legacy['documentation_changes_only']
 inherited=legacy['inherited_verification'];audit=legacy['audit014']
 assert inherited['passed'] and inherited['scenario_executions']==663
 assert inherited['fresh_whole_change_review_probes_passed']==12
 assert inherited['superseded_engine_executions']==6 and inherited['runtime_hashes']==before
 assert audit['groups_passed']==94 and audit['integration_comparisons_passed']==8
 verified_subset(audit['integration_baseline_hashes'],baseline)
 contracts=read('tests-refactor/contracts.json');assert contracts['passed']==contracts['total']==8 and contracts['source_unchanged'] and contracts['source_hashes']==before
 diff=read('tests-refactor/independent/current.json');assert diff['source_unchanged'] and diff['counts']['cases']==diff['counts']['passed']>0
 verified_subset(diff['hashes_before']['source'],before);verified_subset(diff['hashes_before']['baseline'],baseline)
 matrix=read('review-0.1.5/policy-matrix-results.json');assert matrix['runtime_unchanged'] and all(x['passed'] for x in matrix['results'])
 verified_subset(matrix['hashes']['current'],before);verified_subset(matrix['hashes']['baseline'],baseline)
 gate=read('review-0.1.5/review-gate.json');assert gate['passed'];verified_subset(gate['runtime_hashes'],before)
 # Compile all six runtime files on both supported interpreters.
 if deps:sys.path.insert(0,str(deps))
 syntax=[]
 for engine in ('lua51','lua54'):
  lua=importlib.import_module('lupa.'+engine).LuaRuntime(unpack_returned_tuples=True)
  compile_lua=lua.eval('function(code,name) local loadfn=loadstring or load; local f,e=loadfn(code,name); assert(f,e); return true end')
  for f in sorted(SOURCE.glob('*.lua')):assert compile_lua(f.read_text(encoding='utf-8'),f.name);syntax.append({'runtime':engine,'file':f.name,'passed':True})
 report={'passed':True,'version':'0.1.5-shadow','runtime_hashes':before,'baseline_runtime_hashes':baseline,'reports_reused':a.summarize,'runs':runs,
  'original_test_sources_unchanged':True,'preserved_original_test_files':76,'legacy_scenario_controls_passed':663,'legacy_review_probes_passed':12,
  'superseded_historical_assertions_excluded':6,'audit014_checks_passed':94,'native_014_comparisons_passed':8,
  'contracts_passed':8,'differential_cases_passed':diff['counts']['passed'],'differential_counts':diff['counts'],
  'review_policy_comparisons_passed':sum(x['exact_policy_state_comparisons'] for x in matrix['results']),
  'baseline_adaptation_controls_per_variant':adapted['current_controls_per_variant'],'adapted_private_cache_files':len(legacy['adaptation_provenance']['adapted_files']),
  'syntax_checks_passed':len(syntax),'syntax_checks':syntax,'additional_inherited_checks':{k:inherited[k] for k in ('independent_boundary_checks_passed','seed_constructor_cases','seed_invalid_inputs_checked','native_replay_trajectories_passed','capacity_reproduction_runs_passed','native_cross_version_and_reload_comparisons_passed')},
  'staged_documentation_note':'See legacy current-full report for exact staged/current source hashes and any documented non-runtime release-text changes.',
  'limits':['Offline ordinary Lua with modeled WoW APIs; no live-client proof.','Refactor equivalence does not establish predictive usefulness or frame-time improvement.','Unchanged bounded history cannot reconstruct discarded identities or sealed deidentified evidence.']}
 (REPORTS/'verification.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
 print(json.dumps(report,indent=2))
if __name__=='__main__':main()
