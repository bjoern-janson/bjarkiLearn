"""Run preserved suites and temporal regressions against bundled 0.1.4 source."""
from pathlib import Path
import argparse, hashlib, importlib, json, subprocess, sys, time
ROOT=Path(__file__).resolve().parent
SOURCE=ROOT/'source/bjarkiLearn'
REPORTS=ROOT/'reports-0.1.4'
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def hashes(): return {p.name:sha(p) for p in sorted(SOURCE.glob('*.lua'))}
def read(path): return json.loads((ROOT/path).read_text(encoding='utf-8-sig'))
def main():
 parser=argparse.ArgumentParser();parser.add_argument('--reuse-repro',action='store_true',help='Reuse an already verified same-runtime-hash reset-repro report from this build. Default reruns it.');parser.add_argument('--summarize',action='store_true',help='Validate existing reports against current runtime hashes without rerunning suites.');args=parser.parse_args()
 REPORTS.mkdir(exist_ok=True)
 expected=read('fixtures/v0.1.3-preserved-test-hashes.json')
 preserved=lambda:{n:sha(ROOT/n) for n in expected}
 assert preserved()==expected, 'Prior test files changed'
 dependency_args=[]
 try: importlib.import_module('lupa.lua51')
 except ImportError:
  fallback=Path('C:/Users/Mewn/Documents/Codex/2026-10-16/let/work/deps')
  if not fallback.is_dir(): raise SystemExit('Install test dependencies: python -m pip install -r requirements-test.txt')
  dependency_args=['--lupa-path',str(fallback)]
 before=hashes();runs=[]
 jobs=[
  ('prior136',['run_legacy.py']),
  ('audit_controls',['run_audit_controls.py','--source',str(SOURCE),'--output',str(REPORTS/'audit-controls.json')]),
  ('registration',['new-tests/registration/run.py','--source',str(SOURCE),'--output',str(REPORTS/'registration.json')]),
  ('restore',['new-tests/restore/run.py','--source',str(SOURCE),'--output',str(REPORTS/'restore.json')]),
  ('seeds',['new-tests/seeds/run_seed_regressions.py','--source',str(SOURCE),'--baseline',str(ROOT/'baseline-0.1.1/source/bjarkiLearn'),'--output',str(REPORTS/'seeds.json')]),
  ('fresh_review',['review-0.1.2/run.py','--source',str(SOURCE),'--output',str(REPORTS/'fresh-review.json'),*dependency_args]),
  ('audit012_core',['audit-0.1.2/core/run.py','--source',str(SOURCE),'--output',str(REPORTS/'audit012-core.json')]),
  ('audit012_native',['audit-0.1.2/native/run.py','--source',str(SOURCE),'--output',str(REPORTS/'audit012-native.json'),'--bus',str(ROOT/'fixtures/SharedEvidence.lua')]),
  ('audit012_network_restore',['audit-0.1.2/network-restore/run.py','--source',str(SOURCE),'--output',str(REPORTS/'audit012-network-restore.json')]),
  ('reset_core',['tests-reset/run_core.py','--source',str(SOURCE),'--output',str(REPORTS/'reset-core.json')]),
  ('reset_native',['tests-reset/native/run.py','--source',str(SOURCE),'--output',str(REPORTS/'reset-native.json')]),
 ]
 jobs.extend([
  ('review013',['review-0.1.3/run.py','--source',str(SOURCE),'--output',str(REPORTS/'review013.json'),*dependency_args]),
  ('audit013_core',['audit-0.1.3/audit/core/run.py','--source',str(SOURCE),'--output',str(REPORTS/'audit013-core.json')]),
  ('audit013_native',['audit-0.1.3/audit/native/run.py','--source',str(SOURCE),'--output',str(REPORTS/'audit013-native.json')]),
  ('audit013_network',['audit-0.1.3/audit/network-restore/run.py','--source',str(SOURCE),'--output',str(REPORTS/'audit013-network.json')]),
  ('audit013_integration',['audit-0.1.3/audit/integration/run.py','--source',str(SOURCE),'--baseline',str(ROOT/'baseline-0.1.3/source/bjarkiLearn'),'--output',str(REPORTS/'audit013-integration.json')]),
  ('temporal',['tests-time/run.py','--source',str(SOURCE),'--output',str(REPORTS/'temporal.json')]),
  ('temporal_independent',['tests-time/independent/run.py','--source',str(SOURCE),'--output',str(REPORTS/'temporal-independent.json')]),
  ('normalized_legacy',['tests-time/run_normalized_legacy.py','--source',str(SOURCE),'--output',str(REPORTS/'normalized-legacy.json')]),
 ])
 if not args.reuse_repro: jobs.append(('reset_repro',['tests-reset/run_repro.py','--source',str(SOURCE),'--output',str(REPORTS/'reset-repro.json')]))
 if args.summarize: jobs=[]
 for name,job_args in jobs:
  print('Running '+name+'...',flush=True);start=time.perf_counter()
  result=subprocess.run([sys.executable,str(ROOT/job_args[0]),*job_args[1:]],cwd=ROOT,capture_output=True,text=True,encoding='utf-8',errors='replace')
  (REPORTS/(name+'-output.txt')).write_text(result.stdout+result.stderr,encoding='utf-8')
  runs.append({'suite':name,'exit_code':result.returncode,'seconds':round(time.perf_counter()-start,3)})
  if result.returncode and name not in ('audit_controls','audit012_core','audit013_core'):
   print(result.stdout+result.stderr);raise SystemExit(result.returncode)
 legacy=read('reports/verification.json');audit=read('reports-0.1.4/audit-controls.json');registration=read('reports-0.1.4/registration.json');restore=read('reports-0.1.4/restore.json');seeds=read('reports-0.1.4/seeds.json')
 assert legacy['passed'] and legacy['scenario_executions']==136 and legacy['syntax_passed']==12
 assert audit['scenario_executions']==40 and audit['summary']['passed']==38
 assert registration['summary']['passed']==registration['summary']['total']==86 and registration['source_unchanged']
 assert restore['passed']==restore['total']==40 and restore['source_unchanged']
 assert seeds['status']=='PASS' and seeds['failure_count']==0 and seeds['corpus_seed_count']==2577
 fresh=read('reports-0.1.4/fresh-review.json')
 assert fresh['summary']['passed']==fresh['summary']['total']==22136 and fresh['source_unchanged']
 assert fresh['source_hashes']==before
 assert before==hashes()==legacy['runtime_hashes']==audit['source_hashes']==registration['source_hashes']==restore['source_hashes']
 assert before['Network.lua']==seeds['source_sha256']
 assert preserved()==expected and legacy['original_harnesses_unchanged'] and audit['fixture_original_bytes_verified']
 core012=read('reports-0.1.4/audit012-core.json');native012=read('reports-0.1.4/audit012-native.json');network012=read('reports-0.1.4/audit012-network-restore.json')
 reset_core=read('reports-0.1.4/reset-core.json');reset_native=read('reports-0.1.4/reset-native.json');repro=read('reports-0.1.4/reset-repro.json')
 assert len(core012)==12 and sum(r['passed'] for r in core012)==10
 assert native012['summary']['total']==native012['summary']['passed']==36
 assert network012['passed']==network012['total']==18
 assert reset_core['passed']==reset_core['total']==12
 assert reset_native['summary']['passed']==reset_native['summary']['total']==84
 assert repro['passed'] and repro['native_trace_runs_passed']==repro['native_trace_runs']==12 and repro['capacity_runs_passed']==repro['capacity_runs']==8
 for r in (native012,network012,reset_core,reset_native,repro): assert r['source_hashes']==before and r['source_unchanged']
 assert hashes()==before and preserved()==expected
 counts={'prior_packaged':136,'later_audit_controls':38,'registration_repair':86,'restore_repair':40,'audit012_core':10,'audit012_native':36,'audit012_network_restore':18,'reset_core':12,'reset_native_guid_variants':84}
 review013=read('reports-0.1.4/review013.json');core013=read('reports-0.1.4/audit013-core.json');native013=read('reports-0.1.4/audit013-native.json');network013=read('reports-0.1.4/audit013-network.json');integration013=read('reports-0.1.4/audit013-integration.json')
 temporal=read('reports-0.1.4/temporal.json');temporal_independent=read('reports-0.1.4/temporal-independent.json');normalized=read('reports-0.1.4/normalized-legacy.json')
 assert review013['passed']==review013['total']==10
 assert core013['counts']=={'total':40,'passed':38}
 assert native013['summary']['passed']==native013['summary']['total']==54
 assert network013['passed']==network013['total']==21
 assert integration013['passed'] and integration013['total']==integration013['passes']==8
 assert temporal['passed']==temporal['total']==28
 assert temporal_independent['counts']=={'passed':46,'total':46}
 assert normalized['passed']==normalized['total']==6
 for r in (review013,core013,native013,network013,integration013,temporal,temporal_independent,normalized):
  assert r['source_unchanged']
  actual=r.get('source_hashes',r.get('source_hashes_before'))
  assert all(actual[n]==h for n,h in before.items())
 # These immutable original tests assert that a not-yet-observed future cast
 # survives an earlier reset as positive. Do not count that defect as passing.
 superseded=[
  (audit['cases'],'case','engine','active replay reset with pending positive cancels candidate, seals rows, publishes copied corpus'),
  (core012,'name','runtime','reset halfway through training with pending partial window restarts replay'),
  (core013['cases'],'name','runtime','actor_eviction_overlap_pause_and_clock_rollback'),
 ]
 retired=[]
 for rows,key,engine,name in superseded:
  failures=[x for x in rows if not x['passed']]
  assert len(failures)==2 and {x[engine] for x in failures}=={'lua51','lua54'} and all(x[key]==name for x in failures)
  retired.extend({'runtime':x[engine],'case':name,'status':'superseded_future_positive_expectation','original_error':x.get('error')} for x in failures)
 counts.update({'prior_review013':10,'audit013_core':38,'audit013_native':54,'audit013_network_restore':21,'temporal_projection_and_reset':28,'independent_temporal_corrections':46,'observed_clock_legacy_controls':6})
 report={'passed':True,'version':'0.1.4-shadow','scenario_executions':sum(counts.values()),'counts':counts,'independent_boundary_checks_passed':fresh['summary']['passed'],'syntax_checks_passed':12,'runtime_hashes':before,'source_unchanged':True,'preserved_test_files':len(expected),'prior_test_source_bytes_unchanged':True,'audit_fixture_files_unchanged':len(audit['fixture_hashes']),'seed_corpus_distinct_values':seeds['corpus_seed_count'],'seed_constructor_cases':sum(x['accepted_seeds_checked'] for r in seeds['runtimes'].values() for x in r['representations'].values()),'seed_invalid_inputs_checked':sum(r['invalid_inputs_checked'] for r in seeds['runtimes'].values()),'production_default_unchanged':all(r['production_default_control']['baseline_complete_state_and_three_predictions_identical'] for r in seeds['runtimes'].values()),'runs':runs,'repro_report_reused':args.reuse_repro or args.summarize,'reports_reused':args.summarize,'native_replay_trajectories_passed':12,'capacity_reproduction_runs_passed':8,'original_reset_repro_score':repro['capacity_traces'][0]['observed']['score'],'long_integration':legacy['long_integration'],'limits':['Modeled WoW APIs, not live-client verification.','Native silent-false registration trigger on the intended client remains unconfirmed.','Previously sealed deidentified history cannot be retroactively reconstructed.','Saved labels cannot be retroactively validated by the registration repair.','Shadow outputs remain unusable by consumers.']}
 report.update({'superseded_original_assertions':retired,'superseded_engine_executions':len(retired),'prior_current_controls_passed':583,'new_temporal_and_normalized_controls_passed':80,'native_cross_version_and_reload_comparisons_passed':8,'prior_review_checks_passed':10})
 (REPORTS/'verification.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
 print(json.dumps(report,indent=2))
def fresh_review():
 result=subprocess.run([sys.executable,str(ROOT/'review-0.1.4/run.py'),'--source',str(SOURCE),'--output',str(REPORTS/'fresh-review014.json')],cwd=ROOT,capture_output=True,text=True,encoding='utf-8',errors='replace')
 (REPORTS/'fresh-review014-output.txt').write_text(result.stdout+result.stderr,encoding='utf-8')
 if result.returncode: print(result.stdout+result.stderr);raise SystemExit(result.returncode)
 reviewed=read('reports-0.1.4/fresh-review014.json');report=read('reports-0.1.4/verification.json')
 assert reviewed['passed']==reviewed['total']==12 and reviewed['source_unchanged'] and reviewed['baseline_unchanged']
 assert all(reviewed['source_hashes'][n]==h for n,h in hashes().items())
 report['fresh_whole_change_review_probes_passed']=12
 (REPORTS/'verification.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
 print('Fresh independent review: 12/12 passed')
if __name__=='__main__': main();fresh_review()
