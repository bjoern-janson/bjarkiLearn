bjarkiLearn 0.1.4-shadow verification bundle

Reproduce (Python 3, lupa 2.8):
  python -m pip install -r requirements-test.txt
  python run_all.py
  python build_release.py --output dist

On the original host, runners also recognize the pre-existing local Lupa directory. No network access is needed after installing the listed dependency.

Current aggregate: reports-0.1.4/verification.json
Fresh independent review: review-0.1.4/ and reports-0.1.4/fresh-review014.json
New targeted tests: tests-time/ (parent) and tests-time/independent/ (separate test author)
Original bug RED results: reports-0.1.4/projections-red.json and tests-time/independent/baseline-red.json
Original source and install ZIP: baseline-0.1.3/
Review specification and implementation decisions: design.txt, plan.txt
Diff and archive manifest: source-changes.patch, package.json
Original test-source preservation manifest: fixtures/v0.1.3-preserved-test-hashes.json

663 current scenario/control executions plus 12 fresh review probes are required for packaging, across Lua 5.1 and 5.4. Three unchanged older private-Core tests assume a future cast is already positive when a reset happens before its timestamp. Their six engine executions are retained as superseded observations, not passed scenarios. run_all.py verifies their exact names and that no additional old test fails. tests-time/run_normalized_legacy.py inserts an observed clock update before each reset and preserves every original assertion; separate new tests cover the censored future-only outcome and clean replay candidate retention.

Additional seed/boundary checks and native full-state/capacity/reload comparisons are recorded separately from scenario counts. Historical reports retain their original version and claim scope. The 0.1.3 audit integration runner's internal version labels are historical: the current invocation supplies baseline-0.1.3 and current source explicitly.

For a focused reproduction:
  python tests-time/run.py --source source/bjarkiLearn --output temporal.json
  python tests-time/independent/run.py --source source/bjarkiLearn --output independent-temporal.json
  python review-0.1.4/run.py --source source/bjarkiLearn --output independent-review.json

The install ZIP has the same 14-file inventory, both valid TOCs and exact tested runtime bytes. The builder checks prior source preservation, runtime hashes, reviewer gate, CRCs and archived bytes. Historical plans/reports inside this bundle are evidence, not instructions to change repositories or installed addons.

Modeled Lua/WoW APIs do not prove live-client event behavior, taint/secret enforcement, frame cost or predictive usefulness. Existing deidentified saved examples cannot be retroactively reconstructed. All forecasts remain shadow diagnostics, usable=false.
