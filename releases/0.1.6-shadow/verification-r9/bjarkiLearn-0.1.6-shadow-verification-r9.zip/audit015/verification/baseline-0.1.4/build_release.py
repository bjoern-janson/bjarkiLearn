"""Package exact verified 0.1.4 source; run run_all.py first."""
from pathlib import Path
import argparse,difflib,hashlib,json,zipfile
ROOT=Path(__file__).resolve().parent
SOURCE=ROOT/'source/bjarkiLearn';BASE=ROOT/'baseline-0.1.3/source/bjarkiLearn'
p=argparse.ArgumentParser();p.add_argument('--output',default=str(ROOT/'dist'));args=p.parse_args()
OUT=Path(args.output).resolve();OUT.mkdir(parents=True,exist_ok=True)
def sha(data):return hashlib.sha256(data).hexdigest()
def read(path):return json.loads((ROOT/path).read_text(encoding='utf-8'))
def dump(path,value):path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
result=read('reports-0.1.4/verification.json')
assert result['passed'] and result['scenario_executions']==663 and result['syntax_checks_passed']==12
assert result['independent_boundary_checks_passed']==22136 and result['seed_constructor_cases']==7731
assert result['native_replay_trajectories_passed']==12 and result['capacity_reproduction_runs_passed']==8
assert result['native_cross_version_and_reload_comparisons_passed']==8
assert result['runtime_hashes']=={f.name:sha(f.read_bytes()) for f in SOURCE.glob('*.lua')}
assert result['production_default_unchanged'] and result['prior_test_source_bytes_unchanged']
expected=read('fixtures/v0.1.3-preserved-test-hashes.json')
assert len(expected)==66 and all(sha((ROOT/n).read_bytes())==h for n,h in expected.items())
review=read('review-0.1.4/review-gate.json')
assert review['review_cases_passed']==review['review_cases_total']==12 and review['decision']=='No material runtime findings; offline source review passes'
assert all(review['runtime_hashes'][n]==h for n,h in result['runtime_hashes'].items())
independent=read('reports-0.1.4/fresh-review014.json')
assert independent['passed']==independent['total']==12 and independent['source_unchanged'] and independent['baseline_unchanged']
assert all(independent['source_hashes'][n]==h for n,h in result['runtime_hashes'].items())
verification="""# bjarkiLearn 0.1.4-shadow verification

663/663 current scenario/control executions passed across Lua 5.1 and Lua 5.4, plus 12/12 fresh independent whole-change review probes. All six runtime Lua modules loaded syntactically on both engines (12 checks). These are ordinary Lua tests with modeled WoW APIs, not live-client validation or evidence of predictive usefulness.

The aggregate includes 583 applicable preserved checks, 28 new projection/reset checks, 46 independently authored temporal/correction checks, and six observed-clock versions of older reset controls. Three unchanged old private-Core tests (six engine executions) asserted the repaired bug: a cast dated after the last observed clock became positive when resetting before its time. Their raw failures are retained and explicitly excluded, not counted as passing. The separate observed-clock controls preserve every original assertion while inserting the missing clock observation. New future-only controls verify censorship and correct candidate retention instead.

The repair uses time-specific projections of the same bounded registry. It keeps earlier eligible same-family casts and aura witnesses visible when a later record is in the future. Cached projections expire at the next relevant evidence time and cannot answer an earlier query. A cast becomes a positive outcome only once its full interval has matured on an observed Context/Tick/reset clock. Queries do not advance that clock. Early actor-capacity retirement retains the original horizon: later maturity revises the unsealed row and checks serving correction descriptors even after replay eviction. Corrections, retractions, retiming, actor/family reattribution, candidate withdrawal, history floors, rollback and normal native between-tick deliveries are covered.

The new projection/reset suite failed 22 of 28 checks on the frozen 0.1.3 baseline; the independent temporal suite failed 36 of 46. All pass on the final runtime. The other baseline checks are preservation controls. No source is modified by the tests.

Additional checks pass: 7,731 seed-constructor inputs from 2,577 distinct values, 28 invalid inputs, 22,136 prior import/registration boundary probes, 12 repeated complete native replay trajectories, eight original capacity reproduction runs, and eight cross-version/fresh-reload comparisons. The latter compare real Main/Adapter/Core callbacks with modeled host APIs against 0.1.3, excluding only version metadata. The independent review also compares an ordinary observed trajectory against 0.1.3 and stresses bounded correction histories against a separate ledger.

66 prior Lua/Python test, runner and support files remain byte-for-byte unchanged, including the exact baseline root runner and builder. The baseline 0.1.3 install archive and source extraction are preserved. Historical reports describe their original version; current results are under reports-0.1.4. The older 0.1.0 archive did not contain its advertised release harness, so no claim is made that unavailable tests were rerun.

The same 14-file install inventory, two TOCs, version metadata, load references, UTF-8 decoding, archive CRCs and every archived byte are checked. Runtime hashes must match the final aggregate and fresh review. The 16-actor, 128-occurrence, 256-example and 256-serving-descriptor limits remain. No new identity queue, timer, polling callback or dependency was added.

A far-future identity discarded at capacity can conservatively advance the existing replay-protection floor. This avoids giving forgotten identities renewed authority; bounded history does not promise unlimited reconstruction. Previously sealed/deidentified examples cannot be retroactively repaired from discarded raw evidence. The intended feature meanings, target and compatibility key are unchanged.

Reproduce from bjarkiLearn-0.1.4-shadow-verification.zip:

```sh
python -m pip install -r requirements-test.txt
python run_all.py
python build_release.py --output dist
```

Independent review found no remaining material finding in the repair scope. Live event delivery, taint/secret enforcement, native frame cost and predictive usefulness remain unverified in WoW. Shadow outputs retain usable=false. No installed addon or remote repository was modified.

## Runtime SHA-256

| File | SHA-256 |
| --- | --- |
"""
for name,h in sorted(result['runtime_hashes'].items()):verification+=f'| {name} | `{h}` |\n'
(SOURCE/'VERIFICATION.md').write_text(verification,encoding='utf-8',newline='\n')
files={p.relative_to(SOURCE).as_posix():p.read_bytes() for p in SOURCE.rglob('*') if p.is_file()}
base={p.relative_to(BASE).as_posix():p.read_bytes() for p in BASE.rglob('*') if p.is_file()}
assert set(files)==set(base) and len(files)==14
for name,data in files.items():assert '\ufffd' not in data.decode('utf-8'),name
original=ROOT/'baseline-0.1.3/bjarkiLearn-0.1.3-shadow.zip'
assert sha(original.read_bytes())=='2e5211b89922287f924c6775225aadf0fc2071df291129eb9a6b0d2d2913ee30'
with zipfile.ZipFile(original) as z:
 assert z.testzip() is None
 assert {i.filename:z.read(i.filename) for i in z.infolist() if not i.is_dir()}=={'bjarkiLearn/'+n:b for n,b in base.items()}
load_order=['Bootstrap.lua','Rules.lua','Network.lua','Core.lua','Adapter.lua','Main.lua']
for toc in ('bjarkiLearn.toc','bjarkiLearn_Camelot.toc'):
 text=files[toc].decode('utf-8');assert text.count('## Version: 0.1.4-shadow')==1 and '## Interface: 16001' in text
 assert '## SavedVariables: bjarkiLearnDB' in text
 refs=[line.strip() for line in text.splitlines() if line.strip() and not line.startswith('#')]
 assert refs==load_order and all(ref in files for ref in refs)
assert 'version = "0.1.4-shadow"' in files['Bootstrap.lua'].decode('utf-8')
assert {n:sha(files[n]) for n in load_order}==result['runtime_hashes']
for name in ('Network.lua','Adapter.lua','Main.lua'):assert files[name]==base[name]
changed=[n for n in files if files[n]!=base[n]]
patch=''.join(''.join(difflib.unified_diff(base[n].decode('utf-8').splitlines(True),files[n].decode('utf-8').splitlines(True),fromfile='0.1.3/'+n,tofile='0.1.4/'+n)) for n in sorted(changed))
(ROOT/'source-changes.patch').write_text(patch,encoding='utf-8',newline='\n')
def archive(path,entries):
 with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for name,data in sorted(entries.items()):
   info=zipfile.ZipInfo(name,(2026,10,23,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,data)
 with zipfile.ZipFile(path) as z:
  assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==len(entries)
  assert {n:z.read(n) for n in z.namelist()}==entries
 return {'file':path.name,'sha256':sha(path.read_bytes()),'bytes':path.stat().st_size,'files':len(entries),'crc_valid':True,'exact_bytes':True}
addon=archive(OUT/'bjarkiLearn-0.1.4-shadow.zip',{'bjarkiLearn/'+n:b for n,b in files.items()})
package={'addon':addon,'version':'0.1.4-shadow','input_sha256':sha(original.read_bytes()),'original_archive_and_extraction_unchanged':True,'same_14_file_inventory':True,'toc_references_and_versions_valid':True,'strict_utf8':True,'runtime_matches_final_test_run':True,'scenario_executions_passed':663,'superseded_original_engine_executions':6,'fresh_review_checks_passed':12,'seed_constructor_cases_passed':7731,'boundary_checks_passed':22136,'native_replay_trajectories_passed':12,'capacity_reproduction_runs_passed':8,'native_cross_version_and_reload_comparisons_passed':8,'syntax_checks_passed':12,'preserved_test_source_files':len(expected),'changed_files':sorted(changed),'inventory':{n:sha(b) for n,b in sorted(files.items())}}
dump(ROOT/'package.json',package)
selected={}
folders=('source','baseline','baseline-0.1.1','baseline-0.1.2','baseline-0.1.3','tests','tests-reset','tests-time','new-tests','review-main','review-core','review-network','review-adapter','review-integration','review-fresh','review-0.1.2','review-0.1.3','review-0.1.4','audit-controls','audit-0.1.2','audit-0.1.3','fixtures','reports','reports-0.1.2','reports-0.1.3','reports-0.1.4')
for folder in folders:
 for f in (ROOT/folder).rglob('*'):
  if f.is_file() and '__pycache__' not in f.parts and f.suffix!='.pyc':selected[f.relative_to(ROOT).as_posix()]=f.read_bytes()
for name in ('run_all.py','run_legacy.py','run_existing.py','run_audit_controls.py','build_release.py','requirements-test.txt','README-verification.txt','source-changes.patch','package.json','plan.txt','design.txt'):
 selected[name]=(ROOT/name).read_bytes()
bundle=archive(OUT/'bjarkiLearn-0.1.4-shadow-verification.zip',selected)
release={'passed':True,'addon':addon,'verification_bundle':bundle,'package':package};dump(OUT/'bjarkiLearn-0.1.4-shadow-release-checks.json',release)
print(json.dumps({'passed':True,'addon':addon,'verification_bundle':bundle,'changed_files':sorted(changed),'runtime_matches_final_test_run':True,'toc_versions_crc_inventory_and_bytes_valid':True},indent=2))
