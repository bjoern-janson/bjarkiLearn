# bjarkiLearn 0.1.4-shadow verification

663/663 current scenario/control executions passed across Lua 5.1 and Lua 5.4, plus 12/12 fresh independent whole-change review probes. All six runtime Lua modules loaded syntactically on both engines (12 checks). These are ordinary Lua tests with modeled WoW APIs, not live-client validation or evidence of predictive usefulness.

The aggregate includes 583 applicable preserved checks, 28 new projection/reset checks, 46 independently authored temporal/correction checks, and six observed-clock versions of older reset controls. Three unchanged old private-Core tests (six engine executions) asserted the repaired bug: a cast dated after the last observed clock became positive when resetting before its time. Their raw failures are retained and explicitly excluded, not counted as passing. The separate observed-clock controls preserve every original assertion while inserting the missing clock observation. New future-only controls verify censorship and correct candidate retention instead.

The repair uses time-specific projections of the same bounded registry. It keeps earlier eligible same-family casts and aura witnesses visible when a later record is in the future. Cached projections expire at the next relevant evidence time and cannot answer an earlier query. A cast becomes a positive outcome only once its full interval has matured on an observed Context/Tick/reset clock. Queries do not advance that clock. Early actor-capacity retirement retains the original horizon: later maturity revises the unsealed row and checks serving correction descriptors even after replay eviction. Corrections, retractions, retiming, actor/family reattribution, candidate withdrawal, history floors, rollback and normal native between-tick deliveries are covered.

The new projection/reset suite failed 22 of 28 checks on the frozen 0.1.3 baseline; the independent temporal suite failed 36 of 46. All pass on the final runtime. The other baseline checks are preservation controls. No source is modified by the tests.

Additional checks pass: 7,731 seed-constructor inputs from 2,577 distinct values, 28 invalid inputs, 22,136 prior import/registration boundary probes, 12 repeated complete native replay trajectories, eight original capacity reproduction runs, and eight cross-version/fresh-reload comparisons. The latter compare real Main/Adapter/Core callbacks with modeled host APIs against 0.1.3, excluding only version metadata. The independent review also compares an ordinary observed trajectory against 0.1.3 and stresses bounded correction histories against a separate ledger.

66 prior Lua/Python test, runner and support files remain byte-for-byte unchanged, including the exact baseline root runner and builder. The baseline 0.1.3 install archive and source extraction are preserved. Historical reports describe their original version; current results are under reports-0.1.4. The older 0.1.0 archive did not contain its advertised release harness, so no claim is made that unavailable tests were rerun.

The same 14-file install inventory, two TOCs, version metadata, load references, UTF-8 decoding, archive CRCs and every archived byte are checked. Runtime hashes must match the final aggregate and fresh review. The 16-actor, 128-occurrence, 256-example and 256-serving-descriptor limits remain. No new identity queue, timer, polling callback or dependency was added.

A far-future identity discarded at capacity can conservatively advance the existing replay-protection floor. This avoids giving forgotten identities renewed authority; bounded history does not promise unlimited reconstruction. Previously sealed/deidentified examples cannot be retroactively repaired from discarded raw evidence. The intended feature meanings, target and compatibility key are unchanged.

Reproduce from bjarkiLearn-0.1.4-shadow-verification.zip:

```sh
python -m pip install -r requirements-test.txt
python run_all.py
python build_release.py --output dist
```

Independent review found no remaining material finding in the repair scope. Live event delivery, taint/secret enforcement, native frame cost and predictive usefulness remain unverified in WoW. Shadow outputs retain usable=false. No installed addon or remote repository was modified.

## Runtime SHA-256

| File | SHA-256 |
| --- | --- |
| Adapter.lua | `8d202f577b5c0abce58e7655e56b37597ccb17f465233333952614370a614c88` |
| Bootstrap.lua | `68eea6fe6651c8e480d7d9f2ec45c7421cd048521a7b5d44ba4b3ae7b60988e6` |
| Core.lua | `9dc55ae29fd69e76448bd8c83e8386edbaa1bff00009dbd98dc8532678c4dc01` |
| Main.lua | `3d468590005b81484af4d548f54bf41d561165d3762c6142931e87df8596052e` |
| Network.lua | `49668680ce13803c329a816f76863b04bb752cb07e5d2759cf7076af05165c49` |
| Rules.lua | `4456d77323afc59c3946abd3b3037648b137004ff9d9036e892065e039ef602c` |
