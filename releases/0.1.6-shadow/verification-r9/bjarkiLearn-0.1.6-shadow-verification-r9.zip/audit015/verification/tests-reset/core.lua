local ns=...
local cases={}
local function case(name,fn)
 local ok,detail=pcall(fn);cases[#cases+1]={name=name,passed=ok,detail=ok and detail or nil,error=not ok and tostring(detail) or nil}
end
local function context(c,id,health,role,bound,t)
 assert(c:Context({actor=id,at=t or 10,role=role or 'hostile',class='PRIEST',combat=true,bound=bound~=false,health=health}))
end
local function sealed(w)
 assert(w.sealed and w.actor==nil and w.id==nil and w.coverage==nil and w.lost==nil,'sealed/deidentified')
end
case('simultaneous player then hostile flush preserves discovery order and labels',function()
 local c=ns.Core.New();c:SetCoverage(true)
 context(c,'Player-1-100',.2,'self');context(c,'Player-1-200',.8);c:Tick(10,true)
 assert(c:Cast({id='self-reset',actor='Player-1-100',at=11,family=1}))
 assert(c:Cast({id='other-reset',actor='Player-1-200',at=11,family=2}))
 c:ResetSession(11)
 assert(#c.examples==2 and c.examples[1].regime=='player' and c.examples[2].regime=='other','discovery order changed during reset')
 assert(c.examples[1].x[16]==.2 and c.examples[2].x[16]==.8,'feature snapshots remain in order')
 for n,w in ipairs(c.examples) do
  sealed(w);assert(w.y[n]==1 and w.mask[n],'positive survives reset')
  for i=1,6 do if i~=n then assert(not w.mask[i],'absence censored') end end
 end
end)
case('opposite discovery order is preserved without lexical or player preference',function()
 local c=ns.Core.New();c:SetCoverage(true)
 context(c,'Z-hostile',.8);context(c,'A-player',.2,'self');c:Tick(10,true);c:ResetSession(11)
 assert(#c.examples==2 and c.examples[1].regime=='other' and c.examples[2].regime=='player','reset must preserve actual ordered discovery')
 assert(c.examples[1].x[16]==.8 and c.examples[2].x[16]==.2)
end)
case('full actor capacity skips actors without pending windows',function()
 local c=ns.Core.New();c:SetCoverage(true)
 for n=1,16 do context(c,'Actor-'..(100-n),n/20,n==7 and 'self' or 'hostile',n~=3 and n~=11) end
 c:Tick(10,true);c:ResetSession(11)
 assert(#c.examples==14,'only pending windows resolved')
 local row=0
 for n=1,16 do if n~=3 and n~=11 then row=row+1;assert(c.examples[row].x[16]==n/20,'capacity actor order changed');sealed(c.examples[row]) end end
 assert(#c.actorOrder==0 and next(c.actors)==nil and #c.occurrenceOrder==0)
end)
case('discovery order remains valid after actor eviction and reset is idempotent',function()
 local c=ns.Core.New();c:SetCoverage(true)
 for n=1,17 do context(c,'Actor-'..n,n/20,'hostile',true,n) end
 for n=2,17 do context(c,'Actor-'..n,n/20,'hostile',true,20) end
 c:Tick(20,true);c:ResetSession(21)
 assert(#c.examples==16 and c.stats.actorEvictions==1,'exact retained actors flushed')
 for n,w in ipairs(c.examples) do assert(w.x[16]==(n+1)/20,'evicted actor leaked or remaining order changed');sealed(w) end
 local before=c:Export();local revision=c.corpusRevision;c:ResetSession(21)
 assert(#c.examples==#before.examples and c.corpusRevision==revision,'repeated empty reset duplicates no lesson')
end)
case('nonempty completed prefix stays before pending flush',function()
 local c=ns.Core.New();c:SetCoverage(true)
 context(c,'first',.1,'self');c:Tick(10,true);c:Tick(12.25,true)
 context(c,'first',.2,'self',true,13);context(c,'second',.8,'hostile',true,13);c:Tick(13,true)
 c:ResetSession(14)
 assert(#c.examples==3 and c.examples[1].x[16]==.1 and c.examples[2].x[16]==.2 and c.examples[3].x[16]==.8,'reset reordered completed corpus or pending lessons')
end)
case('capacity retirement keeps stable player support and trained result',function()
 local c=ns.Core.New();local saved={schema=ns.Config.schema,compat=ns.Config.compat,examples={}}
 local x=ns.Rules.Features({class='PRIEST',role='self',regime='player',combat=true,bound=true,history={}},0)
 for n=1,255 do local y,mask={},{};for i=1,6 do y[i]=0;mask[i]=true end;saved.examples[n]={x=x,y=y,mask=mask,regime='player'} end
 assert(c:Restore(saved));c:SetCoverage(true)
 context(c,'Player-1-100',nil,'self');context(c,'Player-1-200',nil);c:Tick(10,true)
 assert(c:Cast({id='self-reset',actor='Player-1-100',at=11,family=1}))
 assert(c:Cast({id='other-reset',actor='Player-1-200',at=11,family=2}))
 c:ResetSession(11)
 assert(#c.examples==256 and c.examples[255].regime=='player' and c.examples[256].regime=='other','reset tie order at capacity')
 for n=1,255 do
  local t=20+n*3;context(c,'Player-1-100',nil,'self',true,t);c:Tick(t,true)
  if n<=2 then assert(c:Cast({id='new-positive-'..n,actor='Player-1-100',at=t+1,family=1})) end
  c:Tick(t+2.25,true);assert(#c.examples<=256 and #c.occurrenceOrder<=128 and #c.actorOrder<=16)
 end
 for n=1,260 do c:Tick(1000,false) end
 local s=c:Status()
 assert(c.model and not c.candidate and not c.dirty,'replacement completed')
 assert(s.trainingExamples==255 and s.families[1].positive==2 and s.families[1].negative==253,'retirement changes selected player support')
 assert(c.modelExamples==255 and c.model.totals[1]==255 and c.model.positives[1]==2)
 return {score=c.model:Predict(x).neural[1],modelExamples=c.modelExamples,positive=s.families[1].positive,negative=s.families[1].negative}
end)
return cases
