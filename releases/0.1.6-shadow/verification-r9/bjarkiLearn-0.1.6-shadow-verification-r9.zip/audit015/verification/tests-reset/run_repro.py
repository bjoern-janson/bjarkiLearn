"""Repeat the preserved audit traces with fresh interpreters, same source, and exact equality."""
from pathlib import Path
import argparse, ast, hashlib, importlib, json, sys
try: import lupa
except ImportError: sys.path.insert(0, 'C:/Users/Mewn/Documents/Codex/2026-10-16/let/work/deps')
p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--output',type=Path,required=True);args=p.parse_args()
ROOT=Path(__file__).resolve().parents[1]
source=args.source.resolve()
hashes=lambda:{f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in source.glob('*.lua')}
before=hashes()
# Reuse only pure helper functions from the unchanged prior audit runner.
prior=ROOT/'audit-0.1.2/integration/run.py'
tree=ast.parse(prior.read_text(encoding='utf-8'))
functions=ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef)],type_ignores=[])
env={'importlib':importlib,'root':prior.parent,'harness':(ROOT/'review-integration/harness.lua').read_text(encoding='utf-8')}
exec(compile(functions,str(prior),'exec'),env)
results=[]
for scenario in ('continuous','lifecycle'):
 reference=None
 for engine in ('lua51','lua54'):
  for repeat in range(3):
   current=env['run'](engine,source,scenario)
   if reference is None: reference=current
   diff=env['first_difference'](reference,current)
   results.append({'trace':scenario,'engine':engine,'repeat':repeat,'passed':diff is None,'first_difference':diff,'steps':current['steps'],'checkpoints':len(current['snapshots']),'checks':current['checks']})
   print(scenario,engine,repeat,'PASS' if diff is None else diff,flush=True)
capacity=[]
for engine in ('lua51','lua54'):
 for repeat in range(4):
  lua=importlib.import_module('lupa.'+engine).LuaRuntime(unpack_returned_tuples=True);ns=lua.table()
  for name in ('Bootstrap.lua','Rules.lua','Network.lua','Core.lua'):
   lua.execute((source/name).read_text(encoding='utf-8'),'bjarkiLearn',ns)
  row=dict(lua.execute((ROOT/'audit-0.1.2/core/reset_order.lua').read_text(encoding='utf-8'),ns).items())
  expected={'order':'player,other','trainingExamples':255,'modelExamples':255,'positive':2,'negative':253,'remainingOldRegime':'other'}
  passed=all(row.get(k)==v for k,v in expected.items()) and (not capacity or row==capacity[0]['observed'])
  capacity.append({'engine':engine,'repeat':repeat,'passed':passed,'observed':row})
  print('capacity',engine,repeat,'PASS' if passed else row,flush=True)
report={'passed':all(r['passed'] for r in results+capacity),'source_hashes':before,'source_unchanged':before==hashes(),'native_trace_runs':len(results),'native_trace_runs_passed':sum(r['passed'] for r in results),'capacity_runs':len(capacity),'capacity_runs_passed':sum(r['passed'] for r in capacity),'native_traces':results,'capacity_traces':capacity,'comparison':'Full checkpoints, status, exports, model state and public diagnostics; only version fields excluded by the preserved trace helper. Fresh Lua runtimes and identical ordered inputs. Capacity comparison includes exact score across both engines.'}
assert report['source_unchanged']
args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
sys.exit(0 if report['passed'] else 1)
