-- Real frame callbacks; actual Main, Adapter and Core. No core/reset mock.
function Begin()
 World.ids.player=IDS[1];World.ids.target=IDS[2];World.ids.focus=IDS[3];World.classes.focus='MAGE'
 Init();Advance(10);Equal(#Runtime.core.actorOrder,3)
 for i=1,3 do Equal(Runtime.core.actorOrder[i],IDS[i],'native discovery order') end
 Equal(Runtime.core:Status().pending,3)
end
POS={}
function Cast(unit,spell,family,id,at)
 World.now=at;local actor=World.ids[unit];Event('UNIT_SPELLCAST_SUCCEEDED',unit,id,spell)
 POS[actor]=POS[actor] or {};POS[actor][family]=true
end
function Positives(at)
 Cast('player',22812,6,'native-player-'..at,at)
 Cast('target',1766,5,'native-target-'..at,at)
 Cast('focus',122,3,'native-focus-'..at,at)
end
function Pending()
 local out={}
 for _,id in ipairs(Runtime.core.actorOrder) do local w=Runtime.core.actors[id].window
  if w then out[#out+1]={x=NS.Copy(w.x),regime=w.regime,actor=id,anchor=w.anchor,deadline=w.deadline} end
 end
 return out
end
function Same(a,b,path)
 path=path or 'row'
 if type(a)~='table' or type(b)~='table' then Equal(a,b,path);return end
 for k,v in pairs(a) do Same(v,b[k],path..'.'..tostring(k)) end
 for k in pairs(b) do Check(a[k]~=nil,path..' unexpected key '..tostring(k)) end
end
function VerifyFlush(expected,before)
 local core=Runtime.core;Equal(#core.examples,before+#expected,'one row per pending window')
 for i,w in ipairs(expected) do local row=core.examples[before+i]
  Same(row.x,w.x,'flush row '..i..' actor '..w.actor..' features');Equal(row.regime,w.regime)
  Equal(row.anchor,w.anchor);Equal(row.deadline,w.deadline)
  for family=1,6 do local positive=POS[w.actor] and POS[w.actor][family] or false
   Equal(row.y[family],positive and 1 or 0,'positive preserved '..i..'/'..family)
   Equal(row.mask[family],positive,'absence censored '..i..'/'..family)
  end
  Check(row.sealed);Equal(row.actor,nil);Equal(row.id,nil);Equal(row.coverage,nil);Equal(row.lost,nil)
 end
 for _,row in ipairs(core.examples) do Check(row.sealed);Equal(row.actor,nil);Equal(row.id,nil) end
 Equal(core:Status().pending,0);Equal(#core.occurrenceOrder,0);Equal(#core.modelDependencies,0)
 Check(not Runtime.faulted,'native handler did not fault')
 local saved=core:Export();Equal(#saved.examples,#core.examples)
 for i,row in ipairs(saved.examples) do
  Same(row.x,core.examples[i].x);Same(row.y,core.examples[i].y);Same(row.mask,core.examples[i].mask)
  Equal(row.actor,nil);Equal(row.id,nil)
 end
 Check(#core.actorOrder<=NS.Config.maxActors);Check(#core.examples<=NS.Config.maxExamples)
 Check(#core.occurrenceOrder<=NS.Config.maxOccurrences)
end
SCENARIOS={
 world=function()
  Begin();Positives(10.1);local expected=Pending();local session=Runtime.core.session
  World.now=10.2;Event('PLAYER_ENTERING_WORLD');Equal(Runtime.core.session,session+1);VerifyFlush(expected,0)
  for i=1,3 do Equal(Runtime.core.actorOrder[i],IDS[i],'world refresh order') end
  Check(Runtime.adapter.coverage);Check(Runtime.core.coverage)
 end,
 disable_enable=function()
  Begin();Positives(10.1);local expected=Pending();local adapter=Runtime.adapter
  World.now=10.2;Runtime:Command('disable');VerifyFlush(expected,0)
  Check(adapter.stopped);Equal(Runtime.adapter,nil);Check(not Runtime.enabled)
  Equal(#Runtime.core.actorOrder,0);Check(not Runtime.core.coverage)
  Same(bjarkiLearnDB.learning,Runtime.core:Export(),'disable saved rows')
  Runtime:Command('enable');Check(Runtime.enabled);Check(Runtime.adapter~=adapter)
  for i=1,3 do Equal(Runtime.core.actorOrder[i],IDS[i],'enable discovery order') end
  Check(Runtime.adapter.coverage);Check(Runtime.core.coverage)
  Equal(#Runtime.core.examples,3);Equal(Runtime.core:Status().pending,0)
 end,
 clock_rewind=function()
  Begin();Positives(10.1);local expected=Pending();local session=Runtime.core.session
  Advance(9);Equal(Runtime.core.session,session+1);VerifyFlush(expected,0);Equal(#Runtime.core.actorOrder,0)
  Advance(9.25)
  for i=1,3 do Equal(Runtime.core.actorOrder[i],IDS[i],'rewind recovery discovery order') end
  Check(BjarkiLearn:GetContext('player').fresh);Check(Runtime.adapter.coverage)
 end,
 target_rebinding=function()
  Begin();Positives(10.1);World.now=10.25;World.ids.target=IDS[4]
  Event('PLAYER_TARGET_CHANGED');Advance(10.5)
  Equal(#Runtime.core.actorOrder,4);Equal(Runtime.core.actorOrder[4],IDS[4]);Check(not Runtime.core.actors[IDS[2]].bound)
  Cast('target',853,2,'native-rebound',10.6);local expected=Pending();Equal(#expected,4)
  World.now=10.7;Event('PLAYER_ENTERING_WORLD');VerifyFlush(expected,0)
  Equal(Runtime.core.actorOrder[1],IDS[1]);Equal(Runtime.core.actorOrder[2],IDS[4]);Equal(Runtime.core.actorOrder[3],IDS[3])
 end,
 alias_rebinding=function()
  World.ids.player=IDS[1];World.ids.target=IDS[1];World.ids.focus=IDS[3];World.classes.focus='MAGE'
  Init();Advance(10);Equal(#Runtime.core.actorOrder,2)
  Equal(Runtime.core.actorOrder[1],IDS[1]);Equal(Runtime.core.actorOrder[2],IDS[3])
  Cast('player',22812,6,'native-alias',10.1);Cast('target',22812,6,'native-alias',10.1)
  Equal(Runtime.core.stats.casts,1);Equal(Runtime.core.stats.duplicateCasts,1)
  World.ids.target=IDS[2];World.now=10.25;Event('PLAYER_TARGET_CHANGED');Advance(10.5)
  Equal(#Runtime.core.actorOrder,3);Equal(Runtime.core.actorOrder[3],IDS[2])
  Cast('target',1766,5,'native-alias-new-target',10.6);Cast('focus',122,3,'native-alias-focus',10.6)
  local expected=Pending();World.now=10.7;Event('PLAYER_ENTERING_WORLD');VerifyFlush(expected,0)
 end,
 candidate_cancellation=function()
  Begin();Positives(10.1)
  for i=1,9 do Advance(10+i*.25) end
  Equal(#Runtime.core.examples,3);Equal(Runtime.core:Status().pending,3);Positives(12.3)
  for i=1,8 do Advance(12.25+i*.25) end
  World.combat=false;World.unitCombat=false;Advance(14.5)
  Equal(#Runtime.core.examples,6);Equal(Runtime.core:Status().pending,0)
  Check(Runtime.core.candidate~=nil,'real native replay candidate in flight');Equal(Runtime.core:Status().trainingSteps,4)
  World.combat=true;World.unitCombat=true;Advance(14.75);Positives(14.8)
  local expected=Pending();Equal(#expected,3);Check(Runtime.core.candidate~=nil)
  World.now=14.9;Event('PLAYER_ENTERING_WORLD');VerifyFlush(expected,6)
  Equal(Runtime.core.candidate,nil,'new positive player row cancels replay candidate');Check(Runtime.core.dirty)
 end,
 repeated_lifecycle=function()
  Begin()
  for cycle=1,12 do
   if cycle>1 then Advance(10+cycle) end
   Positives(World.now+.1);local expected=Pending();Equal(#expected,3);local before=#Runtime.core.examples
   World.now=World.now+.1
   if cycle%2==0 then Runtime:Command('disable');VerifyFlush(expected,before);Runtime:Command('enable')
   else Event('PLAYER_ENTERING_WORLD');VerifyFlush(expected,before) end
  end
  Equal(#Runtime.core.examples,36);Check(not Runtime.faulted)
 end,
}
