# Native reset-order regression probes

The runner loads actual Bootstrap, Rules, Network, Core, Adapter, and Main Lua files. The host API harness is an unchanged byte-for-byte copy of `audit-0.1.2/native/harness.lua` (SHA256 `eea3c874f05d4deadc512f5f85301ad637d909df07c5c085d6ea5d4db3ba914d`). No production functions or core/reset implementations are mocked. Native events and updates enter the real registered frame callbacks.

Seven histories run against six different sets of real GUID strings, each in fresh Lua 5.1 and Lua 5.4 runtimes (84 scenarios):

- `PLAYER_ENTERING_WORLD` flushes three pending actors in player/target/focus discovery order and restores readable bindings and coverage.
- Disable seals and saves pending windows; enable creates a fresh adapter and preserves retained rows in the same order.
- Clock rewind flushes through actual `Main.Update -> Core.Tick -> ResetSession`, then restores fresh bindings on the next adapter refresh. This is a robustness control, not an established native trigger.
- Target rebinding preserves the old unbound actor's pending window and appends the newly discovered actor in the expected order.
- Player/target aliases deduplicate one cast, and subsequent target rebinding preserves actual distinct-actor discovery order.
- A real replay candidate created by normal configured training work is cancelled when reset appends a positive player row; old and new retained examples are sealed.
- Twelve alternating world/disable-enable lifecycle transitions retain all 36 expected examples, with ordinary configured actor, occurrence, and example bounds checked after each flush.

Pending row identities and features are captured before the transition using actual `actorOrder`. Each resulting row is checked against that expected order, features, regime, anchor, and deadline. Readable native positives survive; all unobserved families are censored on partial resets. Every sealed example loses actor/window identity, coverage, and lost-evidence metadata. Occurrences and model dependencies clear. The actual full retained `Core:Export()` is hashed, and the same history must yield the same export across GUID variants and both runtime versions. The parent core suite separately covers exact capacity-boundary retention.

Final recorded results:

| Source | Pass | Fail | Source unchanged |
| --- | ---: | ---: | --- |
| Frozen 0.1.2 | 8/84 | 76 | yes |
| Current repair | 84/84 | 0 | yes |

Current repair completed 472,884 assertions. Baseline failures are row feature/order or row anchor/order assertions. Native hash traversal is deliberately uncontrolled; the exact number of baseline failures may vary between new processes. Baseline is required to demonstrate failure overall, not a particular hash-table permutation. No expectation was changed between recorded RED and GREEN runs.

From the build directory:

```powershell
& 'C:/Users/Mewn/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe' tests-reset/native/run.py --source baseline-0.1.2/source/bjarkiLearn --output tests-reset/native/baseline-0.1.2.json
& 'C:/Users/Mewn/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe' tests-reset/native/run.py --source source/bjarkiLearn --output tests-reset/native/current.json
```

`--lupa-path` can supply a directory containing compatible `lupa.lua51` and `lupa.lua54` modules. Both engines are required; neither is silently skipped. Reports include production Lua hashes, test fixture hashes, per-history export hashes, GUID sets, assertions, and full failure text. The runner writes only its requested report; source hashes must remain unchanged.

Claim ceiling: actual addon Lua executed with modeled WoW host APIs. This is offline evidence of deterministic reset behavior and lifecycle routing; it is not a live WoW test.
