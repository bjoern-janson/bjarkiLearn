"""Reset-order tests using actual Main/Adapter/Core and modeled WoW APIs."""
import argparse
import hashlib
import importlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--source', required=True, type=Path)
p.add_argument('--output', required=True, type=Path)
p.add_argument('--lupa-path', action='append', default=[])
a = p.parse_args()
for path in a.lupa_path + ['C:/Users/Mewn/Documents/Codex/2026-10-16/let/work/deps']:
    sys.path.insert(0, path)
source = a.source.resolve()
def hashes():
    return {f.name: hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(source.glob('*.lua'))}
before = hashes()
host = (ROOT / 'harness.lua').read_text(encoding='utf-8-sig')
scenarios = (ROOT / 'scenarios.lua').read_text(encoding='utf-8-sig')
names = ('world', 'disable_enable', 'clock_rewind', 'target_rebinding', 'alias_rebinding', 'candidate_cancellation', 'repeated_lifecycle')
# Fresh native Lua runtimes and varied real string GUID keys test the same
# delivered histories without pretending native hash traversal is portable.
variants = [
    ['Player-1-100', 'Player-1-200', 'Player-1-300', 'Player-1-400'],
    ['Player-9-z', 'Player-9-a', 'Player-9-q', 'Player-9-b'],
    ['Player-123-00987654', 'Player-123-00000001', 'Player-456-12345678', 'Player-1-99999999'],
    ['Player-a-001', 'Player-b-002', 'Player-c-003', 'Player-d-004'],
    ['Player-7-baaaaaaa', 'Player-7-cbbbbbbb', 'Player-7-dccccccc', 'Player-7-eddddddd'],
    ['Player-3-12121212', 'Player-3-56565656', 'Player-3-34343434', 'Player-3-78787878'],
]
def ordinary(value):
    if not hasattr(value, 'items'):
        return value
    items = dict(value.items())
    if items and set(items) == set(range(1, len(items) + 1)):
        return [ordinary(items[i]) for i in range(1, len(items) + 1)]
    return {str(k): ordinary(v) for k, v in items.items()}

results = []
exports = {}
for engine in ('lua51', 'lua54'):
    LuaRuntime = importlib.import_module('lupa.' + engine).LuaRuntime
    for name in names:
        for variant, ids in enumerate(variants):
            lua = LuaRuntime(unpack_returned_tuples=True)
            lua.globals().LEARN_ROOT = source.as_posix()
            lua.globals().IDS = lua.table_from(ids)
            error = None
            export_sha256 = None
            try:
                lua.execute(host)
                lua.execute(scenarios)
                lua.globals().SCENARIOS[name]()
                actual = ordinary(lua.eval('Runtime.core:Export()'))
                encoded = json.dumps(actual, sort_keys=True, separators=(',', ':')).encode('utf-8')
                export_sha256 = hashlib.sha256(encoded).hexdigest()
                if name in exports and exports[name] != export_sha256:
                    raise AssertionError('same native input history produced different retained export')
                exports[name] = export_sha256
            except Exception as exc:
                error = str(exc)
            results.append(dict(engine=engine, case=name, guid_variant=variant,
                                passed=error is None, checks=lua.globals().CHECKS or 0, export_sha256=export_sha256, error=error))
report = dict(source=str(source), source_hashes=before, source_unchanged=hashes() == before,
              fixture_hashes={f.name: hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(ROOT.glob('*')) if f.is_file() and f.suffix in ('.lua', '.py')},
              guid_variants=variants, same_history_export_sha256=exports, cases=results,
              summary=dict(passed=sum(r['passed'] for r in results), total=len(results), checks=sum(r['checks'] for r in results)),
              claim_ceiling='Actual addon modules through real frame handlers with modeled WoW APIs; no live WoW execution. Clock rewind is a robustness control, not an established native trigger.')
a.output.resolve().parent.mkdir(parents=True, exist_ok=True)
a.output.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(summary=report['summary'], source_unchanged=report['source_unchanged'], failures=[dict(engine=r['engine'], case=r['case'], guid_variant=r['guid_variant'], error=r['error']) for r in results if not r['passed']]), indent=2))
sys.exit(0 if report['source_unchanged'] and all(r['passed'] for r in results) else 1)
