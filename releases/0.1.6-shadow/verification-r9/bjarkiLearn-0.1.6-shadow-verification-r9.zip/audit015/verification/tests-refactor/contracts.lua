local ns=...
local cases={}
local function test(name,fn)
 local ok,err=pcall(fn);cases[#cases+1]={name=name,passed=ok,error=not ok and tostring(err) or nil}
end
local function context(c,id,at)
 return assert(c:Context({actor=id,at=at,role="self",class="DRUID",combat=true,bound=true,health=.8,power=.5}))
end
local function cast(c,id,actor,at,revision)
 return c:Cast({id=id,actor=actor,at=at,family=1,revision=revision})
end
test("single evidence authority with time-aware public projections",function()
 local c=ns.Core.New();context(c,"P",10)
 assert(cast(c,"past","P",9));assert(cast(c,"future","P",11))
 assert(c:Aura({id="def",recipient="P",at=9,spellID=22812,expires=15}))
 assert(c:GetContext("P",10).history[1]==9)
 assert(c:GetContext("P",11).history[1]==11)
 assert(c:GetContext("P",10).defensiveWitness.spellID==22812)
 local view=c:GetContext("P",10);view.history[1]=0;view.defensiveWitness.expires=0
 assert(c:GetContext("P",10).history[1]==9 and c:GetContext("P",10).defensiveWitness.expires==15)
 assert(rawget(c.actors.P,"history")==nil and rawget(c.actors.P,"defensiveWitness")==nil,"redundant actor evidence mirrors remain")
end)
test("write invalidation does not rebuild an unused projection",function()
 local c=ns.Core.New();local project=c._Evidence
 c._Evidence=function() error("write path rebuilt an unused projection") end
 context(c,"P",10);context(c,"Q",10)
 assert(cast(c,"one","P",9));assert(cast(c,"one","Q",9,2))
 assert(c:Aura({id="def",recipient="P",at=9,spellID=22812,expires=15}))
 for i=1,130 do assert(c:Aura({id="cap"..i,recipient="P",at=10+i,spellID=22812})) end
 assert(#c.occurrenceOrder==128)
 c._Evidence=project;assert(c:GetContext("P",140).defensiveWitness.at==140)
end)
test("revision and forecast invalidation survives both sides of reattribution",function()
 local c=ns.Core.New();local p=context(c,"P",10);local q=context(c,"Q",10)
 local pr,qr=p.revision,q.revision;p.forecast={sentinel=true};q.forecast={sentinel=true}
 assert(cast(c,"one","P",9));assert(p.revision==pr+1 and not p.forecast)
 assert(q.revision==qr and q.forecast)
 p.forecast={sentinel=true};pr=p.revision
 assert(cast(c,"one","Q",9,2));assert(p.revision==pr+1 and q.revision==qr+1 and not p.forecast and not q.forecast)
 pr=p.revision;p.forecast={sentinel=true}
 assert(c:Aura({id="def",recipient="P",at=9,spellID=22812,expires=15}))
 assert(p.revision==pr+1 and not p.forecast)
 pr=p.revision;p.forecast={sentinel=true}
 assert(not c:Aura({id="def",recipient="P",at=9,spellID=22812,expires=15}))
 assert(p.revision==pr and p.forecast)
end)
test("standalone Rules.Features evidence fallback remains supported",function()
 local a={class="DRUID",role="self",regime="player",combat=true,bound=true,at=10,health=.5,power=.7,history={[1]=9},defensiveWitness={at=9,expires=15,spellID=22812}}
 local x=ns.Rules.Features(a,10);local y=ns.Rules.Features(a,10,{history=a.history,defensiveWitness=a.defensiveWitness})
 for i=1,48 do assert(x[i]==y[i]) end
end)
return cases
