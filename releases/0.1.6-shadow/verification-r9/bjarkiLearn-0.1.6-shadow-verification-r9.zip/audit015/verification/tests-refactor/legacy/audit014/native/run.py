"""Read-only released-module native/lifecycle audit; all probes live beside this runner."""
import argparse
import hashlib
import importlib
import json
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--source',required=True,type=Path)
p.add_argument('--output',required=True,type=Path)
p.add_argument('--bus',type=Path,default=ROOT.parents[1]/'verification/fixtures/SharedEvidence.lua')
p.add_argument('--lupa-path',action='append',default=[])
a=p.parse_args()
for item in a.lupa_path+['C:/Users/Mewn/Documents/Codex/2026-10-16/let/work/deps']:sys.path.insert(0,item)
source=a.source.resolve()
def hashes(path):
 return {p.relative_to(path).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(path.rglob('*')) if p.is_file()}
before=hashes(source)
fixture_before=hashlib.sha256(a.bus.read_bytes()).hexdigest()
results=[]
probe=(ROOT/'probes.lua').read_text(encoding='utf-8-sig')
harness=(ROOT/'harness.lua').read_text(encoding='utf-8-sig')
for engine in ('lua51','lua54'):
 Lua=importlib.import_module('lupa.'+engine).LuaRuntime
 discovery=Lua(unpack_returned_tuples=True);discovery.execute(probe)
 for name in sorted(discovery.globals().CASES.keys()):
  lua=Lua(unpack_returned_tuples=True)
  lua.globals().LEARN_ROOT=source.as_posix();lua.globals().BUS_PATH=a.bus.resolve().as_posix()
  error=None
  try:
   lua.execute(probe);case=lua.globals().CASES[name]
   if case['setup']:lua.execute(case['setup'])
   lua.execute(harness);lua.execute(case['run'])
  except Exception as exc:error=str(exc)
  results.append(dict(engine=engine,case=name,passed=error is None,checks=lua.globals().CHECKS or 0,error=error,detail=lua.globals().DETAIL))
after=hashes(source)
out=dict(source=str(source),bus=str(a.bus.resolve()),source_hashes_before=before,source_hashes_after=after,source_unchanged=before==after,fixture_sha256=fixture_before,fixture_unchanged=fixture_before==hashlib.sha256(a.bus.read_bytes()).hexdigest(),summary=dict(passed=sum(r['passed'] for r in results),total=len(results),checks=sum(r['checks'] for r in results)),cases=results,claim_ceiling='Actual released Main/Adapter/Bootstrap/Rules/Core/Network and actual unchanged SharedEvidence fixture under Lua 5.1/5.4. Host APIs, registration responses and event timing are modeled. Callback faults are explicitly injected private seams, not demonstrated native defects. No live WoW, secret-value enforcement, timing/profiling, actual payload, or predictive-utility proof.')
a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(summary=out['summary'],source_unchanged=out['source_unchanged'],fixture_unchanged=out['fixture_unchanged'],failures=[r for r in results if not r['passed']]),indent=2))
sys.exit(0 if out['source_unchanged'] and out['fixture_unchanged'] and all(r['passed'] for r in results) else 1)
