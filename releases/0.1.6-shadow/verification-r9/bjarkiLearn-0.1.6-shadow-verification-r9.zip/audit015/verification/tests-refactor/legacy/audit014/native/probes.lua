CASES={}
CASES['native cast observes context between scheduled ticks for all three units']={run=[=[
 Init();Advance(10)
 for i,u in ipairs({'player','target','focus'}) do
  local t=10+i*.04;AtCast(t,u,'native-'..u,22812)
  local a=Runtime.core.actors[World.ids[u]]
  Equal(a.at,t);Equal(Runtime.core.now,10)
  if Runtime.core.evidenceTime then Equal(Runtime.core.evidenceTime,t) end
  Equal(Runtime.core.occurrences['cast:native-'..u].at,t)
  Equal(BjarkiLearn:GetContext(u).history[6],t)
 end
 World.now=10.13;Event('PLAYER_ENTERING_WORLD')
 Equal(#Runtime.core.examples,3)
 for _,w in ipairs(Runtime.core.examples) do
  Equal(w.y[6],1);Equal(w.mask[6],true);Check(w.sealed)
  for i=1,5 do Equal(w.mask[i],false) end
 end
 DETAIL='All events used the real registered frame handler; reset immediately after events proves between-tick positives were observed.'
]=]}
CASES['aliased cast deliveries deduplicate and preserve player regime before a poll']={run=[=[
 Init();Advance(10)
 World.ids.target=World.ids.player;World.ids.focus=World.ids.player
 AtCast(10.1,'target','same-cast',22812)
 Equal(BjarkiLearn:GetContext('target').regime,'player')
 AtCast(10.11,'focus','same-cast',22812)
 AtCast(10.12,'player','same-cast',22812)
 Equal(Runtime.adapter.stats.casts,3);Equal(Runtime.core.stats.casts,1)
 Equal(Runtime.core.stats.duplicateCasts,2)
 World.now=10.13;Event('PLAYER_ENTERING_WORLD')
 local w=PlayerExample();Equal(w.y[6],1);Equal(w.mask[6],true)
 Check(math.abs(w.lead[6]-.1)<1e-12)
]=]}
CASES['known and unknown cast fields have distinct coverage consequences']={run=[=[
 Init();Advance(10)
 AtCast(10.1,'player',Opaque,999999)
 Equal(Runtime.adapter.stats.unknownSpells,1);Equal(Runtime.adapter.stats.rejected,0)
 AtCast(10.2,'player',Opaque,22812)
 Equal(Runtime.adapter.stats.rejected,1)
 Finish(10)
 local w=PlayerExample();for i=1,6 do Equal(w.mask[i],false);Equal(w.y[i],0) end
 Check(not Runtime.faulted)
]=]}
CASES['future bus publication preserves earlier eligible witness and bounds cache']={run=[=[
 LoadBus();Init();Advance(10)
 Check(Publish(100,10));Check(Publish(101,11))
 Equal(Runtime.core.stats.casts,nil)
 World.now=10.1
 local c=BjarkiLearn:GetContext('target');Equal(c.defensiveWitness.at,10)
 if Runtime.core.evidenceTime then Equal(Runtime.core.evidenceTime,10) end
 Advance(10.25)
 local f=BjarkiLearn:Forecast('target');Equal(f.expires,11)
 World.now=11;Equal(BjarkiLearn:Forecast('target').reason,'expired')
 Equal(BjarkiLearn:GetContext('target').defensiveWitness.at,11)
 Advance(10.5);Advance(10.75);Advance(11)
 Equal(BjarkiLearn:GetContext('target').defensiveWitness.at,11)
 Equal(Runtime.core.stats.casts,nil)
 DETAIL='Uses actual Bus:Publish validation/delivery. Future payload accepted by protocol; actual Portraits generation of future observedAt is not established.'
]=]}
CASES['future bus replay differs from direct publication at same timestamp']={run=[=[
 LoadBus();Check(Publish(100,11));Init();Advance(10)
 Equal(Runtime.adapter.stats.auras,0);Equal(Runtime.core.stats.auraWitnesses,nil)
 Check(Publish(101,11));Equal(Runtime.adapter.stats.auras,1)
 Equal(BjarkiLearn:GetContext('target').defensiveWitness,nil)
 World.now=10.5;Event('PLAYER_ENTERING_WORLD')
 Equal(Runtime.adapter.stats.auras,1);Equal(BjarkiLearn:GetContext('target').defensiveWitness,nil)
 World.now=11;Event('PLAYER_ENTERING_WORLD')
 Equal(Runtime.adapter.stats.auras,3);Equal(BjarkiLearn:GetContext('target').defensiveWitness.at,11)
 Equal(Runtime.core.stats.casts,nil)
]=]}
CASES['future untracked aura never advances watermark or acquires cast authority']={run=[=[
 LoadBus();Init();Advance(10)
 local before=Runtime.core.evidenceTime;local revision=Runtime.core.corpusRevision
 Check(Publish(101,9999,'Player-1-999'))
 Equal(Runtime.core.evidenceTime,before);Equal(Runtime.core.corpusRevision,revision)
 Equal(Runtime.core.actors['Player-1-999'],nil)
 Equal(BjarkiLearn:GetContext('Player-1-999'),nil)
 World.now=9999;Equal(BjarkiLearn:GetContext('target').defensiveWitness,nil)
 Equal(Runtime.core.evidenceTime,before)
 World.now=10.1;Event('PLAYER_ENTERING_WORLD')
 for _,w in ipairs(Runtime.core.examples) do for i=1,6 do Equal(w.y[i],0);Equal(w.mask[i],false) end end
 Equal(Runtime.core.stats.casts,nil)
]=]}
CASES['bus malformed inaccessible and secret fields never become evidence']={run=[=[
 LoadBus();Init();Advance(10)
 local raw=Aura(100,10)
 local names={'recipientGUID','spellId','observedAt','source','kind','isHelpful'}
 for _,key in ipairs(names) do
  local record=NS.Copy(raw);record[key]=Opaque;Check(not BjarkiEvidenceV1:Publish(record))
 end
 local rec=NS.Copy(raw);rec.auraInstanceID=Opaque;Check(BjarkiEvidenceV1:Publish(rec))
 Equal(Runtime.core.stats.auraWitnesses,nil);Equal(Runtime.adapter.stats.rejected,1)
 local raising=setmetatable({}, {__index=function() error('modeled unreadable field') end})
 Check(not BjarkiEvidenceV1:Publish(raising));Check(not Runtime.faulted)
 Check(Publish(101,10));Equal(Runtime.core.stats.auraWitnesses,1)
]=]}
CASES['world reset after clock rollback keeps observed positive and clears old identity']={run=[=[
 LoadBus();Init();Advance(10);AtCast(10.2,'player','observed-before-rollback',22812)
 Check(Publish(100,11))
 World.now=5;Event('PLAYER_ENTERING_WORLD')
 local w=PlayerExample();Equal(w.y[6],1);Equal(w.mask[6],true);Check(w.sealed)
 for i=1,5 do Equal(w.mask[i],false) end
 Equal(w.actor,nil);Equal(w.id,nil)
 Equal(Runtime.core.now,5)
 if Runtime.core.evidenceTime then Equal(Runtime.core.evidenceTime,5);Equal(Runtime.core.nextCastAt,nil) end
 Equal(Runtime.core.occurrences['cast:observed-before-rollback'],nil)
 Equal(BjarkiLearn:GetContext('target').defensiveWitness,nil)
 AtCast(5.1,'player','post-rollback',22812);Advance(5.25)
 Equal(BjarkiLearn:GetContext('player').history[6],5.1)
 Check(not Runtime.faulted)
]=]}
CASES['clock rollback detected by update seals existing windows and recovers bindings']={run=[=[
 Init();Advance(10);AtCast(10.2,'player','rollback-update',22812)
 Advance(5)
 local w=PlayerExample();Equal(w.y[6],1);Equal(w.mask[6],true);Check(w.sealed)
 Equal(BjarkiLearn:GetContext('player'),nil)
 Advance(5.25);Check(BjarkiLearn:GetContext('player').fresh)
 Equal(BjarkiLearn:GetContext('player').history[6],nil)
 AtCast(5.3,'player','new-time',22812)
 Equal(BjarkiLearn:GetContext('player').history[6],5.3)
 Equal(Runtime.core.gapReasons['scheduler-gap'],1)
 DETAIL='The core clears actors during rollback Tick after Adapter.Tick; public context recovers at the next 0.25-second refresh. Existing behavior, not a new temporal regression.'
]=]}
CASES['disable and enable with unreadable clock cannot restore absence coverage']={run=[=[
 LoadBus();Init();Advance(10);AtCast(10.2,'player','before-clock-loss',22812)
 World.now=Opaque;SlashCmdList.BJARKILEARN('disable')
 Equal(Runtime.enabled,false);Equal(BjarkiLearn:GetContext('player'),nil);Equal(BjarkiEvidenceV1:Status().listeners,0)
 SlashCmdList.BJARKILEARN('enable');Check(Runtime.enabled);Check(not Runtime.adapter.coverage)
 Advance(11);Advance(11.25);Advance(11.5);Advance(11.75);Advance(12);World.combat=false;Advance(12.25)
 local w=PlayerExample();Equal(w.y[6],1);Equal(w.mask[6],true)
 for i=1,5 do Equal(w.mask[i],false) end
 Check(not Runtime.faulted)
]=]}
CASES['logout and fresh module reload rebuild identical model from saved rows']={run=[=[
 RealTrainingHistory()
 local model=NS.Copy(Runtime.core.model);local exported=Runtime.core:Export()
 World.combat=true;World.unitCombat=true;Advance(World.now+.25)
 Check(Runtime.core:Status().pending>0)
 Check(Event('PLAYER_LOGOUT'));Deep(bjarkiLearnDB.learning,exported,'saved completed rows')
 local function clean(v)
  if type(v)=='table' then for k,x in pairs(v) do Check(k~='actor' and k~='id' and k~='history' and k~='occurrences','raw key persisted');clean(x) end
  elseif type(v)=='string' then Check(not v:find('Player%-'),'GUID persisted') end
 end
 clean(bjarkiLearnDB)
 World.now=1000;World.combat=false;World.unitCombat=false
 BjarkiEvidenceV1=nil;LoadAddon();Init()
 Deep(Runtime.core:Export(),exported,'reload rows');Equal(Runtime.core:Status().pending,0)
 TrainToDone();Deep(Runtime.core.model,model,'deterministic rebuilt model')
 Equal(Runtime.core.stats.casts,nil);Equal(BjarkiLearn:GetContext('player').history[6],nil)
 DETAIL='Ten native windows (two observed defensive positives, eight negatives), real training, native logout, fresh module namespace, compatible restore and deterministic complete-model equality. Host globals share one Lua VM; not a live reload.'
]=]}
CASES['reload preserves disabled state and reset clears adaptation while disabled']={run=[=[
 RealTrainingHistory();SlashCmdList.BJARKILEARN('disable');Check(not Runtime.enabled)
 Check(#bjarkiLearnDB.learning.examples>0)
 World.now=0;LoadAddon();Init();Check(not Runtime.enabled);Equal(Runtime.adapter,nil)
 Check(#Runtime.core.examples>0);SlashCmdList.BJARKILEARN('reset')
 Check(not Runtime.enabled);Equal(#Runtime.core.examples,0);Equal(Runtime.core.model,nil)
 Equal(#bjarkiLearnDB.learning.examples,0);Equal(bjarkiLearnDB.enabled,false)
 SlashCmdList.BJARKILEARN('enable');Advance(.25);Check(Runtime.enabled);Check(BjarkiLearn:GetContext('player').fresh)
]=]}
CASES['native API exceptions fail closed without triggering private fault']={run=[=[
 Init();Advance(10)
 UnitGUID=function() error('modeled protected native read') end
 AtCast(10.1,'player','unreadable-native',22812)
 Equal(Runtime.adapter.stats.rejected,1);Check(not Runtime.faulted)
 Equal(Runtime.adapter.coverage,false)
 UnitGUID=function(u) return World.ids[u] end
 Finish(10);local w=PlayerExample();for i=1,6 do Equal(w.mask[i],false) end
 Equal(Runtime.errors,0)
]=]}
CASES['scalar secret and inaccessible host values retain missingness']={run=[=[
 SecretValues[75]=true;InaccessibleValues[50]=true
 Init();Advance(10)
 local c=BjarkiLearn:GetContext('player');Equal(c.health,nil);Equal(c.power,nil)
 Equal(Runtime.core.actors[World.ids.player].window.x[17],0)
 Equal(Runtime.core.actors[World.ids.player].window.x[19],0)
 SecretValues['hidden-cast']=true
 AtCast(10.1,'player','hidden-cast',22812);Equal(Runtime.adapter.stats.rejected,1)
 InaccessibleValues[22812]=true
 AtCast(10.2,'player','ordinary-cast',22812);Equal(Runtime.adapter.stats.rejected,2)
 SecretValues[10.25]=true;Advance(10.25)
 Equal(Runtime.core.now,10);Check(not Runtime.faulted)
 SecretValues={};InaccessibleValues={};Finish(10)
 local w=PlayerExample();for i=1,6 do Equal(w.mask[i],false) end
]=]}
CASES['native-handler and update private faults pause unsubscribe and recover on enable']={run=[=[
 LoadBus();Init();Advance(10)
 local original=Runtime.core.Cast
 Runtime.core.Cast=function() error('injected private Cast defect') end
 World.now=10.1;Event('UNIT_SPELLCAST_SUCCEEDED','player','fault-seam',22812)
 Check(Runtime.faulted);Equal(Runtime.errors,1);Equal(BjarkiEvidenceV1:Status().listeners,0)
 Equal(BjarkiLearn:GetContext('player'),nil);Equal(BjarkiLearn:Forecast('player'),nil)
 Runtime.core.Cast=original
 SlashCmdList.BJARKILEARN('enable');Check(not Runtime.faulted);Equal(BjarkiEvidenceV1:Status().listeners,1)
 local tick=Runtime.core.Tick;Runtime.core.Tick=function() error('injected private Tick defect') end
 Advance(10.25);Check(Runtime.faulted);Equal(Runtime.errors,2);Equal(BjarkiEvidenceV1:Status().listeners,0)
 Runtime.core.Tick=tick
 DETAIL='Fault injection tests pcall containment only. No production/native input causing these private exceptions was found.'
]=]}
CASES['optional bus contains a private listener fault without pausing native casts']={run=[=[
 LoadBus();Init();Advance(10)
 local original=Runtime.core.Aura;Runtime.core.Aura=function() error('injected private Aura defect') end
 Check(Publish(100,10));Equal(BjarkiEvidenceV1:Status().errors,1)
 Check(not Runtime.faulted);Equal(Runtime.errors,0)
 Runtime.core.Aura=original;Check(Publish(101,10));Equal(Runtime.core.stats.auraWitnesses,1)
 AtCast(10.1,'player','after-bus-error',22812);Finish(10)
 Equal(PlayerExample().y[6],1)
 DETAIL='Bus pcall records callback errors separately; Main is not informed. This deliberately injected seam is a fault-containment observation, not a demonstrated producer-reachable bug.'
]=]}
CASES['future public query and backward current query never mutate learning']={run=[=[
 RealTrainingHistory()
 local before=NS.Copy(Runtime.core:Export());local watermark=Runtime.core.evidenceTime
 local revision=Runtime.core.corpusRevision;local t=World.now
 World.now=t+100;local c=BjarkiLearn:GetContext('player');Check(not c.fresh)
 NoScores(BjarkiLearn:Forecast('player'));Equal(Runtime.core.evidenceTime,watermark)
 World.now=t-.1;NoScores(BjarkiLearn:Forecast('player'))
 Deep(Runtime.core:Export(),before,'query purity');Equal(Runtime.core.corpusRevision,revision)
 World.now=t;Check(not Runtime.faulted)
]=]}
for _,kind in ipairs({'nil','true','false','throws','opaque','inaccessible','number','string'}) do
 local permitted=kind=='nil' or kind=='true'
 CASES['cast registration result '..kind]={setup="REGISTRATION={UNIT_SPELLCAST_SUCCEEDED='"..kind.."'}",run=([=[
  Init();Advance(10);Equal(Runtime.castRegistered,%s);Equal(Runtime.adapter.coverage,%s)
  World.now=10.1;Equal(Event('UNIT_SPELLCAST_SUCCEEDED','player','registration-probe',22812),%s)
  Finish(10);local w=PlayerExample()
  for i=1,6 do Equal(w.mask[i],%s) end
  Equal(w.y[6],%s);Check(not Runtime.faulted)
 ]=]):format(tostring(permitted),tostring(permitted),tostring(permitted),tostring(permitted),permitted and '1' or '0')}
end

CASES['native bus anchor preserves eligible witness despite later future publication']={run=[=[
 LoadBus();Init()
 Check(Publish(100,9.5));Check(Publish(101,11))
 Advance(10.25)
 local target=Runtime.core.actors[World.ids.target]
 Equal(target.window.anchor,10.25);Equal(target.window.x[47],1);Equal(target.window.x[48],1)
 Equal(BjarkiLearn:GetContext('target').defensiveWitness.at,9.5)
 for step=2,10 do Advance(10+step*.25) end
 local row
 for _,w in ipairs(Runtime.core.examples) do if w.actor==World.ids.target then row=w;break end end
 Check(row~=nil);Equal(row.x[47],1)
 for i=1,6 do Equal(row.y[i],0);Equal(row.mask[i],false) end
 DETAIL='The real bus delivers two distinct native aura identities. The original retained witness remains eligible for the anchored 48-feature vector; neither aura becomes a cast label.'
]=]}
CASES['future-only native bus witness enters later anchor and leaves first input immutable']={run=[=[
 LoadBus();Init();Check(Publish(101,11))
 Advance(10.25)
 local target=Runtime.core.actors[World.ids.target];local first=target.window
 Equal(first.x[47],0);Equal(first.x[48],0)
 for step=2,10 do Advance(10+step*.25) end
 Equal(first.x[47],0);Equal(first.x[48],0)
 Equal(target.window.anchor,12.5);Equal(target.window.x[47],1);Equal(target.window.x[48],1)
 for i=1,6 do Equal(first.y[i],0);Equal(first.mask[i],false) end
 Equal(Runtime.core.stats.casts,nil)
]=]}
