-- Actual native frame callbacks with deterministic multi-actor churn/resets.
local function copy(value)
 if type(value)~='table' then return value end
 local out={};for k,v in pairs(value) do if k~='version' then out[k]=copy(v) end end;return out
end
World.ids.focus='Player-1-300';World.classes.focus='PRIEST'
UnitHealth=function(u) return (u=='player' and World.health or 75) or 75 end
UnitPower=function(u) return (u=='player' and World.power or 50) or 50 end
if SAVED then
 bjarkiLearnDB=SAVED;World.combat=false;World.unitCombat=false;Init()
 for i=1,400 do Advance(10+i*.125) end
 Check(Runtime.core.model and not Runtime.core.dirty and not Runtime.faulted,'fresh reload replay')
 return {model=Runtime.core.model:Copy(),export=Runtime.core:Export(),checks=CHECKS}
end
Init();Advance(10)
local spells={8122,853,122,15487,1766,22812};local snapshots={}
for cycle=1,280 do
 for step=1,9 do
  local now=10+((cycle-1)*9+step)*.25
  World.health=20+(cycle*11)%81;World.power=(cycle*17)%101;World.now=now
  if step==2 then
   for i,unit in ipairs{'player','target','focus'} do
    Event('UNIT_SPELLCAST_SUCCEEDED',unit,'Cast-multi-'..cycle..'-'..unit,spells[(cycle+i)%6+1])
   end
  end
  if step==4 and cycle%13==0 then
   World.ids.target=World.ids.player;Event('PLAYER_TARGET_CHANGED')
   Event('UNIT_SPELLCAST_SUCCEEDED','target','Cast-alias-'..cycle,8122)
  end
  if step==6 and cycle%13==0 then World.ids.target='Player-1-'..(400+cycle%20);Event('PLAYER_TARGET_CHANGED') end
  if step==5 and cycle%19==0 then
   World.ids.focus=nil;Event('PLAYER_FOCUS_CHANGED')
  elseif step==7 and cycle%19==0 then World.ids.focus='Player-1-300';Event('PLAYER_FOCUS_CHANGED') end
  if step==8 and cycle%29==0 then Event('UNIT_SPELLCAST_SUCCEEDED','player',Opaque,8122) end
  Advance(now)
 end
 if cycle%23==0 then Event('PLAYER_ENTERING_WORLD') end
 if cycle%31==0 then Runtime:Command('disable');Runtime:Command('enable') end
 Check(not Runtime.faulted,'native trajectory fault')
 local c=Runtime.core
 Check(#c.actorOrder<=16 and #c.occurrenceOrder<=128 and #c.examples<=256 and #c.modelDependencies<=256,'capacity')
 if cycle%20==0 then snapshots[#snapshots+1]={status=copy(Runtime:Status()),export=c:Export()} end
end
World.combat=false;World.unitCombat=false;Event('PLAYER_REGEN_ENABLED')
local t=World.now
for i=1,400 do Advance(t+i*.125) end
Check(Runtime.core.model and not Runtime.core.dirty and not Runtime.core.candidate,'final replay')
Event('PLAYER_LOGOUT')
return {snapshots=snapshots,status=copy(Runtime:Status()),export=Runtime.core:Export(),model=Runtime.core.model:Copy(),save=bjarkiLearnDB,checks=CHECKS}
