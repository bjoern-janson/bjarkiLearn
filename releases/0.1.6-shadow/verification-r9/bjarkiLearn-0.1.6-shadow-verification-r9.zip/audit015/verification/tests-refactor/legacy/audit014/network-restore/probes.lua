local ns=...
local C=ns.Config
local results,checks,fingerprints={},0,{}
local function ck(v,msg) checks=checks+1;assert(v,msg or 'assertion') end
local function equal(a,b)
 if type(a)~=type(b) then return false end
 if type(a)~='table' then return a==b end
 for k,v in next,a do if not equal(v,b[k]) then return false end end
 for k in next,b do if a[k]==nil then return false end end
 return true
end
local function same(a,b,msg) ck(equal(a,b),msg) end
local function case(name,fn)
 local n=checks;debugprofilestop=nil
 local ok,detail=pcall(fn)
 results[#results+1]={name=name,passed=ok,checks=checks-n,error=not ok and tostring(detail) or nil,detail=ok and detail or nil}
end
local function context(c,id,t,role,overrides)
 local raw={actor=id,at=t,role=role or 'self',class='PRIEST',bound=true,combat=true,health=.8,power=.7}
 if overrides then for k,v in pairs(overrides) do raw[k]=v end end
 return assert(c:Context(raw))
end
local function new() local c=ns.Core.New();c:SetCoverage(true);return c end
local function cast(c,id,actor,t,f,revision,lo,hi,retracted)
 return c:Cast({id=id,actor=actor,at=t,family=f,revision=revision or 1,minAt=lo,maxAt=hi,retracted=retracted})
end
local function open(c,id,t) context(c,id,t);c:Tick(t,true);return assert(c.actors[id].window) end
local function train(c,t)
 t=t or c.now
 for _=1,1100 do c:Tick(t,false);if not c.dirty then break end end
 ck(not c.dirty and not c.candidate,'replay completes');return c.model
end
local function window(c,id,t,n)
 local w=open(c,id,t)
 if n%4==0 then context(c,id,t+1);assert(cast(c,'event'..n,id,t+1,(n%6)+1)) end
 c:Tick(t+2.25,false)
 return w
end
local function state(model)
 if not model then return 'nil' end
 local out={}
 local function put(v)
  if type(v)=='table' then for i=1,#v do put(v[i]) end else out[#out+1]=string.format('%.17g',v) end
 end
 for _,name in ipairs({'schemaVersion','inputs','hidden','outputs','seed','rngState','learningRate','regularization','linearRegularization','gradientClip','hiddenWeights','hiddenBiases','outputWeights','outputBiases','linearWeights','linearBiases','positives','totals','updates'}) do put(model[name]) end
 return table.concat(out,'\n')
end
local function support(c,model)
 local count,totals,positives=0,{0,0,0,0,0,0},{0,0,0,0,0,0}
 for _,r in ipairs(c:Export().examples) do
  local any=false
  if r.regime=='player' then for f=1,6 do if r.mask[f] then any=true;totals[f]=totals[f]+1;positives[f]=positives[f]+r.y[f] end end end
  if any then count=count+1 end
 end
 if count==0 then ck(model==nil,'no observed rows imply no model');return end
 ck(model~=nil and model:Valid(),'finite completed model');ck(model.updates==count*C.epochs,'update count exactly rows times epochs')
 same(model.totals,totals,'frequency totals count each labeled example once');same(model.positives,positives,'frequency positives count each positive example once')
end
local function replayMatches(c,key)
 local save=c:Export();local original=train(c);support(c,original)
 local restored=new();ck(restored:Restore(save),'export restores');local rebuilt=train(restored)
 support(restored,rebuilt);same(original,rebuilt,'fresh restored corpus has identical full model')
 same(save,restored:Export(),'restore retains exact normalized corpus and diagnostics');ck(#restored.modelDependencies==0,'sealed rows have no raw-identity dependencies')
 if key then fingerprints[key]=state(rebuilt) end
 return restored
end
local function retire(c,t)
 for i=1,C.maxActors do context(c,'retire'..i,t,'hostile') end
 ck(c.actors.P==nil,'P actually retired')
end
case('mature future intervals and correction replay equal a newly restored corpus',function()
 local c=new();local w=open(c,'P',10)
 context(c,'P',10.1);assert(cast(c,'past','P',10.1,1));assert(cast(c,'future','P',11,2,1,10.8,11.2));retire(c,10.2)
 ck(w.y[2]==0 and w.mask[2]==false,'unobserved future remains censored')
 train(c);local serving=c.model;ck(serving~=nil,'past observed positive trains early retired row')
 c:Tick(11.1,nil);ck(c.model==serving and w.y[2]==0,'interval waits for complete upper bound')
 c:Tick(11.2,nil);ck(c.model==nil and w.y[2]==1 and w.mask[2],'maturity withdraws dependent snapshot')
 replayMatches(c,'mature-corrected')
 assert(cast(c,'future','P',11,3,2,10.8,11.2));ck(c.model==nil,'family correction withdraws')
 ck(w.y[2]==0 and not w.mask[2] and w.y[3]==1 and w.mask[3],'only new family remains labeled');replayMatches(c,'family-corrected')
 assert(cast(c,'future','P',11,3,3,10.8,11.2,true));ck(w.y[3]==0 and not w.mask[3],'retracted label censored');replayMatches(c,'retracted')
 return 'All learning via Context/Cast/Tick; no model or corpus mutation.'
end)
case('incomplete replay cancels on correction and cannot publish its former labels',function()
 local c=new();for n=1,24 do window(c,'P',n*4,n) end
 train(c,100);ck(c.model~=nil,'serving baseline');window(c,'P',104,28)
 ck(c.dirty and c.candidate and c.model,'replacement and old generation coexist')
 local abandoned=c.candidate;local revision=c.corpusRevision
 assert(cast(c,'event4','P',17,6,2));ck(c.candidate==nil and c.model==nil,'correction cancels candidate and serving generation');ck(c.corpusRevision>revision,'revision advances')
 local restored=replayMatches(c,'interrupted-correction');ck(c.model~=abandoned.model,'abandoned candidate never published');same(c.model,restored.model,'replayed weights and support are exact')
end)
case('exports and returned forecasts cannot mutate candidate data or optimizer state',function()
 local c=new();for n=1,12 do window(c,'P',n*4,n) end
 train(c,52);window(c,'P',56,16);ck(c.candidate~=nil,'candidate exists')
 local candidate=ns.Copy(c.candidate);local serving=ns.Copy(c.model)
 local saved=c:Export();saved.examples[1].x[1]=1-saved.examples[1].x[1];saved.examples[1].y[1]=1-saved.examples[1].y[1];saved.examples[1].mask[1]=not saved.examples[1].mask[1]
 local f=c:Forecast('P',58.25);f.outputs[1].score=.99999
 same(c.candidate,candidate,'returned tables cannot touch immutable candidate inputs');same(c.model,serving,'returned tables cannot touch serving parameters');replayMatches(c,'detached-exports')
end)
case('invalid restore preserves temporal scalars and in-flight candidate through successful completion',function()
 local c=new();for n=1,10 do window(c,'P',n*4,n) end
 train(c,44);window(c,'P',48,12);assert(cast(c,'pending_future','P',100,1));ck(c.candidate~=nil,'replacement active')
 local original=ns.Copy(c);local refs={};for k,v in pairs(c) do if type(v)=='table' then refs[k]=v end end
 local saved=c:Export();saved.examples[2]=nil
 local ok,why=c:Restore(saved);ck(ok==false and why=='invalid_examples','hole rejected');same(c,original,'all state, temporal frontier and candidate position preserved')
 for k,v in pairs(refs) do ck(c[k]==v,'reference unchanged '..k) end
 replayMatches(c,'failed-restore');ck(c.nextCastAt==original.nextCastAt,'future scheduling survives invalid restore')
end)
case('restore seals a future-censored row and abandons only session-local future authority',function()
 local c=new();local w=open(c,'P',10)
 context(c,'P',10.1);assert(cast(c,'past','P',10.1,1));assert(cast(c,'future','P',11,2));retire(c,10.2)
 ck(w.y[2]==0 and not w.mask[2],'future remains unknown before export')
 local saved=c:Export();local d=new();ck(d:Restore(saved));train(d,10.2)
 c:Tick(11,nil);d:Tick(11,nil)
 ck(w.y[2]==1 and w.mask[2],'original retained raw evidence matures');ck(d.examples[1].y[2]==0 and not d.examples[1].mask[2],'restored sealed row cannot invent discarded evidence')
 ck(#d.occurrenceOrder==0 and #d.actorOrder==0 and #d.modelDependencies==0,'all session identifiers discarded');replayMatches(d,'sealed-future-censored')
end)
case('missing and invalid normalized context fields remain distinct from known zero',function()
 local classes={'WARRIOR','PALADIN','HUNTER','ROGUE','PRIEST','SHAMAN','MAGE','WARLOCK','DRUID','INVALID'}
 local roles={'self','friendly','hostile','INVALID'}
 for _,class in ipairs(classes) do for _,role in ipairs(roles) do
  local c=new();local a=context(c,'P',10,role,{class=class,combat=false,health=0,power=0});local known=ns.Rules.Features(a,10)
  local missing=assert(c:Context({actor='P',at=11,class=class,role=role,bound=true,health=0/0,power=math.huge,combat='false',form='invalid'}));local unknown=ns.Rules.Features(missing,11)
  ck(#known==48 and #unknown==48,'fixed shape')
  for i=1,48 do ck(type(known[i])=='number' and known[i]>=0 and known[i]<=1 and unknown[i]>=0 and unknown[i]<=1,'finite normalized feature '..i) end
  for _,i in ipairs({15,17,19}) do ck(known[i]==1 and unknown[i]==0,'zero and absent known bit '..i) end
  for _,i in ipairs({14,16,18}) do ck(known[i]==0 and unknown[i]==0,'missing value zero only with missing known bit') end
  local candidates=ns.Rules.Candidates(class);for _,f in ipairs(ns.Rules.families) do ck(candidates[f].status~='impossible' and candidates[f].status~='ready','no forbidden certainty') end
 end end
end)
case('bounded native corpus rollover publishes exact retained support and replaces dependencies',function()
 local c=new();for n=1,C.maxExamples do window(c,'P',n*4,n) end
 train(c,1026.25);ck(#c.examples==256 and #c.modelDependencies==256,'at cap, one descriptor per native eligible row')
 local serving=c.model;local oldDependencies=ns.Copy(c.modelDependencies)
 for n=257,270 do window(c,'P',n*4,n) end
 ck(c.model==serving,'routine FIFO rollover preserves serving snapshot');same(c.modelDependencies,oldDependencies,'guards still describe old completed snapshot');ck(c:Status().modelRefreshPending,'pending metadata exposes changed corpus')
 replayMatches(c,'bounded-rollover');ck(#c.modelDependencies<=256 and #c.examples==256 and #c.occurrenceOrder<=128 and #c.actorOrder<=16,'all caps remain bounded')
 ck(c.modelDependencies[1].anchor==60 and c.modelDependencies[256].anchor==1080,'successful replay replaces with current native windows')
 c:ResetSession(1083);ck(#c.modelDependencies==0,'sealing discards raw dependency IDs');replayMatches(c,'bounded-sealed')
end)
case('model copy preserves full learned state while subsequent public learning remains isolated',function()
 local m=assert(ns.Models.New(48,12,6,73013));local x,y,mask={},{},{}
 for i=1,48 do x[i]=(i%7)/6 end;for i=1,6 do y[i]=i%2;mask[i]=true end
 for _=1,32 do ck(m:Learn(x,y,mask)) end
 local clone=assert(m:Copy());same(m,clone,'learned copy identical');local before=ns.Copy(m)
 for i=1,6 do y[i]=1-y[i] end
 ck(clone:Learn(x,y,mask),'copy learns independently');same(m,before,'original preserved');ck(not equal(m,clone),'copy actually diverges')
 local p=assert(clone:Predict(x));for _,head in pairs(p) do for _,v in ipairs(head) do ck(v>=0 and v<=1 and v==v,'finite probability') end end
 fingerprints['network-copy']=state(clone)
end)
return {cases=results,fingerprints=fingerprints}
