"""Independent 0.1.4 composition audit; writes only requested output."""
import argparse, hashlib, importlib, json, sys
from pathlib import Path
p=argparse.ArgumentParser()
p.add_argument('--source',required=True,type=Path)
p.add_argument('--output',required=True,type=Path)
p.add_argument('--lupa-path',type=Path,default=Path('C:/Users/Mewn/Documents/Codex/2026-10-16/let/work/deps'))
a=p.parse_args();sys.path.insert(0,str(a.lupa_path));source=a.source.resolve()
def hashes():
 return {str(f.relative_to(source)):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(source.rglob('*')) if f.is_file()}
before=hashes();results=[];fingerprints={}
for engine in ('lua51','lua54'):
 lua=importlib.import_module('lupa.'+engine).LuaRuntime(unpack_returned_tuples=True);ns=lua.table()
 for filename in ('Bootstrap.lua','Rules.lua','Network.lua','Core.lua'):
  lua.execute((source/filename).read_text(encoding='utf-8-sig'),'bjarkiLearn',ns)
 report=lua.execute(Path(__file__).with_name('probes.lua').read_text(encoding='utf-8-sig'),ns)
 results.extend({'runtime':engine,**dict(case.items())} for _,case in report['cases'].items())
 fingerprints[engine]=dict(report['fingerprints'].items())
for key in sorted(set(fingerprints['lua51'])|set(fingerprints['lua54'])):
 results.append({'runtime':'cross-runtime','name':key+' exact state','checks':1,'passed':fingerprints['lua51'].get(key)==fingerprints['lua54'].get(key)})
after=hashes()
out={'source':str(source),'source_hashes_before':before,'source_hashes_after':after,'source_unchanged':before==after,'total':len(results),'passed':sum(bool(r['passed']) for r in results),'checks':sum(r['checks'] for r in results),'results':results,'fingerprint_sha256':{e:{k:hashlib.sha256(v.encode()).hexdigest() for k,v in values.items()} for e,values in fingerprints.items()}}
a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in out.items() if k not in ('results','source_hashes_before','source_hashes_after')}))
for row in results:
 if not row['passed']:print(json.dumps(row))
sys.exit(0 if out['passed']==out['total'] and out['source_unchanged'] else 1)
