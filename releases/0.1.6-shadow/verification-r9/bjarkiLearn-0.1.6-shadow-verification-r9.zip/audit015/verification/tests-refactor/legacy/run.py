"""Run preserved suites from explicit adapted copies, without production shims."""
from pathlib import Path
import argparse, difflib, hashlib, json, os, shutil, subprocess, sys, tempfile, time
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
RELOCATED={'run_all.py':'baseline-0.1.4/run_all.py','build_release.py':'baseline-0.1.4/build_release.py'}
MANIFESTS=('fixtures/original-harness-hashes.json','fixtures/v0.1.3-preserved-test-hashes.json','audit-controls/original-hashes.json')
ADAPTATIONS=[
 ('review-core/probe_core.py','c.actors.P1.history[1]',"c:_Evidence('P1').history[1]",1,'Correction: unrestricted retained history for former actor.'),
 ('review-core/probe_core.py','c.actors.P2.history[1]',"c:_Evidence('P2').history[1]",1,'Correction: unrestricted retained history for corrected actor.'),
 ('review-adapter/probe.lua','c.actors[E].defensiveWitness','c:GetContext(E,now).defensiveWitness',1,'Aura at observed clock 10; fresh public view.'),
 ('review-adapter/probe.lua',"c.actors['Player-1-CCC'].defensiveWitness","c:GetContext('Player-1-CCC',now).defensiveWitness",1,'Rebound target at observed clock 10.25; fresh public view.'),
 ('audit-controls/new-corrections/run_corrections.py','c.actors.P.history[1]',"c:_Evidence('P').history[1]",1,'Immutable input: unrestricted current retained history after correction.'),
 ('audit-0.1.2/native/run.py','Runtime.core.actors[World.ids.target].defensiveWitness','Runtime.core:GetContext(World.ids.target,World.now).defensiveWitness',3,'Initial replay, world reset replay, late bus load: observed modeled clock.'),
 ('audit-0.1.3/audit/core/probes.lua','eq(c.actors.P.history[1],nil)',"eq(c:_Evidence('P').history[1],nil)",2,'Retraction and retirement: unrestricted retained history excludes old family.'),
 ('audit-0.1.3/audit/core/probes.lua','eq(c.actors.E.history[2],nil)',"eq(c:_Evidence('E').history[2],nil)",1,'Reattribution and retraction: unrestricted retained history excludes old actor/family.'),
 ('audit-0.1.3/audit/core/probes.lua','eq(c.actors.P.history[1],6.5)',"eq(c:GetContext('P',c.actors.P.at).history[1],6.5)",1,'Public copy isolation: second public view at identical query time remains unchanged.'),
]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def hashes(root):return {p.relative_to(root).as_posix():sha(p) for p in sorted(root.rglob('*')) if p.is_file()}
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def write(p,v):
 p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
def original(n):return ROOT/RELOCATED.get(n,n)
def verify():
 expected=read(ROOT/'fixtures/v0.1.4-preserved-test-hashes.json')
 assert {n:sha(original(n)) for n in expected}==expected,'Preserved original changed'
 assert hashes(HERE/'audit014')==read(HERE/'audit014-hashes.json'),'Copied audit014 original changed'
 return expected

def stage(source,adapted,label):
 expected=verify();runs=HERE/'runs';runs.mkdir(exist_ok=True)
 target=Path(tempfile.mkdtemp(prefix=label+'-',dir=runs))
 for n in expected:
  out=target/n;out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(original(n),out)
 for n in MANIFESTS:shutil.copyfile(ROOT/n,target/n)
 for v in ('baseline','baseline-0.1.1','baseline-0.1.2','baseline-0.1.3','baseline-0.1.4'):
  shutil.copytree(ROOT/v/'source',target/v/'source')
 shutil.copytree(source,target/'source/bjarkiLearn');substitutions=[]
 if adapted:
  for n,old,new,count,reason in ADAPTATIONS:
   p=target/n;b=p.read_bytes();assert b.count(old.encode())==count,(n,old,count)
   p.write_bytes(b.replace(old.encode(),new.encode()))
   substitutions.append(dict(file=n,original_expression=old,adapted_expression=new,occurrences=count,reason=reason))
 changed={n:dict(original_sha256=h,staged_sha256=sha(target/n)) for n,h in expected.items() if h!=sha(target/n)}
 assert set(changed)==({r[0] for r in ADAPTATIONS} if adapted else set()),changed
 updates=[]
 for n in MANIFESTS:
  p=target/n;data=read(p);prefix='audit-controls/' if n.startswith('audit-controls/') else ''
  rows=[(r['file'],r) for r in data] if isinstance(data,list) else list(data.get('sha256',data).items())
  edits=[]
  for k,v in rows:
   rel=prefix+k
   if rel not in changed:continue
   old=v['sha256'] if isinstance(v,dict) else v;new=sha(target/rel);assert old==expected[rel]
   if isinstance(v,dict):v['sha256']=new
   else:data.get('sha256',data)[k]=new
   edits.append(dict(file=rel,original_sha256=old,staged_sha256=new))
  if edits:write(p,data);updates.append(dict(manifest=n,entries=edits))
 shutil.copytree(HERE/'audit014',target/'audit014')
 shutil.copytree(ROOT/'baseline-0.1.3/source',target/'verification/baseline-0.1.3/source')
 for n in ('audit-0.1.2/native/harness.lua','fixtures/SharedEvidence.lua'):
  out=target/'verification'/n;out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/n,out)
 provenance=dict(stage=str(target),original_files=expected,original_files_verified=len(expected),relocated_originals=RELOCATED,
  adaptations=substitutions,adapted_files=changed,staged_manifest_updates=updates,source_hashes=hashes(source),
  staged_source_hashes=hashes(target/'source/bjarkiLearn'),production_shims=False,assertions_or_expected_values_changed=False,
  historical_report_notice='Old staged fixture-original fields concern execution copies; outer provenance separately verifies preserved originals.',
  six_retired_future_positive_assertions_handled_by_unchanged_run_all=True)
 assert provenance['source_hashes']==provenance['staged_source_hashes'];write(target/'adaptation-provenance.json',provenance)
 return target,provenance

def run(target,name,args,env):
 out=target/'runner-outputs'/(name+'.txt');out.parent.mkdir(exist_ok=True);start=time.perf_counter()
 print('Running '+name+' ...',flush=True)
 with out.open('w',encoding='utf-8') as stream:
  result=subprocess.run([sys.executable,*args],cwd=target,env=env,stdout=stream,stderr=subprocess.STDOUT)
 row=dict(name=name,exit_code=result.returncode,seconds=round(time.perf_counter()-start,3),output=str(out))
 if result.returncode:print(out.read_text(encoding='utf-8')[-12000:],flush=True)
 return row

def affected(target,env):
 source=str(target/'source/bjarkiLearn');reports=target/'affected-reports';reports.mkdir();jobs=[]
 for name,file in (('core','review-core/probe_core.py'),('adapter','review-adapter/probe.py')):
  code='import run_existing; run_existing.ensure_runtime(); '+f"row,raw=run_existing.execute_runner('{name}','{file}','review-{name}/results.json'); "+'raise SystemExit(row["exit_code"])'
  jobs.append((name,['-c',code]))
 jobs.extend([
  ('controls',['run_audit_controls.py','--source',source,'--output',str(reports/'controls.json')]),
  ('native012',['audit-0.1.2/native/run.py','--source',source,'--bus',str(target/'fixtures/SharedEvidence.lua'),'--output',str(reports/'native012.json')]),
  ('core013',['audit-0.1.3/audit/core/run.py','--source',source,'--output',str(reports/'core013.json')]),
 ])
 runs=[run(target,n,args,env) for n,args in jobs]
 assert [r['exit_code'] for r in runs]==[0,0,1,0,1],runs
 controls,native,core=[read(reports/(n+'.json')) for n in ('controls','native012','core013')]
 assert controls['summary']=={'passed':38,'total':40};assert core['counts']=={'total':40,'passed':38}
 assert native['summary']['passed']==native['summary']['total']==36
 snapshot=dict(core=read(target/'review-core/results.json'),adapter=read(target/'review-adapter/results.json'),
  controls={k:controls[k] for k in ('cases','summary','exclusions','excluded_observations')},
  native={k:native[k] for k in ('cases','summary')},core013={k:core[k] for k in ('cases','counts')})
 return runs,snapshot

def audit014(target,env,execute=True):
 source=str(target/'source/bjarkiLearn');reports=target/'audit014-reports';reports.mkdir(exist_ok=True)
 jobs=[('core',['--baseline',str(target/'baseline-0.1.3/source/bjarkiLearn')]),('native',['--bus',str(target/'fixtures/SharedEvidence.lua')]),('network-restore',[]),('integration',[])]
 runs=[]
 for name,extra in (jobs if execute else []):
  runner=target/'audit014'/name/'run.py'
  command=[str(runner),'--source',source,'--output',str(reports/(name+'.json')),*extra]
  if name=='integration':
   # Original runner has a fixed 0.1.3 path and historical version labels.
   # Redirect only source selection and labels in memory; all trace checks stay.
   redirect="baseline=r/'verification/baseline-0.1.3/source/bjarkiLearn'"
   replacement='baseline=Path('+repr(str(target/'baseline-0.1.4/source/bjarkiLearn'))+')'
   labels="[('0.1.3',baseline),('0.1.4',a.source)]"
   new_labels="[('0.1.4',baseline),('0.1.5',a.source)]"
   code=('from pathlib import Path; p=Path('+repr(str(runner))+'); code=p.read_text(encoding="utf-8-sig"); '
    +'assert code.count('+repr(redirect)+')==1 and code.count('+repr(labels)+')==1; '
    +'code=code.replace('+repr(redirect)+','+repr(replacement)+').replace('+repr(labels)+','+repr(new_labels)+'); '
    +'exec(compile(code,str(p),"exec"),{"__name__":"__main__","__file__":str(p)})')
   command=['-c',code,*command[1:]]
  row=run(target,'audit014-'+name,command,env)
  runs.append(row);assert row['exit_code']==0,row
 core,native,network,integration=[read(reports/(n+'.json')) for n in ('core','native','network-restore','integration')]
 assert core['passed']==core['total']==14;assert native['summary']['passed']==native['summary']['total']==54
 assert network['passed']==network['total']==26;assert integration['passed'] and integration['comparisons']==8
 return dict(runs=runs,groups_passed=94,integration_comparisons_passed=8,integration_baseline='exact preserved 0.1.4',integration_baseline_hashes=hashes(target/'baseline-0.1.4/source/bjarkiLearn'),integration_execution_only_redirects={'baseline_path':'baseline-0.1.4/source/bjarkiLearn','version_labels':['0.1.4','0.1.5'],'assertions_unchanged':True},reports={n:read(reports/(n+'.json')) for n,_ in jobs})

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--source',required=True,type=Path);p.add_argument('--output',required=True,type=Path)
 p.add_argument('--mode',choices=('full','baseline-equivalence','audit014','summarize'),default='full');p.add_argument('--lupa-path',type=Path,action='append',default=[])
 p.add_argument('--stage',type=Path,help='Existing completed full execution stage, only for summarize mode')
 a=p.parse_args();source=a.source.resolve();before=hashes(source);originals=verify();env=dict(os.environ)
 env['PYTHONPATH']=os.pathsep.join([*(str(x.resolve()) for x in a.lupa_path),env.get('PYTHONPATH','')])
 report=dict(mode=a.mode,source=str(source),source_hashes=before,original_test_source_hashes=originals,original_test_files=len(originals))
 if a.mode=='baseline-equivalence':
  old,oldp=stage(source,False,'baseline-original');new,newp=stage(source,True,'baseline-adapted')
  oldruns,oldresults=affected(old,env);newruns,newresults=affected(new,env)
  report.update(original_provenance=oldp,adaptation_provenance=newp,original_runs=oldruns,adapted_runs=newruns,
   original_results=oldresults,adapted_results=newresults,results_identical=oldresults==newresults,
   execution_count_per_variant=162,current_controls_per_variant=158,unchanged_retired_executions_per_variant=4)
  assert report['results_identical'],'Original and adapted baseline results differ'
 else:
  if a.mode=='summarize':
   assert a.stage, '--stage is required for summarize'
   target=a.stage.resolve();assert target.is_relative_to((HERE/'runs').resolve())
   provenance=read(target/'adaptation-provenance.json')
   assert provenance['staged_source_hashes']==hashes(target/'source/bjarkiLearn')
   assert provenance['original_files']==originals
   assert all(sha(target/n)==provenance['adapted_files'].get(n,{}).get('staged_sha256',h) for n,h in originals.items()), 'Staged test fixture changed after execution'
   assert 'Fresh independent review: 12/12 passed' in (target/'runner-outputs/inherited-run-all.txt').read_text()
   before=provenance['source_hashes'];report['source_hashes']=before
  else:target,provenance=stage(source,True,'current-'+a.mode)
  report['adaptation_provenance']=provenance
  if a.mode in ('full','summarize'):
   if a.mode=='full':
    job=run(target,'inherited-run-all',['run_all.py'],env);report['inherited_run']=job;assert job['exit_code']==0,job
   else:report['inherited_run']={'reports_reused':True,'output':str(target/'runner-outputs/inherited-run-all.txt')}
   inherited=read(target/'reports-0.1.4/verification.json')
   assert inherited['passed'] and inherited['scenario_executions']==663 and inherited['superseded_engine_executions']==6
   assert inherited['fresh_whole_change_review_probes_passed']==12
   report['inherited_verification']=inherited
   report['inherited_reports']={f.name:read(f) for f in sorted((target/'reports-0.1.4').glob('*.json'))}
   report['legacy_reports']={f.relative_to(target).as_posix():read(f) for pattern in ('reports/*.json','review-main/*results.json','review-core/results.json','review-network/results.json','review-adapter/results.json','review-fresh/results.json','review-integration/changed-core.json') for f in sorted(target.glob(pattern))}
  report['audit014']=audit014(target,env,execute=a.mode!='summarize')
  staged_hashes=hashes(target/'source/bjarkiLearn')
  for row in report['audit014']['reports'].values():
   assert row['source_unchanged']
   checked=row.get('source_hashes',row.get('source_hashes_before'))
   assert checked and all(staged_hashes[n.replace('\\','/')]==v for n,v in checked.items())
  if 'inherited_verification' in report:
   assert report['inherited_verification']['runtime_hashes']=={n:v for n,v in staged_hashes.items() if n.endswith('.lua')}
 report['source_unchanged']=before==hashes(source);report['original_test_sources_unchanged']=originals==verify()
 report['audit014_original_files_unchanged']=hashes(HERE/'audit014')==read(HERE/'audit014-hashes.json')
 report['final_source_hashes']=hashes(source)
 report['runtime_source_unchanged']={n:v for n,v in before.items() if n.endswith('.lua')}=={n:v for n,v in hashes(source).items() if n.endswith('.lua')}
 report['source_doc_changes_during_execution']=[]
 if not report['source_unchanged']:
  # Explicitly authorized documentation clarification during this run only.
  assert a.mode=='summarize', 'Source changed during a fresh execution'
  allowed={
   'CHANGELOG.md':('Lead-only refinements retain their existing non-dirty behavior.','The outcome updater does not dirty solely for lead changes; existing correction guards can still withdraw a dependent model.'),
   'docs/IMPLEMENTATION.md':('A lead-time-only refinement updates the lead without changing the row revision or dirtying the corpus.','A lead-time-only refinement updates the lead without changing the row revision or dirtying the corpus through the outcome updater. A timestamp correction can still withdraw a dependent serving model through the unchanged correction guards.')}
  changed={n for n in set(before)|set(hashes(source)) if before.get(n)!=hashes(source).get(n)}
  assert changed==set(allowed), changed
  for n,(old,new) in allowed.items():
   earlier=(target/'source/bjarkiLearn'/n).read_text();later=(source/n).read_text()
   assert earlier.count(old)==1 and earlier.replace(old,new)==later, n
   report['source_doc_changes_during_execution'].append(dict(file=n,initial_sha256=before[n],final_sha256=hashes(source)[n],diff='\n'.join(difflib.unified_diff(earlier.splitlines(),later.splitlines(),fromfile='tested/'+n,tofile='final/'+n))))
 report['documentation_changes_only']=bool(report['source_doc_changes_during_execution']) and report['runtime_source_unchanged']
 assert report['runtime_source_unchanged'] and report['original_test_sources_unchanged'] and report['audit014_original_files_unchanged']
 report['passed']=True;write(a.output,report)
 print(json.dumps({k:report[k] for k in ('mode','passed','source_unchanged','original_test_sources_unchanged')}),flush=True)
if __name__=='__main__':main()
