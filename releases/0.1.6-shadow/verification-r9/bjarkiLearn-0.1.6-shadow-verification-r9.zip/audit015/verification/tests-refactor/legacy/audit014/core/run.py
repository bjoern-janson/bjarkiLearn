"""Independent Core/Rules audit; never modifies source or prior verification."""
import argparse, hashlib, importlib, json, sys
from pathlib import Path
p=argparse.ArgumentParser()
p.add_argument('--source',type=Path,required=True)
p.add_argument('--output',type=Path,required=True)
p.add_argument('--baseline',type=Path)
p.add_argument('--lupa-path',type=Path,default=Path('C:/Users/Mewn/Documents/Codex/2026-10-16/let/work/deps'))
a=p.parse_args();sys.path.insert(0,str(a.lupa_path))
root=Path(__file__).resolve().parent
baseline=a.baseline or a.source.parents[1]/'verification/baseline-0.1.3/source/bjarkiLearn'
verification=a.source.parents[1]/'verification'
def hashes(path):
 return {f.relative_to(path).as_posix():hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(path.rglob('*')) if f.is_file()}
before=hashes(a.source);base_before=hashes(baseline);prior_before=hashes(verification);results=[];signatures={}
for engine in ('lua51','lua54'):
 module=importlib.import_module('lupa.'+engine);lua=module.LuaRuntime(unpack_returned_tuples=True)
 def load(path,runtime=lua):
  ns=runtime.table()
  for f in ('Bootstrap.lua','Rules.lua','Network.lua','Core.lua'):runtime.execute((path/f).read_text(encoding='utf-8-sig'),'bjarkiLearn',ns)
  return ns
 rows=lua.execute((root/'probes.lua').read_text(encoding='utf-8'),load(a.source),load(baseline))
 for _,r in rows.items():results.append({'engine':engine,**dict(r.items())})
 repeats=[]
 for repeat in range(12):
  fresh=module.LuaRuntime(unpack_returned_tuples=True)
  repeats.append(fresh.execute((root/'reset.lua').read_text(encoding='utf-8'),load(a.source,fresh)))
 signatures[engine]=[hashlib.sha256(s.encode()).hexdigest() for s in repeats]
 results.append({'engine':engine,'name':'twelve_fresh_states_reset_fifo_and_real_model','passed':len(set(repeats))==1,'detail':'Twelve fresh Lua states, 16 pending actors, full replay buffer; exact export and learned-parameter comparison.'})
report={'source':str(a.source.resolve()),'baseline':str(baseline.resolve()),'source_hashes':before,'baseline_hashes':base_before,'source_unchanged':before==hashes(a.source),'baseline_unchanged':base_before==hashes(baseline),'verification_files_checked':len(prior_before),'prior_verification_unchanged':prior_before==hashes(verification),'total':len(results),'passed':sum(r['passed'] for r in results),'cases':results,'reset_signature_sha256':signatures,'limits':['Modeled Lua execution, not live WoW.','Corrections and future casts use private normalized Core; no public evidence injection exists.','Synthetic row retirement is identified per case.']}
a.output.parent.mkdir(parents=True,exist_ok=True)
a.output.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:report[k] for k in ('total','passed','source_unchanged','baseline_unchanged','prior_verification_unchanged')},indent=2))
print(json.dumps({'failures':[r for r in results if not r['passed']]},indent=2))
raise SystemExit(int(report['passed']!=report['total'] or not report['source_unchanged'] or not report['baseline_unchanged'] or not report['prior_verification_unchanged']))
