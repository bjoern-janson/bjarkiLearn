from pathlib import Path
import argparse,hashlib,importlib,json,sys
try:import lupa
except ImportError:sys.path.insert(0,'C:/Users/Mewn/Documents/Codex/2026-10-16/let/work/deps')
p=argparse.ArgumentParser();p.add_argument('--source',required=True,type=Path);p.add_argument('--output',required=True,type=Path);a=p.parse_args()
r=Path(__file__).resolve().parents[2];baseline=r/'verification/baseline-0.1.3/source/bjarkiLearn'
harness=(r/'verification/audit-0.1.2/native/harness.lua').read_text(encoding='utf-8');trace=Path(__file__).with_name('trace.lua').read_text(encoding='utf-8')
def plain(v):return {k:plain(x) for k,x in v.items()} if hasattr(v,'items') else v
def lua_table(lua,v):return lua.table_from({k:lua_table(lua,x) for k,x in v.items()}) if isinstance(v,dict) else v
def run(engine,source,saved=None):
 lua=importlib.import_module('lupa.'+engine).LuaRuntime(unpack_returned_tuples=True)
 lua.globals().LEARN_ROOT=source.resolve().as_posix();lua.execute(harness)
 if saved:lua.globals().SAVED=lua_table(lua,saved)
 return plain(lua.execute(trace))
def hashes():return {f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in a.source.glob('*.lua')}
before=hashes();ref=None;rows=[]
for engine in ('lua51','lua54'):
 for version,source in [('0.1.3',baseline),('0.1.4',a.source)]:
  data=run(engine,source)
  if ref is None:ref=data
  reloaded=run(engine,source,data['save'])
  rows.append({'runtime':engine,'version':version,'trace_equal':data==ref,'reload_equal':reloaded['model']==data['model'] and reloaded['export']==data['export'],'checks':data['checks']+reloaded['checks'],'examples':data['status']['core']['examples'],'modelVersion':data['status']['core']['modelVersion']})
  print(engine,version,rows[-1],flush=True)
report={'passed':all(x['trace_equal'] and x['reload_equal'] for x in rows),'comparisons':len(rows)*2,'source_hashes':before,'source_unchanged':before==hashes(),'cases':rows,'scope':'280 native multi-actor cycles, alias and identity churn, missing focus, unreadable cast identity, world and disable/enable resets, 2520 scheduled updates, 400 finishing updates, fresh native logout/reload; exact status/export/model equality across both releases and both Lua runtimes.'}
a.output.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');print(json.dumps(report,indent=2));sys.exit(0 if report['passed'] and report['source_unchanged'] else 1)
