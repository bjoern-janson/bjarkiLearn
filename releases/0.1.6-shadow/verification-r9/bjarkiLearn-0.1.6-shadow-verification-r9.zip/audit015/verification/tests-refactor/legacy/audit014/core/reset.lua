local ns=...
local c=ns.Core.New();c:SetCoverage(true)
local function ctx(id,t,index)
 c:Context({actor=id,at=t,class='DRUID',role=index==16 and 'self' or 'hostile',combat=true,bound=true,health=index/16,power=.5})
end
for cycle=1,256 do
 local t=cycle*3
 ctx('player',t,16);c:Tick(t,true);ctx('player',t+.5,16)
 if cycle%3==0 then assert(c:Cast({id='cast'..cycle,actor='player',at=t+.5,family=cycle%6+1})) end
 c:Tick(t+2.25,nil)
end
c:ResetSession(800)
for index=1,16 do ctx('pending'..index,801,index) end
c:Tick(801,true)
for index=1,16 do ctx('pending'..index,801.5,index);assert(c:Cast({id='last'..index,actor='pending'..index,at=801.5,family=index%6+1})) end
c:ResetSession(801.5);assert(#c.examples==256)
for i=1,2000 do c:Tick(801.5,false);if not c.dirty then break end end
assert(c.model and not c.candidate and not c.dirty)
local function canonical(v)
 if type(v)=='number' then return string.format('%.17g',v) end
 if type(v)~='table' then return tostring(v) end
 local keys={};for k in pairs(v) do keys[#keys+1]=k end
 table.sort(keys,function(a,b) if type(a)==type(b) then return a<b else return type(a)<type(b) end end)
 local out={'{'};for _,k in ipairs(keys) do out[#out+1]=tostring(k)..':'..canonical(v[k])..';' end
 out[#out+1]='}';return table.concat(out)
end
return canonical(c:Export())..canonical(c.model)
