local ns,baseline=...
local results={}
local function eq(a,b,msg) assert(a==b,(msg or 'mismatch')..': '..tostring(a)..' ~= '..tostring(b)) end
local function deep(a,b,msg)
 msg=msg or '';eq(type(a),type(b),msg)
 if type(a)~='table' then eq(a,b,msg);return end
 for k,v in pairs(a) do deep(v,b[k],msg..'.'..tostring(k)) end
 for k in pairs(b) do assert(a[k]~=nil,msg..' unexpected '..tostring(k)) end
end
local function test(name,fn)
 local ok,r=pcall(fn);results[#results+1]={name=name,passed=ok,detail=ok and r or nil,error=not ok and tostring(r) or nil}
end
local function context(c,id,t,role)
 return c:Context({actor=id,at=t,role=role or 'self',class='DRUID',combat=true,bound=true,health=.75,power=.5,form='bear'})
end
local function new(module) local c=(module or ns).Core.New();c:SetCoverage(true);return c end
local function cast(c,id,actor,t,f,rev,lo,hi,retracted)
 return c:Cast({id=id,actor=actor,at=t,family=f or 1,revision=rev or 1,minAt=lo,maxAt=hi,retracted=retracted})
end
local function retire(c,t) for i=1,16 do context(c,'retire'..i,t,'hostile') end end
local function train(c)
 for i=1,2048 do c:Tick(c.now,false);if not c.dirty then break end end
 assert(c.model and not c.dirty and not c.candidate,'training incomplete')
end
local function clean(c) local d=new();assert(d:Restore(c:Export()));train(d);return d end

test('exhaustive_interval_edges_three_clock_orders',function()
 local edges={9.75,10,10.25,11,12,12.25};local frontiers={10,10.25,11,12,12.25};local checks=0
 for _,lo in ipairs(edges) do for _,hi in ipairs(edges) do if lo<=hi then
  for _,frontier in ipairs(frontiers) do for mode=1,3 do
   local c=new();context(c,'P',10);c:Tick(10,true);local w=c.actors.P.window
   if mode==1 then context(c,'P',frontier) end
   assert(cast(c,'e','P',(lo+hi)/2,2,1,lo,hi))
   if mode==2 then context(c,'P',frontier) end
   if mode==3 then c:GetContext('P',100);c:Forecast('P',100);eq(c.evidenceTime,10,'queries cannot mature') end
   local observed=mode==3 and 10 or frontier
   retire(c,observed)
   local positive=lo>10 and hi<=12 and hi<=observed
   eq(w.y[2],positive and 1 or 0,'boundary y');eq(w.mask[2],positive,'retired mask')
   if positive then eq(w.lead[2],lo-10) else eq(w.lead[2],nil) end
   for f=1,6 do if f~=2 then eq(w.mask[f],false) end end
   context(c,'retire16',math.max(observed,hi))
   local eventual=lo>10 and hi<=12
   eq(w.y[2],eventual and 1 or 0,'mature y');eq(w.mask[2],eventual,'mature mask')
   checks=checks+1
  end end
 end end end
 return tostring(checks)..' interval/frontier/order cases; exact anchor/deadline, straddles, before/after Context and query-only maturity.'
end)

test('candidate_cancelled_by_maturity_after_actor_retirement',function()
 local c=new();context(c,'P',10);c:Tick(10,true);local w=c.actors.P.window
 context(c,'P',10.125);assert(cast(c,'known','P',10.125,1));assert(cast(c,'future','P',11,2));retire(c,10.25)
 eq(w.mask[1],true);eq(w.mask[2],false)
 for i=1,8 do
  local row={actor='earlier'..i,anchor=0,deadline=2,regime='player',x=ns.Copy(w.x),coverage={},lost={}}
  for f=1,6 do row.coverage[f]=true end
  c:_Resolve(row)
 end
 c:Tick(10.25,false);assert(c.candidate)
 local rev=c.corpusRevision;context(c,'retire16',11)
 eq(c.candidate,nil,'maturity cancels candidate');assert(c.corpusRevision>rev);eq(w.y[2],1);eq(w.mask[2],true)
 train(c);deep(c.model,clean(c).model,'clean maturity replay')
 return 'Retired actor plus partial candidate: exact maturity cancels candidate and full learned state equals clean replay. Eight synthetic earlier _Resolve rows force a partial candidate.'
end)

test('maturity_and_reattribution_after_actor_and_replay_evictions',function()
 local c=new();context(c,'P',10);c:Tick(10,true);local w=c.actors.P.window
 context(c,'P',10.125);assert(cast(c,'known','P',10.125,1));assert(cast(c,'future','P',11,2));retire(c,10.25);train(c)
 local model=c.model;assert(model and #c.modelDependencies==1)
 for i=1,256 do c:_Resolve({actor='filler',anchor=0,deadline=2,regime='other',x=ns.Copy(w.x),coverage={},lost={}}) end
 eq(c.model,model);eq(#c.examples,256);eq(c.actors.P,nil)
 context(c,'retire16',11);eq(c.model,nil,'maturity reaches evicted serving dependency')
 local d=new();context(d,'Q',20);d:Tick(20,true);local v=d.actors.Q.window
 context(d,'Q',21);assert(cast(d,'k','Q',21,3));d:Tick(22.25,false);train(d);local old=d.model
 for i=1,256 do d:_Resolve({actor='filler',anchor=0,deadline=2,regime='other',x=ns.Copy(v.x),coverage={},lost={}}) end
 retire(d,22.25);eq(d.model,old);assert(cast(d,'k','R',100,5,2));eq(d.model,nil,'old side withdraws')
 return 'Serving guards survive actor and replay retirement; maturity and actor/family/time reassignment withdraw original generation. Replay retirement uses synthetic _Resolve rows.'
end)

test('future_revisions_and_occurrence_eviction_leave_no_ghost_due',function()
 local c=new();context(c,'P',10);c:Tick(10,true);local w=c.actors.P.window
 assert(cast(c,'future','P',11,1));assert(cast(c,'future','P',11.5,2,2));assert(cast(c,'future','P',11.5,2,3,nil,nil,true))
 retire(c,10.125)
 for i=1,128 do assert(c:Aura({id=tostring(i),recipient='Q',at=10.125,spellID=22812})) end
 eq(c.occurrences['cast:future'],nil);eq(c.evidenceFloor,11.5)
 context(c,'retire16',12);eq(c.nextCastAt,nil);eq(w.y[1],0);eq(w.y[2],0)
 eq(cast(c,'future','P',11.5,2,1),false)
 local ok,why=cast(c,'future','P',12,3,4);eq(ok,false);eq(why,'revision_history_lost')
 for f=1,6 do eq(w.mask[f],false) end;eq(#c.occurrenceOrder,128)
 return 'Retimed/retracted future ID evicted via 128 auras; stale due marker clears, replay floor protects identity, forgotten revision censored.'
end)

test('observed_boundary_revisions_match_013_with_real_models',function()
 local a,b=new(),new(baseline)
 local function both(fn) fn(a);fn(b);deep(a:Export(),b:Export(),'observed export') end
 for cycle=1,20 do
  local t=cycle*4
  both(function(c) context(c,'P',t);c:Tick(t,true) end)
  both(function(c) context(c,'P',t+2);assert(cast(c,'e'..cycle,'P',t+2,cycle%6+1)) end)
  both(function(c) c:Tick(t+2.25,false);train(c) end)
  both(function(c) assert(cast(c,'e'..cycle,'P',t+2,cycle%6+1,2,t,t+2));train(c) end)
  deep(a.model,b.model,'boundary censor model')
  both(function(c) assert(cast(c,'e'..cycle,'P',t+2,cycle%6+1,3,t+.125,t+2));train(c) end)
  deep(a.model,b.model,'boundary restore model')
  both(function(c) assert(cast(c,'e'..cycle,'P',t+2,cycle%6+1,4,nil,nil,true));train(c) end)
  deep(a.model,b.model,'retract model')
 end
 return '20 windows: exact deadline, anchor-touching uncertainty, contained uncertainty, retraction and 80 real rebuilds/version. Exports and full learned state equal 0.1.3.'
end)

test('independent_capacity_ledger_revisions_and_resets',function()
 local c=new();local ledger,order={},{};local floor=-1;local frontier=0;local windows={};local checks=0;local evictions=0;local seed=631371
 local function draw(n) seed=(seed*48271)%2147483647;return seed%n+1 end
 local function overlap(w,e) return e and w.actor==e.actor and e.hi>w.anchor and e.lo<=w.deadline end
 local function verify()
  eq(#c.occurrenceOrder,#order,'ledger count');eq(c.evidenceFloor,floor,'ledger floor')
  assert(#c.actorOrder<=16 and #c.examples<=256 and #c.modelDependencies<=256)
  for _,w in ipairs(c.examples) do if not w.sealed then
   local lost=windows[w.id].lost
   for f=1,6 do
    local positive,ambiguous,lead=false,false,nil
    for _,e in pairs(ledger) do if e.f==f and overlap(w,e) and not e.retracted then
     if e.lo>w.anchor and e.hi<=w.deadline and e.hi<=frontier then positive=true;lead=math.min(lead or math.huge,e.lo-w.anchor) else ambiguous=true end
    end end
    eq(w.y[f],positive and 1 or 0,'ledger target');eq(w.lead[f],lead,'ledger lead')
    eq(w.mask[f],positive or (w.coverage[f] and not lost[f] and not ambiguous) or false,'ledger mask');checks=checks+1
   end
  end end
 end
 local function observe(t) frontier=math.max(frontier,t);context(c,'clock',t,'hostile') end
 for episode=1,4 do
  local start=episode*20;frontier=start
  for i=1,16 do context(c,'P'..i,start) end;c:Tick(start,true)
  for _,actor in pairs(c.actors) do if actor.window then windows[actor.window.id]={lost={}} end end
  observe(start+.125);for i=1,16 do context(c,'R'..i,start+.125,'hostile') end
  for step=1,750 do
   if step%17==0 then observe(start+.125+step/750*2.5) else
    local id='e'..draw(170);local previous=ledger[id]
    local lo=start-1+draw(40)/10;local hi=lo+(draw(4)==1 and .5 or 0)
    local e={actor='P'..draw(16),lo=lo,hi=hi,at=(lo+hi)/2,f=draw(6),retracted=draw(9)==1,rev=previous and previous.rev+1 or 1,latest=math.max(hi,previous and previous.latest or hi)}
    local expected=previous~=nil or lo>floor
    if not previous and lo<=floor then
     for _,w in ipairs(c.examples) do if not w.sealed and overlap(w,e) then windows[w.id].lost[e.f]=true end end
    elseif not previous then
     if #order==128 then
      local old=ledger[table.remove(order,1)];floor=math.max(floor,old.latest);evictions=evictions+1
      for _,w in ipairs(c.examples) do if not w.sealed and overlap(w,old) then windows[w.id].lost[old.f]=true end end
      ledger[old.id]=nil
     end
     order[#order+1]=id
    end
    local ok=cast(c,id,e.actor,e.at,e.f,e.rev,e.lo,e.hi,e.retracted);eq(ok,expected,'ledger acceptance')
    if expected then e.id=id;ledger[id]=e end
   end
   verify()
  end
  observe(start+4);verify();c:ResetSession(start+4);ledger={};order={};floor=-1
  for _,w in ipairs(c.examples) do assert(w.sealed and not w.actor and not w.id and not w.coverage and not w.lost) end
 end
 assert(evictions>0)
 return tostring(checks)..' row/head oracle comparisons across 3000 operations and '..tostring(evictions)..' evictions. Includes intervals, maturity, actor/family/time corrections, stale replay, retractions and four resets.'
end)
return results
