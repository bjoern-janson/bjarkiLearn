-- Independent host model: modules and the positive-aura bus are actual source.
World={now=10,combat=true,unitCombat=true,ids={player='Player-1-100',target='Player-1-200',focus='Player-1-300'},classes={player='DRUID',target='ROGUE',focus='MAGE'},frames={},chat={}}
Opaque=setmetatable({}, {__tostring=function() error('opaque formatted') end,__index=function() error('opaque indexed') end})
Inaccessible=setmetatable({}, {__tostring=function() error('inaccessible formatted') end,__index=function() error('inaccessible indexed') end})
SecretValues={};InaccessibleValues={}
issecretvalue=function(v) return rawequal(v,Opaque) or SecretValues[v]==true end
issecrettable=function(v) return rawequal(v,Opaque) end
canaccessvalue=function(v) return not rawequal(v,Inaccessible) and InaccessibleValues[v]~=true end
GetTime=function() return World.now end
InCombatLockdown=function() return World.combat end
UnitGUID=function(u) return World.ids[u] end
UnitIsPlayer=function(u) return World.ids[u]~=nil end
UnitClassBase=function(u) return World.classes[u] end
UnitCanAttack=function(_,u) return u~='player' end
UnitAffectingCombat=function() return World.unitCombat end
UnitHealth=function() return 75 end
UnitHealthMax=function() return 100 end
UnitPower=function() return 50 end
UnitPowerMax=function() return 100 end
UnitIsDeadOrGhost=function() return false end
UnitPowerType=function() return 0,'MANA' end
SlashCmdList={}
DEFAULT_CHAT_FRAME={AddMessage=function(_,s) World.chat[#World.chat+1]=s end}
CreateFrame=function()
 local f={scripts={},events={}}
 function f:RegisterEvent(e)
  local outcome=REGISTRATION and REGISTRATION[e]
  if outcome=='throws' then error('modeled native event registration failure') end
  if outcome=='false' then return false end
  if outcome=='opaque' then return Opaque end
  if outcome=='inaccessible' then return Inaccessible end
  if outcome=='number' then return 1 end
  if outcome=='string' then return 'true' end
  self.events[e]=true
  if outcome=='true' then return true end
 end
 function f:SetScript(k,v) self.scripts[k]=v end
 World.frames[#World.frames+1]=f;return f
end
function LoadAddon()
 local ns={}
 BjarkiLearn=nil
 for _,file in ipairs({'Bootstrap.lua','Rules.lua','Network.lua','Core.lua','Adapter.lua','Main.lua'}) do assert(loadfile(LEARN_ROOT..'/'..file))('bjarkiLearn',ns) end
 NS=ns;Runtime=ns.Runtime
end
LoadAddon()
function Check(v,s) CHECKS=(CHECKS or 0)+1;if not v then error(s or 'check failed',2) end end
function Equal(a,b,s) Check(a==b,(s or 'equal')..': '..tostring(a)..' ~= '..tostring(b)) end
function Deep(a,b,path)
 path=path or '';Equal(type(a),type(b),path)
 if type(a)~='table' then Equal(a,b,path);return end
 for k,v in pairs(a) do Deep(v,b[k],path..'.'..tostring(k)) end
 for k in pairs(b) do Check(a[k]~=nil,path..' extra '..tostring(k)) end
end
function Event(e,...)
 if Runtime.frame.events[e] then Runtime.frame.scripts.OnEvent(Runtime.frame,e,...);return true end
 return false
end
function Init() Check(Event('ADDON_LOADED','bjarkiLearn'));Check(Runtime.initialized);Check(not Runtime.faulted) end
function Advance(t) World.now=t;Runtime.frame.scripts.OnUpdate(Runtime.frame,.1) end
function AtCast(t,u,id,spell) World.now=t;Check(Event('UNIT_SPELLCAST_SUCCEEDED',u,id,spell));Check(not Runtime.faulted) end
function Finish(t) for i=1,9 do Advance(t+i*.25) end end
function PlayerExample(n)
 n=n or 1;for _,w in ipairs(Runtime.core.examples) do if w.regime=='player' then n=n-1;if n==0 then return w end end end
end
function LoadBus() assert(loadfile(BUS_PATH))('bjarkiPortraits',{}) end
function Aura(id,at,actor,expiry)
 return {source='bjarkiPortraits',kind='aura-positive',isHelpful=true,recipientGUID=actor or World.ids.target,unit='target',spellId=5277,auraInstanceID=id,observedAt=at or World.now,duration=10,expirationTime=expiry or at+10,newApplication=false}
end
function Publish(id,at,actor,expiry) return BjarkiEvidenceV1:Publish(Aura(id,at,actor,expiry)) end
function NoScores(f) for _,o in ipairs(f.outputs) do Equal(o.score,nil);Equal(o.linear,nil);Equal(o.frequency,nil) end end
function TrainToDone()
 World.combat=false;World.unitCombat=false
 for i=1,4000 do Advance(World.now+.1);if not Runtime.core.dirty and not Runtime.core.candidate then break end end
 Check(Runtime.core.model~=nil,'real model built');Check(not Runtime.core.dirty)
end
function RealTrainingHistory()
 Init()
 for n=1,10 do
  local t=10+(n-1)*3
  World.combat=true;World.unitCombat=true;Advance(t)
  if n<=2 then AtCast(t+.1,'player','training-'..n,22812) end
  for step=1,8 do Advance(t+step*.25) end
  World.combat=false;World.unitCombat=false;Advance(t+2.25)
 end
 TrainToDone()
end
