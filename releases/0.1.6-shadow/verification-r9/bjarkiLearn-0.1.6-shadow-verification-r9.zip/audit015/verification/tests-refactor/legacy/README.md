# Preserved regression execution for 0.1.5

`run.py` executes captured 0.1.4 test sources from disposable directories beneath `runs/`. The 76 original Python/Lua files remain byte-for-byte preserved; the former root `run_all.py` and `build_release.py` are read from `baseline-0.1.4/`. No compatibility fields or other shims are added to production code.

The nine exact-count replacement rules in `ADAPTATIONS` change 12 private field reads across five copied fixtures. Expected values, assertions, event inputs, timestamps, and exclusions remain unchanged. Direct retained-history assertions use `_Evidence(actor)` because the former private mirror represented an unrestricted ledger projection. Native and adapter aura assertions use `GetContext` at their existing observed clocks. The public-copy isolation assertion obtains a second public projection at exactly the first projection's query time.

| Preserved fixture | Reads adapted | Replacement intent |
| --- | ---: | --- |
| `review-core/probe_core.py` | 2 | Both actors' unrestricted history after reattribution |
| `review-adapter/probe.lua` | 2 | Public aura witness at existing `now` |
| `audit-controls/new-corrections/run_corrections.py` | 1 | Unrestricted corrected history alongside immutable original input |
| `audit-0.1.2/native/run.py` | 3 | Public aura witness at existing `World.now` |
| `audit-0.1.3/audit/core/probes.lua` | 4 | Three unrestricted absence checks and one second public copy |

Only affected digest entries in three staged manifests are updated. The outer JSON report lists every exact expression replacement, original/staged SHA-256, and manifest update. Historical child reports retain old field names such as `fixture_original_bytes_verified`; within those child reports, these fields refer to the staged execution copies. The outer `original_test_sources_unchanged` and original hash inventory establish preservation of the actual originals.

The unchanged former `run_all.py` still executes and identifies the same six superseded future-positive assertions. It requires the same cases and Lua engines to fail and excludes them from the 663 current scenario executions. No replacement rule touches those assertions or the existing normalized-clock controls.

## Reproduction

Install `requirements-test.txt` in the invoking Python environment, or pass `--lupa-path /path/to/dependencies`. Run from the verification bundle root:

```text
python tests-refactor/legacy/run.py --mode baseline-equivalence --source baseline-0.1.4/source/bjarkiLearn --output reports-0.1.5/legacy-baseline.json
python tests-refactor/legacy/run.py --mode full --source source/bjarkiLearn --output reports-0.1.5/legacy-current.json
```

Baseline equivalence executes all five affected suites twice against exact 0.1.4: original and adapted fixtures. It requires identical full scenario result structures (162 executions per variant, including the same four retired failures in those selected suites). This validates the assertion adaptations against the preserved implementation.

Full mode executes the unchanged former `run_all.py`, including its fresh 0.1.4 review, then the ten unchanged latest 0.1.4 audit files in `audit014/`. Their dependency layout is recreated in the staging directory. The latest audit covers 14 Core groups, 54 native groups, and 26 network/restore groups. Its integration runner has a fixed historical baseline path; a documented in-memory path and version-label redirect compares the exact 0.1.4 baseline against current source for eight native trace/reload comparisons. No assertion or trace is changed. The separate inherited 0.1.3 integration comparison remains intact.

The outer JSON embeds all inherited final JSON reports, the latest audit reports, source hashes, original preservation checks, and adaptation provenance. These JSON files can be packaged independently of `runs/`; scratch execution directories must be excluded from the delivery archive.

All results are offline Lua 5.1/Lua 5.4 executions using modeled WoW APIs. They do not establish live-client behavior or predictive utility.

For the recorded development run only, two documented prose clarifications landed after the test snapshot was taken. The outer summary therefore keeps `source_unchanged=false`, proves `runtime_source_unchanged=true`, and records exact before/after hashes and unified diffs under `source_doc_changes_during_execution`. `documentation_changes_only=true` requires exact recognition of those two substitutions. A fresh default full execution against the final bundle requires the entire source tree to remain unchanged. `--mode summarize --stage <completed-stage>` validates existing reports and snapshot hashes without rerunning Lua.
