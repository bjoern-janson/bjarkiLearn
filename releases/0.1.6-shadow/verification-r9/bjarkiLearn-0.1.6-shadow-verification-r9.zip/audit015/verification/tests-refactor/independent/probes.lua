-- Independent exact-state comparisons. No production methods are replaced.
-- _Resolve is used only to force bounded replay eviction with neutral rows.
local baseline, source = ...
local cases, rows = {}, {}
local assertions = 0
local function check(value, reason)
    assertions = assertions + 1
    assert(value, reason or "invariant failed")
end
local function eq(a,b,reason)
    check(a==b,(reason or "mismatch")..": "..tostring(a).." ~= "..tostring(b))
end
local function near(a,b,reason) check(math.abs(a-b)<1e-10,reason or "numeric invariant failed") end
local function deep(a,b,path)
    path=path or "$"
    if type(a)~=type(b) then error(path.." type "..type(a).." ~= "..type(b)) end
    if type(a)~="table" then
        if a~=b then error(path.." "..tostring(a).." ~= "..tostring(b)) end
        return 1
    end
    local count=0
    for key,value in pairs(a) do count=count+deep(value,b[key],path.."."..tostring(key)) end
    for key in pairs(b) do if a[key]==nil then error(path.." unexpected key "..tostring(key)) end end
    return count
end
local function test(name,fn) cases[#cases+1]={name=name,fn=fn} end
local function core(ns) local c=ns.Core.New(); c:SetCoverage(true); return c end
local function context(c,id,t,role,options)
    local raw={actor=id,at=t,class="PRIEST",role=role or "self",combat=true,health=.8,power=.6,bound=true}
    for key,value in pairs(options or {}) do raw[key]=value end
    local actor,reason=c:Context(raw); check(actor~=nil,reason); return actor
end
local function cast(c,id,actor,t,family,revision,lo,hi,retracted)
    return c:Cast({id=id,actor=actor,at=t,family=family or 1,revision=revision or 1,
        minAt=lo,maxAt=hi,retracted=retracted})
end
local function aura(c,id,actor,t,spell,expires,fresh)
    return c:Aura({id=id,recipient=actor,at=t,spellID=spell or 22812,expires=expires,newApplication=fresh})
end
local function open(c,id,t,role)
    context(c,id,t,role); c:Tick(t,true); return assert(c.actors[id].window)
end
local function retire(c,t)
    for i=1,16 do context(c,"capacity"..i,t,"hostile") end
    eq(c.actors.P,nil,"actor actually retired")
end
local function train(c,mark)
    for i=1,1100 do
        c:Tick(c.now,false)
        if mark and (i<=3 or not c.dirty) then mark("train"..i,c) end
        if not c.dirty then break end
    end
    check(c.model~=nil and c.candidate==nil and not c.dirty,"completed trained model")
    return c.model
end
local function oneRow(ns)
    local c=core(ns); local w=open(c,"P",10)
    context(c,"P",11); check(cast(c,"one","P",11,1))
    c:Tick(12.25,nil); eq(#c.examples,1); return c,w
end
local function filler(ns,c,w,n)
    for i=1,n do
        local item={actor="filler",anchor=0,deadline=2,regime="other",x=ns.Copy(w.x),coverage={},lost={}}
        for f=1,6 do item.coverage[f]=false end
        c:_Resolve(item)
    end
end

test("fixed_resource_and_schema_contract",function(ns,mark)
    eq(ns.Config.maxActors,16); eq(ns.Config.maxOccurrences,128); eq(ns.Config.maxExamples,256)
    eq(ns.Config.featureCount,48); eq(ns.Config.hiddenCount,12); eq(ns.Config.outputCount,6)
    eq(ns.Config.horizon,2); eq(ns.Config.grace,.25); eq(ns.Config.epochs,4); eq(ns.Config.stepsPerTick,4)
    eq(ns.Config.compat,"learn1/forever16001-provisional1/features48-v1/cast-delivery-v1/h2/player-combat-v1/mlp12-sgd4-v1")
    mark("new",core(ns))
end)

test("actor_revision_and_cached_forecast_invalidation",function(ns,mark)
    local c=core(ns); local a=context(c,"P",10); eq(a.revision,2)
    c:Tick(10,nil); check(a.forecast~=nil); mark("initial",c)
    context(c,"P",10.1); eq(a.revision,2); check(a.forecast~=nil); mark("sameContext",c)
    check(cast(c,"one","P",10.1)); eq(a.revision,3); eq(a.forecast,nil); mark("cast",c)
    c:Tick(10.1,nil); local r=a.revision
    local ok,why=cast(c,"one","P",10.1); eq(ok,false); eq(why,"duplicate")
    eq(a.revision,r); check(a.forecast~=nil); mark("duplicate",c,{ok,why})
    check(aura(c,"a","P",10.1,22812,15)); eq(a.revision,r+1); eq(a.forecast,nil)
    c:Tick(10.1,nil); r=a.revision
    ok,why=aura(c,"a","P",10.1,22812,15); eq(ok,false); eq(why,"duplicate")
    eq(a.revision,r); check(a.forecast~=nil); mark("auraDuplicate",c,{ok,why})
    context(c,"P",10.2,nil,{bound=false}); eq(a.revision,r+1); eq(a.forecast,nil)
    context(c,"P",10.3,nil,{bound=false}); eq(a.revision,r+1)
    context(c,"P",10.4); eq(a.revision,r+2); mark("rebind",c)
end)

test("asof_cast_aura_projections_are_copied_and_pure",function(ns,mark)
    local c=core(ns); context(c,"P",10)
    check(cast(c,"past","P",9,1)); check(cast(c,"future","P",11,1))
    check(aura(c,"past","P",9,22812,15)); check(aura(c,"future","P",11,5277,16))
    c:Tick(10,true); eq(c.actors.P.forecast.expires,11)
    local before=ns.Copy(c)
    for _,t in ipairs({12,10,8,100,10}) do
        local p=c:GetContext("P",t); local f=c:Forecast("P",t)
        if t==10 then eq(p.history[1],9); eq(p.defensiveWitness.at,9) end
        if t==12 then eq(p.history[1],11); eq(p.defensiveWitness.at,11) end
        if t==8 then eq(p.history[1],nil); eq(p.defensiveWitness,nil) end
        p.history[1]=999; if p.defensiveWitness then p.defensiveWitness.at=999 end
        f.outputs[1].reason="consumer mutation"; c:Status().gapReasons.injected=true
    end
    deep(before,c); eq(c.evidenceTime,10); mark("pure",c,nil,{8,10,11,12,100})
    check(cast(c,"future","P",8,1,2)); eq(c:GetContext("P",10).history[1],9)
    check(cast(c,"past","P",12,1,2)); eq(c:GetContext("P",10).history[1],8)
    mark("retimed",c,nil,{8,10,12})
end)

test("reattribution_invalidates_old_and_new_actor",function(ns,mark)
    local c=core(ns); context(c,"P",10); context(c,"Q",10,"hostile")
    check(cast(c,"one","P",9,1)); c:Tick(10,nil)
    local p,q=c.actors.P.revision,c.actors.Q.revision
    check(c.actors.P.forecast and c.actors.Q.forecast)
    check(cast(c,"one","Q",9.5,2,2))
    eq(c.actors.P.revision,p+1); eq(c.actors.Q.revision,q+1)
    eq(c.actors.P.forecast,nil); eq(c.actors.Q.forecast,nil)
    eq(c:GetContext("P",10).history[1],nil); eq(c:GetContext("Q",10).history[2],9.5)
    mark("reattributed",c)
    check(cast(c,"one","absent",9.75,3,3)); eq(c.actors.Q.revision,q+2)
    context(c,"absent",10); eq(c:GetContext("absent",10).history[3],9.75)
    mark("recreated",c)
end)

test("lead_only_change_updates_lead_without_label_revision",function(ns,mark)
    local c,w=oneRow(ns); local corpus,revision=c.corpusRevision,w.revision
    local labels=c.stats.labelRevisions
    check(cast(c,"one","P",11.5,1,2))
    eq(w.y[1],1); eq(w.mask[1],true); eq(w.lead[1],1.5)
    eq(w.revision,revision); eq(c.corpusRevision,corpus); eq(c.stats.labelRevisions,labels)
    mark("leadOnlyUntrained",c)
    train(c,mark); corpus=c.corpusRevision; revision=w.revision
    check(cast(c,"one","P",11.25,1,3))
    eq(w.lead[1],1.25); eq(w.revision,revision); eq(c.model,nil)
    eq(c.corpusRevision,corpus+1); eq(c.stats.labelRevisions,labels)
    mark("leadOnlyWithdrawsDependentModel",c)
end)

test("no_op_correction_keeps_model_and_corpus",function(ns,mark)
    local c,w=oneRow(ns); local m=train(c,mark); local corpus=c.corpusRevision
    local ar=c.actors.P.revision; local wr=w.revision
    check(cast(c,"one","P",11,1,2))
    eq(c.model,m); eq(c.corpusRevision,corpus); eq(w.revision,wr)
    eq(c.actors.P.revision,ar+1); eq(c.actors.P.forecast,nil)
    mark("noopRevision",c)
end)

test("interval_boundaries_and_maturity",function(ns,mark)
    local c=core(ns); local w=open(c,"P",10)
    check(cast(c,"anchor","P",10,1)); check(cast(c,"crossStart","P",10.1,2,1,10,10.2))
    check(cast(c,"inside","P",11,3,1,10.8,11.2)); check(cast(c,"deadline","P",12,4))
    check(cast(c,"crossEnd","P",12,5,1,11.9,12.1)); check(cast(c,"after","P",12.1,6))
    retire(c,10.2); eq(w.y[1],0); eq(w.mask[2],false); eq(w.y[3],0)
    mark("before",c); c:Tick(11,nil); eq(w.y[3],0)
    c:Tick(11.2,nil); eq(w.y[3],1); near(w.lead[3],.8)
    c:Tick(12.1,nil); eq(w.y[4],1); eq(w.lead[4],2); eq(w.mask[5],false); eq(w.y[6],0)
    mark("mature",c)
end)

test("retired_actor_future_backdate_retraction_and_due",function(ns,mark)
    local c=core(ns); local w=open(c,"P",10); check(cast(c,"future","P",11,1))
    retire(c,10.2); eq(w.y[1],0); eq(w.mask[1],false); mark("retired",c)
    check(cast(c,"future","P",10.1,1,2)); eq(w.y[1],1); near(w.lead[1],.1)
    check(cast(c,"future","P",11.5,1,3)); eq(w.y[1],0)
    c:Tick(11,nil); eq(w.y[1],0); mark("oldDue",c)
    check(cast(c,"future","P",11.5,1,4,nil,nil,true)); c:Tick(11.5,nil); eq(w.y[1],0)
    check(cast(c,"future","P",11.5,1,5)); eq(w.y[1],1); eq(w.lead[1],1.5)
    mark("restoredDue",c)
end)

test("simultaneous_maturity_is_one_corpus_change",function(ns,mark)
    local c=core(ns); local w=open(c,"P",10)
    for i=1,120 do check(cast(c,"burst"..i,"P",11+(i%3)*.1,1+i%6)) end
    retire(c,10.2); local corpus=c.corpusRevision
    for f=1,6 do eq(w.y[f],0); eq(w.mask[f],false) end
    c:Tick(11.2,nil); eq(c.corpusRevision,corpus+1)
    for f=1,6 do eq(w.y[f],1); eq(w.mask[f],true) end
    mark("mature120",c)
end)

test("ordinary_cast_retirement_preserves_frozen_serving_model",function(ns,mark)
    local c,w=oneRow(ns); local m=train(c,mark); local saved=ns.Copy(m)
    for i=1,128 do check(aura(c,"filler"..i,"untracked",20+i,22812)) end
    eq(#c.occurrenceOrder,128); eq(c.occurrences["cast:one"],nil); eq(c.evidenceFloor,11)
    eq(w.y[1],0); eq(w.mask[1],false); eq(w.lost[1],true)
    eq(c.model,m); deep(saved,c.model); eq(c:Status().modelRefreshPending,true)
    mark("retiredFrozen",c)
    train(c,mark); check(c.model~=m); eq(c:Status().modelRefreshPending,false)
end)

test("aura_retirement_invalidates_actor_cache_without_dirtying_labels",function(ns,mark)
    local c,w=oneRow(ns); check(aura(c,"one","P",11,22812,16)); train(c)
    local m=c.model; local corpus=c.corpusRevision
    -- Cast retirement may dirty labels; isolate aura retirement itself next.
    for i=1,127 do check(aura(c,"f"..i,"other",20+i)) end
    train(c); m=c.model; corpus=c.corpusRevision
    context(c,"P",12.25); c:Tick(12.25,nil); local revision=c.actors.P.revision
    check(aura(c,"last","other",200))
    eq(c.occurrences["aura:P:one"],nil); eq(c.actors.P.revision,revision+1)
    eq(c.actors.P.forecast,nil); eq(c.model,m); eq(c.corpusRevision,corpus)
    mark("auraRetired",c)
end)

test("replay_eviction_guards_old_side_correction",function(ns,mark)
    local c,w=oneRow(ns); local m=train(c)
    filler(ns,c,w,256); eq(#c.examples,256); check(c.examples[1]~=w)
    eq(c.model,m); eq(#c.modelDependencies,1); mark("replayEvicted",c)
    check(cast(c,"one","Q",50,2,2)); eq(c.model,nil); eq(#c.modelDependencies,0)
    mark("oldSideWithdraw",c)
end)

test("replay_eviction_guards_new_side_correction",function(ns,mark)
    local c,w=oneRow(ns); check(cast(c,"outside","Q",50,2)); train(c)
    filler(ns,c,w,256); check(c.model~=nil)
    check(cast(c,"outside","P",11.5,2,2)); eq(c.model,nil); eq(#c.modelDependencies,0)
    mark("newSideWithdraw",c)
end)

test("replay_eviction_guards_future_maturity",function(ns,mark)
    local c=core(ns); local w=open(c,"P",10)
    context(c,"P",10.1); check(cast(c,"past","P",10.1,1)); check(cast(c,"due","P",11,2))
    retire(c,10.2); local m=train(c); filler(ns,c,w,256)
    eq(c.model,m); eq(#c.modelDependencies,1); mark("guarded",c)
    c:Tick(11,nil); eq(c.model,nil); eq(#c.modelDependencies,0); mark("dueWithdraw",c)
end)

test("unrelated_or_retracted_due_keeps_model",function(ns,mark)
    local c=core(ns); local w=open(c,"P",10)
    context(c,"P",10.1); check(cast(c,"past","P",10.1,1)); check(cast(c,"due","P",11,2))
    retire(c,10.2); check(cast(c,"due","P",11,2,2,nil,nil,true))
    check(cast(c,"unrelated","Q",11,3)); local m=train(c)
    local corpus=c.corpusRevision; c:Tick(11,nil)
    eq(c.model,m); eq(c.corpusRevision,corpus); eq(w.y[2],0); mark("nonAffectingDue",c)
end)

test("latestEver_floor_rejects_identity_replay_and_lost_revision",function(ns,mark)
    local c=core(ns); context(c,"P",10)
    check(cast(c,"one","P",100,1)); check(cast(c,"one","P",9,1,2))
    eq(c.occurrences["cast:one"].latestEver,100)
    for i=1,128 do check(aura(c,"a"..i,"other",110+i)) end
    eq(c.evidenceFloor,100); eq(c.occurrences["cast:one"],nil)
    local ok,reason=cast(c,"one","P",9,1); eq(ok,false); eq(reason,"outside_retained_history")
    mark("floorReject",c,{ok,reason})
    ok,reason=cast(c,"one","P",101,1,3); eq(ok,false); eq(reason,"revision_history_lost")
    eq(#c.occurrenceOrder,128); mark("lostRevision",c,{ok,reason})
end)

test("below_floor_attempt_withdraws_affected_model",function(ns,mark)
    local c,w=oneRow(ns); train(c)
    for i=1,128 do check(aura(c,"fill"..i,"other",20+i)) end
    check(c.model~=nil); local ok,why=cast(c,"forgotten","P",11,1)
    eq(ok,false); eq(why,"outside_retained_history"); eq(c.model,nil)
    eq(w.mask[1],false); mark("floorAffectsModel",c,{ok,why})
end)

test("lead_only_due_does_not_revise_same_labels",function(ns,mark)
    local c=core(ns); local w=open(c,"P",10)
    context(c,"P",10.5); check(cast(c,"known","P",10.5,1))
    check(cast(c,"later","P",11.5,1)); retire(c,10.6)
    local corpus,revision=c.corpusRevision,w.revision
    c:Tick(11.5,nil); eq(w.lead[1],.5); eq(w.revision,revision); eq(c.corpusRevision,corpus)
    mark("unchangedLabelsAndLead",c)
end)

test("training_candidate_exact_state_and_correction_cancellation",function(ns,mark)
    local c=core(ns)
    for i=1,12 do
        local t=10+i*3; open(c,"P",t)
        if i<=2 then context(c,"P",t+.5); check(cast(c,"p"..i,"P",t+.5,1)) end
        c:Tick(t+2.25,nil)
    end
    eq(#c.examples,12); c:Tick(c.now,false); check(c.candidate~=nil); mark("candidate4",c)
    c:Tick(c.now,false); check(c.candidate~=nil); mark("candidate8",c)
    local corpus=c.corpusRevision; check(cast(c,"p1","P",13.5,2,2))
    eq(c.candidate,nil); eq(c.corpusRevision,corpus+1); mark("cancelled",c)
    train(c,mark); eq(c.model.totals[1],12); eq(c.model.positives[1],1)
    context(c,"P",50); c:Tick(50,true); mark("trainedProjection",c)
end)

test("supported_scores_prequential_metrics_and_public_copy",function(ns,mark)
    local c=core(ns)
    for i=1,12 do
        local t=i*3; open(c,"P",t)
        if i<=3 then context(c,"P",t+.5); check(cast(c,"p"..i,"P",t+.5,1)) end
        c:Tick(t+2.25,nil)
    end
    train(c,mark); context(c,"P",40); c:Tick(40,true)
    local f=c:Forecast("P",40); check(f.outputs[1].score~=nil); eq(f.usable,false)
    eq(f.outputs[1].usable,false); eq(f.outputs[1].calibrated,false)
    f.outputs[1].score=999; check(c:Forecast("P",40).outputs[1].score<=1)
    context(c,"P",40.5); check(cast(c,"scored","P",40.5,1)); c:Tick(42.25,nil)
    eq(c:Status().families[1].scored,1); check(c:Status().families[1].neuralLoss>=0)
    mark("scored",c,nil,{40,40.5,42.25})
end)

test("reset_seals_rows_and_clears_transient_guards",function(ns,mark)
    local c,w=oneRow(ns); local m=train(c); local export=c:Export()
    context(c,"P",13); c:Tick(13,true); check(cast(c,"future","P",14,2))
    local pending=c.actors.P.window; c:GetContext("P",100); c:Forecast("P",100)
    c:ResetSession(13.2); eq(pending.y[2],0); eq(pending.mask[2],false)
    eq(c.model,m); eq(#c.modelDependencies,0); eq(#c.actorOrder,0); eq(#c.occurrenceOrder,0)
    for _,row in ipairs(c.examples) do eq(row.sealed,true); eq(row.actor,nil); eq(row.coverage,nil); eq(row.lost,nil) end
    deep(export.examples[1],c:Export().examples[1]); mark("sealed",c)
    context(c,"P",14); check(cast(c,"one","P",11,2))
    deep(export.examples[1],c:Export().examples[1]); mark("newSessionCannotReviseSealed",c)
end)

test("rollback_uses_observed_frontier_before_clearing",function(ns,mark)
    local c=core(ns); local w=open(c,"P",10)
    context(c,"P",11); check(cast(c,"one","P",11,1)); check(cast(c,"future","P",12,2))
    c:Tick(5,nil); eq(w.y[1],1); eq(w.y[2],0); eq(w.mask[2],false)
    eq(w.sealed,true); eq(c.evidenceTime,5); eq(c.nextCastAt,nil)
    mark("rollback",c)
end)

test("restore_validates_atomically_and_rebuilds_sealed_rows",function(ns,mark)
    local c=core(ns); local origin,w=oneRow(ns); local saved=origin:Export()
    local ok,why=c:Restore(saved); eq(ok,true); eq(#c.examples,1); eq(c.examples[1].sealed,true)
    saved.examples[1].x[1]=999; check(c.examples[1].x[1]~=999)
    train(c,mark); local before=ns.Copy(c)
    local bad=origin:Export(); bad.examples[3]=ns.Copy(bad.examples[1])
    ok,why=c:Restore(bad); eq(ok,false); eq(why,"invalid_examples"); deep(before,c)
    mark("invalidSparseAtomic",c,{ok,why})
    context(c,"P",20); c:Tick(20,true); ok,why=c:Restore(origin:Export())
    eq(ok,true); eq(c.model,nil); eq(c.candidate,nil); eq(#c.actorOrder,0); eq(#c.occurrenceOrder,0)
    eq(#c.modelDependencies,0); mark("restoreReplacesRuntime",c); train(c,mark)
end)

test("actor_capacity_tie_order_pause_and_reappearance",function(ns,mark)
    local c=core(ns); local w=open(c,"P",10)
    for i=1,15 do context(c,"A"..i,10,"hostile") end
    context(c,"overflow",10,"hostile"); eq(c.actors.P,nil); eq(#c.actorOrder,16)
    eq(c.openAfter,12.25); eq(c.examples[1],w); mark("tieEviction",c)
    context(c,"P",10.2); c:Tick(10.2,true); eq(c.actors.P.window,nil)
    context(c,"P",12.25); c:Tick(12.25,true); check(c.actors.P.window~=nil)
    eq(c.actors.P.window.anchor,12.25); mark("afterPause",c)
end)

test("aura_revision_expiry_and_future_projection",function(ns,mark)
    local c=core(ns); context(c,"P",10)
    check(aura(c,"a","P",9,22812,15)); check(aura(c,"a","P",10,22812))
    eq(c:GetContext("P",10).defensiveWitness.expires,15)
    check(aura(c,"a","P",11,22812,nil,true))
    eq(c:GetContext("P",10).defensiveWitness,nil)
    eq(c:GetContext("P",11).defensiveWitness.expires,nil)
    local ok,why=aura(c,"a","P",10,22812,16); eq(ok,false); eq(why,"stale_aura")
    mark("auraRevisions",c,{ok,why},{10,11,20})
end)

test("deterministic_mixed_public_trace",function(ns,mark)
    local c=core(ns); local seed=7319; local now=1; local revisions={}
    local function rand(n) seed=(seed*16807)%2147483647; return seed%n+1 end
    local results={}
    for i=1,720 do
        local action=rand(10); local actor="R"..rand(21); now=now+.125
        if action<=3 then
            local a,why=c:Context({actor=actor,at=now,class=({"PRIEST","DRUID","WARRIOR"})[rand(3)],
                role=rand(3)==1 and "self" or "hostile",combat=rand(5)~=1,bound=rand(9)~=1,
                health=rand(10)/10,power=rand(10)/10,form=rand(2)==1 and "cat" or nil})
            results[#results+1]={action,a~=nil,why}
        elseif action<=6 then
            local id="C"..rand(170); revisions[id]=(revisions[id] or 0)+1
            local t=now+(rand(12)-6)*.125; local rev=revisions[id]
            local ok,why=cast(c,id,actor,t,rand(6),rev,nil,nil,rand(11)==1)
            results[#results+1]={action,ok,why}
        elseif action==7 then
            local ok,why=aura(c,"A"..rand(100),actor,now+(rand(5)-3)*.25,rand(2)==1 and 22812 or 5277,now+5)
            results[#results+1]={action,ok,why}
        elseif action==8 then c:Tick(now,rand(3)~=1)
        elseif action==9 then c:Gap("trace_gap",rand(2)==1 and actor or nil)
        else c:SetCoverage(rand(3)~=1) end
        if i%24==0 then mark("trace"..i,c,results,{now-1,now,now+2}); results={} end
        if i==360 then c:ResetSession(now); mark("traceReset",c) end
    end
    c:Tick(now+3,nil); mark("traceFinal",c)
end)

test("native_adapter_cast_aura_aliases_and_reset",function(ns,mark)
    local units={player="Player-1-P",target="Player-1-Q",focus="Player-1-P"}
    local clock=10
    UnitGUID=function(unit) return units[unit] end
    UnitIsPlayer=function(unit) return units[unit]~=nil end
    UnitClassBase=function(unit) return unit=="target" and "DRUID" or "PRIEST" end
    UnitCanAttack=function(_,unit) return unit=="target" end
    UnitAffectingCombat=function() return true end
    UnitHealth=function() return 80 end; UnitHealthMax=function() return 100 end
    UnitPower=function() return 70 end; UnitPowerMax=function() return 100 end
    UnitIsDeadOrGhost=function() return false end
    UnitPowerType=function() return 3,"ENERGY" end
    GetTime=function() return clock end
    local c=ns.Core.New(); local a=ns.Adapter.New(c); a:SetRegistered(true); a:Tick(clock); c:Tick(clock,true)
    local w=c.actors["Player-1-P"].window
    eq(c.actors["Player-1-P"].role,"self"); eq(c.actors["Player-1-Q"].form,"cat")
    clock=10.1; a:OnEvent("UNIT_SPELLCAST_SUCCEEDED","player","native1",8122)
    eq(c.now,10); eq(c.evidenceTime,10.1); eq(c:GetContext("Player-1-P",clock).history[1],10.1)
    a:OnEvent("UNIT_SPELLCAST_SUCCEEDED","focus","native1",8122)
    eq(c.stats.casts,1); eq(c.stats.duplicateCasts,1); eq(a.stats.casts,2)
    a:OnAura({source="bjarkiPortraits",kind="aura-positive",isHelpful=true,recipientGUID="Player-1-P",
        spellId=22812,observedAt=10.1,expirationTime=15,auraInstanceID=123})
    a:OnAura({source="bjarkiPortraits",kind="aura-positive",isHelpful=true,recipientGUID="Player-1-P",
        spellId=5277,observedAt=11,expirationTime=16,auraInstanceID=124})
    eq(c:GetContext("Player-1-P",10.1).defensiveWitness.spellID,22812)
    mark("nativeDelivery",c,{adapter=a:Status(),bindings=ns.Copy(a.bindings)},{10,10.1,11})
    units.focus=nil; clock=10.2; a:OnEvent("PLAYER_FOCUS_CHANGED")
    eq(c.actors["Player-1-P"].bound,true)
    units.target="Player-1-R"; a:OnEvent("PLAYER_TARGET_CHANGED")
    eq(c.actors["Player-1-Q"].bound,false); eq(c.actors["Player-1-R"].bound,true)
    mark("aliasLossAndTargetChange",c,{adapter=a:Status(),bindings=ns.Copy(a.bindings)})
    a:OnEvent("PLAYER_ENTERING_WORLD")
    eq(w.sealed,true); eq(w.y[1],1); eq(w.y[6],0); eq(#c.occurrenceOrder,0)
    mark("nativeWorldReset",c,{adapter=a:Status(),bindings=ns.Copy(a.bindings)})
end)

test("replay_and_model_dependency_capacity_saturate_at_256",function(ns,mark)
    local c=core(ns)
    for i=1,260 do
        local t=i*3; open(c,"P",t); c:Tick(t+2.25,nil)
        if i%64==0 then mark("retained"..i,c) end
    end
    eq(#c.examples,256); eq(c.examples[1].anchor,15)
    train(c,mark); eq(#c.modelDependencies,256); eq(c.modelExamples,256)
    local m=c.model; open(c,"P",783); c:Tick(785.25,nil)
    eq(#c.examples,256); eq(c.examples[1].anchor,18); eq(#c.modelDependencies,256)
    eq(c.model,m); mark("guardAtFullCapacity",c)
    check(cast(c,"oldWindowNewEvidence","P",15.5,1))
    eq(c.model,nil); eq(#c.modelDependencies,0); mark("evictedFirstDependencyWithdraws",c)
end)
-- Both implementations use the same interpreter, isolating source differences
-- from Lua-version differences. Only two explicit actor mirror fields are masked.
for _,case in ipairs(cases) do
    local snapshots={}; local row={name=case.name,passed=false,checkpoints=0,equalLeaves=0,
        modelSnapshots=0,candidateSnapshots=0}; assertions=0
    local function run(ns,isBaseline)
        local index=0
        local function mark(label,c,result,times)
            index=index+1
            check(#c.actorOrder<=16,"actor cap"); check(#c.occurrenceOrder<=128,"occurrence cap")
            check(#c.examples<=256,"replay cap"); check(#c.modelDependencies<=256,"model descriptor cap")
            local count=0; for _ in pairs(c.actors) do count=count+1 end; eq(count,#c.actorOrder,"actor registry/order")
            count=0; for _ in pairs(c.occurrences) do count=count+1 end; eq(count,#c.occurrenceOrder,"occurrence registry/order")
            local untouched=ns.Copy(c)
            local state=ns.Copy(c)
            for _,actor in pairs(state.actors) do actor.history=nil; actor.defensiveWitness=nil end
            local status=c:Status(); status.version="VERSION_ONLY"
            local projections={}
            for _,id in ipairs(c.actorOrder) do
                local item={id=id,queries={}}
                for _,t in ipairs(times or {c.now,c.evidenceTime}) do
                    item.queries[#item.queries+1]={at=t,context=c:GetContext(id,t),forecast=c:Forecast(id,t)}
                end
                projections[#projections+1]=item
            end
            local shot={label=label,core=state,status=status,export=c:Export(),public=projections,result=ns.Copy(result)}
            deep(untouched,c,"query purity")
            if isBaseline then snapshots[index]=shot
            else
                check(snapshots[index]~=nil,"unexpected checkpoint")
                row.equalLeaves=row.equalLeaves+deep(snapshots[index],shot,case.name.."/"..label)
                row.checkpoints=row.checkpoints+1
                if c.model then row.modelSnapshots=row.modelSnapshots+1 end
                if c.candidate then row.candidateSnapshots=row.candidateSnapshots+1 end
            end
        end
        debugprofilestop=nil
        case.fn(ns,mark)
        if not isBaseline then eq(index,#snapshots,"checkpoint count") end
    end
    local ok,reason=pcall(function() run(baseline,true); run(source,false) end)
    row.passed=ok; row.error=not ok and tostring(reason) or nil; row.assertions=assertions
    rows[#rows+1]=row
end
return rows

