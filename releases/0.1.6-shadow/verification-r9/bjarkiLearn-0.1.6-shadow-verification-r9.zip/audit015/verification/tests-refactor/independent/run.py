"""Independent exact-state differential traces for the 0.1.5 Core refactor.

No module source is rewritten or monkey patched. Baseline Core is pinned to the
installed 0.1.4 artifact. Python 3 + lupa (lua51 and lua54) are the only deps.
"""
import argparse
import hashlib
import importlib
import json
import sys
from pathlib import Path

BASELINE_CORE = "9dc55ae29fd69e76448bd8c83e8386edbaa1bff00009dbd98dc8532678c4dc01"
MODULES = ("Bootstrap.lua", "Rules.lua", "Network.lua", "Core.lua", "Adapter.lua")
BASELINE_LUA = {
    "Adapter.lua": "8d202f577b5c0abce58e7655e56b37597ccb17f465233333952614370a614c88",
    "Bootstrap.lua": "68eea6fe6651c8e480d7d9f2ec45c7421cd048521a7b5d44ba4b3ae7b60988e6",
    "Core.lua": BASELINE_CORE,
    "Main.lua": "3d468590005b81484af4d548f54bf41d561165d3762c6142931e87df8596052e",
    "Network.lua": "49668680ce13803c329a816f76863b04bb752cb07e5d2759cf7076af05165c49",
    "Rules.lua": "4456d77323afc59c3946abd3b3037648b137004ff9d9036e892065e039ef602c",
}


def hashes(root):
    return {str(p.relative_to(root)).replace("\\", "/"): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(root.rglob("*")) if p.is_file()}


def plain(value):
    if hasattr(value, "items"):
        return {str(key): plain(item) for key, item in value.items()}
    return value


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", required=True, type=Path)
    parser.add_argument("--baseline", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--lupa-path", type=Path)
    args = parser.parse_args()
    if args.lupa_path:
        sys.path.insert(0, str(args.lupa_path))
    roots = {"source": args.source.resolve(), "baseline": args.baseline.resolve()}
    before = {name: hashes(root) for name, root in roots.items()}
    for name, digest in BASELINE_LUA.items():
        assert before["baseline"][name] == digest, f"Baseline is not exact 0.1.4: {name}"
    rows = []
    probe = Path(__file__).with_name("probes.lua").read_text(encoding="utf-8")
    for engine in ("lua51", "lua54"):
        lua = importlib.import_module("lupa." + engine).LuaRuntime(unpack_returned_tuples=True)
        namespaces = {}
        for name, root in roots.items():
            ns = lua.table()
            for module in MODULES:
                lua.execute((root / module).read_text(encoding="utf-8"), "bjarkiLearn", ns)
            namespaces[name] = ns
        cases = lua.execute(probe, namespaces["baseline"], namespaces["source"])
        for index in range(1, len(cases) + 1):
            row = plain(cases[index])
            row["runtime"] = engine
            rows.append(row)
    after = {name: hashes(root) for name, root in roots.items()}
    counts = {"cases": len(rows), "passed": sum(bool(row["passed"]) for row in rows)}
    for name in ("checkpoints", "equalLeaves", "assertions", "modelSnapshots", "candidateSnapshots"):
        counts[name] = sum(row.get(name, 0) for row in rows)
    report = {
        "scope": "Offline exact-state 0.1.4/0.1.5 equivalence plus independent invariants; no live WoW claim.",
        "baseline_core_pin": BASELINE_CORE,
        "comparison": "Exact scalar equality, own table state and keys; no tolerance. Only actor.history and actor.defensiveWitness are removed from core copies; only Status.version is normalized.",
        "roots": {name: str(root) for name, root in roots.items()},
        "hashes_before": before, "hashes_after": after,
        "source_unchanged": before == after,
        "counts": counts, "cases": rows,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps({"counts": counts, "source_unchanged": before == after,
                      "failures": [row for row in rows if not row["passed"]]}, indent=2))
    return int(before != after or counts["cases"] != counts["passed"])


if __name__ == "__main__":
    raise SystemExit(main())

