local ns=...
local c=ns.Core.New()
local saved={schema=ns.Config.schema,compat=ns.Config.compat,examples={}}
local actor={class='PRIEST',role='self',regime='player',combat=true,bound=true,history={}}
local x=ns.Rules.Features(actor,0)
for n=1,255 do
 local y,mask={},{}
 for i=1,6 do y[i]=0;mask[i]=true end
 saved.examples[n]={x=x,y=y,mask=mask,regime='player'}
end
assert(c:Restore(saved));c:SetCoverage(true)
local function ctx(t,id,role)
 c:Context({actor=id,at=t,role=role,class='PRIEST',combat=true,bound=true})
end
ctx(10,'Player-1-100','self');ctx(10,'Player-1-200','hostile');c:Tick(10,true)
assert(c:Cast({actor='Player-1-100',id='self-reset',at=11,family=1}))
assert(c:Cast({actor='Player-1-200',id='other-reset',at=11,family=2}))
c:ResetSession(11)
local order=c.examples[255].regime..','..c.examples[256].regime
for n=1,255 do
 local t=20+n*3;ctx(t,'Player-1-100','self');c:Tick(t,true)
 if n<=2 then assert(c:Cast({actor='Player-1-100',id='new-positive-'..n,at=t+1,family=1})) end
 c:Tick(t+2.25,true)
end
for n=1,260 do c:Tick(1000,false) end
assert(c.model and not c.dirty)
local stat=c:Status()
return {order=order,trainingExamples=stat.trainingExamples,positive=stat.families[1].positive,negative=stat.families[1].negative,
 modelExamples=stat.modelExamples,score=c.model:Predict(x).neural[1],remainingOldRegime=c.examples[1].regime}
