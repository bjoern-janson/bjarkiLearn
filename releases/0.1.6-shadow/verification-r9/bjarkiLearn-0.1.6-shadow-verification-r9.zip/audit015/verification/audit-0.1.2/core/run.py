import argparse
import json
import sys
from pathlib import Path
sys.path.insert(0, r'C:/Users/Mewn/Documents/Codex/2026-10-16/let/work/deps')
p = argparse.ArgumentParser()
p.add_argument('--source', required=True, type=Path)
p.add_argument('--output', required=True, type=Path)
a = p.parse_args()
root = Path(__file__).resolve().parent
results = []
for engine in ('lua51', 'lua54'):
    module = __import__('lupa.' + engine, fromlist=['LuaRuntime'])
    lua = module.LuaRuntime(unpack_returned_tuples=True)
    ns = lua.table()
    for filename in ('Bootstrap.lua', 'Rules.lua', 'Network.lua', 'Core.lua'):
        lua.execute((a.source / filename).read_text(encoding='utf-8'), 'bjarkiLearn', ns)
    cases = lua.execute((root / 'probes.lua').read_text(encoding='utf-8'), ns)
    for _, row in cases.items():
        results.append(dict(runtime=engine, name=row['name'], passed=bool(row['passed']), detail=row['detail'], error=row['error']))
a.output.parent.mkdir(parents=True, exist_ok=True)
a.output.write_text(json.dumps(results, indent=2), encoding='utf-8')
print(json.dumps(results, indent=2))
raise SystemExit(any(not row['passed'] for row in results))
