import argparse,json,sys,importlib
from pathlib import Path
try: import lupa
except ImportError:sys.path.insert(0,r'C:/Users/Mewn/Documents/Codex/2026-10-16/let/work/deps')
p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--runs',type=int,default=12);a=p.parse_args()
root=Path(__file__).resolve().parent
out=[]
for engine in ('lua51','lua54'):
 for n in range(a.runs):
  lua=importlib.import_module('lupa.'+engine).LuaRuntime(unpack_returned_tuples=True);ns=lua.table()
  for f in ('Bootstrap.lua','Rules.lua','Network.lua','Core.lua'):
   lua.execute((a.source/f).read_text(encoding='utf-8'),'bjarkiLearn',ns)
  row=dict(lua.execute((root/'reset_order.lua').read_text(encoding='utf-8'),ns).items());row.update(engine=engine,run=n)
  out.append(row)
a.output.write_text(json.dumps(out,indent=2),encoding='utf-8')
for engine in ('lua51','lua54'):
 variants={json.dumps({k:v for k,v in r.items() if k not in ('run','engine')},sort_keys=True) for r in out if r['engine']==engine}
 print(engine,'variants',len(variants))
 for v in sorted(variants):print(v)
