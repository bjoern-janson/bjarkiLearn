# Independent Core audit

No confirmed remaining bug or regression found in the reviewed Core learning, correction, retention, and lifecycle paths. This is a bounded source and executable Lua audit, not live WoW validation.

Reviewed the exact install source Core.lua in full, plus its Bootstrap, Rules, Main, Adapter, README and docs/IMPLEMENTATION contracts. Compared Core.lua against the exact 0.1.1 baseline: the sole 0.1.2 functional change is the collection-shape validation in Restore at lines 542-556. The correction, training, eviction and session lifecycle paths are unchanged.

New portable --source/--output runner: run.py; executable Lua cases: probes.lua. Results: results-0.1.2.json and results-0.1.1.json. Six composed scenarios passed under both actual Lua 5.1 and 5.4 runtimes for each version, 24 case executions total. These execute source Core/Network methods, not copied implementations.

1. Correct an older training outcome while both a serving model and a partial replacement candidate exist. Both superseded generations disappear immediately. The corrected rebuild matches a fresh independent restore/replay exactly across neural, linear and frequency outputs.
2. Replace an exact positive with boundary-crossing uncertainty during partial candidate training. Both generations are withdrawn, and subsequent head statistics exclude exactly that masked label.
3. Keep two positives for one head, evict the first through the real 128-occurrence cap, then retract the remaining retained positive. The head remains supported while one exact positive survives; it becomes censored after retraction, rather than a false negative. Unrelated family negatives remain intact.
4. Lose and regain the actor binding during a pending window. Rebinding preserves one original lesson, an observed post-rebind positive is usable, and interrupted absence labels are censored.
5. Reset while a partial replacement is training and another window contains a positive but has not reached its deadline. Reset seals/deidentifies the lessons, cancels the superseded candidate, preserves the last serving model, and clean replay matches independent restore/replay exactly.
6. Retire 256 examples while combat prevents replacement, finish replacement, then revise an old occurrence whose lesson is outside the new corpus. The old serving model survives routine retirement, the registry is replaced on successful publication, and an obsolete correction cannot withdraw the new clean model.

Relevant source points: Core.lua 64-70 (candidate cancellation/withdrawal), 181-207 (correction dependencies and revised-label replay), 209-223 (occurrence retirement and loss masks), 344-354 (example retirement), 357-408 (candidate publication and generation registry), 512-527 (session sealing), and 536-577 (atomic restore).

Limits and non-findings:

- Immutable historical features are explicitly required by the anchor contract. Later occurrence/aura corrections do not rewrite old x vectors; that is intentional and not a defect.
- Core Cast correction APIs are private normalized-data operations. The current Main/Adapter native cast path supplies revision 1 at the current validated GetTime. These tests validate the supported internal correction mechanics, not a currently exposed external correction producer.
- An out-of-order future-timestamp private-Core injection is not demonstrated through Main/Adapter and is not reported as a product finding.
- Successful synthetic tests establish the exercised invariants only. They do not establish client event delivery, performance, or predictive usefulness.

Reproduce from the audit workspace using Python with Lupa installed:

    python audit/core/run.py --source source/bjarkiLearn --output audit/core/results-0.1.2.json
    python audit/core/run.py --source verification/baseline-0.1.1/source/bjarkiLearn --output audit/core/results-0.1.1.json

The runner's optional local dependency path is the supplied audit machine Lupa directory; installed Lupa also works when that directory is absent. No production source or pre-existing test file was edited.

## Follow-up: simultaneous reset resolution order

Root's native lifecycle differential observed export row order differences across separate Lua 5.4 states. Core.ResetSession resolves pending actors using pairs(self.actors) at lines 513-519, so simultaneous pending player and other windows can be appended in either order. The original 1800-step native trace had identical models, status and public projections; its differences were incidental export order.

A focused additional probe (reset_order.py and reset_order.lua) establishes that the order can eventually affect bounded FIFO retention. Starting with 255 compatible saved lessons, open one player and one hostile window at the same anchor, observe a positive for each, and reset at the same timestamp. Append 255 further player lessons, including two positives. Depending on reset order, the oldest surviving reset lesson is player or other:

- other,player leaves 256 eligible player lessons, 3 positives and 253 negatives. Completed neural prediction on the fixed input: 0.021232807662716947.
- player,other leaves 255 eligible player lessons, 2 positives and 253 negatives. Completed neural prediction: 0.010933261231142183.

Repeated actual Lua54 states observed both variants in exact 0.1.2 (12 runs) and exact 0.1.1 (6 runs). Lua51 observed only other,player in those runs. Results are preserved in reset-order-0.1.2.json and reset-order-0.1.1.json. The runner executes the actual source with --source and --output. No production files changed.

Classification: pre-existing collection-order nondeterminism and bounded FIFO sensitivity; not a confirmed 0.1.2 regression or contract violation. The two unfinished windows share an anchor and resolve time; their tie order is unspecified, no later window was discarded ahead of an earlier one, and deterministic clean replay of each actual retained ordered corpus remains satisfied. This distinction matters: numeric equality across independent collection runs is too strong an audit assertion when unordered simultaneous resolutions are included. At capacity the difference can become numerically material, so it should not be described as universally export-only.
