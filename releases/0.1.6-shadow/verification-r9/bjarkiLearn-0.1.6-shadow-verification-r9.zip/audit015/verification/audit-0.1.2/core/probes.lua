local ns=...
local cases={}
local function run(name,fn)
 local ok,detail=pcall(fn)
 cases[#cases+1]={name=name,passed=ok,detail=ok and detail or nil,error=not ok and tostring(detail) or nil}
end
local function ctx(c,t,id,bound)
 return c:Context({actor=id or 'P',at=t,role='self',class='PRIEST',combat=true,bound=bound~=false})
end
local function settle(c,t)
 for n=1,300 do c:Tick(t,false) end
 assert(c.model and not c.dirty and not c.candidate,'completed model')
end
local function warm()
 local c=ns.Core.New(); c:SetCoverage(true)
 for n=1,12 do
  local t=n*3; ctx(c,t); c:Tick(t,true)
  if n<=3 then assert(c:Cast({id='p'..n,actor='P',at=t+1,family=1})) end
  c:Tick(t+2.25,true)
 end
 settle(c,40)
 return c
end
local function samePrediction(a,b,x)
 local p,q=a:Predict(x),b:Predict(x)
 for _,name in ipairs({'neural','linear','frequency'}) do
  for i=1,6 do assert(p[name][i]==q[name][i],'deterministic rebuilt '..name..' '..i) end
 end
end
run('candidate withdrawn by correction on an older completed-model row',function()
 local c=warm(); local serving=c.model
 ctx(c,45); c:Tick(45,true); c:Tick(47.25,true)
 c:Tick(48,false); local candidate=c.candidate
 assert(candidate and c.model==serving,'serving preserved during candidate rebuild')
 assert(c:Cast({id='p1',actor='P',at=4,family=1,revision=2,retracted=true}))
 assert(c.candidate==nil and c.model==nil and c.dirty,'both generations withdrawn')
 local d=ns.Core.New(); assert(d:Restore(c:Export()))
 settle(c,49); settle(d,49)
 assert(c.model.positives[1]==2 and c.model.totals[1]==13)
 samePrediction(c.model,d.model,c.examples[1].x)
 return 'both serving and partial candidate removed; clean replay equals independent restored corpus'
end)
run('candidate invalidated when the same positive label becomes uncertain',function()
 local c=warm()
 ctx(c,45); c:Tick(45,true); c:Tick(47.25,true); c:Tick(48,false)
 assert(c.candidate,'partial candidate')
 assert(c:Cast({id='p2',actor='P',at=7,minAt=6,maxAt=7,family=1,revision=2}))
 assert(not c.model and not c.candidate,'superseded partial training removed')
 assert(not c.examples[2].mask[1] and c.examples[2].y[1]==0)
 settle(c,49)
 assert(c.model.positives[1]==2 and c.model.totals[1]==12,'masked head counts exactly')
 return 'uncertainty correction cancels partial training and excludes only its affected head'
end)
run('multi-positive eviction keeps supported label then censors lost remainder',function()
 local c=ns.Core.New(); c:SetCoverage(true); ctx(c,10); c:Tick(10,true)
 assert(c:Cast({id='first',actor='P',at=10.5,family=1}))
 assert(c:Cast({id='second',actor='P',at=11,family=1}))
 c:Tick(12.25,false); local w=c.examples[1]
 for n=1,127 do assert(c:Aura({recipient='Enemy',id='a'..n,at=13+n,spellID=22812})) end
 assert(not c.occurrences['cast:first'] and c.occurrences['cast:second'])
 assert(w.y[1]==1 and w.mask[1] and w.lost[1],'remaining exact positive retains outcome')
 assert(c:Cast({id='second',actor='P',at=11,family=1,revision=2,retracted=true}))
 assert(w.y[1]==0 and not w.mask[1],'forgotten positive cannot become absence')
 assert(w.mask[2] and w.y[2]==0,'other family unaffected')
 return 'eviction plus later retraction preserves unknown rather than creating a false negative'
end)
run('binding interruption preserves one window and later censors absence',function()
 local c=ns.Core.New(); c:SetCoverage(true); ctx(c,10); c:Tick(10,true)
 local w=c.actors.P.window
 ctx(c,10.5,'P',false); ctx(c,10.7); c:Tick(10.7,true)
 assert(c.actors.P.window==w and #c.examples==0,'rebind cannot duplicate live lesson')
 assert(c:Cast({id='observed-after-rebind',actor='P',at=11,family=1}))
 c:Tick(12.25,false)
 assert(#c.examples==1 and w.y[1]==1 and w.mask[1] and not w.mask[2])
 return 'same anchor survives rebind; observed positive usable and interrupted absences censored'
end)
run('reset halfway through training with pending partial window restarts replay',function()
 local c=warm(); local serving=c.model
 ctx(c,45); c:Tick(45,true); c:Tick(47.25,true); c:Tick(48,false)
 assert(c.candidate and c.model==serving)
 ctx(c,49); c:Tick(49,true)
 assert(c:Cast({id='before-reset',actor='P',at=49.5,family=2}))
 c:ResetSession(0)
 assert(c.candidate==nil and c.model==serving,'partial corpus resets candidate but keeps completed snapshot')
 local w=c.examples[#c.examples]
 assert(w.sealed and w.y[2]==1 and w.mask[2] and not w.mask[1])
 assert(#c.actorOrder==0 and #c.occurrenceOrder==0 and #c.modelDependencies==0)
 local d=ns.Core.New(); assert(d:Restore(c:Export()))
 settle(c,1); settle(d,1); samePrediction(c.model,d.model,w.x)
 return 'reset resolves partial positive, censors absence, seals identities, and deterministically rebuilds'
end)
run('ordinary retention can finish a replacement and retire old correction guards',function()
 local c=warm(); local old=c.model
 for n=1,256 do
  local t=50+n*3; ctx(c,t); c:Tick(t,true); c:Tick(t+2.25,true)
 end
 assert(c.model==old and c.dirty,'continuous combat keeps completed serving generation')
 settle(c,830)
 local replacement=c.model
 assert(replacement~=old and #c.modelDependencies==256)
 assert(c:Cast({id='p1',actor='P',at=4,family=1,revision=2,retracted=true}))
 assert(c.model==replacement and not c.dirty,'correction outside replacement corpus has no authority')
 return 'old dependency registry replaced at publication; retired lessons no longer withdraw clean model'
end)
return cases
