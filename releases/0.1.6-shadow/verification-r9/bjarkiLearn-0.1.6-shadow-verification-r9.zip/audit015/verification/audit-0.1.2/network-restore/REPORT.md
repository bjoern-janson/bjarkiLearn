# Independent Network and persistence audit

No material functional finding was reproduced in the reviewed scope. No production source or supplied verification test was changed.

Exact reviewed current source: `source/bjarkiLearn` under this audit extraction. `current.json` records SHA-256 values before and after execution, including Network.lua `49668680ce13803c329a816f76863b04bb752cb07e5d2759cf7076af05165c49` and Core.lua `8a104ca8806f5c19984cc4ed2a69a1d2c4969c9f626d03fcbd637e3bbef276f3`.

## Source assessment

Read Network.lua in full, Core.lua including replay/prediction and Export/Restore, Bootstrap.lua boundaries, Rules.lua feature construction, Main.lua initialization/save route, and the API/implementation/README contracts. Compared the 0.1.2 patch against the 0.1.1 baseline.

- Network.lua:126-163: fmod plus the negative adjustment yields a positive Park-Miller residue over the accepted seed interval. The subsequent product is below 2^53. This review did not rerun the already packaged thousands-of-seeds normalization corpus or claim it as new independent coverage.
- Network.lua:53-111: model parameters, vectors and counters are checked before model operations. Dense parameter tables cannot contain recursive numeric leaves. Model shape/state checks and the private model interface were assessed separately from public/native input boundaries.
- Network.lua:167-214: sign-stable sigmoid, bounded tanh and finite running dot checks prevent nonfinite values from becoming exposed predictions for accepted ordinary inputs. Rejecting an overflowing intermediate dot even when later cancellation could produce a finite result is a conservative numerical policy, not a reproduced bug.
- Network.lua:216-306: candidates own copied parameter/statistic tables. Each gradient, step and final candidate validates before the sole commit. Masked labels have no training or statistic influence; omitted output heads remain untouched while shared hidden weights may move.
- Core.lua:536-579: outer collection keys are checked with raw `next`; accepted keys are integral and bounded to 1..256. Counting them and validating every 1..count record rejects gaps before `self.examples=restored` at line 572. No live state writes occur during successful record normalization before that commit point. The incompatible-schema counter is an intentional separate diagnostic path.
- Core.lua:15-28 and 561-570: required vector positions are copied and validated, optional diagnostic predictions are sanitized separately, and only canonical training/prediction fields survive export. Extra inner-vector fields and row metadata are discarded. The documented plain/dense requirement applies to the outer collection; accepting then normalizing inner metadata is not a finding.

## New executable evidence

Nine scenarios run on both Lua 5.1 and Lua 5.4, 18 executions per source version. Results:

| Source | Passed | Failed | Source unchanged |
| --- | ---: | ---: | --- |
| Exact 0.1.2 extraction | 18 | 0 | yes |
| Bundled 0.1.1 baseline | 18 | 0 | yes |
| Bundled 0.1.0 baseline | 18 | 0 | yes |

The probes add behavior-level and metamorphic coverage rather than repeating sparse-array/seed boundary sweeps:

1. Flip every omitted label across a 300-update mixed-mask trajectory; complete model states remain exactly equal.
2. Permute input coordinates and corresponding neural/linear weights across 150 updates; predictions and learned weights commute within 1e-12.
3. Train identical models for 200 updates with statistics enabled/disabled; every parameter stays exactly equal while observation counts differ as intended.
4. Set a valid two-input linear head to weights `{-1.5e308,1.5e308}`, inputs `{1,1}`, target zero and learning rate `1.5e308`. Forward cancellation is finite; the finite `7.5e307` update would overflow subtraction from the negative weight. Learn rejects and preserves all original own state and nested table references.
5. Exercise both signs of 1e308 saturated hidden/output logits; predictions and an accepted update remain finite and valid.
6. Generate 32 actual Core windows including real casts and censored windows, complete a serving model after 24 windows, retain at least seven real pre-outcome scores, serialize Export to ordinary Lua source with 17-digit numbers, parse it, Restore and rebuild. Full model state and evaluation family metrics remain exactly equal. Export contains neither private actor nor cast IDs.
7. Replace saved optional prediction data with NaN, infinities, out-of-range and wrong-shape fields; Restore sanitizes it, evaluation withholds unpaired predictions and the rebuilt model remains exactly equal.
8. Add identity-like row metadata and extra inner-vector fields; Restore and Export canonicalize them away without changing training.
9. Restore the same save into two independent cores, then mutate caller-owned inputs and one core's vectors; the other core's export and rebuilt model remain unchanged.

The same outcomes on all three source versions are preservation controls, not claims that these tests reproduce the repaired defects. Prior failing sparse-collection and seed observations were not rebranded as new tests.

## Reproduce

With Python and Lupa installed:

```sh
python run.py --source ../../source/bjarkiLearn --output current.json
python run.py --source ../../verification/baseline-0.1.1/source/bjarkiLearn --output baseline011.json
python run.py --source ../../verification/baseline/source/bjarkiLearn --output baseline010.json
```

Run from this directory. Optional `--lupa-path PATH` adds a supplied dependency directory; a local known dependency fallback is available on this machine. The exact run used `C:/Users/Mewn/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe`.

## Limits and classification

No private metatable adversary, manually mutated internal configuration/model, or invented secret-value semantics was promoted into a practical user bug. These are ordinary Lua executions; native secret enforcement, event completeness, frame-time cost, and predictive value remain unproven. The absence of a finding in these checks does not prove all possible numerical or persistence behavior.
