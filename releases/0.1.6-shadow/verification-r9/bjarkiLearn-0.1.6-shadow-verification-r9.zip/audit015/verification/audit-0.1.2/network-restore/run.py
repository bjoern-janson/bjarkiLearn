import argparse, hashlib, importlib, json, sys
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--lupa-path',type=Path);a=p.parse_args()
if a.lupa_path: sys.path.insert(0,str(a.lupa_path))
try: import lupa
except ModuleNotFoundError: sys.path.insert(0,'C:/Users/Mewn/Documents/Codex/2026-10-16/let/work/deps')
source=a.source.resolve()
def hashes(): return {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in source.glob('*.lua')}
before=hashes();results=[]
for engine in ('lua51','lua54'):
 lua=importlib.import_module('lupa.'+engine).LuaRuntime(unpack_returned_tuples=True);ns=lua.table()
 for name in ('Bootstrap.lua','Rules.lua','Network.lua','Core.lua'): lua.execute((source/name).read_text(encoding='utf-8-sig'),'bjarkiLearn',ns)
 report=lua.execute(Path(__file__).with_name('probes.lua').read_text(encoding='utf-8'),ns)
 for _,case in report.items(): results.append({'runtime':engine,**dict(case.items())})
out={'source':str(source),'source_hashes':before,'source_unchanged':before==hashes(),'total':len(results),'passed':sum(r['passed'] for r in results),'results':results}
a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in out.items() if k not in ('results','source_hashes')}))
for r in results:
 if not r['passed']: print(json.dumps(r))
sys.exit(0 if out['passed']==out['total'] and out['source_unchanged'] else 1)
