local ns=...
local M,C=ns.Models,ns.Config
local results,checks={},0
local function ck(value,message) checks=checks+1;assert(value,message) end
local function near(a,b,tolerance) ck(math.abs(a-b)<=(tolerance or 1e-12),'numeric difference '..tostring(a)..' '..tostring(b)) end
local function copy(v)
 if type(v)~='table' then return v end
 local out={};for k,x in next,v do out[k]=copy(x) end;return out
end
local function equal(a,b,tolerance)
 if type(a)~=type(b) then return false end
 if type(a)=='number' then return math.abs(a-b)<=(tolerance or 0) end
 if type(a)~='table' then return a==b end
 for k,v in next,a do if not equal(v,b[k],tolerance) then return false end end
 for k in next,b do if a[k]==nil then return false end end
 return true
end
local function case(name,fn)
 local before=checks;local ok,why=pcall(fn)
 results[#results+1]={name=name,passed=ok,checks=checks-before,error=not ok and tostring(why) or nil}
end
local function finish(c)
 for _=1,2000 do c:_Train();if not c.dirty then ck(c.candidate==nil,'candidate cleared');return end end
 error('replay never completed')
end
local function dataset()
 local c=ns.Core.New();c:SetCoverage(true)
 for n=1,32 do
  local t=3*n
  ck(c:Context({actor='private-player-identity',at=t,role='self',class='PRIEST',combat=true,
   bound=true,health=n%5/4,power=n%4/3})~=nil,'context')
  c:Tick(t,true)
  if n%3==0 then ck(c:Cast({id='private-cast-'..n,actor='private-player-identity',at=t+.5,family=n%6+1}),'cast') end
  if n%7==0 then c:Gap('independent-probe-gap') end
  c:Tick(t+2.25,true)
  if n==24 then finish(c);ck(c.model~=nil,'initial trained snapshot') end
 end
 ck(#c.examples==32,'real windows resolved');finish(c);ck(c.model~=nil,'trained model')
 ck(c:Status().families[1].scored>=7,'real pre-outcome serving predictions retained')
 return c
end
local parameters={'hiddenWeights','hiddenBiases','outputWeights','outputBiases','linearWeights','linearBiases'}
case('masked labels cannot change a 300-update trajectory',function()
 local a,b=M.New(4,7,3,113),M.New(4,7,3,113)
 for n=1,300 do
  local x={n%3/2,n%5/4,n%7/6,n%11/10}
  local y,z,mask={},{},{}
  for o=1,3 do y[o]=(n+o)%2;mask[o]=(n+o)%3==0;z[o]=mask[o] and y[o] or 1-y[o] end
  ck(a:Learn(x,y,mask,n<=100),'first trajectory')
  ck(b:Learn(x,z,mask,n<=100),'second trajectory')
  ck(equal(a,b),'masked label leaked into parameters or statistics')
 end
 ck(a.updates==300 and a.totals[1]+a.totals[2]+a.totals[3]==100,'statistics first pass only')
end)
case('input permutation commutes with training and prediction',function()
 local a=M.New(4,5,3,41);local b=a:Copy()
 local p={4,2,1,3}
 for h=1,5 do for j=1,4 do b.hiddenWeights[h][j]=a.hiddenWeights[h][p[j]] end end
 for o=1,3 do for j=1,4 do b.linearWeights[o][j]=a.linearWeights[o][p[j]] end end
 for n=1,150 do
  local x={n%3/2,n%5/4,n%7/6,n%11/10};local z={}
  for j=1,4 do z[j]=x[p[j]] end
  local y,mask={n%2,(n+1)%2,n%3==0 and 1 or 0},{true,n%3~=0,n%4~=0}
  local u,v=a:Predict(x),b:Predict(z)
  for _,name in ipairs({'neural','linear','frequency'}) do for o=1,3 do near(u[name][o],v[name][o]) end end
  ck(a:Learn(x,y,mask),'original');ck(b:Learn(z,y,mask),'permuted')
 end
 for h=1,5 do for j=1,4 do near(b.hiddenWeights[h][j],a.hiddenWeights[h][p[j]]) end end
end)
case('statistics flag cannot affect learned parameter trajectory',function()
 local a,b=M.New(3,4,2,29),M.New(3,4,2,29)
 for n=1,200 do
  local x,y,mask={n%2,n%3/2,.4},{n%2,(n+1)%2},{true,n%3~=0}
  ck(a:Learn(x,y,mask,true));ck(b:Learn(x,y,mask,false))
 end
 for _,field in ipairs(parameters) do ck(equal(a[field],b[field]),field) end
 ck(a.updates==200 and b.updates==200 and a.totals[1]==200 and b.totals[1]==0,'flag affects observations only')
end)
case('finite change with overflowing subtraction rejects atomically',function()
 local m=M.New(2,2,2,47)
 m.regularization=0;m.linearRegularization=0;m.learningRate=1.5e308
 m.linearWeights[2]={-1.5e308,1.5e308}
 local before=copy(m);local refs={};for k,v in next,m do if type(v)=='table' then refs[k]=v end end
 local prediction=m:Predict({1,1});ck(prediction~=nil,'finite cancellation prediction')
 local ok,reason=m:Learn({1,1},{0,0},{true,true})
 ck(not ok and reason=='nonfinite_update','subtraction overflow rejected')
 ck(equal(m,before),'candidate updates escaped')
 for k,v in next,refs do ck(m[k]==v,'original reference replaced') end
 ck(m:Valid(),'original model valid')
end)
case('all saturated finite heads produce finite predictions',function()
 local m=M.New(3,4,2,53)
 for h=1,4 do m.hiddenWeights[h]={0,0,0};m.hiddenBiases[h]=h%2==0 and 1e308 or -1e308 end
 for o=1,2 do m.outputWeights[o]={0,0,0,0};m.linearWeights[o]={0,0,0}
  m.outputBiases[o]=o==1 and 1e308 or -1e308;m.linearBiases[o]=m.outputBiases[o] end
 local p=m:Predict({.2,.4,.6});ck(p~=nil)
 for _,name in ipairs({'neural','linear'}) do ck(p[name][1]==1 and p[name][2]==0,'stable saturation') end
 ck(m:Learn({.2,.4,.6},{0,1},{true,true}),'finite saturated update')
 ck(m:Valid(),'valid after saturated update')
end)
case('saved literal round trip rebuilds actual corpus exactly',function()
 local a=dataset();local exported=a:Export()
 local function serialize(v)
  if type(v)=='table' then local fields={};for k,x in next,v do fields[#fields+1]='['..serialize(k)..']='..serialize(x) end;return '{'..table.concat(fields,',')..'}' end
  if type(v)=='number' then return string.format('%.17g',v) end
  if type(v)=='boolean' then return tostring(v) end
  return string.format('%q',v)
 end
 local literal=serialize(exported)
 ck(not string.find(literal,'private%-player%-identity') and not string.find(literal,'private%-cast'),'identities excluded')
 local loader=loadstring or load
 local restored=assert(loader('return '..literal))()
 local b=ns.Core.New();ck(b:Restore(restored));finish(b)
 ck(equal(a.model,b.model),'serialized corpus changed model')
 ck(equal(a:Status().families,b:Status().families),'saved evaluation changed')
 for _,row in ipairs(b.examples) do ck(row.sealed and row.actor==nil and row.id==nil,'sealed') end
end)
case('optional diagnostic sanitization cannot change training',function()
 local a=dataset();local saved=a:Export()
 for _,row in ipairs(saved.examples) do row.predictions={neural={0/0,math.huge,-1,1.1},linear='unreadable-shape',frequency={false,'bad'}} end
 local b=ns.Core.New();ck(b:Restore(saved),'diagnostics optional');finish(b)
 ck(equal(a.model,b.model),'diagnostics contaminated model')
 for _,family in ipairs(b:Status().families) do ck(family.scored==0 and family.neuralLoss==nil,'unpaired diagnostics withheld') end
end)
case('row and vector metadata are normalized away on export',function()
 local a=dataset();local saved=a:Export()
 for _,row in ipairs(saved.examples) do row.actor='private-injected';row.id='private-injected';row.x.extra='metadata';row.y[1000]='metadata';row.mask[-1]='metadata' end
 local b=ns.Core.New();ck(b:Restore(saved),'only documented outer collection must be dense plain')
 ck(equal(a:Export(),b:Export()),'normalization leaves canonical save unchanged');finish(b)
 ck(equal(a.model,b.model),'metadata changed model')
end)
case('independent restores retain no caller-owned vectors',function()
 local a=dataset();local saved=a:Export();local b,d=ns.Core.New(),ns.Core.New()
 ck(b:Restore(saved));ck(d:Restore(saved));local untouched=copy(d:Export())
 saved.examples[1].x[1]=1-saved.examples[1].x[1];saved.examples[1].y[1]=1-saved.examples[1].y[1]
 b.examples[1].x[2]=1-b.examples[1].x[2];b.examples[1].mask[1]=not b.examples[1].mask[1]
 ck(equal(d:Export(),untouched),'independent core shares imported vectors')
 finish(d);ck(equal(d.model,a.model),'caller mutation reached training')
end)
return results

