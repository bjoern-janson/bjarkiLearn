# Independent native-path audit of bjarkiLearn 0.1.2-shadow

No additional material finding was established in Main.lua, Adapter.lua, Rules.lua or the Bootstrap readable-value boundary. This result is an offline source and modeled-host result, not live-client validation.

The exact extracted 0.1.2 source was reviewed against the supplied 0.1.1 archive extraction. Adapter.lua and Rules.lua are byte-identical. The only Main.lua change is the intended registration-return repair at lines 32-36. Bootstrap.lua changes only the version string. No production files or existing harnesses were edited by this audit.

## Independent dynamic verification

`run.py` loads all actual addon modules, then drives Main through its installed frame OnEvent/OnUpdate callbacks. Only unavailable WoW host functions are modeled. The original bundled `verification/fixtures/SharedEvidence.lua` is loaded for bus controls. Outcomes use explicit expected labels, bindings, occurrence counts and session/listener state; no replacement coverage predicate is substituted for the implementation.

- 18 scenarios under Lua 5.1 and Lua 5.4: 36/36 passed, 370 checks on 0.1.2.
- The same 36/36 passed, 370 checks on the exact 0.1.1 baseline.
- Both runs compare SHA-256 hashes before/after and confirm all production Lua files remained unchanged.
- Reports: `current.json`, `baseline-0.1.1.json`.

Scenarios cover actual readable cast delivery; player GUID read throwing despite surviving self aliases; readable nonplayer contradiction; unavailable optional class/health/power/form reads; secret event unit and inaccessible spell fields; unknown spells; unsupported pet tokens; unknown combat; unreadable event/update clock; self-alias cast deduplication; losing a target alias without losing player coverage; target/focus rebindings; PLAYER_ENTERING_WORLD partial-window sealing and original-bus resubscription/replay; a late-loaded bus; rejected aura identity; subscription failure; disable/enable listener cleanup; and clock rewind recovery.

## Paths and conclusions

- Main.lua 32-37: only readable true or legacy nil registration results grant cast coverage; exceptions/false/unreadable/unexpected types are rejected. The supplied registration regression suite covers the repaired cases in more detail. No further assumption that a successful pcall alone grants coverage remains.
- Main.lua 104-154 and Adapter.lua 132-149: dispatched collection failures stop the adapter, while protected native reads convert unavailable data into gaps or missing optional fields. The new controls do not find fabricated cast labels after unreadable event fields or clocks.
- Adapter.lua 55-110: player-binding loss revokes negative coverage, even if target/focus still alias the prior player. Alias loss preserves a surviving player observation stream. Target/focus identity changes do not reuse old public bindings.
- Adapter.lua 151-222: optional aura intake stays positive-only context; original-bus replay never becomes a native cast occurrence. A world transition unsubscribes, seals/clears the session, rebinds, and establishes a fresh subscription that receives the bounded replay. Missing/incompatible/failed subscriptions do not grant or remove native cast coverage.
- Rules.lua: vocabulary remains explicit and its six-family schema remains separate from aura witnesses. Unknown spell IDs do not receive a guessed family, and unsupported pet unit tokens do not get player attribution.
- Bootstrap.lua: native values are checked before adapter comparison/index/format use; modeled secret and inaccessible values do not escape into semantic evidence in the executed paths.

## Evidence limits and unconfirmed possibilities

The controls establish behavior under declared host results. They do not establish which event payloads, cast identities, registration returns, secret/readability policies, event ordering, clocks or profiling cost the Forever 16001 client actually supplies. Those remain live/native checks.

Clock rewind is deliberately a robustness control; no native trigger was established. It causes the core to reset after the adapter's first refresh, and normal bindings recover at the next 0.25-second refresh. This is not reported as a confirmed native bug.

A private Core:Cast call with an arbitrary future timestamp is not an established native trigger: Adapter:OnEvent timestamps native deliveries from the protected current GetTime read and supplies no event-provided cast time. The aura bridge does carry observation timestamps but cannot create cast outcomes. No production failure claim is made from private-core injection alone.

Possible failure of lifecycle-event registration other than cast registration is diagnosed but does not by itself disprove cast-stream coverage. A concrete native case causing incorrect retained labels was not established in this audit. Likewise, arbitrary corruption of an existing protocol-compatible bus is not treated as a normal native behavior.

## Reproduce

From the extracted audit root's workspace, with Lupa 5.1/5.4 installed:

```text
python audit/native/run.py --source source/bjarkiLearn --output audit/native/current.json
python audit/native/run.py --source verification/baseline-0.1.1/source/bjarkiLearn --output audit/native/baseline-0.1.1.json
```

The script accepts `--lupa-path` and `--bus` for portable dependency/fixture locations. Its default bus path resolves within this audit extraction. It writes only the requested report, and never writes addon files.

