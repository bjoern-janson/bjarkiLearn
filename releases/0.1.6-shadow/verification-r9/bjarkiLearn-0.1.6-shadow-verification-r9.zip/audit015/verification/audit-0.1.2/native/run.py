"""Independent actual Main/Adapter/Core probes with modeled WoW host APIs."""
import argparse,hashlib,importlib,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--source',required=True,type=Path)
p.add_argument('--output',required=True,type=Path)
p.add_argument('--bus',type=Path,default=ROOT.parents[1]/'verification/fixtures/SharedEvidence.lua')
p.add_argument('--lupa-path',action='append',default=[])
a=p.parse_args()
for path in a.lupa_path+['C:/Users/Mewn/Documents/Codex/2026-10-16/let/work/deps']:sys.path.insert(0,path)
source=a.source.resolve()
hashes=lambda:{f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(source.glob('*.lua'))}
before=hashes()
cases={
'frame callbacks collect readable casts': '''
 Init();Advance(10);World.now=10.25;Event('UNIT_SPELLCAST_SUCCEEDED','player','Cast-1',22812)
 EndFirst();local w=PlayerExample();ExpectPlayerMasks(true);Equal(w.y[6],1)
 for i=1,5 do Equal(w.y[i],0) end;Equal(Runtime.core.stats.casts,1);Check(not Runtime.faulted)
''',
'throwing identity read removes player coverage despite aliases': '''
 World.ids.target=World.ids.player;World.ids.focus=World.ids.player;Init();Advance(10)
 local native=UnitGUID;UnitGUID=function(u) if u=='player' then error('identity unavailable') end return native(u) end
 Advance(10.25);Check(not Runtime.adapter.coverage);Equal(Runtime.adapter.bindings.player,nil)
 UnitGUID=native;EndFirst();ExpectPlayerMasks(false);Check(not Runtime.faulted)
''',
'nonplayer contradiction removes coverage': '''
 Init();Advance(10);local native=UnitIsPlayer
 UnitIsPlayer=function(u) if u=='player' then return false end return native(u) end
 Advance(10.25);Check(not Runtime.adapter.coverage);UnitIsPlayer=native
 EndFirst();ExpectPlayerMasks(false);Check(not Runtime.faulted)
''',
'optional unavailable native fields preserve valid cast evidence': '''
 Init();Advance(10);UnitClassBase=function() error('class unavailable') end;UnitClass=nil
 UnitHealth=function() return Opaque end;UnitPowerMax=function() return Inaccessible end
 UnitPowerType=function() error('power type unavailable') end
 Advance(10.25);local c=BjarkiLearn:GetContext('player')
 Equal(c.class,nil);Equal(c.health,nil);Equal(c.power,nil);Equal(c.form,nil)
 World.now=10.3;Event('UNIT_SPELLCAST_SUCCEEDED','player','Cast-optional',22812)
 EndFirst();ExpectPlayerMasks(true);Equal(PlayerExample().y[6],1);Check(not Runtime.faulted)
''',
'secret event unit censors all tracked absence': '''
 Init();Advance(10);World.now=10.25;Event('UNIT_SPELLCAST_SUCCEEDED',Opaque,'Cast-secret',22812)
 EndFirst();ExpectPlayerMasks(false);Equal(Runtime.core.stats.casts,nil);Check(not Runtime.faulted)
''',
'inaccessible relevant spell censors player absence': '''
 Init();Advance(10);World.now=10.25;Event('UNIT_SPELLCAST_SUCCEEDED','player','Cast-secret',Inaccessible)
 EndFirst();ExpectPlayerMasks(false);Equal(Runtime.adapter.stats.rejected,1);Check(not Runtime.faulted)
''',
'unknown spell receives no family or known-vocabulary censorship': '''
 Init();Advance(10);World.now=10.25;Event('UNIT_SPELLCAST_SUCCEEDED','player',Opaque,99999)
 EndFirst();ExpectPlayerMasks(true);Equal(Runtime.adapter.stats.unknownSpells,1)
 Equal(Runtime.core.stats.casts,nil);Check(not Runtime.faulted)
''',
'untracked unit does not pretend pet ownership': '''
 Init();Advance(10);World.now=10.25;Event('UNIT_SPELLCAST_SUCCEEDED','pet','Cast-pet',19647)
 EndFirst();ExpectPlayerMasks(true);Equal(Runtime.core.stats.casts,nil)
 for i=1,6 do Equal(PlayerExample().y[i],0) end
''',
'unknown combat censors and defers training': '''
 Init();Advance(10);World.combat=Opaque;Advance(10.25);Advance(10.5)
 Advance(11);Advance(11.5);Advance(12);Advance(12.3)
 ExpectPlayerMasks(false);Equal(Runtime.core:Status().trainingSteps,0);Check(not Runtime.faulted)
''',
'unreadable clock censors without fabricated occurrence': '''
 Init();Advance(10);World.now=Inaccessible;Event('UNIT_SPELLCAST_SUCCEEDED','player','Cast-time',22812)
 Runtime.frame.scripts.OnUpdate(Runtime.frame,.1);World.now=10.25
 EndFirst();ExpectPlayerMasks(false);Equal(Runtime.core.stats.casts,nil);Check(not Runtime.faulted)
''',
'alias deduplication and target loss preserve player coverage': '''
 World.ids.target=World.ids.player;Init();Advance(10);World.now=10.25
 Event('UNIT_SPELLCAST_SUCCEEDED','player','Cast-alias',22812)
 Event('UNIT_SPELLCAST_SUCCEEDED','target','Cast-alias',22812)
 World.ids.target='Player-1-200';Event('PLAYER_TARGET_CHANGED')
 EndFirst();ExpectPlayerMasks(true);Equal(PlayerExample().y[6],1)
 Equal(Runtime.core.stats.casts,1);Equal(Runtime.core.stats.duplicateCasts,1)
 Equal(Runtime.core.actors[World.ids.player].role,'self')
''',
'focus and target rebindings preserve actor distinction': '''
 World.ids.focus=World.ids.target;Init();Advance(10);local old=World.ids.target
 World.ids.target='Player-1-201';World.now=10.1;Event('PLAYER_TARGET_CHANGED')
 Equal(BjarkiLearn:GetContext('target').actor,'Player-1-201');Equal(BjarkiLearn:GetContext('focus').actor,old)
 World.ids.focus='Player-1-202';Event('PLAYER_FOCUS_CHANGED')
 Equal(BjarkiLearn:GetContext(old),nil);Equal(Runtime.core.actors[old].bound,false)
 Check(Runtime.adapter.coverage);Check(not Runtime.faulted)
''',
'world reset seals partial positive and replays real evidence bus': '''
 LoadBus();Check(PublishAura(42,10));Init();Advance(10)
 Equal(Runtime.core.actors[World.ids.target].defensiveWitness.spellID,5277)
 local bus=BjarkiEvidenceV1;local oldSession=Runtime.core.session
 World.now=10.25;Event('UNIT_SPELLCAST_SUCCEEDED','player','Cast-world',22812);Event('PLAYER_ENTERING_WORLD')
 Equal(Runtime.core.session,oldSession+1);Equal(Runtime.core:Status().pending,0)
 Equal(#Runtime.core.occurrenceOrder,1);Equal(Runtime.core.actors[World.ids.target].defensiveWitness.spellID,5277)
 Equal(bus:Status().listeners,1);Equal(bus:Status().subscriptions,2)
 local w=PlayerExample();Check(w.sealed);Equal(w.actor,nil);Equal(w.y[6],1);Equal(w.mask[6],true)
 for i=1,5 do Equal(w.mask[i],false) end
 Check(Runtime.adapter.coverage);Check(Runtime.core.coverage);Check(not Runtime.faulted)
''',
'late bus loads via addon event and adds no cast label': '''
 Init();Advance(10);Check(not Runtime.adapter.stats.busConnected)
 LoadBus();Check(PublishAura(43,10));World.now=10.25;Event('ADDON_LOADED','bjarkiPortraits')
 Equal(Runtime.adapter.stats.auras,1);Equal(Runtime.core.stats.casts,nil)
 Equal(Runtime.core.actors[World.ids.target].defensiveWitness.spellID,5277)
 EndFirst();ExpectPlayerMasks(true);for i=1,6 do Equal(PlayerExample().y[i],0) end
''',
'unknown aura identity rejected through real bus': '''
 LoadBus();Init();Advance(10);Check(PublishAura(nil,10))
 Equal(Runtime.adapter.stats.rejected,1);Equal(Runtime.core.stats.auraWitnesses,nil)
 EndFirst();ExpectPlayerMasks(true);Equal(BjarkiEvidenceV1:Status().errors,0)
''',
'failed optional subscription is diagnosed and preserves collection': '''
 BjarkiEvidenceV1={schema=1,protocol='bjarki-positive-aura-v1',Subscribe=function() return false end,Unsubscribe=function() return true end}
 Init();Advance(10);Equal(Runtime.adapter.stats.busErrors,1)
 Check(not Runtime.adapter.stats.busConnected);Check(Runtime.adapter.coverage)
 EndFirst();ExpectPlayerMasks(true);Check(not Runtime.faulted)
''',
'disable and enable replace one bus listener': '''
 LoadBus();Init();Advance(10);local old=Runtime.adapter
 Runtime:Command('disable');Check(old.stopped);Equal(BjarkiEvidenceV1:Status().listeners,0)
 local prior=old.stats.auras;Check(PublishAura(44,10));Equal(old.stats.auras,prior)
 Runtime:Command('enable');Check(Runtime.adapter~=old)
 Equal(BjarkiEvidenceV1:Status().listeners,1);Equal(Runtime.adapter.stats.auras,1)
 Check(Runtime.adapter.coverage);Check(not Runtime.faulted)
''',
'clock rewind robustness recovers binding next refresh': '''
 Init();Advance(10);local s=Runtime.core.session;Advance(9)
 Equal(Runtime.core.session,s+1);Check(Runtime.adapter.coverage);Check(Runtime.core.coverage)
 Advance(9.25);Check(BjarkiLearn:GetContext('player').fresh)
 Advance(9.5);Advance(10);Advance(10.5);Advance(11);World.combat=false;Advance(11.6)
 Check(not Runtime.faulted);Check(Runtime.core:Status().examples>=1)
''',
}
results=[]
for engine in ('lua51','lua54'):
 LuaRuntime=importlib.import_module('lupa.'+engine).LuaRuntime
 for name,code in cases.items():
  lua=LuaRuntime(unpack_returned_tuples=True);lua.globals().LEARN_ROOT=source.as_posix();lua.globals().BUS_PATH=a.bus.resolve().as_posix();error=None
  try:lua.execute((ROOT/'harness.lua').read_text(encoding='utf-8-sig'));lua.execute(code)
  except Exception as exc:error=str(exc)
  results.append(dict(engine=engine,case=name,passed=error is None,checks=lua.globals().CHECKS or 0,error=error))
report=dict(source=str(source),source_hashes=before,source_unchanged=hashes()==before,summary=dict(passed=sum(r['passed'] for r in results),total=len(results),checks=sum(r['checks'] for r in results)),cases=results,claim_ceiling='Actual addon Lua with modeled WoW APIs and original evidence bus; no live WoW execution. Clock rewind is a robustness control with no established native trigger.')
a.output.resolve().parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(summary=report['summary'],source_unchanged=report['source_unchanged'],failures=[r for r in results if not r['passed']]),indent=2))
sys.exit(0 if report['source_unchanged'] and all(r['passed'] for r in results) else 1)
