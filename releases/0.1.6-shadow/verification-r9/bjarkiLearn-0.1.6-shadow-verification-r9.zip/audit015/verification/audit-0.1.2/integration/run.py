"""Cross-version actual Main/Adapter/Core regression trajectories."""
from pathlib import Path
import argparse,hashlib,importlib,json,sys
try: import lupa
except ImportError:sys.path.insert(0,r'C:/Users/Mewn/Documents/Codex/2026-10-16/let/work/deps')
p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--baseline',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
root=Path(__file__).resolve().parent; audit=root.parents[1]
harness=(audit/'verification/review-integration/harness.lua').read_text(encoding='utf-8')
def freeze(value):
 if hasattr(value,'items'):
  return {str(k):freeze(v) for k,v in value.items() if k!='version'}
 if isinstance(value,float) and value.is_integer():return int(value)
 return value
def run(engine,source,scenario):
 lua=importlib.import_module('lupa.'+engine).LuaRuntime(unpack_returned_tuples=True)
 lua.globals().LEARN_ROOT=source.resolve().as_posix();lua.globals().SCENARIO=scenario
 lua.execute(harness)
 return freeze(lua.execute((root/'trace.lua').read_text(encoding='utf-8')))
def first_difference(x,y,path=''):
 if type(x)!=type(y):return (path,x,y)
 if isinstance(x,dict):
  for key in sorted(set(x)|set(y)):
   if key not in x or key not in y:return (path+'/'+key,x.get(key),y.get(key))
   d=first_difference(x[key],y[key],path+'/'+key)
   if d:return d
  return None
 return None if x==y else (path,x,y)
results=[]
for engine in ('lua51','lua54'):
 for scenario in ('continuous','lifecycle'):
  old=run(engine,a.baseline,scenario);new=run(engine,a.source,scenario);difference=first_difference(old,new)
  results.append({'engine':engine,'scenario':scenario,'passed':difference is None,'first_difference':difference,'checkpoints':len(new['snapshots']),'checks_per_version':new['checks'],'steps_per_version':new['steps'],'final_core':new['final']['core']})
  print(engine,scenario,'PASS' if difference is None else difference,flush=True)
report={'passed':all(r['passed'] for r in results),'cases':results,'scenario_comparisons':len(results),'note':'Version fields alone excluded. Real captured forecasts, context, status, exports and full completed model compared on both runtimes.'}
a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
sys.exit(0 if report['passed'] else 1)
