from pathlib import Path
import ast,importlib,json,sys
sys.path.insert(0,r'C:/Users/Mewn/Documents/Codex/2026-10-16/let/work/deps')
root=Path(__file__).resolve().parent;audit=root.parents[1]
harness=(audit/'verification/review-integration/harness.lua').read_text(encoding='utf-8')
tree=ast.parse((root/'run.py').read_text(encoding='utf-8'))
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef)],type_ignores=[]),'run-functions','exec'))
source=audit/'source/bjarkiLearn';baseline=audit/'verification/baseline-0.1.1/source/bjarkiLearn'
runs=[run('lua54',s,'lifecycle') for s in (source,source,source,baseline)]
comparisons=[]
for index,result in enumerate(runs[1:],1):
 rows=[]
 for step,left in runs[0]['snapshots'].items():
  right=result['snapshots'][step]
  d={field:first_difference(left.get(field),right.get(field)) for field in ('status','model','publics','export')}
  d={k:v for k,v in d.items() if v}
  if d:
   a=left['export']['examples'];b=right['export']['examples']
   key=lambda x:json.dumps(x,sort_keys=True,separators=(',',':'))
   same_bag=sorted(key(x) for x in a.values())==sorted(key(x) for x in b.values())
   player_a=[x for x in a.values() if x['regime']=='player'];player_b=[x for x in b.values() if x['regime']=='player']
   rows.append({'checkpoint':step,'differences':d,'same_example_multiset':same_bag,'same_player_order':player_a==player_b})
 comparisons.append({'comparison':('same_version_'+str(index)) if index<3 else 'baseline011','differences':rows})
(root/'order-diagnosis.json').write_text(json.dumps(comparisons,indent=2)+'\n',encoding='utf-8')
for r in comparisons:print(json.dumps({'comparison':r['comparison'],'differing_checkpoints':len(r['differences']),'first':r['differences'][:2]}),flush=True)
