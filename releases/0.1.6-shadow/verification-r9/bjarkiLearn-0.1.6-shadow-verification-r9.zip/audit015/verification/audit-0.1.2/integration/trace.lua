Init()
local seed=SCENARIO=='continuous' and 731 or 1297
local function random(n) seed=(seed*16807)%2147483647;return seed%n+1 end
local snapshots={}
local function capture(step)
 local c=Runtime.core
 Check(not Runtime.faulted,'runtime must stay healthy')
 Check(#c.examples<=256 and #c.occurrenceOrder<=128 and #c.actorOrder<=16 and #c.modelDependencies<=256,'state bounds')
 if c.model then Check(c.model:Valid(),'serving model valid') end
 if c.candidate then Check(c.candidate.model:Valid(),'candidate model valid') end
 local publics={}
 for _,unit in ipairs({'player','target','focus'}) do
  local f=BjarkiLearn:Forecast(unit)
  if f then
   Check(f.usable==false,'shadow authority unchanged')
   for _,o in ipairs(f.outputs) do
    Check(o.usable==false,'head remains shadow')
    if f.regime~='player' then Check(o.score==nil,'other regime remains withheld') end
   end
  end
  publics[unit]={forecast=f,context=BjarkiLearn:GetContext(unit)}
 end
 snapshots[#snapshots+1]={step=step,status=Runtime:Status(),export=c:Export(),model=c.model and c.model:Copy() or nil,publics=publics}
end
for step=1,1800 do
 World.now=10+step*.125
 World.health=20+random(81);World.power=random(101)-1
 local combat=step%240<190
 World.combat=combat;World.unitCombat=combat
 if step%31==0 then
  local aliases={nil,World.guid,'Player-1-200','Player-1-300'}
  local choice=random(4);World.target=aliases[choice]
  Event('PLAYER_TARGET_CHANGED')
 end
 if step%47==0 then World.focus=random(2)==1 and World.target or 'Player-1-400';Event('PLAYER_FOCUS_CHANGED') end
 if step%13==0 then
  local spells={8122,853,122,15487,1766,22812,999999}
  local units={'player','target','focus','party1'}
  local unit=units[random(4)];Event('UNIT_SPELLCAST_SUCCEEDED',unit,'Cast-differential-'..step,spells[random(#spells)])
 end
 if SCENARIO=='lifecycle' then
  if step%79==0 then Event('UNIT_SPELLCAST_SUCCEEDED','player',nil,8122) end
  if step%97==0 then local old=GetTime;GetTime=function() return nil end;Runtime:Update();GetTime=old end
  if step%107==0 then World.combat=nil end
  if step%211==0 then Runtime:Command('disable') end
  if step%211==2 then Runtime:Command('enable') end
  if step%379==0 then Event('PLAYER_ENTERING_WORLD') end
 end
 Runtime:Update()
 if step%60==0 then capture(step) end
end
-- Freeze context activity while finishing deferred replay through real Main.
World.combat=false;World.unitCombat=false
for i=1,270 do Advance(World.now+.125) end
capture(1801)
return {snapshots=snapshots,checks=CHECKS,steps=1800,final=Runtime:Status()}
