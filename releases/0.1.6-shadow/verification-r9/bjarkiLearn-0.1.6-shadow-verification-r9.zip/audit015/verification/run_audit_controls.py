"""Portable wrapper for unchanged 0.1.1 audit correctness controls.

Run all 40 included control executions on a supplied addon source. Three older
observations are excluded explicitly; their expectations describe fixed defects
or a separate private Core timing assumption, not required release invariants.
"""
from pathlib import Path
import argparse
import ast
import hashlib
import importlib
import json
import sys

ROOT=Path(__file__).resolve().parent
CONTROLS=ROOT/'audit-controls'
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--source',required=True,type=Path)
p.add_argument('--output',required=True,type=Path)
p.add_argument('--lupa-path',action='append',default=[])
a=p.parse_args()
for path in a.lupa_path: sys.path.insert(0,path)
try:
 import lupa
except ImportError:
 fallback=Path('C:/Users/Mewn/Documents/Codex/2026-10-16/let/work/deps')
 if fallback.exists(): sys.path.insert(0,str(fallback))
 import lupa
source=a.source.resolve()

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def source_hashes(): return {p.name:sha(p) for p in sorted(source.glob('*.lua'))}
def fixture_hashes(): return {p.relative_to(CONTROLS).as_posix():sha(p) for p in sorted(CONTROLS.rglob('*')) if p.is_file() and p.suffix in ('.lua','.py')}
def literals(path,names):
 result={}
 for node in ast.parse(path.read_text(encoding='utf-8-sig')).body:
  if isinstance(node,ast.Assign):
   for target in node.targets:
    if isinstance(target,ast.Name) and target.id in names: result[target.id]=ast.literal_eval(node.value)
 if set(result)!=set(names): raise ValueError('Missing requested original fixture literal')
 return result
def plain(value):
 if hasattr(value,'items'):
  entries=dict(value.items())
  if entries and set(entries)==set(range(1,len(entries)+1)): return [plain(entries[i]) for i in range(1,len(entries)+1)]
  return {str(k):plain(v) for k,v in entries.items()}
 return value

def core_runtime(LuaRuntime):
 lua=LuaRuntime(unpack_returned_tuples=True); ns=lua.table()
 for filename in ('Bootstrap.lua','Rules.lua','Network.lua','Core.lua'):
  lua.execute((source/filename).read_text(encoding='utf-8-sig'),'bjarkiLearn',ns)
 return lua,ns

before=source_hashes(); fixtures_before=fixture_hashes()
manifest=json.loads((CONTROLS/'original-hashes.json').read_text())
fixture_integrity=all(fixtures_before.get(r['file'])==r['sha256'] for r in manifest)
corrections=literals(CONTROLS/'new-corrections/run_corrections.py',('PRELUDE','PROBES'))
integration=literals(CONTROLS/'new-integration/run.py',('cases',))['cases']
assert len(corrections['PROBES'])==11 and len(integration)==6
sparse_name='malformed sparse save accepted and silently truncates retained rows (robustness observation)'
exclusions=[
 {'suite':'corrections','case':'future_exact_cast_enters_earlier_anchor_input','reason':'Private Core future-timestamp observation is outside these release controls; not executed.'},
 {'suite':'lifecycle','case':sparse_name,'reason':'Superseded malformed-save defect observation; unchanged file executes it, but its result is excluded and never counted as a control.'},
 {'suite':'integration','case':'register_false','reason':'Superseded explicit-false registration defect observation; not executed. F1 desired-behavior regression covers the fixed contract.'},
]
rows=[]; excluded_observations=[]
for engine in ('lua51','lua54'):
 LuaRuntime=importlib.import_module('lupa.'+engine).LuaRuntime
 for name,body in corrections['PROBES'].items():
  lua,ns=core_runtime(LuaRuntime)
  try: detail=lua.execute(corrections['PRELUDE']+body,ns); error=None
  except Exception as exc: detail=None; error=str(exc)
  rows.append(dict(engine=engine,suite='corrections',case=name,passed=error is None,detail=detail,error=error))
 lua,ns=core_runtime(LuaRuntime)
 lifecycle=lua.execute((CONTROLS/'new-lifecycle/probes.lua').read_text(encoding='utf-8-sig'),ns)
 for _,case in lifecycle['cases'].items():
  record=dict(engine=engine,suite='lifecycle',**plain(case))
  record['case']=record.pop('name')
  if record['case']==sparse_name:
   record['status']='excluded_superseded_observation'
   record['observed_original_assertion_passed']=record.pop('passed')
   excluded_observations.append(record)
  else: rows.append(record)
 for name in integration:
  if name=='register_false': continue
  lua=LuaRuntime(unpack_returned_tuples=True)
  lua.globals().LEARN_ROOT=source.as_posix()
  lua.globals().BUS_PATH=(CONTROLS/'fixtures/SharedEvidence.lua').as_posix()
  lua.globals().CASE=name
  lua.globals().FAIL_CAST_REG=name=='register_throw_control'
  try:
   lua.execute((CONTROLS/'fixtures/harness.lua').read_text(encoding='utf-8-sig'))
   detail=plain(lua.execute((CONTROLS/'new-integration/probes.lua').read_text(encoding='utf-8-sig')))
   error=None
  except Exception as exc: detail=None; error=str(exc)
  rows.append(dict(engine=engine,suite='integration',case=name,passed=error is None,detail=detail,error=error))
unchanged=before==source_hashes()
fixtures_unchanged=fixtures_before==fixture_hashes()
report=dict(passed=fixture_integrity and unchanged and fixtures_unchanged and len(rows)==40 and all(r['passed'] for r in rows),
 scenario_executions=len(rows),source=str(source),source_hashes=before,source_unchanged=unchanged,
 fixture_hashes=fixtures_before,fixture_original_bytes_verified=fixture_integrity,fixtures_unchanged=fixtures_unchanged,
 summary=dict(passed=sum(r['passed'] for r in rows),total=len(rows)),cases=rows,
 exclusions=exclusions,excluded_observations=excluded_observations)
a.output.parent.mkdir(parents=True,exist_ok=True)
a.output.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:report[k] for k in ('passed','scenario_executions','summary','source_unchanged','fixture_original_bytes_verified','fixtures_unchanged')},indent=2))
for row in rows:
 if not row['passed']: print(json.dumps(row,indent=2))
raise SystemExit(0 if report['passed'] else 1)
