"""Build deterministic 0.1.5 archives from the exact verified runtime."""
from pathlib import Path
import argparse,difflib,hashlib,json,zipfile
ROOT=Path(__file__).resolve().parent
SOURCE=ROOT/'source/bjarkiLearn';BASE=ROOT/'baseline-0.1.4/source/bjarkiLearn'
def sha(data):return hashlib.sha256(data).hexdigest()
def read(path):return json.loads((ROOT/path).read_text(encoding='utf-8-sig'))
def dump(path,value):path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
def main():
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=ROOT/'dist');a=p.parse_args()
 out=a.output.resolve();out.mkdir(parents=True,exist_ok=True)
 result=read('reports-0.1.5/verification.json')
 runtime={f.name:sha(f.read_bytes()) for f in SOURCE.glob('*.lua')}
 assert result['passed'] and result['runtime_hashes']==runtime
 assert result['syntax_checks_passed']==12 and result['original_test_sources_unchanged']
 assert result['legacy_scenario_controls_passed']==663 and result['legacy_review_probes_passed']==12
 assert result['contracts_passed']==8 and result['differential_cases_passed']>0
 assert result['native_014_comparisons_passed']==8
 review=read('review-0.1.5/review-gate.json')
 assert review['passed'] and all(review['runtime_hashes'][n]==h for n,h in runtime.items())
 expected=read('fixtures/v0.1.4-preserved-test-hashes.json')
 def original(name):return ROOT/('baseline-0.1.4/'+name if name in ('run_all.py','build_release.py') else name)
 assert len(expected)==76 and all(sha(original(n).read_bytes())==h for n,h in expected.items())
 original_archive=ROOT/'baseline-0.1.4/bjarkiLearn-0.1.4-shadow.zip'
 assert sha(original_archive.read_bytes())=='3cf686e9b1e3fe78b8577c15c75e2e1ba08fc6142b4cf794b36ac9da048f461d'
 files={f.relative_to(SOURCE).as_posix():f.read_bytes() for f in SOURCE.rglob('*') if f.is_file()}
 base={f.relative_to(BASE).as_posix():f.read_bytes() for f in BASE.rglob('*') if f.is_file()}
 assert set(files)==set(base) and len(files)==14
 with zipfile.ZipFile(original_archive) as z:
  assert z.testzip() is None
  assert {n:z.read(n) for n in z.namelist() if not n.endswith('/')}=={'bjarkiLearn/'+n:b for n,b in base.items()}
 for name,data in files.items():assert '\ufffd' not in data.decode('utf-8'),name
 modules=['Bootstrap.lua','Rules.lua','Network.lua','Core.lua','Adapter.lua','Main.lua']
 for name in ('bjarkiLearn.toc','bjarkiLearn_Camelot.toc'):
  text=files[name].decode('utf-8')
  assert text.count('## Version: 0.1.5-shadow')==1 and '## Interface: 16001' in text
  assert '## SavedVariables: bjarkiLearnDB' in text
  assert [l.strip() for l in text.splitlines() if l.strip() and not l.startswith('#')]==modules
 assert 'version = "0.1.5-shadow"' in files['Bootstrap.lua'].decode('utf-8')
 for name in ('Rules.lua','Network.lua','Adapter.lua','Main.lua'):assert files[name]==base[name]
 assert files['Bootstrap.lua'].decode('utf-8').replace('0.1.5-shadow','0.1.4-shadow').splitlines()==base['Bootstrap.lua'].decode('utf-8').splitlines()
 changed=sorted(n for n in files if files[n]!=base[n])
 patch=''.join(''.join(difflib.unified_diff(base[n].decode('utf-8').splitlines(True),files[n].decode('utf-8').splitlines(True),fromfile='0.1.4/'+n,tofile='0.1.5/'+n)) for n in changed)
 (ROOT/'source-changes.patch').write_text(patch,encoding='utf-8',newline='\n')
 def archive(path,entries):
  with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
   for name,data in sorted(entries.items()):
    info=zipfile.ZipInfo(name,(2026,10,23,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
    z.writestr(info,data)
  with zipfile.ZipFile(path) as z:
   assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==len(entries)
   assert {n:z.read(n) for n in z.namelist()}==entries
  return {'file':path.name,'sha256':sha(path.read_bytes()),'bytes':path.stat().st_size,'files':len(entries),'crc_valid':True,'exact_bytes':True}
 addon=archive(out/'bjarkiLearn-0.1.5-shadow.zip',{'bjarkiLearn/'+n:b for n,b in files.items()})
 package={'version':'0.1.5-shadow','addon':addon,'baseline_archive_sha256':sha(original_archive.read_bytes()),'runtime_hashes':runtime,'runtime_matches_final_test_run':True,'original_test_source_files':len(expected),'original_test_sources_unchanged':True,'same_14_file_inventory':True,'toc_references_and_versions_valid':True,'strict_utf8':True,'changed_files':changed,'inventory':{n:sha(b) for n,b in sorted(files.items())},'verification_report':'reports-0.1.5/verification.json','review_report':'review-0.1.5/review-gate.json'}
 dump(ROOT/'package.json',package)
 folders=('source','baseline','baseline-0.1.1','baseline-0.1.2','baseline-0.1.3','baseline-0.1.4','tests','tests-reset','tests-time','tests-refactor','new-tests','review-main','review-core','review-network','review-adapter','review-integration','review-fresh','review-0.1.2','review-0.1.3','review-0.1.4','review-0.1.5','audit-controls','audit-0.1.2','audit-0.1.3','fixtures','reports','reports-0.1.2','reports-0.1.3','reports-0.1.4','reports-0.1.5','docs')
 entries={}
 for folder in folders:
  for f in (ROOT/folder).rglob('*'):
   rel=f.relative_to(ROOT)
   if f.is_file() and not set(rel.parts)&{'__pycache__','runs','dist'} and f.suffix!='.pyc':entries[rel.as_posix()]=f.read_bytes()
 for name in ('run_all.py','run_legacy.py','run_existing.py','run_audit_controls.py','build_release.py','requirements-test.txt','README-verification.txt','source-changes.patch','package.json','progress.md','plan.txt','design.txt'):
  entries[name]=(ROOT/name).read_bytes()
 bundle=archive(out/'bjarkiLearn-0.1.5-shadow-verification.zip',entries)
 release={'passed':True,'addon':addon,'verification_bundle':bundle,'package':package}
 dump(out/'bjarkiLearn-0.1.5-shadow-release-checks.json',release)
 print(json.dumps({'passed':True,'addon':addon,'verification_bundle':bundle,'changed_files':changed},indent=2))
if __name__=='__main__':main()
