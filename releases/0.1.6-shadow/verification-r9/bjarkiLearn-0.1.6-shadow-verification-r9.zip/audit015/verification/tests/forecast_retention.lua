local ns=...
local cases={}
local checks=0
local function check(ok,msg) checks=checks+1; assert(ok,msg) end
local function ctx(c,t,id,role)
 c:Context({actor=id or 'P',at=t,role=role or 'self',class='PRIEST',combat=true,bound=true,health=.8,power=.7})
end
local function cast(c,id,t,actor,family,revision,retracted)
 return c:Cast({id=id,at=t,actor=actor or 'P',family=family or 1,revision=revision or 1,retracted=retracted})
end
local function copy(v)
 if type(v)~='table' then return v end
 local out={}; for k,x in pairs(v) do out[k]=copy(x) end
 return setmetatable(out,getmetatable(v))
end
local base=ns.Core.New(); base:SetCoverage(true)
for n=1,256 do
 local t=10+(n-1)*3; ctx(base,t); base:Tick(t,true)
 if n==2 or n==4 or n==6 or n==8 then assert(cast(base,'train-'..n,t+.5)) end
 base:Tick(t+2.25,true)
end
for n=1,300 do base:Tick(780,false) end
assert(base.model and not base.dirty and #base.examples==256,'warm real model')
local function retire(c,count)
 for n=1,count do local t=1000+(n-1)*3; ctx(c,t); c:Tick(t,true); c:Tick(t+2.25,true) end
end
local function score(c,t)
 ctx(c,t); c:Tick(t,true); return c:Forecast('P',t).outputs[1].score
end
local function run(name,fn)
 local before=checks; local ok,msg=pcall(fn,copy(base))
 cases[#cases+1]={name=name,passed=ok,error=not ok and tostring(msg) or nil,checks=checks-before}
end
run('routine example retirement and cached snapshot metadata',function(c)
 local model=c.model; local rev=c.corpusRevision; local steps=c:Status().trainingSteps
 retire(c,2)
 check(c.model==model,'routine retirement withdrew serving model')
 check(score(c,1007)~=nil,'numeric forecast interrupted')
 local s=c:Status(); local f=c:Forecast('P',1007)
 check(s.modelDependencyCount==256 and #c.examples==256,'bounded serving dependencies')
 check(s.modelCorpusRevision==rev and s.modelRefreshPending==true and s.modelExamples==256,'snapshot metadata')
 check(f.modelCorpusRevision==rev and f.modelRefreshPending==true,'forecast snapshot metadata')
 check(s.trainingSteps==steps and not s.training,'no combat training')
 c:_Dirty(false); local cached=c:Forecast('P',1007)
 check(cached.corpusRevision==c.corpusRevision and cached.modelRefreshPending,'cached metadata stays current')
 check(c:Forecast('P',1009).outputs[1].score==nil,'stale input still withholds')
end)
run('late first evidence in retired negative training row',function(c)
 retire(c,2); check(c.model~=nil,'serving precondition')
 check(cast(c,'late-new',10.5),'late positive accepted')
 check(c.model==nil and c.candidate==nil,'retired negative correction invalidates')
 check(score(c,1007)==nil,'corrected forecast withheld')
 check(c:Status().modelDependencyCount==0 and c:Status().modelCorpusRevision==nil,'dependency cleanup')
end)
run('retraction of retired positive training row',function(c)
 retire(c,2); check(c.model~=nil,'serving precondition')
 check(cast(c,'train-2',13.5,'P',1,2,true),'revision accepted')
 check(c.model==nil,'retired positive correction invalidates')
end)
run('old actor and time dependency protected on reattribution',function(c)
 retire(c,2); check(c.model~=nil,'serving precondition')
 check(cast(c,'train-2',1500,'Enemy',3,2),'actor/time/family revision accepted')
 check(c.model==nil,'old dependency invalidated')
end)
run('new actor and time dependency protected on reattribution',function(c)
 check(cast(c,'move-in',900,'Enemy',3),'unrelated occurrence accepted')
 check(c.model~=nil,'unrelated actor preserves serving')
 retire(c,2); check(c.model~=nil,'serving precondition')
 check(cast(c,'move-in',10.5,'P',2,2),'new actor/time accepted')
 check(c.model==nil,'new dependency invalidated')
end)
run('routine occurrence retirement versus rejected history',function(c)
 local model=c.model
 for n=1,129 do check(cast(c,'flood-'..n,1200+n,'Enemy',2),'future unrelated evidence') end
 check(#c.occurrenceOrder==128 and c.model==model,'occurrence retirement withdrew model')
 check(c.examples[2].y[1]==0 and not c.examples[2].mask[1],'retired evidence censors replay')
 check(c:Status().modelDependencyCount==256,'retired occurrence preserves serving dependency')
 local ok,why=cast(c,'below-floor',13.5)
 check(not ok and why=='outside_retained_history','old evidence must remain rejected')
 check(c.model==nil,'rejected conflicting evidence invalidates serving')
end)
run('unknown correction after occurrence retirement',function(c)
 for n=1,129 do cast(c,'flood-'..n,1200+n,'Enemy',2) end
 check(c.model~=nil,'serving precondition')
 local ok,why=cast(c,'train-2',13.5,'P',1,2,true)
 check(not ok and why=='revision_history_lost' and c.model==nil,'lost correction conservative invalidation')
end)
run('duplicate and unchanged semantic revision preserve serving',function(c)
 local model=c.model
 local ok,why=cast(c,'train-2',13.5)
 check(not ok and why=='duplicate' and c.model==model,'duplicate no-op')
 check(cast(c,'train-2',13.5,'P',1,2),'same evidence newer revision accepted')
 check(c.model==model,'identical semantic revision should preserve valid serving')
 ok,why=cast(c,'train-2',13.5,'P',1,1,true)
 check(not ok and why=='duplicate' and c.model==model,'older contradictory revision no-op')
end)
run('replacement releases retired dependencies and deterministic recent replay',function(c)
 retire(c,2); check(c.model~=nil,'serving precondition')
 -- Resolve the final open window before beginning stable replay.
 for n=1,300 do c:Tick(1010,false) end
 check(c.model~=nil and not c.dirty,'replacement complete')
 local s=c:Status(); check(s.modelCorpusRevision==s.corpusRevision and not s.modelRefreshPending,'replacement current')
 check(s.modelDependencyCount==256,'replacement dependencies bounded')
 local d=ns.Core.New(); check(d:Restore(c:Export()),'restore corpus')
 for n=1,300 do d:Tick(1010,false) end
 local p=c.model:Predict(c.examples[1].x); local q=d.model:Predict(c.examples[1].x)
 for _,kind in ipairs({'neural','linear','frequency'}) do for i=1,6 do check(p[kind][i]==q[kind][i],'recent corpus deterministic replay') end end
 local model=c.model; check(cast(c,'late-discarded',10.5),'old new occurrence accepted')
 check(c.model==model,'replaced model should release old dependency')
end)
run('candidate canceled by correction and reset seals dependency lifetime',function(c)
 retire(c,2); c:Tick(1010,false)
 check(c.model~=nil and c.candidate~=nil,'serving plus rebuilding candidate')
 check(cast(c,'train-2',13.5,'P',1,2,true),'correction accepted')
 check(c.model==nil and c.candidate==nil,'correction cancels candidate and serving')
 for n=1,300 do c:Tick(1010,false) end
 check(c.model~=nil,'corrected replay recovers')
 local model=c.model; c:ResetSession(0)
 check(c.model==model and c:Status().modelDependencyCount==0,'session sealing removes raw dependencies')
 check(cast(c,'new-session',13.5),'new session observation')
 check(c.model==model,'sealed historical model not incorrectly revised')
end)
run('empty replay and failed replacement metadata',function(c)
 c:_Dirty(false); c.examples={}; c:Tick(800,false)
 check(c.model==nil and c:Status().modelDependencyCount==0 and c:Status().modelExamples==nil,'empty replay clears serving metadata')
 c=copy(base); retire(c,2); c:Tick(1010,false)
 check(c.candidate~=nil,'candidate started')
 c.candidate.model.Learn=function() return false end
 local model=c.model; c:Tick(1010,false)
 check(c.model==model and not c.dirty and c.candidate==nil,'failure retains valid serving snapshot')
 check(c:Status().modelRefreshPending==true,'failed rebuild does not claim snapshot current')
end)
return {cases=cases,checks=checks}
