from pathlib import Path
import sys, json, argparse, importlib
sys.path.insert(0, 'C:/Users/Mewn/Documents/Codex/2026-10-16/let/work/deps')
p=argparse.ArgumentParser(); p.add_argument('--source', required=True); p.add_argument('--output', required=True); args=p.parse_args()
source=Path(args.source).resolve(); root=Path(__file__).resolve().parent
out={'source':str(source),'runtimes':{}}
def plain(v):
 if hasattr(v,'items'):
  d=dict(v.items())
  if d and set(d)==set(range(1,len(d)+1)): return [plain(d[k]) for k in range(1,len(d)+1)]
  return {str(k):plain(x) for k,x in d.items()}
 return v
for engine in ('lua51','lua54'):
 lua=importlib.import_module('lupa.'+engine).LuaRuntime(unpack_returned_tuples=True)
 ns=lua.table()
 for name in ('Bootstrap','Rules','Network','Core'):
  lua.execute((source/(name+'.lua')).read_text(encoding='utf-8-sig'),'bjarkiLearn',ns)
 result=plain(lua.execute((root/'forecast_retention.lua').read_text(encoding='utf-8-sig'),ns))
 result['passed']=all(c['passed'] for c in result['cases']); out['runtimes'][engine]=result
Path(args.output).write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
sys.exit(0 if all(r['passed'] for r in out['runtimes'].values()) else 1)
