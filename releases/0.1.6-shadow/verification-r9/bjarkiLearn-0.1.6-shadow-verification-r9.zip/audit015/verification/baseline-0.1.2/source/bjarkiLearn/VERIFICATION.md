# bjarkiLearn 0.1.2-shadow verification

## Release checks

**302/302 scenario executions passed across Lua 5.1 and Lua 5.4.** All six runtime Lua modules passed syntax loading on both engines (12 checks). A separate exact-integer seed corpus and independent boundary sweeps also passed. These counts describe modeled checks, not live-client validation or predictive accuracy.

| Scenario suites | Executions across both runtimes |
| --- | ---: |
| All preserved packaged 0.1.1 suites | 136 |
| Later 0.1.1 audit correctness controls | 40 |
| Registration repair and coverage controls | 86 |
| Save-shape and atomic rejection controls | 40 |

The seed suite checks 2,577 distinct boundary and randomized integer seeds in three runtime/number representations (7,731 constructor cases), plus 28 invalid inputs. Python arbitrary-precision integer modulo supplies the independent normalization oracle. Complete model state, RNG state, weights and predictions agree across Lua 5.1 doubles and Lua 5.4 integer/float inputs. The actual production 48/12/6 model with seed 73013 matches the unchanged 0.1.1 model bit-for-bit on both engines, including three prediction inputs.

Fresh independent review found no material functional finding. Its additional 22,136 boundary checks cover every dense import length from 0 to 256, sparse mutations, protected metatables, invalid keys, 10,030 exact-oracle seeds per engine and seven registration return forms. These are repeated boundary probes, not 22,136 independent gameplay scenarios.

## Repairs and before/after evidence

- Registration: an explicit false return no longer grants cast-stream absence coverage. Legacy nil and readable true returns remain supported. Exceptions, unreadable values and unexpected result types fail closed. Real Main/Adapter/Core tests verify censored absence and retained readable positive casts. On unchanged 0.1.1, the new suite had 60 expected failures; all 86 checks pass after repair.
- Restore: a malformed saved-example array cannot silently load only its prefix. All collection keys and every expected record are validated before state replacement; holes, invalid keys and metatable-backed arrays are rejected. Live model, candidate, pending windows, occurrence history, corpus revision and exported data remain unchanged after rejection. Valid empty/dense/capacity imports retain their replacement semantics. On unchanged 0.1.1, 30 of 40 new cases failed as expected; all 40 now pass.
- Seeds: signed remainder normalization handles the full accepted integer range without the extreme-negative quotient rounding in Lua 5.1. The baseline corpus recorded 336 failed assertions, including a constructed model that immediately failed validation. The repaired corpus has zero failures. Constructor defaults and production initialization are unchanged.

The 136 previous suites still check forecast continuity through retirement, immediate correction invalidation, bounded correction descriptors, replay replacement, combat deferral, persistence and integration. The sustained test retained scored forecasts through 321 example evictions and 57 occurrence evictions; serving descriptors stayed at or below 256. The 16-actor, 128-occurrence and 256-example caps remain unchanged.

## Preservation and scope

Twenty prior test/runner/support source files are preserved byte-for-byte; the previous run_all.py is retained as run_legacy.py. Seven later audit fixture files are also preserved. The wrapper explicitly excludes the two historical defect observations superseded by these repairs and the private-Core future-timestamp observation outside this scope. They are never counted as passing correctness controls. The unmodified lifecycle file still executes its historical sparse-save assertion; its expected failure is recorded separately as a superseded observation.

The original 0.1.0 archive did not supply its older advertised 124-case release harness. This release does not claim to have rerun that unavailable harness. The provided verification bundle contains every test actually run here, unchanged baselines, RED/GREEN results, source hashes, source diff and independent review.

No saved schema, feature meaning, vocabulary or compatibility key changes were made. Old saved labels cannot be retroactively validated by this registration repair. No installed addon or GitHub repository was modified. All public forecasts remain shadow diagnostics with usable=false.

## Reproduce

Extract bjarkiLearn-0.1.2-shadow-verification.zip and run:

```sh
python -m pip install -r requirements-test.txt
python run_all.py
python build_release.py --output dist
```

The final summary is reports-0.1.2/verification.json. Detailed suite reports live alongside it. The install ZIP retains the same 14-file inventory; packaging validates both TOCs, versions, load references, strict UTF-8, CRCs and exact archived source bytes.

Native event delivery, whether the target client actually returns silent false for registration, taint/secret-value enforcement, rendering, actual frame cost and predictive usefulness remain unverified in WoW. Ordinary Lua mocks cannot establish them.

## Runtime SHA-256

| File | SHA-256 |
| --- | --- |
| Adapter.lua | `8d202f577b5c0abce58e7655e56b37597ccb17f465233333952614370a614c88` |
| Bootstrap.lua | `86a757524d67e67b9d101bf3cc09105e0a14ba265033b977f2a1a4ecd14c6dac` |
| Core.lua | `8a104ca8806f5c19984cc4ed2a69a1d2c4969c9f626d03fcbd637e3bbef276f3` |
| Main.lua | `3d468590005b81484af4d548f54bf41d561165d3762c6142931e87df8596052e` |
| Network.lua | `49668680ce13803c329a816f76863b04bb752cb07e5d2759cf7076af05165c49` |
| Rules.lua | `25ef0cc8edb17cab6d251a63784589bcabc6c9485cd30e46078b404e4df8a532` |
