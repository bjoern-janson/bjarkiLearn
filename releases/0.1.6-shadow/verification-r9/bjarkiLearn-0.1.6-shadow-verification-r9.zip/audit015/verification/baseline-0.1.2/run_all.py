"""Run the preserved suites and 0.1.2 repair regressions against bundled source."""
from pathlib import Path
import hashlib, importlib, json, subprocess, sys, time
ROOT=Path(__file__).resolve().parent
SOURCE=ROOT/'source/bjarkiLearn'
REPORTS=ROOT/'reports-0.1.2'
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def hashes(): return {p.name:sha(p) for p in sorted(SOURCE.glob('*.lua'))}
def read(path): return json.loads((ROOT/path).read_text(encoding='utf-8-sig'))
def main():
 REPORTS.mkdir(exist_ok=True)
 expected=read('fixtures/v0.1.1-test-source-hashes.json')['sha256']
 preserved=lambda:{n:sha(ROOT/n) for n in expected}
 assert preserved()==expected, 'Prior test files changed'
 dependency_args=[]
 try: importlib.import_module('lupa.lua51')
 except ImportError:
  fallback=Path('C:/Users/Mewn/Documents/Codex/2026-10-16/let/work/deps')
  if not fallback.is_dir(): raise SystemExit('Install test dependencies: python -m pip install -r requirements-test.txt')
  dependency_args=['--lupa-path',str(fallback)]
 before=hashes();runs=[]
 jobs=[
  ('prior136',['run_legacy.py']),
  ('audit_controls',['run_audit_controls.py','--source',str(SOURCE),'--output',str(REPORTS/'audit-controls.json')]),
  ('registration',['new-tests/registration/run.py','--source',str(SOURCE),'--output',str(REPORTS/'registration.json')]),
  ('restore',['new-tests/restore/run.py','--source',str(SOURCE),'--output',str(REPORTS/'restore.json')]),
  ('seeds',['new-tests/seeds/run_seed_regressions.py','--source',str(SOURCE),'--baseline',str(ROOT/'baseline-0.1.1/source/bjarkiLearn'),'--output',str(REPORTS/'seeds.json')]),
  ('fresh_review',['review-0.1.2/run.py','--source',str(SOURCE),'--output',str(REPORTS/'fresh-review.json'),*dependency_args]),
 ]
 for name,args in jobs:
  print('Running '+name+'...',flush=True);start=time.perf_counter()
  result=subprocess.run([sys.executable,str(ROOT/args[0]),*args[1:]],cwd=ROOT,capture_output=True,text=True,encoding='utf-8',errors='replace')
  (REPORTS/(name+'-output.txt')).write_text(result.stdout+result.stderr,encoding='utf-8')
  runs.append({'suite':name,'exit_code':result.returncode,'seconds':round(time.perf_counter()-start,3)})
  if result.returncode:
   print(result.stdout+result.stderr);raise SystemExit(result.returncode)
 legacy=read('reports/verification.json');audit=read('reports-0.1.2/audit-controls.json');registration=read('reports-0.1.2/registration.json');restore=read('reports-0.1.2/restore.json');seeds=read('reports-0.1.2/seeds.json')
 assert legacy['passed'] and legacy['scenario_executions']==136 and legacy['syntax_passed']==12
 assert audit['passed'] and audit['scenario_executions']==40
 assert registration['summary']['passed']==registration['summary']['total']==86 and registration['source_unchanged']
 assert restore['passed']==restore['total']==40 and restore['source_unchanged']
 assert seeds['status']=='PASS' and seeds['failure_count']==0 and seeds['corpus_seed_count']==2577
 fresh=read('reports-0.1.2/fresh-review.json')
 assert fresh['summary']['passed']==fresh['summary']['total']==22136 and fresh['source_unchanged']
 assert fresh['source_hashes']==before
 assert before==hashes()==legacy['runtime_hashes']==audit['source_hashes']==registration['source_hashes']==restore['source_hashes']
 assert before['Network.lua']==seeds['source_sha256']
 assert preserved()==expected and legacy['original_harnesses_unchanged'] and audit['fixture_original_bytes_verified']
 counts={'prior_packaged':136,'later_audit_controls':40,'registration_repair':86,'restore_repair':40}
 report={'passed':True,'version':'0.1.2-shadow','scenario_executions':sum(counts.values()),'counts':counts,'independent_boundary_checks_passed':fresh['summary']['passed'],'syntax_checks_passed':12,'runtime_hashes':before,'source_unchanged':True,'preserved_test_files':len(expected),'prior_test_source_bytes_unchanged':True,'audit_fixture_files_unchanged':len(audit['fixture_hashes']),'seed_corpus_distinct_values':seeds['corpus_seed_count'],'seed_constructor_cases':sum(x['accepted_seeds_checked'] for r in seeds['runtimes'].values() for x in r['representations'].values()),'seed_invalid_inputs_checked':sum(r['invalid_inputs_checked'] for r in seeds['runtimes'].values()),'production_default_unchanged':all(r['production_default_control']['baseline_complete_state_and_three_predictions_identical'] for r in seeds['runtimes'].values()),'runs':runs,'long_integration':legacy['long_integration'],'limits':['Modeled WoW APIs, not live-client verification.','Native silent-false registration trigger on the intended client remains unconfirmed.','Private Core future-timestamp observation remains outside this repair.','Saved labels cannot be retroactively validated by the registration repair.','Shadow outputs remain unusable by consumers.']}
 (REPORTS/'verification.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
 print(json.dumps(report,indent=2))
if __name__=='__main__': main()
