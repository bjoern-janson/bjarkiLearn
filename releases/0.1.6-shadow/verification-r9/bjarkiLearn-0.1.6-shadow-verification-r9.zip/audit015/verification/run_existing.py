"""Run the byte-identical independent 0.1.0 audit harnesses against sibling source.

Usage: python run_existing.py
Requires Lupa with lua51 and lua54 (python -m pip install lupa).
Only two pre-existing runner path assignments are redirected in memory. The
original Python/Lua files remain byte-identical to their captured audit copies.
The seed_portability.py advisory is preserved but intentionally not executed.
"""
from pathlib import Path
import contextlib
import hashlib
import importlib
import io
import json
import sys
import traceback

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'source/bjarkiLearn'
REPORT = ROOT / 'reports/existing-tests.json'
MANIFEST = ROOT / 'fixtures/original-harness-hashes.json'
RUNNERS = [
    ('main', 'review-main/run.py', 'review-main/results.json'),
    ('warm', 'review-main/run_warm.py', 'review-main/warm-results.json'),
    ('core', 'review-core/probe_core.py', 'review-core/results.json'),
    ('network', 'review-network/audit_network.py', 'review-network/results.json'),
    ('adapter', 'review-adapter/probe.py', 'review-adapter/results.json'),
]
REDIRECTIONS = {
    'review-main/run_warm.py': (
        "root=Path('work/learn-shadow-0.1.0-audit/review-main').resolve()",
        "root=Path(__file__).resolve().parent",
    ),
    'review-adapter/probe.py': (
        "BUS = BASE.parents[0] / 'github-2026-10-23/repos/bjarkiPortraits/SharedEvidence.lua'",
        "BUS = BASE / 'fixtures/SharedEvidence.lua'",
    ),
}
EXPECTED_SUITE_COUNTS = {'main': 28, 'warm': 2, 'core': 16, 'network': 22, 'adapter': 30}
ADAPTER_CAVEAT = 'clock_rewind_live_trigger_established'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def source_hashes():
    return {p.name: sha(p) for p in sorted(SOURCE.glob('*.lua'))}

def ensure_runtime():
    try:
        importlib.import_module('lupa.lua51')
        importlib.import_module('lupa.lua54')
    except ImportError:
        # Optional fallback for the original audit machine; never required by a
        # relocated bundle when Lupa is installed in the invoking interpreter.
        fallback = Path('C:/Users/Mewn/Documents/Codex/2026-10-16/let/work/deps')
        if fallback.is_dir():
            sys.path.insert(0, str(fallback))
        try:
            importlib.import_module('lupa.lua51')
            importlib.import_module('lupa.lua54')
        except ImportError as exc:
            raise SystemExit('Install test dependency with: python -m pip install lupa') from exc

def execute_runner(name, relative, output):
    path = ROOT / relative
    result_path = ROOT / output
    if result_path.exists():
        result_path.unlink()  # Do not interpret an earlier run as fresh evidence.
    code = path.read_text(encoding='utf-8-sig')
    substitutions = []
    if relative in REDIRECTIONS:
        old, new = REDIRECTIONS[relative]
        if code.count(old) != 1:
            raise AssertionError(f'Expected exactly one path assignment in {relative}')
        code = code.replace(old, new, 1)
        substitutions.append({'original': old, 'runtime_only': new})
    stdout, stderr = io.StringIO(), io.StringIO()
    exit_code, error = 0, None
    try:
        with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
            exec(compile(code, str(path), 'exec'), {'__name__': '__main__', '__file__': str(path)})
    except SystemExit as exc:
        exit_code = int(exc.code) if isinstance(exc.code, int) else (0 if exc.code is None else 1)
        if exit_code:
            error = str(exc)
    except Exception:
        exit_code, error = 1, traceback.format_exc()
    (path.parent / (path.stem + '-wrapper-output.txt')).write_text(
        stdout.getvalue() + stderr.getvalue() + ('\n' + error if error else ''), encoding='utf-8')
    raw = json.loads(result_path.read_text(encoding='utf-8-sig')) if result_path.exists() else None
    return {'suite': name, 'runner': relative, 'exit_code': exit_code, 'error': error,
            'output': output, 'runtime_path_substitutions': substitutions}, raw

def main():
    ensure_runtime()
    expected = json.loads(MANIFEST.read_text(encoding='utf-8'))['sha256']
    before = source_hashes()
    harness_before = {rel: sha(ROOT / rel) for rel in expected}
    if harness_before != expected:
        raise SystemExit('Harness/fixture differs from original audit capture; refusing to run.')
    runners, cases, syntax, caveats = [], [], [], []
    for name, relative, output in RUNNERS:
        print('Running ' + name + '...', flush=True)
        runner, raw = execute_runner(name, relative, output)
        runners.append(runner)
        if raw is None:
            continue
        if name == 'main':
            cases.extend(dict(suite=name, engine=r['engine'], case=r['case'], passed=r['passed'],
                              checks=r['checks'], error=r['error']) for r in raw['cases'])
            syntax = raw['syntax']
        elif name == 'warm':
            cases.extend(dict(suite=name, engine=r['engine'], case='warm native pipeline',
                              passed=r['passed'], checks=r['checks'], error=r['error']) for r in raw)
        elif name == 'core':
            cases.extend(dict(suite=name, engine=r['runtime'], case=r['probe'], passed=r['passed'],
                              error=r.get('error'), detail=r.get('detail')) for r in raw)
        elif name == 'network':
            for engine in raw['results']:
                cases.extend(dict(suite=name, engine=engine['engine'], case=case, passed=True)
                             for case in engine['cases'])
        elif name == 'adapter':
            for engine, rows in raw.items():
                for case, passed in rows.items():
                    row = dict(suite=name, engine=engine, case=case, passed=passed)
                    if case == ADAPTER_CAVEAT:
                        caveats.append(dict(engine=engine, flag=case, value=passed,
                                            meaning='A modeled clock-rewind test; no live trigger established.'))
                    else:
                        cases.append(row)
    counts = {name: sum(r['suite'] == name for r in cases) for name in EXPECTED_SUITE_COUNTS}
    after = source_hashes()
    harness_after = {rel: sha(ROOT / rel) for rel in expected}
    failures = [r for r in cases if r['passed'] is not True]
    syntax_failures = [r for r in syntax if r['passed'] is not True]
    validation_errors = []
    if counts != EXPECTED_SUITE_COUNTS:
        validation_errors.append({'scenario_counts': counts, 'expected': EXPECTED_SUITE_COUNTS})
    syntax_pairs = {(r['engine'], r['file']) for r in syntax}
    if len(syntax) != 12 or len(syntax_pairs) != 12:
        validation_errors.append('Expected 12 distinct Lua-engine/module syntax checks.')
    if len(before) != 6:
        validation_errors.append('Expected six Lua runtime source files.')
    if before != after:
        validation_errors.append('Runtime source changed during tests.')
    if harness_before != harness_after or harness_after != expected:
        validation_errors.append('Harness or fixture bytes changed during tests.')
    if len(caveats) != 2 or any(r['value'] is not False for r in caveats):
        validation_errors.append('Expected two explicit unestablished-live-clock-trigger caveat flags.')
    success = not (failures or syntax_failures or validation_errors or any(r['exit_code'] for r in runners))
    report = {
        'passed': success,
        'summary': {'scenario_executions': len(cases), 'passed': sum(r['passed'] is True for r in cases),
                    'failed': len(failures), 'syntax_checks': len(syntax),
                    'syntax_passed': sum(r['passed'] is True for r in syntax), 'suite_counts': counts},
        'cases': cases, 'syntax': syntax, 'failures': failures, 'syntax_failures': syntax_failures,
        'validation_errors': validation_errors, 'runners': runners, 'caveats': caveats,
        'source_unchanged': before == after, 'source_hashes': before,
        'harnesses_identical_to_original_capture': harness_before == expected == harness_after,
        'harness_hashes': harness_after, 'wrapper_sha256': sha(Path(__file__)),
        'notes': [
            'Original audit Python and Lua files copied byte-for-byte; manifest captures original hashes.',
            'Exactly two path assignments redirected in memory; no test assertion or fixture content changed.',
            'Adapter caveat flag clock_rewind_live_trigger_established=false is not a failed scenario.',
            'seed_portability.py preserved but excluded: unrelated advisory, not part of 98 audit scenarios.',
            'These are ordinary Lua/modelled API checks, not live-client validation.',
        ],
    }
    REPORT.parent.mkdir(exist_ok=True)
    REPORT.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'passed': success, 'summary': report['summary'], 'failures': failures,
                      'syntax_failures': syntax_failures, 'validation_errors': validation_errors}, indent=2))
    return 0 if success else 1

if __name__ == '__main__':
    raise SystemExit(main())

