from pathlib import Path
import hashlib, importlib, itertools, json, sys
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, 'C:/Users/Mewn/Documents/Codex/2026-10-16/let/work/deps')
SOURCE = ROOT / 'source/bjarkiLearn'
BASELINE = ROOT / 'baseline-0.1.4/source/bjarkiLearn'
def hashes(folder):
    return {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(folder.iterdir()) if p.suffix in ('.lua','.toc')}
before = {'baseline':hashes(BASELINE),'current':hashes(SOURCE)}
results=[]
for engine in ('lua51','lua54'):
    functions=[]
    for source in (BASELINE,SOURCE):
        lua=importlib.import_module('lupa.'+engine).LuaRuntime(unpack_returned_tuples=True)
        ns=lua.table()
        for name in ('Bootstrap.lua','Rules.lua','Network.lua','Core.lua'):
            lua.execute((source/name).read_text(encoding='utf-8'),'bjarkiLearn',ns)
        functions.append(lua.execute(Path(__file__).with_name('policy_matrix.lua').read_text(encoding='utf-8'),ns))
    checked=0
    for case in itertools.product(('evidence','retirement','time'),range(64),range(10),range(3),(0,1,2,3)):
        expected,actual=(f(*case) for f in functions)
        if expected!=actual:
            raise AssertionError((engine,case,expected,actual))
        checked+=1
    results.append({'engine':engine,'exact_policy_state_comparisons':checked,'passed':True})
after={'baseline':hashes(BASELINE),'current':hashes(SOURCE)}
assert before==after,'Reviewed runtime changed during test'
report={'kind':'white-box reconciliation policy equivalence; synthetic bounded states, actual Labels and dirty/withdraw implementations', 'results':results,'runtime_unchanged':before==after,'hashes':before}
Path(__file__).with_name('policy-matrix-results.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'results':results,'runtime_unchanged':True},indent=2))
