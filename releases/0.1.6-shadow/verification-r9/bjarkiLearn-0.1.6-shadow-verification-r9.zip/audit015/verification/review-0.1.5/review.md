# Independent whole-change review: bjarkiLearn 0.1.5

Verdict: no Critical, Important or Minor source findings. Approve the two internal refactors as bounded offline-equivalent changes against exact 0.1.4. This is not live WoW validation. Runtime fingerprints and the gate are in review-gate.json; all install-source hashes are in reviewed-source-hashes.json.

## Review basis and strengths

Read the approved plan and progress rulings, the complete Core, the exact runtime diff, Rules, public API contract and consumers, contract tests, the available independent differential tests, and updated install documentation. The frozen baseline Core SHA-256 is 9dc55ae29fd69e76448bd8c83e8386edbaa1bff00009dbd98dc8532678c4dc01; reviewed current Core is 3766ae3f630f5f4aa072242411d9768a3b7899a39ea9bf5a43bdb3010afa800a.

- Core.lua:114-116,170-174,285,343-344,363 retain every actor revision/cache invalidation site and order. All production feature extraction paths provide explicit time-projected evidence (398-399,498-500); GetContext still returns a fresh projection (506-516). Rules.Features retains its standalone evidence-bearing-actor fallback. The removed mirrors have no remaining production consumer.
- Core.lua:224-270 cleanly separates the three trigger policies without introducing another store. Evidence change (244-248) checks serving guards before updating affected rows and withdraws once if required. Retirement (249-253) only dirties replay and preserves serving state. Observed-time advance (254-270) checks newly mature occurrences against model descriptors independently of row retention, then updates every unsealed row once.
- Core.lua:324-335 deliberately routes below-floor rejected evidence through correction reconciliation. It is not weakened into routine retirement. Reattribution (343-344) does not depend on either actor being bound or fresh; a missing actor remains a no-op, as before.
- The time-advance call preserves the old since=0 behavior: zero is truthy in Lua. Original call sites only use the three combinations now represented by named paths. Dirty/withdraw decisions, row revisions, lead updates, candidate cancellation and stats are equivalent.
- The bounded occurrence insertion/eviction ordering, latestEver/evidenceFloor policy, candidate/model descriptors, reset ordering, restore validation, schema and compatibility key are unchanged. The other five Lua modules are byte-identical except Bootstrap version metadata; both TOCs only change version metadata.

## Evidence

Reviewer-owned policy_matrix.lua and run_policy_matrix.py compare actual baseline/current reconciliation code, _Labels and dirty/withdraw effects over synthetic bounded states. Both Lua 5.1 and Lua 5.4 passed 23,040 exact serialized Core-state comparisons each (46,080 total). The matrix varies three triggers, sealed/player/other rows, coverage/lost state, previous labels/masks, ten correction/interval/identity variants, absent/P/Q serving guards and four observed-time frontiers. Lead is independently initialized to force an update. Both runtime inventories were unchanged across the run. See policy-matrix-results.json.

This is white-box policy equivalence evidence, not 46,080 independent end-to-end integration scenarios. Caller ordering and production consumers were inspected directly. The existing contract tests explicitly check absent mirrors, pure public copies, no write-path projection, actor invalidation and standalone Rules fallback. The separate test authors own the full legacy regression replay and larger cross-version traces; their complete final results were not yet available at this review point.

## Findings

Critical: none.

Important: none.

Minor: none requiring code changes.

Wording clarification sent to executor: an outcome updater lead-only change does not dirty by itself. An actual timestamp correction may still withdraw a dependent serving model through correction guards even if labels/masks stay unchanged; preserving this is required for equivalence with 0.1.4. The independent test leadOnlyWithdrawsDependentModel correctly distinguishes these cases. Documentation should retain this distinction rather than imply all timestamp refinements are globally exempt from dirty/withdraw policy.

## Declined to judge

- Live WoW event delivery, native rendering, actual taint/secret enforcement and frame-time cost: no live client was exercised.
- Predictive usefulness or calibration: equivalence and synthetic tests do not supply independent encounter evidence.
- Recovery beyond discarded identities or sealed/deidentified history: unchanged bounded-history limitations are explicitly outside these refactors.
- Final builder, portable verifier and ZIP integrity: executor is still completing packaging; a bounded final inspection will follow notification. This gate approves the reviewed runtime, not an uninspected final archive.

No source, inherited tests or Git state were mutated. Reviewer additions are confined to review-0.1.5.

## Final packaging-source inspection

Inspected root run_all.py, build_release.py, README-verification.txt and the staged runner once after completion. All three Python scripts compile. The original runtime SHA-256 values remain unchanged; reviewed-source-hashes.json now includes the two accepted documentation clarifications. The final independent report records 56/56 cases, 208 checkpoints and 1,819,360 exact scalar comparisons.

One Important packaging-source defect was identified and resolved: run_all.py:51 expected documentation_changes_only when source_unchanged was false, but the producer did not emit the field. tests-refactor/legacy/run.py:188 now sets it after validating exactly the two allowed substitutions, retaining runtime_source_unchanged and full disclosure of the staged/current documentation hashes. The correction was inspected and compiled; actual aggregate execution remains part of the executor's final checks.

No open material packaging-source findings. Inspected checks cover current runtime and baseline report hashes, immutable original tests, exact frozen ZIP/source identity, 14 install files, both TOCs/version/load order, explicit source-change scope, UTF-8 decoding, duplicate-free ZIP names, CRC/archived-byte equality, fixed archive metadata and exclusion of transient execution directories. README correctly distinguishes same-input deterministic packaging from regenerated reports containing new timing/path data. Production packaging uses installed Lupa when available; the developer fallback is not a prerequisite on another machine.

This completes the requested whole-change source review. Actual final ZIP CRC/byte validation, aggregate execution and clean-extraction rebuild are deliberately left to the executor, which is performing them; this review does not report those pending executions as passed. See packaging-source-review.json for exact inspected script fingerprints and the resolved finding.
