local ns=...
local function encode(t)
 if type(t)~='table' then return type(t)..':'..tostring(t) end
 local keys={} for k in pairs(t) do keys[#keys+1]=k end
 table.sort(keys,function(a,b)return tostring(a)<tostring(b) end)
 local out={} for _,k in ipairs(keys) do out[#out+1]=encode(k)..'='..encode(t[k]) end
 return '{'..table.concat(out,',')..'}'
end
return function(trigger,bits,variant,guard,since)
 local c=ns.Core.New()
 local function bit(n)return math.floor(bits/2^n)%2==1 end
 local w={actor='P',anchor=1,deadline=3,regime=bit(0) and 'player' or 'other',sealed=bit(1),revision=7,coverage={},lost={},y={},mask={},lead={}}
 for i=1,6 do w.coverage[i]=true;w.y[i]=0;w.mask[i]=true end
 w.coverage[1]=bit(2);w.lost[1]=bit(3);w.y[1]=bit(4) and 1 or 0;w.mask[1]=bit(5);w.lead[1]=99
 local old={kind='cast',actor='P',at=2,minAt=2,maxAt=2,family=1,retracted=false}
 local new=ns.Copy(old)
 if variant==1 then new.at=2.5;new.minAt=2.5;new.maxAt=2.5
 elseif variant==2 then new.actor='Q'
 elseif variant==3 then new.retracted=true
 elseif variant==4 then new.minAt=.5
 elseif variant==5 then new.at=4;new.minAt=4;new.maxAt=4
 elseif variant==6 then new.family=2
 elseif variant==7 then old.actor='Q';new.actor='Q'
 elseif variant==8 then old=nil
 elseif variant==9 then new=nil end
 c.examples={w};c.actors={P={revision=2,forecast={cached=true}},Q={revision=3,forecast={cached=true}}}
 c.corpusRevision=12;c.candidate={sentinel=true};c.evidenceTime=3
 if guard>0 then
  c.model={sentinel=true};c.modelCorpusRevision=11;c.modelExamples=1
  c.modelDependencies={{actor=guard==1 and 'P' or 'Q',anchor=1,deadline=3}}
 end
 if trigger~='retirement' and new then c.occurrences['cast:x']=new;c.occurrenceOrder={'cast:x'} end
 if c._Reconcile then
  if trigger=='evidence' then c:_Reconcile(old,new)
  elseif trigger=='retirement' then c:_Reconcile(old,nil,true)
  else c:_Reconcile(nil,nil,false,since) end
 else
  if trigger=='evidence' then c:_ReconcileEvidenceChange(old,new)
  elseif trigger=='retirement' then c:_ReconcileHistoryRetirement(old)
  else c:_ReconcileTimeAdvance(since) end
 end
 return encode(c)
end
