local ns=NS
local results={}
local P,E='Player-1-AAA','Player-1-BBB'
local now=10
local ids, classes, combats, dead, powers
local function reset(registered)
    now=10
    ids={player=P,target=E}; classes={player='DRUID',target='ROGUE'}
    combats={player=true,target=true}; dead={}; powers={}
    UnitGUID=function(u) return ids[u] end
    UnitIsPlayer=function(u) if ids[u] then return true end end
    UnitClassBase=function(u) return classes[u] end
    UnitCanAttack=function(_,u) if u=='player' or ids[u]==P then return false elseif ids[u] then return true end end
    UnitAffectingCombat=function(u) return combats[u] end
    UnitHealth=function() return 50 end; UnitHealthMax=function() return 100 end
    UnitPower=function() return 30 end; UnitPowerMax=function() return 100 end
    UnitIsDeadOrGhost=function(u) return dead[u]==true end
    UnitPowerType=function(u) return 0,powers[u] or 'MANA' end
    GetTime=function() return now end
    local c=ns.Core.New(); local a=ns.Adapter.New(c)
    a:SetRegistered(registered~=false); a:Tick(now); c:Tick(now,true)
    return c,a
end
local function finish(c,a)
    for i=1,10 do local t=10+i*.25; if t>=now then now=t; a:Tick(now); c:Tick(now,true) end end
end
local function example(c,regime)
    for _,w in ipairs(c.examples) do if w.regime==regime then return w end end
end
local c,a=reset(); finish(c,a)
local p,e=assert(example(c,'player')),assert(example(c,'other'))
for i=1,6 do assert(p.mask[i] and p.y[i]==0); assert(not e.mask[i]) end
results.player_only_negative_coverage=true

c,a=reset(); ids.target=P; a:Bind('target',now)
now=10.25; a:OnCast('player','cast-1',22812,now); a:OnCast('target','cast-1',22812,now)
assert(c.stats.casts==1 and c.stats.duplicateCasts==1 and a.stats.casts==2)
assert(c.actors[P].role=='self'); finish(c,a)
p=example(c,'player'); assert(p.y[6]==1 and p.mask[6])
results.player_alias_cast_deduplicates=true

c,a=reset(); ids.target=P; a:Bind('target',now); ids.target=E; a:Bind('target',now)
finish(c,a); p=example(c,'player'); for i=1,6 do assert(p.mask[i]) end
results.target_alias_loss_preserves_player_coverage=true

c,a=reset(); now=10.2; a:OnCast('player',nil,22812,now); finish(c,a)
p=example(c,'player'); for i=1,6 do assert(not p.mask[i]) end
assert(c.gapReasons['unreadable-cast']==1)
results.unreadable_registered_cast_censors=true

c,a=reset(); now=10.2; a:OnCast('player',nil,99999,now); finish(c,a)
p=example(c,'player'); for i=1,6 do assert(p.mask[i]) end
assert(a.stats.unknownSpells==1)
results.unknown_spell_not_assigned_guessed_family=true

c,a=reset(false); now=10.2; a:OnCast('player','cast-1',22812,now); finish(c,a)
p=example(c,'player'); for i=1,5 do assert(not p.mask[i]) end
assert(p.mask[6] and p.y[6]==1)
results.unregistered_stream_positive_only=true

c,a=reset(); now=10.6; a:Tick(now); c:Tick(now,true); finish(c,a)
p=example(c,'player'); for i=1,6 do assert(not p.mask[i]) end
assert(c.gapReasons['scheduler-gap'])
results.scheduler_gap_censors=true

c,a=reset(); classes.player=nil; UnitClass=nil; UnitHealth=function() return nil end
UnitPower=function() return nil end; combats.player=nil; a:Bind('player',now)
local x=ns.Rules.Features(c.actors[P],now)
assert(#x==48 and x[10]==0 and x[15]==0 and x[17]==0 and x[19]==0)
assert(c.actors[P].health==nil and c.actors[P].power==nil)
results.feature_schema_preserves_missingness=true

c,a=reset(); powers.player='ENERGY'; a:Bind('player',now); assert(c.actors[P].form=='cat')
dead.player=true; a:Bind('player',now); assert(c.actors[P].form==nil)
results.druid_form_requires_readable_alive_witness=true

c,a=reset(); BjarkiEvidenceV1=nil
local loader=loadstring or load
assert(loader(BUS_SOURCE))('bjarkiPortraits',{})
local bus=BjarkiEvidenceV1
local function publish(instance,spell,recipient,observed)
    return bus:Publish({source='bjarkiPortraits',kind='aura-positive',isHelpful=true,
        recipientGUID=recipient or E,unit='target',spellId=spell or 5277,
        observedAt=observed or 10,auraInstanceID=instance,expirationTime=20,
        duration=10,newApplication=false})
end
assert(publish(42)); assert(a:ConnectBus(now)); assert(a.stats.auras==1)
assert(c.stats.auraWitnesses==1 and not c.stats.casts)
assert(c.actors[E].defensiveWitness.spellID==5277)
assert(publish(nil)); assert(a.stats.rejected==1)
assert(publish(43,16689)); assert(a.stats.auras==1)
assert(publish(44,22812,'Player-1-CCC'))
assert(not c.actors['Player-1-CCC'])
ids.target='Player-1-CCC'; now=10.25; a:Bind('target',now)
assert(c.actors['Player-1-CCC'].defensiveWitness.spellID==22812)
a:Stop(); assert(not a.stats.busConnected and bus:Status().listeners==0)
local before=a.stats.auras; assert(publish(45)); assert(a.stats.auras==before)
results.real_shared_evidence_replay_filter_delayed_binding_stop=true

c,a=reset(); assert(a:ConnectBus(now)); local beforeSession=c.session
now=10.25; a:OnEvent('PLAYER_ENTERING_WORLD')
assert(c.session==beforeSession+1 and c.coverage and a.coverage)
assert(c.stats.auraWitnesses and c.stats.auraWitnesses>0)
results.world_entry_rebinds_and_replays_bus=true

-- Clock rewind is a modeled robustness control; its live trigger is unestablished.
c,a=reset(); now=9; a:Tick(now); c:Tick(now,true)
assert(a.coverage==true and c.coverage==true)
for i=1,12 do now=9+i*.25; a:Tick(now); c:Tick(now,true) end
assert(a.coverage==true and c.coverage==true)
results.clock_rewind_preserves_coverage=true
results.clock_rewind_live_trigger_established=false
c,a=reset(); local opaque=setmetatable({}, {__tostring=function() error('opaque formatting') end})
issecretvalue=function(v) return rawequal(v,opaque) end
local oldGUID=UnitGUID
UnitGUID=function(u) if u=='player' then return opaque end return oldGUID(u) end
now=10.25; a:Tick(now); c:Tick(now,true)
assert(a.bindings.player==nil and not c.coverage)
a:OnCast(opaque,'cast-1',22812,now)
assert(c.gapReasons['unreadable-unit']==1)
issecretvalue=nil
results.modeled_secret_identity_and_unit_fail_closed=true

c,a=reset(); UnitIsPlayer=function() return false end; a:Bind('player',now)
assert(a.bindings.player==nil and not c.coverage)
results.readable_nonplayer_contradiction_rejects_guid=true

c,a=reset(); BjarkiEvidenceV1=nil; assert(not a:ConnectBus(now))
BjarkiEvidenceV1={schema=2,protocol='incompatible'}; assert(not a:ConnectBus(now))
assert(not a.stats.busConnected and c.coverage)
results.optional_missing_incompatible_bus_preserves_collection=true
return results



