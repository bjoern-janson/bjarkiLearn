from pathlib import Path
import sys, json, importlib
BASE = Path(__file__).resolve().parents[1]
sys.path.insert(0, 'C:/Users/Mewn/Documents/Codex/2026-10-16/let/work/deps')
SOURCE = BASE / 'source/bjarkiLearn'
BUS = BASE.parents[0] / 'github-2026-10-23/repos/bjarkiPortraits/SharedEvidence.lua'
out = {}
for name in ('lua51', 'lua54'):
    lua = importlib.import_module('lupa.' + name).LuaRuntime(unpack_returned_tuples=True)
    ns = lua.table()
    for file in ('Bootstrap.lua', 'Rules.lua', 'Network.lua', 'Core.lua', 'Adapter.lua'):
        lua.execute((SOURCE / file).read_text(encoding='utf-8-sig'), 'bjarkiLearn', ns)
    lua.globals().NS = ns
    lua.globals().BUS_SOURCE = BUS.read_text(encoding='utf-8-sig')
    table = lua.execute((BASE / 'review-adapter/probe.lua').read_text())
    out[name] = {k: v for k,v in table.items()}
print(json.dumps(out, indent=2, sort_keys=True))
(BASE / 'review-adapter/results.json').write_text(json.dumps(out, indent=2, sort_keys=True) + '\n')
