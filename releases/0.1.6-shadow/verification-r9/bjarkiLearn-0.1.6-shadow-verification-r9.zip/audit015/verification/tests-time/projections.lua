local ns=...
local rows={}
local function test(name,fn)
 local ok,err=pcall(fn); rows[#rows+1]={name=name,passed=ok,error=not ok and tostring(err) or nil}
end
local function ctx(c,t,id)
 assert(c:Context{actor=id or 'P',at=t,role='self',class='PRIEST',combat=true,bound=true})
end
local function cast(c,id,t,revision,extra)
 local e={actor='P',id=id,at=t,family=1,revision=revision or 1}
 for k,v in pairs(extra or {}) do e[k]=v end
 assert(c:Cast(e))
end
local function core(t)
 local c=ns.Core.New(); c:SetCoverage(true);ctx(c,t or 10);return c
end
local function model(c)
 c.model={positives={2,2,2,2,2,2},totals={10,10,10,10,10,10},Predict=function(_,x)
  local p={neural={},linear={},frequency={}}
  for i=1,6 do for _,k in ipairs{'neural','linear','frequency'} do p[k][i]=x[20] end end
  return p
 end}
end
test('future_cast_is_target_only_after_its_time',function()
 local c=core();cast(c,'future',11);c:Tick(10,true);local w=c.actors.P.window
 assert(w.x[20]==0 and w.x[21]==0,'future evidence leaked into anchor input')
 c:Tick(12.25,true);assert(w.y[1]==1 and w.mask[1],'mature target missing')
 assert(w.x[20]==0 and w.x[21]==0,'immutable anchor changed')
end)
test('future_latest_does_not_hide_earlier_valid_cast',function()
 local c=core();cast(c,'past',9);cast(c,'future',11);c:Tick(10,true)
 assert(c.actors.P.window.x[20]==1-1/30 and c.actors.P.window.x[21]==1)
 assert(c:GetContext('P',10).history[1]==9);assert(c:GetContext('P',11).history[1]==11)
end)
test('context_queries_are_pure_and_order_independent',function()
 local c=core();cast(c,'past',9);cast(c,'future',11);local rev=c.corpusRevision
 assert(c:GetContext('P',100).history[1]==11)
 assert(c:GetContext('P',10).history[1]==9,'future query polluted earlier view')
 assert(c:GetContext('P',8).history[1]==nil);assert(c.corpusRevision==rev)
 c:Tick(10,true);c:ResetSession(10.5)
 assert(c.examples[1].y[1]==0 and not c.examples[1].mask[1],'query matured a future outcome')
end)
test('forecast_cache_expires_when_future_input_becomes_current',function()
 local c=core();cast(c,'past',9);cast(c,'future',10.5);model(c);c:Tick(10,true)
 assert(c:Forecast('P',10).outputs[1].score==1-1/30)
 assert(c:Forecast('P',10.5).outputs[1].score==nil,'stale cache survived evidence boundary')
 ctx(c,10.5);c:Tick(10.5,true);assert(c:Forecast('P',10.5).outputs[1].score==1)
end)
test('forecast_from_later_time_cannot_answer_earlier_query',function()
 local c=core();cast(c,'future',10.5);model(c);c:Tick(10.5,true)
 assert(c:Forecast('P',10.5).outputs[1].score==1)
 assert(c:Forecast('P',10.25).outputs[1].score==nil,'future projection answered older query')
end)
test('future_context_is_not_inferred_before_its_observation',function()
 local c=core(11);model(c);c:Tick(10,true)
 assert(c.actors.P.window==nil and c.actors.P.forecast==nil)
end)
test('defensive_witness_projection_preserves_earlier_positive',function()
 local c=core();assert(c:Aura{id='old',recipient='P',at=9,spellID=22812,expires=20})
 assert(c:Aura{id='new',recipient='P',at=11,spellID=5277,expires=21});c:Tick(10,true)
 assert(c.actors.P.window.x[47]==1,'future witness hid valid earlier witness')
 assert(c:GetContext('P',10).defensiveWitness.spellID==22812)
 assert(c:GetContext('P',11).defensiveWitness.spellID==5277)
 assert(c:GetContext('P',8).defensiveWitness==nil);assert(c:Forecast('P',10).expires==11)
end)
test('rules_direct_input_does_not_treat_future_as_recent',function()
 local x=ns.Rules.Features({history={[1]=11}},10);assert(x[20]==0 and x[21]==0)
end)
test('early_reset_does_not_seal_future_positive',function()
 local c=core();c:Tick(10,true);cast(c,'future',11);c:ResetSession(10.5)
 local w=c.examples[1];assert(w.sealed and not w.mask[1] and w.y[1]==0)
 c:Tick(20,false);assert(not w.mask[1] and w.y[1]==0)
end)
test('reset_at_due_time_preserves_positive',function()
 local c=core();c:Tick(10,true);cast(c,'future',11);c:ResetSession(11)
 assert(c.examples[1].y[1]==1 and c.examples[1].mask[1])
end)
test('rollback_preserves_already_observed_positive',function()
 local c=core();c:Tick(10,true);ctx(c,11);cast(c,'observed',11);c:Tick(0,false)
 assert(c.examples[1].sealed and c.examples[1].y[1]==1 and c.examples[1].mask[1]);assert(#c.occurrenceOrder==0)
end)
test('invalid_query_has_no_history_authority',function()
 local c=core();cast(c,'future',11);local view=c:GetContext('P',nil)
 assert(not view.fresh and next(view.history)==nil and view.defensiveWitness==nil)
end)
test('late_delivery_remains_accepted_between_ticks',function()
 local c=core();c:Tick(10,true);ctx(c,10.4);cast(c,'normal',10.4)
 assert(c.now==10 and c:GetContext('P',10.4).history[1]==10.4)
 c:ResetSession(10.4);assert(c.examples[1].y[1]==1 and c.examples[1].mask[1])
end)
test('future_only_partial_reset_preserves_clean_candidate',function()
 local c=core(1)
 for n=1,12 do
  ctx(c,n*3);c:Tick(n*3,true)
  if n<=3 then cast(c,'warm-'..n,n*3+1) end
  c:Tick(n*3+2.25,true)
 end
 for i=1,20 do c:Tick(40,false) end
 assert(c.model and not c.dirty)
 ctx(c,42);c:Tick(42,true);c:Tick(44.25,true);c:Tick(45,false)
 local serving,candidate=c.model,c.candidate;assert(candidate)
 ctx(c,46);c:Tick(46,true);cast(c,'future-before-reset',46.5)
 c:ResetSession(0)
 local w=c.examples[#c.examples]
 assert(w.sealed and w.y[1]==0 and not w.mask[1])
 assert(c.model==serving and c.candidate==candidate,'censored future-only row changed training data')
 for i=1,30 do c:Tick(1,false) end
 assert(c.model.positives[1]==3 and c.model.totals[1]==13)
end)
return rows
