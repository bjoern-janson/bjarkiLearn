"""Run exact former partial-positive reset tests with a clock observation before reset.
Original fixtures remain byte-for-byte unchanged. This wrapper only inserts the
missing Context timestamp; all original assertions in selected controls remain.
"""
from pathlib import Path
import argparse,hashlib,importlib,json,sys
try: import lupa
except ImportError: sys.path.insert(0,'C:/Users/Mewn/Documents/Codex/2026-10-16/let/work/deps')
p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
r=Path(__file__).resolve().parents[1]
specs=[
 ('audit-controls/new-lifecycle/probes.lua','active replay reset with pending positive cancels candidate, seals rows, publishes copied corpus',"ck(c:Cast({actor='P',id='partial-positive',at=65,family=1}),'pending positive')",'context(c,65)'),
 ('audit-0.1.2/core/probes.lua','reset halfway through training with pending partial window restarts replay',"assert(c:Cast({id='before-reset',actor='P',at=49.5,family=2}))",'ctx(c,49.5)'),
 ('audit-0.1.3/audit/core/probes.lua','actor_eviction_overlap_pause_and_clock_rollback',"assert(cast(c,'old','P',12.5,1));", "assert(c:Context{actor='P',at=12.5,role='self',class='PRIEST',combat=true,bound=true});"),
]
hashes=lambda:{f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in a.source.glob('*.lua')}
before=hashes();results=[]
for engine in ('lua51','lua54'):
 for file,name,needle,insertion in specs:
  lua=importlib.import_module('lupa.'+engine).LuaRuntime(unpack_returned_tuples=True);ns=lua.table()
  for f in ('Bootstrap.lua','Rules.lua','Network.lua','Core.lua','Adapter.lua'):lua.execute((a.source/f).read_text(encoding='utf-8'),'bjarkiLearn',ns)
  code=(r/file).read_text(encoding='utf-8-sig');assert code.count(needle)==1
  code=code.replace(needle,needle+' '+insertion)
  rows=lua.execute(code,ns);rows=rows['cases'] or rows
  matches=[row for _,row in rows.items() if row['name']==name];assert len(matches)==1
  row=dict(matches[0].items());results.append({'engine':engine,'fixture':file,'inserted_clock_observation':insertion,'name':name,'passed':row['passed'],'error':row.get('error')})
report={'source_hashes':before,'source_unchanged':before==hashes(),'total':len(results),'passed':sum(x['passed'] for x in results),'cases':results}
a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');print(json.dumps(report,indent=2));sys.exit(0 if report['passed']==report['total'] and report['source_unchanged'] else 1)
