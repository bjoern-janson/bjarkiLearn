"""Independent temporal regression probes; read-only released module loading."""
import argparse, hashlib, importlib, json, sys
from pathlib import Path
p=argparse.ArgumentParser()
p.add_argument('--source',type=Path,required=True)
p.add_argument('--output',type=Path,required=True)
p.add_argument('--lupa-path',type=Path)
a=p.parse_args()
if a.lupa_path: sys.path.insert(0,str(a.lupa_path))
else:
    try: importlib.import_module('lupa')
    except ImportError: sys.path.insert(0,'C:/Users/Mewn/Documents/Codex/2026-10-16/let/work/deps')
def hashes():
    return {str(p.relative_to(a.source)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(a.source.rglob('*')) if p.is_file()}
before=hashes(); results=[]
for engine in ('lua51','lua54'):
    lua=importlib.import_module('lupa.'+engine).LuaRuntime(unpack_returned_tuples=True)
    ns=lua.table()
    for name in ('Bootstrap.lua','Rules.lua','Network.lua','Core.lua','Adapter.lua'):
        lua.execute((a.source/name).read_text(encoding='utf-8'),'bjarkiLearn',ns)
    rows=lua.execute(Path(__file__).with_name('probes.lua').read_text(encoding='utf-8'),ns)
    for i in range(1,len(rows)+1):
        r=rows[i]; results.append({'runtime':engine,'name':r['name'],'passed':bool(r['passed']),'detail':r['detail'],'error':r['error']})
after=hashes()
report={'source':str(a.source.resolve()),'source_unchanged':before==after,'source_hashes_before':before,'source_hashes_after':after,'counts':{'total':len(results),'passed':sum(r['passed'] for r in results)},'cases':results}
a.output.parent.mkdir(parents=True,exist_ok=True)
a.output.write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps({'counts':report['counts'],'source_unchanged':report['source_unchanged'],'failures':[r for r in results if not r['passed']]},indent=2))
raise SystemExit(int(before!=after or any(not r['passed'] for r in results)))
