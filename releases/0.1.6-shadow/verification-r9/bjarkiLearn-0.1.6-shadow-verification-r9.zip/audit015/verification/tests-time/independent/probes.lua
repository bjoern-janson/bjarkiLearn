local ns=...
local C=ns.Config
local rows={}
local function eq(a,b,msg) assert(a==b,(msg or "mismatch")..": "..tostring(a).." ~= "..tostring(b)) end
local function close(a,b,msg) assert(math.abs(a-b)<1e-12,msg or "numeric mismatch") end
local function deep(a,b,path)
    path=path or ""; eq(type(a),type(b),path.." type")
    if type(a)~="table" then eq(a,b,path); return end
    for k,v in pairs(a) do deep(v,b[k],path.."."..tostring(k)) end
    for k in pairs(b) do assert(a[k]~=nil,path.." unexpected "..tostring(k)) end
end
local function test(name,fn)
    debugprofilestop=nil
    local ok,detail=pcall(fn)
    rows[#rows+1]={name=name,passed=ok,detail=ok and detail or nil,error=not ok and tostring(detail) or nil}
end
local function ctx(c,id,t,role)
    return assert(c:Context({actor=id,at=t,class="PRIEST",role=role or "self",combat=true,health=.8,power=.7,bound=true}))
end
local function cast(c,id,actor,t,family,revision,lo,hi,retracted)
    return c:Cast({id=id,actor=actor,at=t,family=family or 1,revision=revision or 1,minAt=lo,maxAt=hi,retracted=retracted})
end
local function core() local c=ns.Core.New(); c:SetCoverage(true); return c end
local function open(c,id,t) ctx(c,id,t); c:Tick(t,true); return assert(c.actors[id].window) end
local function retire(c,now)
    for i=1,C.maxActors do ctx(c,"capacity"..i,now) end
    assert(not c.actors.P,"primary actor not retired")
end
local function retired(family,lo,hi)
    local c=core(); local w=open(c,"P",10)
    assert(cast(c,"future","P",11,family or 1,1,lo,hi))
    retire(c,10.2); eq(#c.examples,1); eq(c.examples[1],w)
    return c,w
end
local function train(c)
    for i=1,1100 do c:Tick(c.now,false); if not c.dirty then break end end
    assert(c.model and not c.dirty and not c.candidate,"no trained snapshot")
    return c.model
end

test("earlier_same_family_survives_future_record",function()
    local c=core(); ctx(c,"P",10)
    assert(cast(c,"past","P",9,1)); assert(cast(c,"future","P",11,1))
    eq(c:GetContext("P",10).history[1],9)
    c:Tick(10,true); local w=c.actors.P.window
    eq(w.x[21],1); close(w.x[20],1-1/30)
    eq(#c.occurrenceOrder,2)
    return "Future occurrence stays retained; prior eligible cast supplies input."
end)
test("future_then_past_queries_are_pure",function()
    local c=core(); ctx(c,"P",10); assert(cast(c,"past","P",9,1)); assert(cast(c,"future","P",11,1))
    local before=ns.Copy({c:Status(),c.actors.P,c.examples,c.occurrences})
    eq(c:GetContext("P",12).history[1],11)
    eq(c:GetContext("P",10).history[1],9)
    deep(before,{c:Status(),c.actors.P,c.examples,c.occurrences})
    c:ResetSession(10.2)
    return "Read-only future queries do not change evidence authority."
end)
test("future_revision_backdates_into_history",function()
    local c=core(); ctx(c,"P",10); assert(cast(c,"one","P",11,1))
    eq(c:GetContext("P",10).history[1],nil)
    assert(cast(c,"one","P",9,1,2)); eq(c:GetContext("P",10).history[1],9)
    eq(c.occurrences["cast:one"].latestEver,11); eq(#c.occurrenceOrder,1)
    return "Retiming exposes the accepted revision without a second identity."
end)
test("past_revision_moves_into_future",function()
    local c=core(); ctx(c,"P",10); assert(cast(c,"past","P",8,1)); assert(cast(c,"one","P",9,1))
    assert(cast(c,"one","P",11,1,2)); eq(c:GetContext("P",10).history[1],8)
    eq(c:GetContext("P",11).history[1],11); eq(#c.occurrenceOrder,2)
    return "Forward correction restores earlier retained same-family history."
end)
test("future_revision_reassigns_actor_and_family",function()
    local c=core(); ctx(c,"P",10); ctx(c,"Q",10)
    assert(cast(c,"one","P",11,1)); assert(cast(c,"one","Q",9,2,2))
    eq(c:GetContext("P",10).history[1],nil); eq(c:GetContext("Q",10).history[2],9)
    assert(cast(c,"one","P",12,3,3))
    eq(c:GetContext("Q",10).history[2],nil); eq(c:GetContext("P",10).history[3],nil)
    eq(c:GetContext("P",12).history[3],12); eq(#c.occurrenceOrder,1)
    return "Actor and family reattribution update both as-of projections."
end)
test("future_retraction_does_not_resurrect_at_due_time",function()
    local c,w=retired(); assert(cast(c,"future","P",11,1,2,nil,nil,true))
    c:Tick(11,nil); eq(w.y[1],0); eq(w.mask[1],false)
    assert(cast(c,"future","P",11,1,3)); eq(w.y[1],1); eq(w.mask[1],true)
    return "Retraction survives maturity; later accepted restoration is immediate."
end)
test("capacity_retirement_waits_then_matures_without_actor",function()
    local c,w=retired(); eq(w.y[1],0); eq(w.mask[1],false); eq(w.sealed,nil)
    c:Tick(10.9,nil); eq(w.y[1],0)
    c:Tick(11,nil); eq(w.y[1],1); eq(w.mask[1],true); eq(w.lead[1],1)
    eq(w.deadline,12); eq(#c.examples,1); eq(#c.actorOrder,C.maxActors)
    return "Retired row retains its horizon and admits a due positive without its actor."
end)
test("interval_maturity_waits_for_upper_bound",function()
    local c,w=retired(1,10.8,11.2); eq(w.y[1],0)
    c:Tick(11,nil); eq(w.y[1],0); eq(w.mask[1],false)
    c:Tick(11.2,nil); eq(w.y[1],1); eq(w.mask[1],true); close(w.lead[1],.8)
    return "A wholly in-window uncertain occurrence waits until maxAt."
end)
test("retired_row_future_backdate_matures_immediately",function()
    local c,w=retired(); eq(w.y[1],0)
    assert(cast(c,"future","P",10.1,1,2)); eq(w.y[1],1); eq(w.mask[1],true); close(w.lead[1],.1)
    assert(cast(c,"future","P",11,1,3)); eq(w.y[1],0); eq(w.mask[1],false)
    c:Tick(11,nil); eq(w.y[1],1)
    return "Corrections can cross the maturity frontier in either direction."
end)
test("interval_revision_moves_due_boundary",function()
    local c,w=retired(1,10.5,11.5); eq(w.y[1],0)
    assert(cast(c,"future","P",10.1,1,2,10.05,10.15)); eq(w.y[1],1)
    assert(cast(c,"future","P",10.1,1,3,10.05,11.75)); eq(w.y[1],0)
    c:Tick(11.5,nil); eq(w.y[1],0)
    c:Tick(11.75,nil); eq(w.y[1],1)
    return "Current revision determines maturity; earlier pending boundaries cannot publish it."
end)
test("context_time_alone_matures_retired_positive",function()
    local c,w=retired(); eq(w.y[1],0)
    ctx(c,"capacity16",11); eq(w.y[1],1); eq(w.mask[1],true)
    return "Observed native context advances evidence time between scheduled ticks."
end)
test("future_query_does_not_mature_retired_row",function()
    local c,w=retired(); eq(w.y[1],0)
    c:GetContext("capacity16",100); eq(w.y[1],0)
    c:Forecast("capacity16",100); eq(w.y[1],0)
    c:ResetSession(10.2); eq(w.y[1],0); eq(w.mask[1],false); eq(w.sealed,true)
    return "Consumer query time cannot acquire label authority."
end)
test("early_reset_never_seals_future_positive",function()
    local c=core(); local w=open(c,"P",10); assert(cast(c,"one","P",11,1))
    c:ResetSession(10.2); eq(w.y[1],0); eq(w.mask[1],false); eq(w.sealed,true)
    c:Tick(12,nil); eq(w.y[1],0); eq(#c.occurrenceOrder,0)
    return "An early session boundary seals uncertainty without future label leakage."
end)
test("rollback_preserves_observed_positive",function()
    local c=core(); local w=open(c,"P",10)
    ctx(c,"P",11); assert(cast(c,"one","P",11,1))
    c:ResetSession(5); eq(w.y[1],1); eq(w.mask[1],true); eq(w.sealed,true)
    eq(c.now,5); eq(#c.occurrenceOrder,0)
    return "An observed between-tick cast survives rollback sealing."
end)
test("maturity_withdraws_snapshot_after_replay_eviction",function()
    local c=core(); local w=open(c,"P",10)
    ctx(c,"P",10.1); assert(cast(c,"past","P",10.1,1)); assert(cast(c,"future","P",11,2))
    retire(c,10.2); eq(w.y[1],1); eq(w.y[2],0); train(c)
    assert(#c.modelDependencies>0); local serving=c.model
    for i=1,C.maxExamples do
        local filler={actor="filler",anchor=0,deadline=2,regime="other",x=ns.Copy(w.x),coverage={},lost={}}
        for f=1,6 do filler.coverage[f]=false end
        c:_Resolve(filler)
    end
    eq(#c.examples,C.maxExamples); assert(c.examples[1]~=w); eq(c.model,serving)
    c:Tick(11,nil); eq(c.model,nil); eq(#c.modelDependencies,0)
    return "Due event invalidates dependent completed snapshot even after replay row FIFO eviction."
end)
test("retracted_due_event_keeps_unaffected_serving_snapshot",function()
    local c=core(); local w=open(c,"P",10)
    ctx(c,"P",10.1); assert(cast(c,"past","P",10.1,1)); assert(cast(c,"future","P",11,2))
    retire(c,10.2); assert(cast(c,"future","P",11,2,2,nil,nil,true)); train(c)
    local serving=c.model; c:Tick(11,nil); eq(c.model,serving); eq(w.y[2],0)
    return "Stale due markers do not invalidate a generation for a retracted occurrence."
end)
test("future_burst_stays_bounded_and_preserves_latest_ever_floor",function()
    local c=core(); ctx(c,"P",10)
    assert(cast(c,"one","P",100,1)); assert(cast(c,"one","P",9,1,2))
    for i=1,C.maxOccurrences do assert(cast(c,"future"..i,"P",100+i,2)) end
    eq(#c.occurrenceOrder,C.maxOccurrences); eq(c.occurrences["cast:one"],nil); eq(c.evidenceFloor,100)
    local ok,why=cast(c,"one","P",9,1); eq(ok,false); eq(why,"outside_retained_history")
    eq(c:GetContext("P",10).history[1],nil); eq(c:GetContext("P",10).history[2],nil)
    c:Tick(150,nil); eq(#c.occurrenceOrder,C.maxOccurrences)
    eq(c:GetContext("P",150).history[2],150)
    return "Future records share the existing 128 identities; backdate never erases replay protection."
end)
test("forgotten_future_revision_remains_censored",function()
    local c=core(); ctx(c,"P",10); assert(cast(c,"one","P",11,1))
    for i=1,C.maxOccurrences do assert(cast(c,"f"..i,"P",20+i,2)) end
    local ok,why=cast(c,"one","P",10.1,1,2); eq(ok,false); eq(why,"revision_history_lost")
    eq(#c.occurrenceOrder,C.maxOccurrences); eq(c.occurrences["cast:one"],nil)
    return "Bounded history cannot manufacture lost correction provenance."
end)
test("native_between_tick_cast_is_accepted_and_observed",function()
    UnitGUID=function(unit) if unit=="player" then return "Player-1-P" end end
    UnitIsPlayer=function(unit) return unit=="player" end
    UnitClassBase=function() return "PRIEST" end
    UnitCanAttack=function() return false end
    UnitAffectingCombat=function() return true end
    UnitHealth=function() return 80 end; UnitHealthMax=function() return 100 end
    UnitPower=function() return 70 end; UnitPowerMax=function() return 100 end
    local c=core(); local a=ns.Adapter.New(c); a:SetRegistered(true); a:Tick(10); c:Tick(10,true)
    local w=c.actors["Player-1-P"].window
    a:OnCast("player","native",8122,10.1)
    eq(c.now,10); eq(c.occurrences["cast:native"].at,10.1)
    eq(c:GetContext("Player-1-P",10.1).history[1],10.1)
    c:ResetSession(10.1); eq(w.y[1],1); eq(w.mask[1],true)
    return "Real adapter binding observes the between-tick timestamp before admission."
end)
test("future_aura_does_not_hide_earlier_readable_witness",function()
    local c=core(); ctx(c,"P",10)
    assert(c:Aura({id="past",recipient="P",at=9,spellID=22812,expires=15}))
    assert(c:Aura({id="future",recipient="P",at=11,spellID=5277,expires=16}))
    eq(c:GetContext("P",10).defensiveWitness.at,9)
    c:Tick(10,true); eq(c.actors.P.window.x[47],1); eq(c.actors.P.window.x[48],1)
    eq(c:GetContext("P",11).defensiveWitness.at,11)
    return "As-of witness projection applies to the independent positive aura channel too."
end)
test("maturity_burst_reconciles_one_corpus_generation",function()
    local c=core(); local w=open(c,"P",10)
    for i=1,120 do assert(cast(c,"burst"..i,"P",11+(i%3)*.1,1+(i%6))) end
    retire(c,10.2)
    for i=1,6 do eq(w.y[i],0); eq(w.mask[i],false) end
    local revision=c.corpusRevision
    c:Tick(11.2,nil)
    for i=1,6 do eq(w.y[i],1); eq(w.mask[i],true) end
    eq(c.corpusRevision,revision+1); eq(#c.occurrenceOrder,120)
    return "120 simultaneous maturities change the corpus once, without a per-event reconciliation cascade."
end)
test("corrected_later_due_ignores_superseded_boundary",function()
    local c,w=retired(); eq(w.y[1],0)
    assert(cast(c,"future","P",11.75,1,2))
    c:Tick(11,nil); eq(w.y[1],0)
    c:Tick(11.75,nil); eq(w.y[1],1); eq(w.lead[1],1.75)
    return "An obsolete earliest-due scalar cannot admit a later current revision."
end)
test("evicted_future_record_cannot_mature_through_stale_due_marker",function()
    local c,w=retired(); eq(w.y[1],0)
    for i=1,C.maxOccurrences do assert(cast(c,"far"..i,"Q",100+i,2)) end
    eq(c.occurrences["cast:future"],nil); eq(w.lost[1],true)
    c:Tick(11,nil); eq(w.y[1],0); eq(w.mask[1],false)
    eq(#c.occurrenceOrder,C.maxOccurrences)
    return "Discarded evidence remains uncertain; a stale scheduled boundary carries no identity authority."
end)
return rows
