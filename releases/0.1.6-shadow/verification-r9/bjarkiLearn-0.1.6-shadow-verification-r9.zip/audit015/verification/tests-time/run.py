import argparse,hashlib,importlib,json,sys
from pathlib import Path
try:import lupa
except ImportError:sys.path.insert(0,r'C:/Users/Mewn/Documents/Codex/2026-10-16/let/work/deps')
p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
root=Path(__file__).resolve().parent
hashes=lambda:{f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in a.source.glob('*.lua')}
before=hashes();results=[]
for engine in ('lua51','lua54'):
 lua=importlib.import_module('lupa.'+engine).LuaRuntime(unpack_returned_tuples=True);ns=lua.table()
 for f in ('Bootstrap.lua','Rules.lua','Network.lua','Core.lua'):lua.execute((a.source/f).read_text(encoding='utf-8'),'bjarkiLearn',ns)
 for _,case in lua.execute((root/'projections.lua').read_text(encoding='utf-8'),ns).items():
  row={'engine':engine,**dict(case.items())}
  if hasattr(row.get('detail'),'items'):row['detail']=dict(row['detail'].items())
  results.append(row)
out={'source_hashes':before,'source_unchanged':before==hashes(),'total':len(results),'passed':sum(r['passed'] for r in results),'cases':results}
a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print(json.dumps(out,indent=2));sys.exit(0 if out['passed']==out['total'] and out['source_unchanged'] else 1)
