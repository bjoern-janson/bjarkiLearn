# bjarkiLearn 0.1.1-shadow verification

## Release checks

**136/136 scenario executions passed across Lua 5.1 and Lua 5.4; zero failures.** All six runtime Lua modules passed syntax loading on both engines (12 checks). The final test run checked unchanged source hashes and original audit-harness bytes.

| Tests | Executions across both runtimes |
| --- | ---: |
| Preserved independent 0.1.0 audit | 98 |
| New focused retention/correction regressions | 22 |
| Fresh independent review probes | 14 |
| Sustained full-history integration | 2 |

The 0.1.0 install archive did not contain the earlier 124-case release harness described in its old verification document. This repair does not claim to rerun those unavailable tests. Its separate verification bundle contains every test actually executed here, the exact source, original audit harness hashes, before/after results, review reports and package manifest.

## Observed behavior

- The new retention tests reproduce the interruption on unchanged 0.1.0. After repair, every one of 320 combat windows retained a numeric shadow forecast through 321 example and 57 occurrence evictions. There was no combat training; 256 retained forecasts remained paired with scored outcomes instead of zero.
- The serving generation stayed frozen during combat. Its frequency estimate was about 0.100775; after outside-combat replacement the estimate was about 0.496124, matching the recent training corpus.
- Accepted late evidence and revisions invalidate serving models even after affected training lessons are evicted. Tests cover retired negatives becoming positive, retractions, both sides of actor/time changes, interval widening and exact boundaries, forgotten revisions, below-floor replay, duplicates and unchanged semantic revisions.
- Routine occurrence retirement still censors dependent replay labels. The example and occurrence limits remain 256 and 128, actors remain limited to 16, and the additional serving dependency registry never exceeded 256 descriptors. No second candidate dependency registry exists.
- Replacement remains deterministic against a clean replay of recent examples. Corrections cancel in-progress candidates. Actor eviction, reset during replay, session sealing, restore atomicity, empty replay, failed replacement metadata, stale public forecasts, copied projections, disable/enable and save/restart controls passed.
- Fresh independent code review found no remaining material finding in the repair. A documentation encoding defect found during review was corrected and strict UTF-8 decoding rechecked for all 14 release files.

## Lifecycle and limits

A completed model may retain influence from examples that have left the replay buffer until the next successful replacement. Routine forgetting does not assert that the original evidence was false. Genuine evidence corrections withdraw affected adaptive state immediately; a bounded set of transient actor/window descriptors preserves correction scope for that serving generation. Existing sealed-session boundaries remain unchanged. Prolonged combat or corpus churn can delay replacement indefinitely. Status and copied forecasts disclose the serving and current corpus revisions and whether refresh remains pending.

These are ordinary Lua tests with modeled WoW APIs, not live-client validation. Native delivery completeness, taint, secret-value enforcement, actual frame-time cost and predictive usefulness remain unverified. Scores remain uncalibrated shadow diagnostics with usable=false. No consumer behavior is enabled.

## Reproduce

Extract the separate bjarkiLearn-0.1.1-shadow-verification.zip, then run:

```sh
python -m pip install -r requirements-test.txt
python run_all.py
python build_release.py --output dist
```

Results are in reports/verification.json, with detailed per-suite files. The package builder checks both TOCs, versions, UTF-8, CRCs, inventory and exact archived bytes. The install ZIP contains only the same 14 runtime/documentation files as the original archive.

## Runtime SHA-256

| File | SHA-256 |
| --- | --- |
| Adapter.lua | `8d202f577b5c0abce58e7655e56b37597ccb17f465233333952614370a614c88` |
| Bootstrap.lua | `c96fca5427d5d3fc5aca47ea66037a658a8dbac937991b6818db5677d6c974cb` |
| Core.lua | `92fccf5a9756322cc03f3b9f4ae0ad6c7055324a96ef05dd0e4813dbadc7a4d1` |
| Main.lua | `7c1293d701171d3052c25cbab3dfcda4440619f8396e01103dcc4ecb22c06ec2` |
| Network.lua | `2334ac31ce6a9c9946b17fd35441bc4db319a3febc6edf4e0fc3c278fae5f7e8` |
| Rules.lua | `25ef0cc8edb17cab6d251a63784589bcabc6c9485cd30e46078b404e4df8a532` |
