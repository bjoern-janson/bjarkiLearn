# Changes

## 0.1.1-shadow

- Keep the last completed shadow model through routine example and occurrence retirement; rebuild from the bounded recent corpus outside combat.
- Preserve immediate correction invalidation after training rows have been retired, using at most 256 transient serving-window descriptors. Check both sides of actor/time changes and retain conservative handling of lost or stale history.
- Expose serving snapshot revision, example count and pending refresh state in copied forecast/status projections, with dependency count in core status.
- Preserve the 16-actor, 128-occurrence and 256-example caps, existing session sealing, player-only support, shadow-only outputs, combat deferral and saved-example compatibility.
- Add focused retention/correction tests and sustained full-history integration verification on Lua 5.1 and 5.4. See VERIFICATION.md and the separate reproducibility bundle.

## 0.1.0-shadow

- First installable optional addon, with ordinary and Camelot manifests for Interface 16001.
- Native readable semantic context for player, target and focus; provisional class candidates; optional existing Portraits positive-aura bridge.
- Six-head 48–12–6 neural candidate, regularized logistic comparator and event-frequency comparator.
- Immutable forecast anchors, per-head coverage masks, native occurrence deduplication, revisable outcomes and deterministic clean replay after corrections.
- Explicit player-stream learning regime; enemy absence remains unknown and enemy learned scores remain withheld.
- Bounded actors, occurrences and retained examples, combat training deferral, atomic finite updates and deidentified compatible persistence.
- Read-only copied diagnostics, slash commands and measured-update reporting when a profiling clock is available.
- Lua 5.1/5.4 regression suite, 1,100-cycle capacity replay and synthetic adaptation/restart controls.

This is a shadow release. Live-client validation, probability calibration, practical consumer benefit and changes to suite presentation remain pending.
