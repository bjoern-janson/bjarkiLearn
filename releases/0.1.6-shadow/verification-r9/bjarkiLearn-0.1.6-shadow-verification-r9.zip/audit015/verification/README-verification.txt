bjarkiLearn 0.1.5-shadow verification bundle

Installable addon source is source/bjarkiLearn. The exact prior install ZIP and source are in baseline-0.1.4. Runtime changes are Core.lua refactors plus Bootstrap/TOC versions; source-changes.patch includes documentation too.

Python 3 and lupa==2.8 are required. From this directory:
  python -m pip install -r requirements-test.txt
  python run_all.py
  python build_release.py --output dist

Current results: reports-0.1.5/verification.json; independent review: review-0.1.5.
Original regression scripts remain unchanged. Tests-refactor/legacy creates disposable execution copies under its runs directory, adapts precisely listed private-cache reads, and records original/adapted hashes. Root historical run_all.py and build_release.py are preserved under baseline-0.1.4; original hashes are fixtures/v0.1.4-preserved-test-hashes.json. Historical report directories retain their version labels and must not be mistaken for current release evidence.

New contracts verify a single evidence authority and unchanged invalidation. Independent differential tests compare ordered inputs with 0.1.4, including public outputs and full learned state. Native trace comparisons run real Main/Adapter/Core with modeled APIs. Only the removed private actor mirrors and version metadata are normalized. Original obsolete future-positive assertions from pre-0.1.4 remain explicit historical failures, not passing tests.

The builder checks current runtime hashes, baseline and original tests, 14-file inventory, both TOCs/load references, version consistency, CRCs and archived bytes. Archive creation uses fixed metadata for reproducibility. A clean extraction can rebuild the same archive bytes before re-running tests; rerunning tests changes timestamps/paths in evidence reports while preserving the deterministic addon archive.

This is offline logic verification under Lua 5.1 and Lua 5.4. Live WoW behavior, native frame-time performance, taint/secret enforcement and predictive usefulness remain unverified. Shadow outputs remain unusable by consumers.
