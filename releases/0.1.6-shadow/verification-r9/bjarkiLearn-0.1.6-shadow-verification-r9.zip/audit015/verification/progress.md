# SDD ledger — plan: docs/superpowers/plans/2026-10-23-refactor-015.md

Ruling: Use isolated archive workspace, not Git worktree or commits — user requested ZIP-only refactors and exact immutable baseline is available. No shared checkout edits.
Pre-flight: Both tasks share Core actor/occurrence state; keep all call order and invalidation policy unchanged.
Baseline: exact 0.1.4 install and verification SHA-256 checked; preserved 76 original Lua/Python support files.
Task 1 RED: 8 contracts, 4 passed and 4 expected mirror-presence/write-projection failures across Lua 5.1/5.4. Existing invalidation/fallback controls passed.
Task 1 implementation: removed actor mirror storage and retained every revision/cache-invalidation call site.
Task 2 implementation: explicit change/retirement/time entrypoints, shared outcome and overlap-selection helpers; preserved all dirty decisions.
Task 1: complete — contracts.py 8/8 pass after 4 expected baseline failures; revision/cache controls preserved.
Task 2: complete — independent 56/56; 208 checkpoints, 1819360 exact scalar comparisons; inherited663+12review, latest audit94+8native comparisons pass. Reviewer matrix46080/46080.
Final review: no remaining material findings. Release-script missing documentation flag fixed; root aggregate passed. Runtime source unchanged.
Final scope rulings: live WoW behavior and predictive usefulness remain unverified; bounded-history reconstruction limits unchanged. Final package execution and byte checks belong to executor.
Ruling: Preserve archive workspace and ledger because this ZIP task has no Git history for recovery. No merge or remote publication needed.
Task 3: initial archive verified 14files,2TOCs,CRCs and exactbytes; clean-extraction fullroot verification starts next.
Task 3: clean extracted verification bundle ran default run_all.py with all five jobs exit0, reports_reused=false. Final full runner source_unchanged=true, original_test_sources_unchanged=true. Fresh final counts: 663 inherited scenarios,12 previous review probes,94 subsequent audit checks,8 native014/reload comparisons,8 contracts,56 differential cases,46080 reviewer policy comparisons,12 syntax checks. Seed/boundary/reset checks also pass. Final release builder validates inventory,baseline,originalbytes,versions,CRCs and exact archived bytes; the external final-validation report records the final archive reproduction without a self-referential bundle hash.
