local ns=...
local results,checks={},0
local function ck(v,why) checks=checks+1;assert(v,why or 'assertion') end
local function near(a,b,eps) ck(math.abs(a-b)<=(eps or 1e-12),tostring(a)..' != '..tostring(b)) end
local function equal(a,b)
 if type(a)~=type(b) then return false end
 if type(a)~='table' then return a==b end
 for k,v in next,a do if not equal(v,b[k]) then return false end end
 for k in next,b do if a[k]==nil then return false end end
 return true
end
local function case(name,fn)
 local n=checks;local ok,why=pcall(fn)
 results[#results+1]={name=name,passed=ok,checks=checks-n,error=not ok and tostring(why) or nil}
end
local function production() return assert(ns.Models.New(48,12,6,73013)) end
local function row(n)
 local x,y,mask={},{},{}
 for j=1,48 do x[j]=((j*37+n*19)%101)/100 end
 for j=1,6 do y[j]=(n+j)%2;mask[j]=(n+j)%4~=0 end
 return x,y,mask
end
local function fields(m,fn)
 for _,name in ipairs({'hiddenWeights','hiddenBiases','outputWeights','outputBiases','linearWeights','linearBiases'}) do
  for i,value in ipairs(m[name]) do
   if type(value)=='table' then for j in ipairs(value) do fn(name,i,j) end else fn(name,i) end
  end
 end
end
local function at(m,f,i,j) if j then return m[f][i][j] else return m[f][i] end end
local function put(m,f,i,j,v) if j then m[f][i][j]=v else m[f][i]=v end end
local function objective(m,x,y,mask)
 local p=assert(m:Predict(x));local observed=0
 for o=1,6 do if mask[o] then observed=observed+1 end end
 local loss=0
 local function ce(prob,label) return -label*math.log(prob)-(1-label)*math.log(1-prob) end
 for o=1,6 do if mask[o] then
  loss=loss+ce(p.neural[o],y[o])/observed+ce(p.linear[o],y[o])
  for h=1,12 do loss=loss+0.5*m.regularization*m.outputWeights[o][h]^2 end
  for i=1,48 do loss=loss+0.5*m.linearRegularization*m.linearWeights[o][i]^2 end
 end end
 for h=1,12 do for i=1,48 do loss=loss+0.5*m.regularization*m.hiddenWeights[h][i]^2 end end
 return loss
end
case('all 960 production parameter gradients match independent finite differences',function()
 local m=production();local x,y,mask=row(9)
 for o=1,6 do for j=1,48 do m.linearWeights[o][j]=((j+o)%7-3)*.003 end end
 local updated=assert(m:Copy());ck(updated:Learn(x,y,mask),'learn')
 local n=0
 fields(m,function(f,i,j)
  local original=at(m,f,i,j);local eps=1e-5
  put(m,f,i,j,original+eps);local plus=objective(m,x,y,mask)
  put(m,f,i,j,original-eps);local minus=objective(m,x,y,mask)
  put(m,f,i,j,original)
  local derivative=(plus-minus)/(2*eps)
  local actual=(original-at(updated,f,i,j))/m.learningRate
  ck(math.abs(derivative)<.95,'unexpected clipping fixture');near(derivative,actual,3e-8);n=n+1
 end)
 ck(n==960,'covered every weight and bias')
end)
case('all 64 output masks have exact support counts and preserve omitted heads',function()
 local base=production();local x,y=row(3)
 for bits=0,63 do
  local m=assert(base:Copy());local mask={};local observed=0
  for o=1,6 do mask[o]=math.floor(bits/2^(o-1))%2==1;if mask[o] then observed=observed+1 end end
  ck(m:Learn(x,y,mask),'mask update');ck(m.updates==(observed==0 and 0 or 1),'updates')
  for o=1,6 do
   ck(m.totals[o]==(mask[o] and 1 or 0),'masked total');ck(m.positives[o]==(mask[o] and y[o] or 0),'masked positive')
   if not mask[o] then
    ck(equal(m.outputWeights[o],base.outputWeights[o]),'omitted neural head changed')
    ck(equal(m.linearWeights[o],base.linearWeights[o]),'omitted linear head changed')
    ck(m.outputBiases[o]==base.outputBiases[o] and m.linearBiases[o]==base.linearBiases[o],'omitted bias')
   end
  end
  if observed==0 then ck(equal(base,m),'all-unobserved is strict no-op') end
 end
end)
case('production saturation clipping and transactional overflow',function()
 local m=production();local x,y,mask=row(1)
 for h=1,12 do for i=1,48 do m.hiddenWeights[h][i]=0 end;m.hiddenBiases[h]=h%2==0 and 1e308 or -1e308 end
 for o=1,6 do
  for h=1,12 do m.outputWeights[o][h]=0 end
  for i=1,48 do m.linearWeights[o][i]=0 end
  m.outputBiases[o]=o%2==0 and 1e308 or -1e308;m.linearBiases[o]=m.outputBiases[o]
 end
 local p=assert(m:Predict(x))
 for o=1,6 do ck(p.neural[o]==(o%2==0 and 1 or 0),'neural saturation');ck(p.linear[o]==p.neural[o],'linear saturation') end
 ck(m:Learn(x,y,mask),'saturation learn');ck(m:Valid(),'saturation valid')
 m=production();m.gradientClip=.00001;local before=assert(m:Copy());ck(m:Learn(x,y,mask),'clipped learn')
 fields(m,function(f,i,j) ck(math.abs(at(m,f,i,j)-at(before,f,i,j))<=m.learningRate*m.gradientClip+1e-16,'clip bound') end)
 m=production();m.learningRate=1.7e308;m.regularization=0;m.linearRegularization=0
 for i=1,48 do x[i]=0 end;x[1]=1;x[2]=1
 m.linearWeights[6][1]=-1.7e308;m.linearWeights[6][2]=1.7e308
 y={0,0,0,0,0,0};mask={true,true,true,true,true,true}
 before=assert(m:Copy());local refs={};for k,v in next,m do if type(v)=='table' then refs[k]=v end end
 ck(m:Predict(x)~=nil,'finite cancellation precursor')
 local ok,why=m:Learn(x,y,mask);ck(not ok and why=='nonfinite_update','overflow rejection')
 ck(equal(m,before),'failed update atomic');for k,v in next,refs do ck(m[k]==v,'failed update reference atomic') end
end)
case('recordStatistics false preserves exact production parameter trajectory',function()
 local a,b=production(),production()
 for n=1,80 do local x,y,mask=row(n);ck(a:Learn(x,y,mask,true));ck(b:Learn(x,y,mask,false)) end
 fields(a,function(f,i,j) ck(at(a,f,i,j)==at(b,f,i,j),'statistics changed parameter') end)
 ck(a.updates==80 and b.updates==80,'updates count optimization steps')
 for o=1,6 do ck(a.totals[o]==60 and b.totals[o]==0,'support counts observations only') end
end)
local function savedRows(n)
 local saved={schema=ns.Config.schema,compat=ns.Config.compat,examples={}}
 for j=1,n do local x,y,mask=row(j);saved.examples[j]={x=x,y=y,mask=mask,regime='player'} end
 return saved
end
case('snapshot support exact two-positive eight-negative boundary',function()
 local c=ns.Core.New();c.model=production();c.model.updates=20
 c.model.positives={1,2,2,3,0,10};c.model.totals={20,9,10,11,10,20}
 local x=row(1);local p=c:_Predictions({regime='player'},x)
 for o=1,6 do
  local allowed=o>=3 and o~=5
  for _,name in ipairs({'neural','linear','frequency'}) do ck((p[name][o]~=nil)==allowed,'threshold '..o) end
  if allowed then near(p.frequency[o],(c.model.positives[o]+1)/(c.model.totals[o]+2)) end
 end
 local q=c:_Predictions({regime='other'},x)
 for _,name in ipairs({'neural','linear','frequency'}) do ck(next(q[name])==nil,'enemy abstention') end
 local a={actor='A',class='PRIEST',regime='player',revision=1}
 c:_MakeForecast(a,1,x,p)
 ck(a.forecast.usable==false,'forecast authority')
 for _,out in ipairs(a.forecast.outputs) do ck(out.calibrated==false and out.usable==false,'head authority') end
end)
case('optional-channel combinations score complete paired labeled player heads only',function()
 local saved=savedRows(8)
 for bits=0,7 do
  local r=saved.examples[bits+1];r.predictions={};r.mask={true,true,false,true,true,true};r.y={1,0,1,0,1,0}
  for k,name in ipairs({'neural','linear','frequency'}) do
   if math.floor(bits/2^(k-1))%2==1 then r.predictions[name]={0,.25,.5,.75,1,0} end
  end
 end
 local c=ns.Core.New();ck(c:Restore(saved));local status=c:Status()
 for o=1,6 do
  ck(status.families[o].scored==(o==3 and 0 or 1),'paired denominator')
  if o~=3 then near(status.families[o].neuralLoss,(saved.examples[8].predictions.neural[o]-saved.examples[8].y[o])^2) end
 end
 for _,r in ipairs(saved.examples) do r.regime='other' end
 local d=ns.Core.New();ck(d:Restore(saved));for _,f in ipairs(d:Status().families) do ck(f.scored==0,'other predictions not scored') end
end)
case('invalid diagnostic scalars cannot enter losses or change labels',function()
 local invalid={false,'0.5',-1,1.000001,math.huge,-math.huge,0/0,{},function()end}
 for _,bad in ipairs(invalid) do
  local saved=savedRows(1);local r=saved.examples[1];r.mask={true,true,true,true,true,true}
  r.predictions={neural={bad,bad,bad,bad,bad,bad},linear={0,0,0,0,0,0},frequency={1,1,1,1,1,1}}
  local c=ns.Core.New();ck(c:Restore(saved),'invalid diagnostics optional')
  ck(equal(c.examples[1].y,r.y) and equal(c.examples[1].mask,r.mask),'diagnostics changed labels')
  for _,f in ipairs(c:Status().families) do ck(f.scored==0 and f.neuralLoss==nil,'invalid scalar scored') end
 end
end)
case('largest retained corpus exports bounded ordinary deidentified fields',function()
 local saved=savedRows(256);saved.examples[1].actor='PRIVATE_GUID';saved.examples[1].x.extra=saved
 saved.examples[1].predictions={neural={0,1,.5},linear={0,1,.5},frequency={0,1,.5}}
 local c=ns.Core.New();ck(c:Restore(saved));local exported=c:Export();ck(#exported.examples==256,'bounded count')
 local count=0
 local function walk(v)
  ck(type(v)=='number' or type(v)=='table' or type(v)=='boolean' or type(v)=='string','ordinary serialized type')
  if type(v)=='string' then ck(v~='PRIVATE_GUID','identity stripped') end
  if type(v)=='table' then ck(getmetatable(v)==nil,'plain exported table');for _,item in next,v do count=count+1;walk(item) end end
 end
 walk(exported);ck(count<19000,'bounded export field count')
 saved.examples[1].x[1]=.12345;ck(exported.examples[1].x[1]~=.12345,'import detached')
 exported.examples[2].x[1]=.12345;ck(c.examples[2].x[1]~=.12345,'export detached')
 local original=c.examples;local bad=savedRows(1);bad.examples[257]=bad.examples[1]
 local ok,reason=c:Restore(bad);ck(not ok and reason=='invalid_examples','over-capacity rejected');ck(c.examples==original,'rejection preserves rows')
end)
case('readable helpers stop before indexing or calling protected values',function()
 local oldSecret,oldTable,oldAccess=issecretvalue,issecrettable,canaccessvalue
 local blocked={};local protected=setmetatable({},{__index=function()error('INDEXED PROTECTED')end});blocked[protected]=true
 issecretvalue=function(v)return blocked[v] or false end;issecrettable=function()return false end;canaccessvalue=function()return true end
 local ok,why=pcall(function()
  ck(ns.Safe.Field(protected,'x')==nil,'protected table')
  local calls=0;local fn=function()calls=calls+1;return protected end;blocked[fn]=true
  ck(ns.Safe.Call(fn)==nil and calls==0,'protected function');blocked[fn]=nil
  ck(ns.Safe.Call(fn)==nil and calls==1,'protected result')
  local t=setmetatable({},{__index=function()error('index failure')end});ck(ns.Safe.Field(t,'x')==nil,'field error contained')
  issecretvalue=function()error('predicate unavailable')end;ck(not ns.Safe.Readable(1),'predicate errors fail closed')
  issecretvalue=nil;issecrettable=nil;canaccessvalue=function()return false end
  ck(ns.Safe.Number(0)==nil and ns.Safe.Boolean(false)==nil and ns.Safe.String('')==nil,'inaccessible primitive')
 end)
 issecretvalue,issecrettable,canaccessvalue=oldSecret,oldTable,oldAccess;ck(ok,why)
end)
case('feature schema normalizes and distinguishes unknown from known zero',function()
 local absent=ns.Rules.Features({role='unknown'},100)
 local zero=ns.Rules.Features({class='DRUID',role='self',combat=false,health=0,power=0,form='bear',history={[1]=0,[6]=100},defensiveWitness={at=99,expires=101}},100)
 ck(#absent==48 and #zero==48,'feature shape')
 for i=1,48 do ck(absent[i]>=0 and absent[i]<=1 and zero[i]>=0 and zero[i]<=1,'normalized '..i) end
 ck(absent[15]==0 and zero[15]==1,'combat known');ck(absent[17]==0 and zero[17]==1,'health known');ck(absent[19]==0 and zero[19]==1,'power known')
 ck(zero[20]==0 and zero[21]==1,'old history known distinction');ck(zero[30]==1 and zero[31]==1,'current history')
 ck(zero[44]==0 and zero[45]==1 and zero[46]==1,'form onehot');ck(zero[47]==1 and zero[48]==1,'positive witness')
 local expired=ns.Rules.Features({role='self',defensiveWitness={at=99,expires=100}},100)
 ck(expired[47]==0 and expired[48]==0,'expiry withholds witness')
end)
local m=production()
for n=1,48 do local x,y,mask=row(n);assert(m:Learn(x,y,mask,n<=24)) end
local fingerprint={}
fields(m,function(f,i,j) fingerprint[#fingerprint+1]=string.format('%.17g',at(m,f,i,j)) end)
for _,name in ipairs({'positives','totals'}) do for _,v in ipairs(m[name]) do fingerprint[#fingerprint+1]=string.format('%.17g',v) end end
fingerprint[#fingerprint+1]=string.format('%.17g',m.seed);fingerprint[#fingerprint+1]=string.format('%.17g',m.rngState)
return {cases=results,fingerprint=table.concat(fingerprint,'\n')}
