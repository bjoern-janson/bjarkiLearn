"""Independent Core audit. Loads released modules; never edits source."""
import argparse
import hashlib
import importlib
import json
import sys
from pathlib import Path


def hashes(source):
    return {str(p.relative_to(source)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(source.rglob('*')) if p.is_file()}


p = argparse.ArgumentParser()
p.add_argument('--source', required=True, type=Path)
p.add_argument('--output', required=True, type=Path)
p.add_argument('--lupa-path', type=Path)
a = p.parse_args()
if a.lupa_path:
    sys.path.insert(0, str(a.lupa_path))
else:
    try:
        importlib.import_module('lupa')
    except ImportError:
        fallback = Path('C:/Users/Mewn/Documents/Codex/2026-10-16/let/work/deps')
        if fallback.exists():
            sys.path.insert(0, str(fallback))
before = hashes(a.source)
results = []
for engine in ('lua51', 'lua54'):
    lua = importlib.import_module('lupa.' + engine).LuaRuntime(unpack_returned_tuples=True)
    ns = lua.table()
    for filename in ('Bootstrap.lua', 'Rules.lua', 'Network.lua', 'Core.lua', 'Adapter.lua'):
        lua.execute((a.source / filename).read_text(encoding='utf-8'), 'bjarkiLearn', ns)
    rows = lua.execute(Path(__file__).with_name('probes.lua').read_text(encoding='utf-8'), ns)
    for i in range(1, len(rows) + 1):
        row = rows[i]
        results.append(dict(runtime=engine, name=row['name'], passed=bool(row['passed']),
                            detail=row['detail'], error=row['error']))
after = hashes(a.source)
report = dict(source=str(a.source.resolve()), source_hashes_before=before,
              source_hashes_after=after, source_unchanged=before == after,
              counts=dict(total=len(results), passed=sum(r['passed'] for r in results)), cases=results)
a.output.parent.mkdir(parents=True, exist_ok=True)
a.output.write_text(json.dumps(report, indent=2), encoding='utf-8')
print(json.dumps(dict(counts=report['counts'], source_unchanged=report['source_unchanged'],
                      failures=[r for r in results if not r['passed']]), indent=2))
raise SystemExit(int(before != after or any(not r['passed'] for r in results)))
