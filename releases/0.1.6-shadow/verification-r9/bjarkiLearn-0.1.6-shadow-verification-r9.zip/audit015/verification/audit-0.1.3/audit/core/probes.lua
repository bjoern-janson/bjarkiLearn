local ns=...
local C=ns.Config
local results,original={},{}
for k,v in pairs(C) do original[k]=v end
local function check(name,fn)
    for k,v in pairs(original) do C[k]=v end
    debugprofilestop=nil
    local ok,detail=pcall(fn)
    results[#results+1]={name=name,passed=ok,detail=ok and detail or nil,error=not ok and tostring(detail) or nil}
end
local function eq(a,b,msg) assert(a==b,(msg or 'mismatch')..': '..tostring(a)..' ~= '..tostring(b)) end
local function deep(a,b,path)
    path=path or ''; eq(type(a),type(b),path..' type')
    if type(a)~='table' then eq(a,b,path); return end
    for k,v in pairs(a) do deep(v,b[k],path..'.'..tostring(k)) end
    for k in pairs(b) do assert(a[k]~=nil,path..' unexpected '..tostring(k)) end
end
local function context(c,id,at,role)
    return assert(c:Context({actor=id,at=at,role=role or 'self',class='PRIEST',bound=true,combat=true,health=.8,power=.7}))
end
local function cast(c,id,actor,at,family,revision,lo,hi,retracted)
    return c:Cast({id=id,actor=actor,at=at,family=family or 1,revision=revision or 1,minAt=lo,maxAt=hi,retracted=retracted})
end
local function core() local c=ns.Core.New(); c:SetCoverage(true); return c end
local function window(c,id,t,role) context(c,id,t,role); c:Tick(t,true); return assert(c.actors[id].window) end
local function finish(c,t) c:Tick(t,nil) end
local function train(c)
    for i=1,1100 do c:Tick(c.now+.001,false); if not c.dirty then break end end
    assert(c.model and not c.candidate and not c.dirty,'training did not publish'); return c.model
end
local function trained(n)
    local c=core()
    for i=1,n or 12 do
        local t=i*3; window(c,'P',t)
        if i<=2 then assert(cast(c,'warm'..i,'P',t+.5,1)) end
        finish(c,t+2.25)
    end
    train(c); return c
end
local function served(c,t) context(c,'P',t); c:Tick(t,true); return c:Forecast('P',t) end

check('interval_label_oracle_sweep',function()
    local cases=0
    for _,lo in ipairs({8,9.999,10,10.001,11,12,12.001,13}) do
        for _,hi in ipairs({8,9.999,10,10.001,11,12,12.001,13}) do
            if lo<=hi then
                for family=1,6 do for _,covered in ipairs({true,false}) do for _,retracted in ipairs({true,false}) do
                    local c=core(); c:SetCoverage(covered); local w=window(c,'P',10)
                    assert(cast(c,'one','P',(lo+hi)/2,family,1,lo,hi,retracted)); finish(c,12.25)
                    local positive=not retracted and lo>10 and hi<=12
                    local uncertain=not retracted and hi>10 and lo<=12 and not positive
                    for f=1,6 do
                        eq(w.y[f],f==family and positive and 1 or 0,'label')
                        local expected=covered
                        if f==family then if positive then expected=true elseif uncertain then expected=false end end
                        eq(w.mask[f],expected,'mask')
                    end
                    cases=cases+1
                end end end
            end
        end
    end
    return tostring(cases)..' histories: anchor/deadline, uncertainty, retraction, coverage, six families'
end)
check('positive_uncertain_evidence_all_delivery_orders',function()
    local final
    for _,order in ipairs({{1,2,3},{1,3,2},{2,1,3},{2,3,1},{3,1,2},{3,2,1}}) do
        local c=core(); c:SetCoverage(false); local w=window(c,'P',10)
        local rows={{'anchor',10,9,11},{'inside',11,11,11},{'deadline',12,11,13}}
        for _,i in ipairs(order) do local r=rows[i]; assert(cast(c,r[1],'P',r[2],1,1,r[3],r[4])) end
        finish(c,12.25); eq(w.y[1],1); eq(w.mask[1],true); eq(w.lead[1],1)
        if final then deep(final,{w.y,w.mask,w.lead}) else final=ns.Copy({w.y,w.mask,w.lead}) end
    end
    return 'six permutations agree; separate positive witness establishes existence'
end)
check('revision_actor_family_interval_and_retraction_chain',function()
    local c=core(); local p=window(c,'P',10); local e=window(c,'E',10,'hostile')
    assert(cast(c,'one','P',11,1)); finish(c,12.25); eq(p.y[1],1); eq(e.y[1],0)
    assert(cast(c,'one','E',11,2,2)); eq(p.y[1],0); eq(p.mask[1],true); eq(e.y[2],1); eq(e.mask[2],true)
    eq(#c.occurrenceOrder,1); eq(#c.examples,2)
    assert(cast(c,'one','E',11,2,3,10,12.5)); eq(e.y[2],0); eq(e.mask[2],false)
    assert(cast(c,'one','P',11,3,4,nil,nil,true)); eq(p.y[3],0); eq(p.mask[3],true); eq(e.y[2],0)
    eq(c.actors.P.history[1],nil); eq(c.actors.E.history[2],nil)
    local ok,why=cast(c,'one','P',11,1,3); eq(ok,false); eq(why,'duplicate'); eq(#c.examples,2)
    return 'one occurrence revised across actor/family/uncertainty/retraction; older revisions rejected'
end)
check('correction_keeps_anchor_input_and_independent_positive',function()
    local c=core(); local w=window(c,'P',10)
    assert(cast(c,'a','P',10.25,1)); assert(cast(c,'b','P',11.25,1)); finish(c,12.25)
    local x=ns.Copy(w.x); eq(w.lead[1],.25)
    assert(cast(c,'a','P',10.25,1,2,nil,nil,true))
    eq(w.y[1],1); eq(w.mask[1],true); eq(w.lead[1],1.25); deep(w.x,x); eq(#c.examples,1)
    return 'earliest witness retracts; later positive and immutable anchor features remain'
end)
check('gap_scope_and_coverage_recovery',function()
    local c=core(); local p=window(c,'P',10); local q=window(c,'Q',10)
    c:Context({actor='Q',at=11,bound=false}); eq(c.actors.Q.class,'PRIEST')
    assert(cast(c,'positive','Q',11,4)); finish(c,12.25)
    for i=1,6 do eq(p.mask[i],true); eq(q.mask[i],i==4) end
    local w=window(c,'P',13); c:SetCoverage(false); c:SetCoverage(true); finish(c,15.25)
    for i=1,6 do eq(w.mask[i],false) end
    local next=window(c,'P',16); finish(c,18.25)
    for i=1,6 do eq(next.mask[i],true); eq(next.y[i],0) end
    return 'actor-specific gap; re-enable cannot resurrect current absence; fresh window recovers'
end)
check('serving_retirement_then_deterministic_replacement',function()
    C.maxExamples=12
    local c=trained(); local old,revision=c.model,c.modelCorpusRevision
    assert(served(c,40).outputs[1].score); finish(c,42.25)
    eq(c.model,old); eq(c.modelCorpusRevision,revision); eq(#c.examples,12)
    eq(c:Status().modelRefreshPending,true); eq(c.model.positives[1],2)
    train(c); assert(c.model~=old); eq(c.model.positives[1],1); eq(c:Status().modelRefreshPending,false)
    eq(served(c,45).outputs[1].score,nil)
    return 'frozen serving model survives FIFO; replacement drops retired positive support'
end)
check('evicted_row_guard_and_semantic_noop_revision',function()
    C.maxExamples=12
    local c=trained(); local old=c.model; window(c,'P',40); finish(c,42.25)
    eq(c.examples[1].anchor,6); eq(c.model,old); eq(#c.modelDependencies,12)
    assert(cast(c,'warm1','P',3.5,1,2)); eq(c.model,old,'unchanged revision')
    assert(cast(c,'warm1','P',3.5,1,3,nil,nil,true)); eq(c.model,nil); eq(c.candidate,nil); eq(#c.modelDependencies,0)
    return 'evicted row guard survives; unchanged semantic revision preserves model; retraction withdraws'
end)
check('dependency_guard_old_and_new_actor_overlap',function()
    for _,direction in ipairs({'out','in'}) do
        local c=trained(); local old,revision=c.model,c.corpusRevision
        assert(cast(c,'unrelated','P',100,1)); assert(cast(c,'unrelated','P',101,2,2))
        eq(c.model,old); eq(c.corpusRevision,revision)
        if direction=='out' then assert(cast(c,'warm1','Q',3.5,1,2))
        else assert(cast(c,'outside','Q',3.5,1)); assert(c.model); assert(cast(c,'outside','P',3.5,1,2)) end
        eq(c.model,nil,direction); eq(#c.modelDependencies,0)
    end
    return 'both sides of reattribution guarded; unrelated evidence preserves serving generation'
end)
check('occurrence_retirement_and_stale_replay_floor',function()
    local c=trained(); local old=c.model
    for i=1,128 do c:Aura({id='aura'..i,recipient='Q',at=40+i*.001,spellID=22812}) end
    eq(#c.occurrenceOrder,128); eq(c.model,old); eq(c.examples[1].mask[1],false)
    eq(c.examples[2].mask[1],false); eq(c:Status().modelRefreshPending,true); eq(c.evidenceFloor,6.5)
    eq(c.actors.P.history[1],nil)
    local ok,why=cast(c,'warm1','P',3.5,1); eq(ok,false); eq(why,'outside_retained_history'); eq(c.model,nil)
    return 'aura churn retires cast labels; stale replay denied; affected serving snapshot withdrawn'
end)
check('lost_revision_family_censorship_and_candidate_cancel',function()
    local c=trained(); window(c,'P',40); finish(c,42.25); c:Tick(42.3,false); assert(c.candidate)
    local before=#c.occurrenceOrder; local ok,why=cast(c,'missing','P',11,2,2)
    eq(ok,false); eq(why,'revision_history_lost'); eq(c.model,nil); eq(c.candidate,nil); eq(#c.occurrenceOrder,before)
    for _,w in ipairs(c.examples) do eq(w.mask[2],false); eq(w.lost[2],true) end
    train(c); eq(c.model.totals[2],0)
    return 'missing old revision denies incoming occurrence; rebuild excludes uncertain actor/family labels'
end)
check('training_pause_resume_matches_clean_replay',function()
    local c=trained(); window(c,'P',40); finish(c,42.25); c:Tick(42.3,false)
    local job=c.candidate; assert(job); local index,epoch,steps=job.index,job.epoch,c.stats.trainingSteps
    c:Tick(42.4,true); c:Tick(42.5,nil)
    eq(c.candidate,job); eq(job.index,index); eq(job.epoch,epoch); eq(c.stats.trainingSteps,steps)
    train(c); local fresh=core(); assert(fresh:Restore(c:Export())); train(fresh); deep(c.model,fresh.model)
    return 'combat and unknown combat pause; resumed complete parameters equal clean replay'
end)
check('correction_and_new_data_restart_candidate',function()
    local c=trained(); window(c,'P',40); finish(c,42.25); c:Tick(42.3,false)
    local oldJob=c.candidate; assert(oldJob)
    assert(cast(c,'warm1','P',3.5,1,2,nil,nil,true)); eq(c.candidate,nil); eq(c.model,nil)
    c:Tick(42.4,false); assert(c.candidate and c.candidate~=oldJob)
    window(c,'P',45); finish(c,47.25); eq(c.candidate,nil)
    train(c); local fresh=core(); assert(fresh:Restore(c:Export())); train(fresh); deep(c.model,fresh.model)
    return 'correction/new corpus cancel stale replay; final state equals clean rebuilt parameters'
end)
check('failed_candidate_keeps_snapshot_and_refresh_metadata',function()
    local c=trained(); local old=c.model; window(c,'P',40); finish(c,42.25); c:Tick(42.3,false)
    assert(c.candidate); c.candidate.model.Learn=function() return false end; c:Tick(42.4,false)
    eq(c.model,old); eq(c.dirty,false); eq(c.candidate,nil); eq(c:Status().modelRefreshPending,true)
    eq(c.stats.numericFailures,1); assert(served(c,43).outputs[1].score)
    return 'injected candidate failure leaves completed snapshot and pending corpus metadata'
end)
check('reset_seals_positives_and_deidentifies_all_rows',function()
    local c=trained(); local old=c.model; local p=window(c,'P',40); local q=window(c,'Q',40,'hostile')
    assert(cast(c,'p-end','P',40.4,3)); assert(cast(c,'q-end','Q',40.6,2)); c:ResetSession(40.75)
    eq(c.model,old); eq(#c.modelDependencies,0); eq(#c.actorOrder,0); eq(#c.occurrenceOrder,0)
    eq(p.y[3],1); eq(p.mask[3],true); eq(q.y[2],1); eq(q.mask[2],true)
    for _,w in ipairs(c.examples) do eq(w.sealed,true); eq(w.actor,nil); eq(w.id,nil); eq(w.coverage,nil); eq(w.lost,nil) end
    for i=1,6 do if i~=3 then eq(p.mask[i],false) end end
    local saved=ns.Copy(c:Export()); assert(cast(c,'p-end','P',40.4,3)); deep(c:Export(),saved)
    return 'early reset keeps positives/censors absence; reused IDs cannot revise sealed history'
end)
check('reset_replay_continuity_and_corpus_sensitive_cancel',function()
    local c=trained(); window(c,'P',40); finish(c,42.25); c:Tick(42.3,false)
    local job=c.candidate; assert(job); c:ResetSession(43); eq(c.candidate,job); train(c); eq(#c.modelDependencies,0)
    window(c,'P',45); assert(cast(c,'positive','P',45.5,1)); finish(c,47.25); c:Tick(47.3,false)
    assert(c.candidate); window(c,'P',48); assert(cast(c,'pending-positive','P',48.25,1)); c:ResetSession(48.5)
    eq(c.candidate,nil); train(c); local fresh=core(); assert(fresh:Restore(c:Export())); train(fresh); deep(c.model,fresh.model)
    return 'unchanged corpus sealing preserves replay; new positive row cancels and rebuilds'
end)
check('capacity_reset_uses_first_seen_nonlexical_order',function()
    C.maxExamples=4; local c=core()
    for i=1,3 do window(c,'P',i*3); finish(c,i*3+2.25) end
    context(c,'Z',20,'hostile'); context(c,'B',20,'hostile'); context(c,'A',20,'hostile'); context(c,'P',20); c:Tick(20,true)
    for family,id in ipairs({'P','Z','B','A'}) do assert(cast(c,id..'-positive',id,20.5,family)) end
    c:ResetSession(20.75); eq(#c.examples,4)
    for i=1,4 do eq(c.examples[i].y[i],1,'first-seen index '..i) end
    eq(c.stats.exampleEvictions,3); eq(c.examples[1].regime,'player')
    return 'P,Z,B,A flush order preserved at FIFO capacity; completed rows retire first'
end)
check('actor_eviction_overlap_pause_and_clock_rollback',function()
    C.maxActors=2; local c=core(); local p=window(c,'P',10); window(c,'Q',10,'hostile')
    context(c,'R',10.5,'hostile'); eq(#c.actorOrder,2); eq(c.examples[1],p); eq(c.openAfter,12.25)
    context(c,'P',10.6); c:Tick(10.6,true); eq(c.actors.P.window,nil)
    context(c,'P',12.25); c:Tick(12.25,true); eq(c.actors.P.window.anchor,12.25)
    assert(cast(c,'old','P',12.5,1)); local w=c.actors.P.window; c:Tick(1,true)
    eq(c.now,1); eq(c.session,2); eq(#c.actorOrder,0); eq(#c.occurrenceOrder,0)
    eq(w.sealed,true); eq(w.y[1],1); eq(w.mask[1],true); eq(c.evidenceFloor,-1)
    window(c,'P',2); assert(cast(c,'old','P',2.5,2)); finish(c,4.25); eq(c.examples[#c.examples].y[2],1)
    return 'capacity pause prevents overlapping lessons; rollback starts a clean occurrence epoch'
end)
check('export_restore_and_projection_copy_isolation',function()
    local c=trained(); local exported=c:Export(); local fresh=core(); assert(fresh:Restore(exported)); train(fresh)
    deep(c.model,fresh.model); exported.examples[1].y[1]=0; eq(fresh.examples[1].y[1],1)
    local v=c:GetContext('P',c.actors.P.at); v.history[1]=999; eq(c.actors.P.history[1],6.5)
    local f=served(c,40); f.outputs[1].score=99; assert(c:Forecast('P',40).outputs[1].score<=1)
    return 'restored model equals original; external save/context/forecast mutations do not alter state'
end)

local function native()
    local s={time=0,combat=true,units={player='Player-Audit-P',target='Player-Audit-E'}}
    GetTime=function() return s.time end
    UnitGUID=function(u) return s.units[u] end; UnitIsPlayer=function(u) return s.units[u]~=nil end
    UnitClassBase=function(u) return u=='player' and 'PRIEST' or 'MAGE' end
    UnitCanAttack=function(_,u) return u~='player' end; UnitAffectingCombat=function() return s.combat end
    UnitHealth=function() return 100 end; UnitHealthMax=function() return 100 end
    UnitPower=function() return 90 end; UnitPowerMax=function() return 100 end
    UnitIsDeadOrGhost=function() return false end
    local c=core(); local a=ns.Adapter.New(c); a:SetRegistered(true)
    local function tick(t) s.time=t; a:Tick(t); c:Tick(t,s.combat) end
    local function emit(t,id,spell,u) s.time=t; a:OnEvent('UNIT_SPELLCAST_SUCCEEDED',u or 'player',id,spell) end
    return c,a,s,tick,emit
end
check('native_alias_duplicate_and_aura_retirement',function()
    local c,a,s,tick,emit=native(); s.units.target=s.units.player; tick(0); tick(.25)
    emit(.5,'cast-one',8122); emit(.5,'cast-one',8122,'target'); for i=2,9 do tick(i*.25) end
    eq(c.stats.casts,1); eq(c.stats.duplicateCasts,1); eq(c.examples[1].y[1],1); eq(c.examples[1].mask[1],true)
    for i=1,128 do a:OnAura({source='bjarkiPortraits',kind='aura-positive',isHelpful=true,
        recipientGUID='Player-Audit-E',spellId=22812,observedAt=3+i*.001,auraInstanceID=i,expirationTime=20}) end
    eq(#c.occurrenceOrder,128); eq(c.examples[1].mask[1],false); eq(c.evidenceFloor,.5)
    eq(c.stats.occurrenceEvictions,1); eq(#c.actorOrder,1)
    return 'actual Adapter deduplicates self aliases; aura producer forces bounded cast retirement/censorship'
end)
check('native_world_reset_and_next_fresh_occurrence',function()
    local c,a,s,tick,emit=native(); tick(0); tick(.25)
    emit(.5,'player-fear',8122); tick(.5); emit(.75,'enemy-root',122,'target'); tick(.75)
    s.time=1; a:OnEvent('PLAYER_ENTERING_WORLD')
    eq(#c.examples,2); eq(c.examples[1].regime,'player'); eq(c.examples[2].regime,'other')
    eq(c.examples[1].y[1],1); eq(c.examples[2].y[3],1); eq(c.examples[1].mask[2],false)
    eq(c.examples[2].mask[1],false); eq(c.examples[1].actor,nil); eq(c.examples[2].actor,nil)
    tick(1); assert(c.actors[s.units.player].window); tick(1.25); emit(1.5,'player-next',8122)
    for i=6,13 do tick(i*.25) end
    eq(c.examples[3].y[1],1); eq(c.examples[3].regime,'player'); eq(c:Status().gapReasons['scheduler-gap'],nil)
    return 'actual Adapter reset flushes player/target order, then learns separate fresh post-reset occurrence'
end)
for k,v in pairs(original) do C[k]=v end
return results
