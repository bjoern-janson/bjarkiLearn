"""Additional independent frame-routed native audit of an immutable addon source."""
import argparse
import hashlib
import importlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source', required=True, type=Path)
parser.add_argument('--output', required=True, type=Path)
parser.add_argument('--bus', type=Path, default=ROOT.parents[1] / 'verification/fixtures/SharedEvidence.lua')
parser.add_argument('--lupa-path', action='append', default=[])
args = parser.parse_args()
for item in args.lupa_path + ['C:/Users/Mewn/Documents/Codex/2026-10-16/let/work/deps']:
    sys.path.insert(0, item)
source = args.source.resolve()
def hashes():
    return {p.relative_to(source).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(source.rglob('*')) if p.is_file()}
before = hashes()
results = []
for engine in ('lua51', 'lua54'):
    LuaRuntime = importlib.import_module('lupa.' + engine).LuaRuntime
    discovery = LuaRuntime(unpack_returned_tuples=True)
    discovery.execute((ROOT / 'probes.lua').read_text(encoding='utf-8-sig'))
    names = sorted(discovery.globals().CASES.keys())
    for name in names:
        lua = LuaRuntime(unpack_returned_tuples=True)
        lua.globals().LEARN_ROOT = source.as_posix()
        lua.globals().BUS_PATH = args.bus.resolve().as_posix()
        error = None
        try:
            lua.execute((ROOT / 'probes.lua').read_text(encoding='utf-8-sig'))
            case = lua.globals().CASES[name]
            if case['setup']:
                lua.execute(case['setup'])
            lua.execute((ROOT / 'harness.lua').read_text(encoding='utf-8-sig'))
            lua.execute(case['run'])
        except Exception as exc:
            error = str(exc)
        results.append(dict(engine=engine, case=name, passed=error is None,
                            checks=lua.globals().CHECKS or 0, error=error))
report = dict(source=str(source), source_hashes_before=before,
              source_hashes_after=hashes(), source_unchanged=hashes() == before,
              summary=dict(passed=sum(r['passed'] for r in results), total=len(results),
                           checks=sum(r['checks'] for r in results)), cases=results,
              claim_ceiling='Actual addon Main/Adapter/Core and unchanged SharedEvidence bus with modeled host APIs. Native event delivery is restricted to modeled successful registrations. No live WoW execution or proof of actual Forever API availability, payloads, timings, or predictive utility.')
args.output.resolve().parent.mkdir(parents=True, exist_ok=True)
args.output.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(summary=report['summary'], source_unchanged=report['source_unchanged'],
                      failures=[r for r in results if not r['passed']]), indent=2))
sys.exit(0 if report['source_unchanged'] and all(r['passed'] for r in results) else 1)
