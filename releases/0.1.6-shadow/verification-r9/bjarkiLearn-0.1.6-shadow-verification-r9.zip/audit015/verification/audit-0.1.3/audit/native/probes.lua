CASES={
 ['all installed events and public vocabulary']={run=[[
  Init();Advance(10)
  local expected={'ADDON_LOADED','PLAYER_LOGOUT','PLAYER_ENTERING_WORLD','PLAYER_TARGET_CHANGED','PLAYER_FOCUS_CHANGED','UNIT_SPELLCAST_SUCCEEDED','PLAYER_REGEN_ENABLED','PLAYER_REGEN_DISABLED','PLAYER_ALIVE','PLAYER_DEAD'}
  local n=0;for _ in pairs(Runtime.frame.events) do n=n+1 end;Equal(n,#expected)
  for _,e in ipairs(expected) do Check(Runtime.frame.events[e],e) end
  Equal(SLASH_BJARKILEARN1,'/blearn');Equal(SLASH_BJARKILEARN2,'/bjarkilearn')
  Equal(BjarkiLearn.protocol,'bjarki-learn-v1');Equal(BjarkiLearn.mode,'shadow')
  Check(BjarkiLearn.Cast==nil and BjarkiLearn.Aura==nil and BjarkiLearn.Train==nil)
  Equal(Runtime:Status().registrationErrors[1],nil)
 ]]},
 ['explicit false registration prevents actual native delivery and all negatives']={setup="REGISTRATION={UNIT_SPELLCAST_SUCCEEDED='false'}",run=[[
  Init();Advance(10);Check(not Runtime.castRegistered);Check(not Runtime.adapter.coverage)
  World.now=10.2;Check(not Event('UNIT_SPELLCAST_SUCCEEDED','player','never-delivered',22812))
  EndFirst();ExpectPlayerMasks(false);Equal(Runtime.adapter.stats.casts,0);Equal(Runtime.core.stats.casts,nil)
  Equal(Runtime.registrationErrors[1],'UNIT_SPELLCAST_SUCCEEDED');Check(not Runtime.faulted)
 ]]},
 ['throwing registration prevents actual native delivery and all negatives']={setup="REGISTRATION={UNIT_SPELLCAST_SUCCEEDED='throws'}",run=[[
  Init();Advance(10);Check(not Runtime.castRegistered)
  World.now=10.2;Check(not Event('UNIT_SPELLCAST_SUCCEEDED','player','never-delivered',22812))
  EndFirst();ExpectPlayerMasks(false);Equal(Runtime.adapter.stats.casts,0);Check(not Runtime.faulted)
 ]]},
 ['readable true registration grants coverage']={setup="REGISTRATION={UNIT_SPELLCAST_SUCCEEDED='true'}",run=[[
  Init();Advance(10);Check(Runtime.castRegistered);Check(Runtime.adapter.coverage)
  World.now=10.2;Check(Event('UNIT_SPELLCAST_SUCCEEDED','player','delivered',22812))
  EndFirst();ExpectPlayerMasks(true);Equal(PlayerExample().y[6],1);Equal(Runtime.core.stats.casts,1)
 ]]},
 ['other registration failure does not fabricate a cast failure']={setup="REGISTRATION={PLAYER_FOCUS_CHANGED='throws'}",run=[[
  Init();Advance(10);Check(Runtime.castRegistered);Check(Runtime.adapter.coverage)
  Equal(Runtime.registrationErrors[1],'PLAYER_FOCUS_CHANGED')
  World.ids.focus='Player-1-300';World.classes.focus='MAGE';World.now=10.1
  Check(not Event('PLAYER_FOCUS_CHANGED'));Equal(BjarkiLearn:GetContext('focus'),nil)
  Advance(10.25);Equal(BjarkiLearn:GetContext('focus').actor,'Player-1-300')
  EndFirst();ExpectPlayerMasks(true)
 ]]},
 ['scheduler interruption preserves delivered positive and censors all absence']={run=[[
  Init();Advance(10);World.now=10.2;Event('UNIT_SPELLCAST_SUCCEEDED','player','before-stall',22812)
  Advance(11);Advance(11.5);Advance(12);World.combat=false;World.unitCombat=false;Advance(12.3)
  local w=PlayerExample();Equal(w.y[6],1);Equal(w.mask[6],true)
  for i=1,5 do Equal(w.mask[i],false) end
  Equal(Runtime.core.gapReasons['scheduler-gap'],1);Check(not Runtime.faulted)
 ]]},
 ['half-second service boundary retains full absence coverage']={run=[[
  Init();Advance(10);EndFirst();ExpectPlayerMasks(true)
  Equal(Runtime.core.gapReasons['scheduler-gap'],nil)
 ]]},
 ['known combat exit retains full horizon and defers native-handler training']={run=[[
  Init();Advance(10);World.now=10.25;World.unitCombat=false;World.combat=false
  Event('PLAYER_REGEN_ENABLED');Equal(Runtime.core:Status().trainingSteps,0)
  World.now=10.4;Event('UNIT_SPELLCAST_SUCCEEDED','player','after-combat-exit',22812)
  EndFirst();ExpectPlayerMasks(true);Equal(PlayerExample().y[6],1)
  Check(Runtime.core:Status().trainingSteps>0);Equal(Runtime.core:Status().pending,0)
 ]]},
 ['unit combat missingness censors player while global combat stays readable']={run=[[
  Init();Advance(10);World.unitCombat=Opaque;Advance(10.25)
  Check(Runtime.core.gapReasons.combat_unknown>0)
  World.unitCombat=true;EndFirst();ExpectPlayerMasks(false)
  Equal(Runtime.core.gapReasons['unreadable-combat'],nil)
 ]]},
 ['unreadable global combat repeats safely then permits next complete window']={run=[[
  Init();Advance(10);World.combat=Opaque;Advance(10.25);Advance(10.5);Advance(10.75)
  Equal(Runtime.core.gapReasons['unreadable-combat'],1)
  World.combat=true;Advance(11);Advance(11.5);Advance(12);Advance(12.25)
  local first=PlayerExample();for i=1,6 do Equal(first.mask[i],false) end
  Advance(12.5);Advance(13);Advance(13.5);Advance(14);World.combat=false;World.unitCombat=false;Advance(14.5)
  local last;for _,w in ipairs(Runtime.core.examples) do if w.regime=='player' then last=w end end
  Check(last~=first);for i=1,6 do Equal(last.mask[i],true) end
 ]]},
 ['cast event validates tracked unit before optional native reads']={run=[[
  Init();Advance(10);local reads=0;local old=UnitGUID
  UnitGUID=function(u) reads=reads+1;return old(u) end
  World.now=10.2;Event('UNIT_SPELLCAST_SUCCEEDED','party1',Opaque,Opaque)
  Equal(reads,0);Equal(Runtime.adapter.stats.rejected,0);Equal(Runtime.adapter.stats.unknownSpells,0)
  EndFirst();ExpectPlayerMasks(true)
 ]]},
 ['unknown player type with valid GUID still records ordinary cast']={run=[[
  Init();Advance(10);UnitIsPlayer=function() return Opaque end
  World.now=10.2;Event('UNIT_SPELLCAST_SUCCEEDED','player','guid-proves-player',22812)
  EndFirst();ExpectPlayerMasks(true);Equal(PlayerExample().y[6],1);Check(Runtime.adapter.coverage)
 ]]},
 ['lost player binding with surviving alias does not retain negative coverage']={run=[[
  World.ids.target=World.ids.player;World.classes.target='DRUID';Init();Advance(10)
  local native=UnitGUID;UnitGUID=function(u) if u=='player' then return Opaque end return native(u) end
  Advance(10.25);Check(not Runtime.adapter.coverage)
  World.now=10.3;Event('UNIT_SPELLCAST_SUCCEEDED','target','alias-positive',22812)
  UnitGUID=native;Advance(10.5);Advance(11);Advance(11.5);Advance(12);World.combat=false;Advance(12.3)
  local w=PlayerExample();Equal(w.mask[6],true);Equal(w.y[6],1)
  for i=1,5 do Equal(w.mask[i],false) end
  Equal(BjarkiLearn:GetContext('player').regime,'player')
 ]]},
 ['invalid GUID removal and recovery preserve actor and session boundaries']={run=[[
  Init();Advance(10);local original=World.ids.player
  World.ids.player='Creature-1-123';Advance(10.25);Equal(BjarkiLearn:GetContext('player'),nil)
  Check(not Runtime.adapter.coverage);Check(not Runtime.core.actors[original].bound)
  World.ids.player=original;Advance(10.5);Check(Runtime.adapter.coverage)
  EndFirst();ExpectPlayerMasks(false);Equal(BjarkiLearn:GetContext('player').actor,original)
 ]]},
 ['public projections are copied and unresolved GUIDs are inaccessible']={run=[[
  Init();Advance(10);local c=BjarkiLearn:GetContext('player');local f=BjarkiLearn:Forecast('player');local s=BjarkiLearn:Status()
  c.class='MAGE';c.candidates.defensive.status='invented';c.history[6]=999
  f.outputs[6].score=.999;f.outputs[6].candidate.status='invented';f.usable=true
  s.core.families[6].positive=999;s.registrationErrors[1]='invented';s.adapter.casts=999
  Equal(BjarkiLearn:GetContext('player').class,'DRUID');Equal(BjarkiLearn:GetContext('player').history[6],nil)
  Equal(BjarkiLearn:GetContext('player').candidates.defensive.status,'candidate')
  Equal(BjarkiLearn:Forecast('player').usable,false);Equal(BjarkiLearn:Forecast('player').outputs[6].score,nil)
  Equal(BjarkiLearn:Status().core.families[6].positive,0);Equal(BjarkiLearn:Status().registrationErrors[1],nil)
  Equal(BjarkiLearn:Status().adapter.casts,0)
  Equal(BjarkiLearn:Forecast('Player-1-999'),nil);Equal(BjarkiLearn:GetContext(Opaque),nil)
  Equal(BjarkiLearn:GetContext('Player-1-100').actor,'Player-1-100')
 ]]},
 ['public queries with unavailable clock and stale context withhold projection']={run=[[
  Init();Advance(10);World.now=Opaque;Equal(BjarkiLearn:GetContext('player'),nil);Equal(BjarkiLearn:Forecast('player'),nil)
  World.now=11.01;Equal(BjarkiLearn:GetContext('player').fresh,false)
  local f=BjarkiLearn:Forecast('player');Equal(f.reason,'stale_context')
  for i=1,6 do Equal(f.outputs[i].score,nil);Equal(f.outputs[i].linear,nil);Equal(f.outputs[i].frequency,nil) end
  World.now=10.25;Advance(10.25);Check(BjarkiLearn:GetContext('player').fresh)
 ]]},
 ['preexisting public global remains untouched but collection works']={setup="BjarkiLearn={sentinel='foreign'}",run=[[
  Init();Advance(10);Equal(BjarkiLearn.sentinel,'foreign');Equal(BjarkiLearn.protocol,nil)
  Check(not Runtime.publicAvailable);EndFirst();ExpectPlayerMasks(true)
 ]]},
 ['optional class fallback and form require readable alive power token']={run=[[
  UnitClassBase=nil;UnitClass=function(u) return 'localized',u=='player' and 'DRUID' or 'ROGUE' end
  UnitPowerType=function() return 3,'ENERGY' end;Init();Advance(10)
  Equal(BjarkiLearn:GetContext('player').class,'DRUID');Equal(BjarkiLearn:GetContext('player').form,'cat')
  UnitIsDeadOrGhost=function() return true end;World.now=10.1;Event('PLAYER_DEAD')
  Equal(BjarkiLearn:GetContext('player').form,nil)
  UnitIsDeadOrGhost=function() return false end;UnitPowerType=function() return 1,'RAGE' end
  World.now=10.2;Event('PLAYER_ALIVE');Equal(BjarkiLearn:GetContext('player').form,'bear')
  UnitPowerType=function() return 3,Opaque end;Advance(10.25);Equal(BjarkiLearn:GetContext('player').form,nil)
  EndFirst();ExpectPlayerMasks(true)
 ]]},
 ['slash disable enable reset and logout preserve exact intended data classes']={run=[[
  LoadBus();PublishAura(61,10);Init();Advance(10);World.now=10.2
  Event('UNIT_SPELLCAST_SUCCEEDED','player','pre-disable',22812)
  SlashCmdList.BJARKILEARN(' disable ');Check(not Runtime.enabled);Equal(BjarkiLearn:GetContext('player'),nil)
  local w=PlayerExample();Check(w.sealed);Equal(w.actor,nil);Equal(w.y[6],1);Equal(w.mask[6],true)
  for i=1,5 do Equal(w.mask[i],false) end
  Equal(bjarkiLearnDB.enabled,false);Equal(#bjarkiLearnDB.learning.examples,2)
  local oldCount=#Runtime.core.examples;Event('UNIT_SPELLCAST_SUCCEEDED','player','disabled',22812)
  Equal(#Runtime.core.examples,oldCount);Equal(BjarkiEvidenceV1:Status().listeners,0)
  SlashCmdList.BJARKILEARN('ENABLE');Check(Runtime.enabled);Equal(#Runtime.core.examples,oldCount)
  Equal(BjarkiEvidenceV1:Status().listeners,1);Equal(Runtime.core.stats.casts,1)
  SlashCmdList.BJARKILEARN('reset');Equal(#Runtime.core.examples,0);Equal(Runtime.core.model,nil)
  Equal(Runtime.core:Status().pending,0);Equal(BjarkiEvidenceV1:Status().listeners,1)
  Check(BjarkiLearn:GetContext('target').defensiveWitness~=nil)
  Event('PLAYER_LOGOUT');Equal(#bjarkiLearnDB.learning.examples,0);Check(bjarkiLearnDB.enabled)
 ]]},
 ['saved disabled state collects nothing until explicitly enabled']={setup="bjarkiLearnDB={schema=1,enabled=false}",run=[[
  LoadBus();Init();Advance(10);Check(not Runtime.enabled);Equal(Runtime.adapter,nil)
  Equal(BjarkiLearn:GetContext('player'),nil);Equal(BjarkiEvidenceV1:Status().listeners,0)
  World.now=10.25;Event('UNIT_SPELLCAST_SUCCEEDED','player','disabled-start',22812)
  Equal(Runtime.core.stats.casts,nil);SlashCmdList.BJARKILEARN('enable')
  Check(Runtime.adapter.coverage);Equal(BjarkiEvidenceV1:Status().listeners,1)
  Advance(10.5);Equal(Runtime.core:Status().pending,2)
 ]]},
 ['unsupported commands and duplicate lifecycle events have no mutation']={run=[[
  Init();Advance(10);local core=Runtime.core;local adapter=Runtime.adapter;local session=core.session
  Event('ADDON_LOADED','bjarkiLearn');SlashCmdList.BJARKILEARN('reset extra');SlashCmdList.BJARKILEARN('inspect party1')
  SlashCmdList.BJARKILEARN('something');SlashCmdList.BJARKILEARN('enable')
  Equal(Runtime.core,core);Equal(Runtime.adapter,adapter);Equal(core.session,session)
  Equal(core:Status().pending,2);Check(#World.chat>=4)
 ]]},
 ['bus replay bound and expiry do not create cast outcomes']={run=[[
  LoadBus();PublishAura(70,1.9);PublishAura(71,2);PublishAura(72,10)
  Init();Advance(10);Equal(Runtime.adapter.stats.auras,2)
  Equal(Runtime.core.stats.auraWitnesses,2);Equal(Runtime.core.stats.casts,nil)
  Equal(BjarkiLearn:GetContext('target').defensiveWitness.at,10)
  local w=Runtime.core.actors[World.ids.target].window;Equal(w.x[47],1);Equal(w.x[48],1)
  EndFirst();ExpectPlayerMasks(true);for i=1,6 do Equal(PlayerExample().y[i],0) end
 ]]},
 ['bus untracked recipient stays unbound and cannot open a window']={run=[[
  LoadBus();Init();Advance(10);World.now=10.2
  Check(BjarkiEvidenceV1:Publish({source='bjarkiPortraits',kind='aura-positive',isHelpful=true,recipientGUID='Player-1-999',unit='targettarget',spellId=5277,auraInstanceID=73,observedAt=10.2,duration=10,expirationTime=20}))
  Equal(Runtime.core.actors['Player-1-999'],nil);Equal(BjarkiLearn:GetContext('Player-1-999'),nil)
  Equal(Runtime.core.stats.auraWitnesses,1);Equal(Runtime.core:Status().pending,2)
  World.ids.focus='Player-1-999';World.classes.focus='ROGUE';Event('PLAYER_FOCUS_CHANGED')
  local c=BjarkiLearn:GetContext('focus');Check(c.fresh);Equal(c.defensiveWitness.spellID,5277)
  Advance(10.25);Equal(Runtime.core:Status().pending,3);Equal(Runtime.core.stats.casts,nil)
 ]]},
 ['real bus refuses malformed positives and expired aura has no fresh witness feature']={run=[[
  LoadBus();Init();Advance(10)
  Check(not BjarkiEvidenceV1:Publish({source='bjarkiPortraits',kind='aura-positive',isHelpful=false,recipientGUID=World.ids.target,unit='target',spellId=5277,auraInstanceID=74,observedAt=10}))
  Check(BjarkiEvidenceV1:Publish({source='bjarkiPortraits',kind='aura-positive',isHelpful=true,recipientGUID=World.ids.target,unit='target',spellId=5277,auraInstanceID=74,observedAt=10,duration=10,expirationTime=9}))
  Equal(Runtime.adapter.stats.auras,1);Equal(Runtime.core.stats.casts,nil)
  local x=NS.Rules.Features(Runtime.core.actors[World.ids.target],10);Equal(x[47],0);Equal(x[48],0)
  EndFirst();ExpectPlayerMasks(true)
 ]]},
 ['bus unavailable and later real load recover on registered addon event']={run=[[
  BjarkiEvidenceV1={schema=2,protocol='bjarki-positive-aura-v1'};Init();Advance(10)
  Check(not Runtime.adapter.stats.busConnected);Equal(Runtime.adapter.stats.busErrors,0)
  BjarkiEvidenceV1=nil;LoadBus();PublishAura(75,10.1);World.now=10.2;Event('ADDON_LOADED','bjarkiPortraits')
  Check(Runtime.adapter.stats.busConnected);Equal(Runtime.adapter.stats.auras,1)
  Event('ADDON_LOADED','unrelated');Equal(Runtime.adapter.stats.auras,1);Equal(BjarkiEvidenceV1:Status().listeners,1)
 ]]},
 ['world reset replays once despite alias changes and leaves old callback inert after disable']={run=[[
  World.ids.focus=World.ids.target;World.classes.focus='ROGUE';LoadBus();PublishAura(76,10);Init();Advance(10)
  local adapter=Runtime.adapter;Equal(adapter.stats.auras,1);World.now=10.25;Event('PLAYER_ENTERING_WORLD')
  Equal(adapter.stats.auras,2);Equal(BjarkiEvidenceV1:Status().listeners,1);Equal(Runtime.core.stats.auraWitnesses,2)
  local callback=adapter.callback;SlashCmdList.BJARKILEARN('disable');local seen=adapter.stats.auras
  callback({source='bjarkiPortraits',kind='aura-positive',isHelpful=true,recipientGUID=World.ids.target,spellId=5277,auraInstanceID=77,observedAt=10.3})
  Equal(adapter.stats.auras,seen);Equal(BjarkiEvidenceV1:Status().listeners,0)
 ]]},
}

CASES['trained public scores remain copied and expire through native scheduling']={run=[[
 Init();Advance(10)
 for cycle=1,10 do
  local anchor=10+(cycle-1)*2.25
  if cycle<=2 then World.now=anchor+.2;Event('UNIT_SPELLCAST_SUCCEEDED','player','support-'..cycle,22812) end
  for step=1,9 do
   if cycle==10 and step==9 then World.combat=false;World.unitCombat=false end
   Advance(anchor+step*.25)
  end
 end
 Equal(Runtime.core:Status().trainingSteps,4)
 for step=1,11 do Advance(32.5+step*.25) end
 Check(Runtime.core.model~=nil);Equal(Runtime.core.model.positives[6],2);Equal(Runtime.core.model.totals[6],10)
 local original=BjarkiLearn:Forecast('player');Check(type(original.outputs[6].score)=='number')
 Equal(original.usable,false);Equal(original.outputs[6].usable,false);Equal(original.outputs[6].calibrated,false)
 local score=original.outputs[6].score;local sample=original.at;original.outputs[6].score=-1
 Equal(BjarkiLearn:Forecast('player').outputs[6].score,score)
 local old=World.now;World.now=old+1.01
 local stale=BjarkiLearn:Forecast('player');Equal(stale.reason,'stale_context')
 for i=1,6 do Equal(stale.outputs[i].score,nil);Equal(stale.outputs[i].linear,nil);Equal(stale.outputs[i].frequency,nil) end
 World.now=old;Advance(old+.25)
 Check(type(BjarkiLearn:Forecast('player').outputs[6].score)=='number')
 World.now=World.now+.01;Event('UNIT_SPELLCAST_SUCCEEDED','player','changes-context',22812)
 local invalidated=BjarkiLearn:Forecast('player');Equal(invalidated.outputs[6].score,nil)
 Equal(invalidated.outputs[6].reason,'not_computed')
 Advance(old+.5);Check(type(BjarkiLearn:Forecast('player').outputs[6].score)=='number')
 Check(not Runtime.faulted)
]]}
