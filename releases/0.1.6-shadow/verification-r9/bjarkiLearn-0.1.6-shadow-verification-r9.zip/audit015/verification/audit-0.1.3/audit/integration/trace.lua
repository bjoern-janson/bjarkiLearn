-- Actual frame handlers and release modules; only the native host is modeled.
UnitHealth=function() return World.health or 75 end
UnitPower=function() return World.power or 50 end
if SCENARIO=='alias_lifecycle' then World.ids.target=World.ids.player;World.ids.focus=World.ids.player
else World.ids.focus='Player-1-300';World.classes.focus='PRIEST' end
if ROUNDTRIP then
 bjarkiLearnDB=SAVED;World.combat=false;World.unitCombat=false
 Init()
 for i=1,300 do Advance(10+i*.125) end
 Check(not Runtime.faulted and Runtime.core.model~=nil and not Runtime.core.dirty and not Runtime.core.candidate,'reload replay completes')
 return {model=Runtime.core.model:Copy(),export=Runtime.core:Export(),checks=CHECKS}
end
Init();Advance(10)
local snapshots={}
local spells={8122,853,122,15487,1766,22812}
for cycle=1,100 do
 for step=1,9 do
  local now=10+((cycle-1)*9+step)*.25
  World.health=20+(cycle*7)%81;World.power=(cycle*13)%101
  if step==2 then
   World.now=now
   local spell=spells[(cycle-1)%6+1]
   Event('UNIT_SPELLCAST_SUCCEEDED','player','Cast-trace-player-'..cycle,spell)
   local targetCast=(SCENARIO=='alias_lifecycle' and 'Cast-trace-player-' or 'Cast-trace-target-')..cycle
   Event('UNIT_SPELLCAST_SUCCEEDED','target',targetCast,spell)
   if SCENARIO~='alias_lifecycle' then Event('UNIT_SPELLCAST_SUCCEEDED','focus','Cast-trace-focus-'..cycle,spells[cycle%6+1]) end
  end
  Advance(now)
 end
 if SCENARIO=='alias_lifecycle' then
  if cycle%17==0 then Event('PLAYER_ENTERING_WORLD') end
  if cycle%23==0 then Runtime:Command('disable');Runtime:Command('enable') end
 end
 local core=Runtime.core
 Check(not Runtime.faulted,'healthy after cycle')
 Check(#core.examples<=256 and #core.actorOrder<=16 and #core.occurrenceOrder<=128 and #core.modelDependencies<=256,'bounds')
 if cycle%25==0 then snapshots[#snapshots+1]={status=Runtime:Status(),export=core:Export()} end
end
World.combat=false;World.unitCombat=false
local start=World.now
for i=1,320 do Advance(start+i*.125) end
Check(Runtime.core.model~=nil and not Runtime.core.dirty and not Runtime.core.candidate,'final replay completes')
Event('PLAYER_LOGOUT');Check(bjarkiLearnDB~=nil,'native logout saves')
local function noIdentity(v)
 if type(v)=='table' then for k,x in pairs(v) do noIdentity(k);noIdentity(x) end
 elseif type(v)=='string' then Check(not v:find('Player%-') and not v:find('Cast%-'),'save deidentified') end
end
noIdentity(bjarkiLearnDB)
return {snapshots=snapshots,status=Runtime:Status(),model=Runtime.core.model:Copy(),export=Runtime.core:Export(),save=bjarkiLearnDB,checks=CHECKS}
