from pathlib import Path
import argparse,hashlib,importlib,json,sys
try:import lupa
except ImportError:sys.path.insert(0,'C:/Users/Mewn/Documents/Codex/2026-10-16/let/work/deps')
p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--baseline',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
root=Path(__file__).resolve().parent;audit=root.parents[1]
harness=(audit/'verification/audit-0.1.2/native/harness.lua').read_text(encoding='utf-8')
trace=(root/'trace.lua').read_text(encoding='utf-8')
def frozen(v):
 if hasattr(v,'items'):return {k:frozen(x) for k,x in v.items() if k!='version'}
 return v

def tables(lua,v):
 if isinstance(v,dict):return lua.table_from({k:tables(lua,x) for k,x in v.items()})
 return v

def run(engine,source,scenario,saved=None):
 lua=importlib.import_module('lupa.'+engine).LuaRuntime(unpack_returned_tuples=True)
 lua.globals().LEARN_ROOT=source.resolve().as_posix();lua.globals().SCENARIO=scenario;lua.globals().ROUNDTRIP=saved is not None
 lua.execute(harness)
 if saved is not None:lua.globals().SAVED=tables(lua,saved)
 return frozen(lua.execute(trace))

def hashes():return {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in a.source.glob('*.lua')}
before=hashes();results=[]
for scenario in ('continuous_three_actors','alias_lifecycle'):
 reference=None
 for engine in ('lua51','lua54'):
  for label,source in (('0.1.2',a.baseline),('0.1.3',a.source)):
   r=run(engine,source,scenario)
   if reference is None:reference=r
   same=r==reference
   reloaded=run(engine,source,scenario,r['save'])
   roundtrip=r['model']==reloaded['model'] and r['export']==reloaded['export']
   results.append({'scenario':scenario,'engine':engine,'version':label,'passed':same and roundtrip,'full_trace_identical_to_reference':same,'logout_reload_export_and_completed_model_identical':roundtrip,'checks':r['checks']+reloaded['checks'],'examples':r['status']['core']['examples'],'modelExamples':r['status']['core']['modelExamples']})
   print(scenario,engine,label,results[-1]['passed'],flush=True)
report={'passed':all(r['passed'] for r in results),'total':len(results),'passes':sum(r['passed'] for r in results),'source_unchanged':before==hashes(),'source_hashes':before,'cases':results,'scope':'Two actual frame-handler trajectories,100 windows each, repeated on baseline/release and Lua5.1/5.4. Full status/export/model exact comparisons ignore only version fields. Fresh Lua runtime logout/reload recomputes identical model and exports. Multi-actor trajectory has no session reset; alias lifecycle has one unique actor, so old reset hash order is not a compatibility target.'}
a.output.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');sys.exit(0 if report['passed'] and report['source_unchanged'] else 1)
