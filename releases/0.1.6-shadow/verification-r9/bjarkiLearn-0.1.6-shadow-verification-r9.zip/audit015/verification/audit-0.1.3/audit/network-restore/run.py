"""Independent production-shape network, normalization, and scoring audit."""
import argparse, hashlib, importlib, json, sys
from pathlib import Path
p=argparse.ArgumentParser()
p.add_argument('--source',required=True,type=Path);p.add_argument('--output',required=True,type=Path)
p.add_argument('--lupa-path',type=Path);a=p.parse_args()
if a.lupa_path: sys.path.insert(0,str(a.lupa_path))
try: import lupa
except ModuleNotFoundError: sys.path.insert(0,'C:/Users/Mewn/Documents/Codex/2026-10-16/let/work/deps')
source=a.source.resolve()
def hashes():
 return {str(f.relative_to(source)):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(source.rglob('*')) if f.is_file()}
before=hashes();results=[];fingerprints={}
for engine in ('lua51','lua54'):
 lua=importlib.import_module('lupa.'+engine).LuaRuntime(unpack_returned_tuples=True);ns=lua.table()
 for filename in ('Bootstrap.lua','Rules.lua','Network.lua','Core.lua'):
  lua.execute((source/filename).read_text(encoding='utf-8-sig'),'bjarkiLearn',ns)
 report=lua.execute(Path(__file__).with_name('probes.lua').read_text(encoding='utf-8-sig'),ns)
 for _,case in report['cases'].items(): results.append({'runtime':engine,**dict(case.items())})
 fingerprints[engine]=report['fingerprint']
results.append({'runtime':'cross-runtime','name':'production deterministic trained-state fingerprint','passed':fingerprints['lua51']==fingerprints['lua54'],'checks':1})
after=hashes()
out={'source':str(source),'source_hashes_before':before,'source_hashes_after':after,'source_unchanged':before==after,'total':len(results),'passed':sum(bool(r['passed']) for r in results),'checks':sum(r['checks'] for r in results),'results':results,'fingerprint_sha256':{k:hashlib.sha256(v.encode()).hexdigest() for k,v in fingerprints.items()}}
a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in out.items() if k not in ('results','source_hashes_before','source_hashes_after')}))
for row in results:
 if not row['passed']: print(json.dumps(row))
sys.exit(0 if out['passed']==out['total'] and out['source_unchanged'] else 1)
