local ns,old=...
local rows={}
local function eq(a,b,msg) assert(a==b,(msg or 'mismatch')..': '..tostring(a)..' ~= '..tostring(b)) end
local function deep(a,b,path)
 path=path or ''; eq(type(a),type(b),path)
 if type(a)~='table' then eq(a,b,path); return end
 for k,v in pairs(a) do deep(v,b[k],path..'.'..tostring(k)) end
 for k in pairs(b) do assert(a[k]~=nil,path..' extra '..tostring(k)) end
end
local function test(name,f) local ok,why=pcall(f); rows[#rows+1]={name=name,passed=ok,detail=ok and why or nil,error=not ok and tostring(why) or nil} end
local function context(c,id,t) return c:Context({actor=id,at=t,role='self',class='PRIEST',combat=true,bound=true,health=.8,power=.7}) end
local function core(module) local c=module.Core.New(); c:SetCoverage(true); return c end
local function cast(c,id,actor,t,f,rev,lo,hi,retracted) return c:Cast({id=id,actor=actor,at=t,family=f,revision=rev,minAt=lo,maxAt=hi,retracted=retracted}) end
local function train(c) for i=1,2000 do c:Tick(c.now,false); if not c.dirty then break end end; assert(c.model and not c.candidate and not c.dirty) end

test('native_observed_core_trajectory_matches_013',function()
 local a,b=core(ns),core(old)
 local function both(f) f(a);f(b);deep(a:Export(),b:Export(),'export');deep(a.modelDependencies,b.modelDependencies,'guards') end
 for n=1,80 do
  local t=n*4
  both(function(c) context(c,'P',t);c:Tick(t,true) end)
  if n%4==0 then both(function(c) context(c,'P',t+.4);assert(cast(c,'c'..n,'P',t+.4,n%6+1,1)) end) end
  if n%7==0 then both(function(c) context(c,'P',t+.6);assert(c:Aura({id='a'..n,recipient='P',at=t+.6,spellID=22812,expires=t+1.5})) end) end
  if n%12==0 then both(function(c) context(c,'P',t+.8);assert(cast(c,'c'..n,'P',t+.7,2,2)) end) end
  both(function(c) context(c,'P',t+2.25);c:Tick(t+2.25,false) end)
  both(function(c) train(c) end)
  deep(a:Forecast('P',t+2.25),b:Forecast('P',t+2.25),'forecast')
  deep(a:GetContext('P',t+2.25),b:GetContext('P',t+2.25),'context')
 end
 both(function(c)c:ResetSession(0) end);both(function(c)train(c) end)
 return '80 ordinary observed windows, between-tick casts, corrections, auras, real training and rollback match 0.1.3 exactly in exported data, guards, forecasts and contexts.'
end)

test('independent_ledger_800_corrections_and_clock_steps',function()
 local c=core(ns);local ledger={};local observed=10;local rng=71329
 local function draw(n)rng=(rng*48271)%2147483647;return rng%n+1 end
 for i=1,16 do context(c,'P'..i,10) end;c:Tick(10,true)
 for i=1,14 do context(c,'R'..i,10.1) end;observed=10.1
 eq(#c.examples,14)
 local checks=0
 local function verify()
  for _,w in ipairs(c.examples) do
   for f=1,6 do
    local positive=false;local ambiguous=false;local lead=nil
    for _,e in pairs(ledger) do
     if not e.retracted and e.actor==w.actor and e.f==f and e.hi>w.anchor and e.lo<=w.deadline then
      if e.lo>w.anchor and e.hi<=w.deadline and e.hi<=observed then
       positive=true;lead=math.min(lead or 1e9,e.lo-w.anchor)
      else ambiguous=true end
     end
    end
    eq(w.y[f],positive and 1 or 0,'ledger y');eq(w.mask[f],positive or (not ambiguous and w.coverage[f] and not w.lost[f]) or false,'ledger mask')
    eq(w.lead[f],lead,'ledger lead');checks=checks+1
   end
  end
  for _,id in ipairs({'P15','P16'}) do
   local at=9+draw(35)/10;local view=c:GetContext(id,at);local expected={}
   for _,e in pairs(ledger) do
    if e.actor==id and not e.retracted and e.lo==e.hi and e.t<=at then expected[e.f]=math.max(expected[e.f] or -1,e.t) end
   end
   deep(view.history,expected,'ledger projection')
  end
 end
 for step=1,800 do
  if step%9==0 then
   observed=observed+.025
   if step%18==0 then c:Tick(observed,nil) else context(c,'R14',observed) end
  else
   local id='e'..draw(80);local previous=ledger[id];local rev=previous and previous.rev+1 or 1
   local actor='P'..draw(16);local f=draw(6);local t=9+draw(40)/10
   local lo=t;local hi=t
   if draw(4)==1 then lo=t-.15;hi=t+.15 end
   local retracted=draw(7)==1
   assert(cast(c,id,actor,t,f,rev,lo,hi,retracted))
   ledger[id]={actor=actor,f=f,t=t,lo=lo,hi=hi,rev=rev,retracted=retracted}
  end
  verify()
 end
 observed=15;c:Tick(15,nil);verify();eq(#c.examples,16);assert(#c.occurrenceOrder<=80)
 return tostring(checks)..' row/head ledger comparisons plus 1602 as-of projections; retained retired actors, intervals, retractions, actor/family/time changes and both observed-time entry points.'
end)

test('rejected_context_cannot_mature_future_label',function()
 local c=core(ns);context(c,'P',10);c:Tick(10,true);local w=c.actors.P.window
 assert(cast(c,'e','P',11,1,1));for i=1,16 do context(c,'R'..i,10.1) end
 eq(w.y[1],0);local rev=c.corpusRevision
 eq(c:Context({actor='',at=100}),nil);eq(c:Context({actor='R16',at=0}),nil)
 eq(c:Context({actor='R16',at=0/0}),nil);eq(c:Context({actor='R16',at=math.huge}),nil)
 eq(w.y[1],0);eq(c.corpusRevision,rev);context(c,'R16',11);eq(w.y[1],1)
 return 'Only accepted context observations move outcome authority.'
end)

test('stale_due_marker_rebuilds_earliest_live_due',function()
 local c=core(ns);context(c,'P',10);c:Tick(10,true);local w=c.actors.P.window
 assert(cast(c,'a','P',10.3,1,1));assert(cast(c,'b','P',11.2,2,1))
 assert(cast(c,'a','P',10.3,1,2,nil,nil,true));for i=1,16 do context(c,'R'..i,10.1) end
 c:Tick(10.3,nil);eq(w.y[1],0);eq(w.y[2],0);eq(c.nextCastAt,11.2)
 assert(cast(c,'a','P',10.8,3,3));c:Tick(10.8,nil);eq(w.y[3],1);eq(w.y[2],0)
 assert(cast(c,'b','P',11.8,4,2));c:Tick(11.2,nil);eq(w.y[4],0);eq(c.nextCastAt,11.8)
 c:Tick(11.8,nil);eq(w.y[4],1);eq(c.nextCastAt,nil)
 return 'Retracted and retimed minima cannot starve a second pending event or revive obsolete content.'
end)

test('future_projection_guard_clears_all_model_outputs',function()
 local c=core(ns);context(c,'P',10)
 c.model={Predict=function()return {neural={.7,.7,.7,.7,.7,.7},linear={.6,.6,.6,.6,.6,.6},frequency={.2,.2,.2,.2,.2,.2}} end,positives={2,2,2,2,2,2},totals={10,10,10,10,10,10}}
 assert(cast(c,'a','P',10.5,1,1));c:Tick(10.5,true)
 local before=ns.Copy(c.actors.P.forecast);local f=c:Forecast('P',10.25)
 eq(f.reason,'future_projection');for _,o in ipairs(f.outputs)do eq(o.score,nil);eq(o.linear,nil);eq(o.frequency,nil);eq(o.status,'withheld') end
 deep(before,c.actors.P.forecast,'pure forecast');eq(c:Forecast('P',10.5).outputs[1].score,.7)
 return 'Earlier consumer requests cannot expose any cached score channel or mutate the current projection.'
end)

test('future_revision_after_evicted_row_withdraws_original_actor_guard',function()
 local c=core(ns);context(c,'P',10);c:Tick(10,true);local w=c.actors.P.window
 context(c,'P',10.1);assert(cast(c,'past','P',10.1,1,1));assert(cast(c,'future','Q',11,2,1))
 for i=1,16 do context(c,'R'..i,10.2) end;train(c);local serving=c.model
 for i=1,256 do c:_Resolve({actor='filler',anchor=0,deadline=2,regime='other',x=ns.Copy(w.x),coverage={},lost={}}) end
 eq(c.model,serving);assert(cast(c,'future','P',11,2,2));eq(c.model,nil)
 return 'A future actor reassignment still invalidates a dependent serving generation whose replay row was evicted.'
end)
return rows
