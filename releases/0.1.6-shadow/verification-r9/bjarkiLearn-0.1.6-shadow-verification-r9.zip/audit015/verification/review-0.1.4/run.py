import argparse, hashlib, importlib, json, sys
from pathlib import Path
p=argparse.ArgumentParser()
p.add_argument('--source',type=Path,required=True)
p.add_argument('--output',type=Path,required=True)
p.add_argument('--baseline',type=Path)
p.add_argument('--lupa-path',type=Path)
a=p.parse_args()
if a.lupa_path: sys.path.insert(0,str(a.lupa_path))
else:
    try: importlib.import_module('lupa')
    except ImportError: sys.path.insert(0,'C:/Users/Mewn/Documents/Codex/2026-10-16/let/work/deps')
root=Path(__file__).resolve().parent
baseline=a.baseline or root.parent/'baseline-0.1.3/source/bjarkiLearn'
def hashes(path):
    return {str(f.relative_to(path)):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(path.rglob('*')) if f.is_file()}
before=hashes(a.source); base_before=hashes(baseline); results=[]
for engine in ('lua51','lua54'):
    lua=importlib.import_module('lupa.'+engine).LuaRuntime(unpack_returned_tuples=True)
    def load(path):
        ns=lua.table()
        for f in ('Bootstrap.lua','Rules.lua','Network.lua','Core.lua','Adapter.lua'):
            lua.execute((path/f).read_text(encoding='utf-8'),'bjarkiLearn',ns)
        return ns
    ns=load(a.source); old=load(baseline)
    rows=lua.execute((root/'probes.lua').read_text(encoding='utf-8'),ns,old)
    for _,r in rows.items(): results.append({'engine':engine,**dict(r.items())})
report={'source':str(a.source.resolve()),'source_hashes':before,'source_unchanged':before==hashes(a.source),
        'baseline_hashes':base_before,'baseline_unchanged':base_before==hashes(baseline),
        'total':len(results),'passed':sum(r['passed'] for r in results),'cases':results}
a.output.parent.mkdir(parents=True,exist_ok=True)
a.output.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'total':report['total'],'passed':report['passed'],'source_unchanged':report['source_unchanged'],
                  'failures':[r for r in results if not r['passed']]},indent=2))
raise SystemExit(int(report['passed']!=report['total'] or not report['source_unchanged'] or not report['baseline_unchanged']))
