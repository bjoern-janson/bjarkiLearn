# Fresh whole-change review: bjarkiLearn 0.1.4

Decision: no material runtime findings. The source change is suitable for the coordinator's final offline release gates. This is not live-client validation or evidence of predictive usefulness.

Reviewed against baseline-0.1.3/source/bjarkiLearn, including design.txt, plan.txt, full Core.lua and Rules.lua diffs, native Adapter call ordering, and the added API/implementation documentation. Production files were not edited by this reviewer.

Independent probes: 12/12 executions pass under Lupa Lua 5.1 and 5.4. Source and baseline hashes remain unchanged during execution. Each engine includes:

- An 80-window differential against 0.1.3, using ordinary Context-before-Cast delivery, between-tick observations, retiming corrections, aura evidence, real neural/linear/frequency training, and session rollback. Exported examples, model dependency descriptors, forecasts and copied context match exactly.
- An external event ledger with 800 correction/clock steps, 67,620 row/head comparisons, and 1,602 as-of history projections. The ledger covers actor/family/time reassignment, uncertain intervals, retraction/restoration, retained capacity-retired windows, and Context/Tick clock advancement.
- Rejected context timestamps cannot mature a future label.
- Retracted and retimed earliest-due records cannot starve other pending events or resurrect superseded content.
- Queries before the forecast's own time clear all three score channels without changing the cached forecast.
- Future actor reassignment invalidates a dependent serving model after the original replay row has been evicted.

Static reasoning gates:

1. Input projection scans the existing accepted occurrence registry by as-of time. It retains earlier same-family exact evidence when a later distinct occurrence remains in the future, and does not mutate query authority. Future auras likewise cannot hide an earlier eligible distinct witness.
2. Cast timestamps do not advance outcome maturity. Accepted Context/Tick/Reset observations do. Positive labels require maxAt within both the window and observed frontier. A stale nextCastAt can cause an unnecessary bounded sweep, but the sweep consults the current retained revision rather than stale identity state.
3. Early actor retirement does not seal retained rows. Maturity and revisions can still affect those rows without a live actor binding. Serving dependency checks survive replay eviction, including for newly mature events.
4. Revisions in either time direction continue to use the single identity registry. latestEver and evidenceFloor retirement behavior are preserved. Unknown correction history remains conservative. No second identity queue/map, native API, timer or dependency was added.
5. Native Adapter:OnCast still binds at the event observation time before Core:Cast. This preserves legitimate between-tick events. Main.lua, Adapter.lua and Network.lua remain byte-identical to 0.1.3.
6. The existing caps remain 16 actors, 128 occurrences, 256 examples and 256 serving descriptors. Reconciliation is batched when a retained due time is reached, but nested bounded scans remain possible; no client-time performance claim is made.

Superseded legacy reset assertions are justified. Direct fixture inspection confirms three cases inject a raw future cast after the latest accepted observation and then roll back/reset: 65 after clock64, 49.5 after clock49, and 12.5 after clock12.25. Their old positive-label expectations assert the defect being corrected, so they are not preservation requirements. The original files should remain immutable. The coordinator's separate normalization wrapper adds an accepted Context at the cast time while retaining all original selected assertions; this preserves the meaningful already-observed-positive and candidate/replay controls. Superseded executions must remain reported separately rather than counted as passing.

The reviewer saw an old 0.1.2 verification-ZIP reference in README and reported it to the coordinator for the final documentation pass. That is a documentation gate, not a runtime finding.

Reproduce from the verification root:

    python review-0.1.4/run.py --source source/bjarkiLearn --output review-0.1.4/results.json

Optional --baseline PATH and --lupa-path PATH allow alternate extraction layouts. Results record full source and baseline inventories. review-gate.json binds this decision to exact runtime and TOC SHA-256 hashes. Final package/source byte equality, ZIP integrity, standalone rebuild and aggregate regression accounting remain coordinator gates; no live WoW behavior was observed.

