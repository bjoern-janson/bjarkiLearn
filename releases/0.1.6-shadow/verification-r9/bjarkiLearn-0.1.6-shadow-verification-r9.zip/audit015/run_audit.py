"""Rerun the independent audit, or validate and summarize its existing reports.
Requires Python 3.10+ and Lupa with lua51 and lua54. No addon edits.
"""
from pathlib import Path
import argparse, hashlib, json, os, subprocess, sys, time, zipfile
ROOT=Path(__file__).resolve().parent
SOURCE=ROOT/'source/bjarkiLearn'
BASE=ROOT/'verification/baseline-0.1.4/source/bjarkiLearn'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def hashes(p):return {f.relative_to(p).as_posix():sha(f) for f in sorted(p.rglob('*')) if f.is_file()}
def read(p):return json.loads((ROOT/p).read_text(encoding='utf-8-sig'))
def save(p,d):(ROOT/p).write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8')
def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--summarize',action='store_true',help='Validate existing reports without executing tests')
 p.add_argument('--skip-packaged',action='store_true',help='Reuse packaged reports, rerun the four independent suites')
 p.add_argument('--lupa-path',type=Path)
 a=p.parse_args();jobs=[]
 if not a.summarize:
  env=os.environ.copy()
  if a.lupa_path:env['PYTHONPATH']=str(a.lupa_path)+os.pathsep+env.get('PYTHONPATH','')
  tasks=[]
  if not a.skip_packaged:tasks.append(('packaged',ROOT/'verification',['run_all.py']))
  for name in ('core','native','network-restore','integration'):
   report='current.json' if name=='native' else 'results.json'
   command=[str(ROOT/'audit'/name/'run.py'),'--source',str(SOURCE),'--baseline',str(BASE),'--output',str(ROOT/'audit'/name/report)]
   if a.lupa_path and name!='integration':command+=['--lupa-path',str(a.lupa_path)]
   tasks.append((name,ROOT,command))
  for name,cwd,command in tasks:
   started=time.monotonic()
   result=subprocess.run([sys.executable,*command],cwd=cwd,env=env)
   jobs.append(dict(suite=name,exit_code=result.returncode,seconds=round(time.monotonic()-started,3)))
   if result.returncode:save('audit-rerun-jobs.json',jobs);raise SystemExit(result.returncode)
  save('audit-rerun-jobs.json',jobs)
 original=read('archive-checks.json');source=hashes(SOURCE);base=hashes(BASE)
 assert source==original['source_hashes']==hashes(ROOT/'verification/source/bjarkiLearn')
 baseline_zip=ROOT/'verification/baseline-0.1.4/bjarkiLearn-0.1.4-shadow.zip'
 assert sha(baseline_zip)=='3cf686e9b1e3fe78b8577c15c75e2e1ba08fc6142b4cf794b36ac9da048f461d'
 with zipfile.ZipFile(baseline_zip) as z:
  assert z.testzip() is None
  assert {n.removeprefix('bjarkiLearn/'):hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist() if not n.endswith('/')}==base
 before=read('verification-original-hashes.json')
 code={n:h for n,h in before.items() if Path(n).suffix in ('.py','.lua')}
 changed=[n for n,h in code.items() if sha(ROOT/'verification'/n)!=h]
 assert not changed,changed
 packaged=read('verification/reports-0.1.5/verification.json')
 assert packaged['passed'] and packaged['original_test_sources_unchanged']
 assert packaged['runtime_hashes']=={n:h for n,h in source.items() if n.endswith('.lua')}
 assert packaged['baseline_runtime_hashes']=={n:h for n,h in base.items() if n.endswith('.lua')}
 assert all(j['exit_code']==0 for j in packaged['runs'])
 core=read('audit/core/results.json')
 assert core['total']==core['passed'] and all(x['passed'] for x in core['cases'])
 assert core['source_hashes']==source and core['baseline_hashes']==base
 assert core['source_unchanged'] and core['baseline_unchanged']
 native=read('audit/native/current.json')
 assert native['summary']['total']==native['summary']['passed'] and all(x['passed'] for x in native['cases'])
 assert all(x['public_projection_equal'] and x['trace_equal'] for x in native['comparisons'])
 for name,expected in [('current',source),('baseline',base)]:
  tree=native['source_trees'][name];assert tree['unchanged'] and tree['before']==tree['after']==expected
 network=read('audit/network-restore/results.json')
 assert network['source_unchanged'] and network['source_hashes_before']==network['source_hashes_after']==dict(current=source,baseline=base)
 assert network['scenario_total']==network['scenario_passed'] and all(x['passed'] for x in network['results']+network['comparisons'])
 integration=read('audit/integration/results.json')
 assert integration['passed'] and integration['source_unchanged'] and integration['source_hashes']==source and integration['baseline_hashes']==base
 assert integration['passes']==integration['total'] and all(x['passed'] for x in integration['comparisons'])
 # Recheck manifest metadata and load order against the archived source itself.
 modules=['Bootstrap.lua','Rules.lua','Network.lua','Core.lua','Adapter.lua','Main.lua']
 for name in ('bjarkiLearn.toc','bjarkiLearn_Camelot.toc'):
  text=(SOURCE/name).read_text()
  assert text.count('## Version: 0.1.5-shadow')==1 and '## Interface: 16001' in text
  assert '## SavedVariables: bjarkiLearnDB' in text
  assert [line.strip() for line in text.splitlines() if line.strip() and not line.startswith('#')]==modules
 assert len(source)==14 and all((SOURCE/name).is_file() for name in modules)
 assert 'version = "0.1.5-shadow"' in (SOURCE/'Bootstrap.lua').read_text()
 rebuild=read('package-rebuild/bjarkiLearn-0.1.5-shadow-release-checks.json') if (ROOT/'package-rebuild/bjarkiLearn-0.1.5-shadow-release-checks.json').exists() else None
 if rebuild:assert rebuild['passed'] and rebuild['addon']['sha256']==original['addon']['sha256']
 focused=[x for x in core['cases'] if x['source_version']!='0.1.5_vs_0.1.4']
 differential=[x for x in core['cases'] if x['source_version']=='0.1.5_vs_0.1.4']
 summary=dict(passed=True,confirmed_findings=0,
  conclusion='No confirmed remaining bug or 0.1.5 regression found in this bounded source and offline-execution audit.',
  tests_executed_by_this_invocation=not a.summarize,jobs=jobs,
  addon=original['addon'],original_verification_archive=original['verification'],source_hashes=source,baseline_hashes=base,
  source_unchanged=True,install_and_verification_source_identical=True,
  original_verification_lua_python_files_checked=len(code),original_verification_lua_python_files_unchanged=True,
  archive_rebuild_byte_identical=bool(rebuild),toc_inventory_versions_valid=True,
  packaged=packaged,
  independent=dict(
   core=dict(focused_executions=len(focused),focused_passed=sum(x['passed'] for x in focused),differential_traces=len(differential),differential_passed=sum(x['passed'] for x in differential),transitions=sum(x.get('comparisons',0) for x in differential),full_state_comparisons=sum(x.get('fullStateComparisons',0) for x in differential)),
   native=dict(**native['summary'],public_projection_comparisons=len(native['comparisons'])),
   network_restore=dict(executions=network['scenario_total'],passed=network['scenario_passed'],assertions=network['assertions'],exact_state_comparisons=len(network['comparisons']),seed_oracles=network['seed_oracles']),
   integration=dict(exact_comparisons=integration['total'],passed=integration['passes'],checks=sum(x['checks'] for x in integration['runs']),native_traces=len(integration['runs']),full_snapshots=sum(x['snapshots'] for x in integration['runs']))),
  independent_test_hashes={f.relative_to(ROOT).as_posix():sha(f) for f in sorted((ROOT/'audit').rglob('*')) if f.is_file() and f.suffix in ('.lua','.py')},
  limits=['Ordinary Lua 5.1 and Lua 5.4 with modeled WoW APIs; no live-client verification.',
   'Finite scenario and trace equality is not exhaustive equivalence or proof of no bugs.',
   'No measured live frame-time, predictive usefulness, calibration, taint or secret-value enforcement claim.',
   'Bounded retained evidence cannot recover discarded identities or raw correction authority for sealed imported rows.'])
 save('audit-summary.json',summary)
 print(json.dumps({k:summary[k] for k in ('passed','confirmed_findings','source_unchanged','archive_rebuild_byte_identical','original_verification_lua_python_files_checked','independent')},indent=2))
if __name__=='__main__':main()
