"""Compatibility entry point; all packaging uses current acceptance gates."""

from build_verification_r6 import *


if __name__ == '__main__':
    raise SystemExit(main())
