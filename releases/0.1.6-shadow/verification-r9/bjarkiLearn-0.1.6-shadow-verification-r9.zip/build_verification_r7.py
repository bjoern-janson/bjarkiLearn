"""Compatibility entry point; all packaging uses revision-8 acceptance gates."""

from build_verification_r8 import *


if __name__ == "__main__":
    raise SystemExit(main())
