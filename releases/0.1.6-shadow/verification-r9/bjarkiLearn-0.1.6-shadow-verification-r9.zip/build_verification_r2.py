"""Compatibility entry point; all packaging uses revision-4 acceptance gates."""

from build_verification_r4 import main


if __name__ == '__main__':
    raise SystemExit(main())
