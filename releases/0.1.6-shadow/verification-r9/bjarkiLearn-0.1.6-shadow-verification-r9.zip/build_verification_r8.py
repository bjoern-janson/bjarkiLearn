"""Run the canonical revision-9 builder in this compatibility namespace.

Keeping an independent namespace preserves callers that load this former builder
as an isolated module, including the unchanged revision-8 platform model tests.
The implementation is read from the same sealed revision-9 source, never copied.
"""
from pathlib import Path as _Path

_implementation = _Path(__file__).with_name('build_verification_r9.py')
exec(compile(_implementation.read_bytes(), str(_implementation), 'exec'), globals())
